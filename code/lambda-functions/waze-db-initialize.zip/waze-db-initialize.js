(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/waze-db-initialize.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/balanced-match/index.js":
/*!**********************************************!*\
  !*** ./node_modules/balanced-match/index.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = balanced;
function balanced(a, b, str) {
  if (a instanceof RegExp) a = maybeMatch(a, str);
  if (b instanceof RegExp) b = maybeMatch(b, str);

  var r = range(a, b, str);

  return r && {
    start: r[0],
    end: r[1],
    pre: str.slice(0, r[0]),
    body: str.slice(r[0] + a.length, r[1]),
    post: str.slice(r[1] + b.length)
  };
}

function maybeMatch(reg, str) {
  var m = str.match(reg);
  return m ? m[0] : null;
}

balanced.range = range;
function range(a, b, str) {
  var begs, beg, left, right, result;
  var ai = str.indexOf(a);
  var bi = str.indexOf(b, ai + 1);
  var i = ai;

  if (ai >= 0 && bi > 0) {
    begs = [];
    left = str.length;

    while (i >= 0 && !result) {
      if (i == ai) {
        begs.push(i);
        ai = str.indexOf(a, i + 1);
      } else if (begs.length == 1) {
        result = [ begs.pop(), bi ];
      } else {
        beg = begs.pop();
        if (beg < left) {
          left = beg;
          right = bi;
        }

        bi = str.indexOf(b, i + 1);
      }

      i = ai < bi && ai >= 0 ? ai : bi;
    }

    if (begs.length) {
      result = [ left, right ];
    }
  }

  return result;
}


/***/ }),

/***/ "./node_modules/brace-expansion/index.js":
/*!***********************************************!*\
  !*** ./node_modules/brace-expansion/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var concatMap = __webpack_require__(/*! concat-map */ "./node_modules/concat-map/index.js");
var balanced = __webpack_require__(/*! balanced-match */ "./node_modules/balanced-match/index.js");

module.exports = expandTop;

var escSlash = '\0SLASH'+Math.random()+'\0';
var escOpen = '\0OPEN'+Math.random()+'\0';
var escClose = '\0CLOSE'+Math.random()+'\0';
var escComma = '\0COMMA'+Math.random()+'\0';
var escPeriod = '\0PERIOD'+Math.random()+'\0';

function numeric(str) {
  return parseInt(str, 10) == str
    ? parseInt(str, 10)
    : str.charCodeAt(0);
}

function escapeBraces(str) {
  return str.split('\\\\').join(escSlash)
            .split('\\{').join(escOpen)
            .split('\\}').join(escClose)
            .split('\\,').join(escComma)
            .split('\\.').join(escPeriod);
}

function unescapeBraces(str) {
  return str.split(escSlash).join('\\')
            .split(escOpen).join('{')
            .split(escClose).join('}')
            .split(escComma).join(',')
            .split(escPeriod).join('.');
}


// Basically just str.split(","), but handling cases
// where we have nested braced sections, which should be
// treated as individual members, like {a,{b,c},d}
function parseCommaParts(str) {
  if (!str)
    return [''];

  var parts = [];
  var m = balanced('{', '}', str);

  if (!m)
    return str.split(',');

  var pre = m.pre;
  var body = m.body;
  var post = m.post;
  var p = pre.split(',');

  p[p.length-1] += '{' + body + '}';
  var postParts = parseCommaParts(post);
  if (post.length) {
    p[p.length-1] += postParts.shift();
    p.push.apply(p, postParts);
  }

  parts.push.apply(parts, p);

  return parts;
}

function expandTop(str) {
  if (!str)
    return [];

  // I don't know why Bash 4.3 does this, but it does.
  // Anything starting with {} will have the first two bytes preserved
  // but *only* at the top level, so {},a}b will not expand to anything,
  // but a{},b}c will be expanded to [a}c,abc].
  // One could argue that this is a bug in Bash, but since the goal of
  // this module is to match Bash's rules, we escape a leading {}
  if (str.substr(0, 2) === '{}') {
    str = '\\{\\}' + str.substr(2);
  }

  return expand(escapeBraces(str), true).map(unescapeBraces);
}

function identity(e) {
  return e;
}

function embrace(str) {
  return '{' + str + '}';
}
function isPadded(el) {
  return /^-?0\d/.test(el);
}

function lte(i, y) {
  return i <= y;
}
function gte(i, y) {
  return i >= y;
}

function expand(str, isTop) {
  var expansions = [];

  var m = balanced('{', '}', str);
  if (!m || /\$$/.test(m.pre)) return [str];

  var isNumericSequence = /^-?\d+\.\.-?\d+(?:\.\.-?\d+)?$/.test(m.body);
  var isAlphaSequence = /^[a-zA-Z]\.\.[a-zA-Z](?:\.\.-?\d+)?$/.test(m.body);
  var isSequence = isNumericSequence || isAlphaSequence;
  var isOptions = m.body.indexOf(',') >= 0;
  if (!isSequence && !isOptions) {
    // {a},b}
    if (m.post.match(/,.*\}/)) {
      str = m.pre + '{' + m.body + escClose + m.post;
      return expand(str);
    }
    return [str];
  }

  var n;
  if (isSequence) {
    n = m.body.split(/\.\./);
  } else {
    n = parseCommaParts(m.body);
    if (n.length === 1) {
      // x{{a,b}}y ==> x{a}y x{b}y
      n = expand(n[0], false).map(embrace);
      if (n.length === 1) {
        var post = m.post.length
          ? expand(m.post, false)
          : [''];
        return post.map(function(p) {
          return m.pre + n[0] + p;
        });
      }
    }
  }

  // at this point, n is the parts, and we know it's not a comma set
  // with a single entry.

  // no need to expand pre, since it is guaranteed to be free of brace-sets
  var pre = m.pre;
  var post = m.post.length
    ? expand(m.post, false)
    : [''];

  var N;

  if (isSequence) {
    var x = numeric(n[0]);
    var y = numeric(n[1]);
    var width = Math.max(n[0].length, n[1].length)
    var incr = n.length == 3
      ? Math.abs(numeric(n[2]))
      : 1;
    var test = lte;
    var reverse = y < x;
    if (reverse) {
      incr *= -1;
      test = gte;
    }
    var pad = n.some(isPadded);

    N = [];

    for (var i = x; test(i, y); i += incr) {
      var c;
      if (isAlphaSequence) {
        c = String.fromCharCode(i);
        if (c === '\\')
          c = '';
      } else {
        c = String(i);
        if (pad) {
          var need = width - c.length;
          if (need > 0) {
            var z = new Array(need + 1).join('0');
            if (i < 0)
              c = '-' + z + c.slice(1);
            else
              c = z + c;
          }
        }
      }
      N.push(c);
    }
  } else {
    N = concatMap(n, function(el) { return expand(el, false) });
  }

  for (var j = 0; j < N.length; j++) {
    for (var k = 0; k < post.length; k++) {
      var expansion = pre + N[j] + post[k];
      if (!isTop || isSequence || expansion)
        expansions.push(expansion);
    }
  }

  return expansions;
}



/***/ }),

/***/ "./node_modules/buffer-writer/index.js":
/*!*********************************************!*\
  !*** ./node_modules/buffer-writer/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

//binary data writer tuned for creating
//postgres message packets as effeciently as possible by reusing the
//same buffer to avoid memcpy and limit memory allocations
var Writer = module.exports = function(size) {
  this.size = size || 1024;
  this.buffer = Buffer(this.size + 5);
  this.offset = 5;
  this.headerPosition = 0;
};

//resizes internal buffer if not enough size left
Writer.prototype._ensure = function(size) {
  var remaining = this.buffer.length - this.offset;
  if(remaining < size) {
    var oldBuffer = this.buffer;
    // exponential growth factor of around ~ 1.5
    // https://stackoverflow.com/questions/2269063/buffer-growth-strategy
    var newSize = oldBuffer.length + (oldBuffer.length >> 1) + size;
    this.buffer = new Buffer(newSize);
    oldBuffer.copy(this.buffer);
  }
};

Writer.prototype.addInt32 = function(num) {
  this._ensure(4);
  this.buffer[this.offset++] = (num >>> 24 & 0xFF);
  this.buffer[this.offset++] = (num >>> 16 & 0xFF);
  this.buffer[this.offset++] = (num >>>  8 & 0xFF);
  this.buffer[this.offset++] = (num >>>  0 & 0xFF);
  return this;
};

Writer.prototype.addInt16 = function(num) {
  this._ensure(2);
  this.buffer[this.offset++] = (num >>>  8 & 0xFF);
  this.buffer[this.offset++] = (num >>>  0 & 0xFF);
  return this;
};

//for versions of node requiring 'length' as 3rd argument to buffer.write
var writeString = function(buffer, string, offset, len) {
  buffer.write(string, offset, len);
};

//overwrite function for older versions of node
if(Buffer.prototype.write.length === 3) {
  writeString = function(buffer, string, offset, len) {
    buffer.write(string, offset);
  };
}

Writer.prototype.addCString = function(string) {
  //just write a 0 for empty or null strings
  if(!string) {
    this._ensure(1);
  } else {
    var len = Buffer.byteLength(string);
    this._ensure(len + 1); //+1 for null terminator
    writeString(this.buffer, string, this.offset, len);
    this.offset += len;
  }

  this.buffer[this.offset++] = 0; // null terminator
  return this;
};

Writer.prototype.addChar = function(c) {
  this._ensure(1);
  writeString(this.buffer, c, this.offset, 1);
  this.offset++;
  return this;
};

Writer.prototype.addString = function(string) {
  string = string || "";
  var len = Buffer.byteLength(string);
  this._ensure(len);
  this.buffer.write(string, this.offset);
  this.offset += len;
  return this;
};

Writer.prototype.getByteLength = function() {
  return this.offset - 5;
};

Writer.prototype.add = function(otherBuffer) {
  this._ensure(otherBuffer.length);
  otherBuffer.copy(this.buffer, this.offset);
  this.offset += otherBuffer.length;
  return this;
};

Writer.prototype.clear = function() {
  this.offset = 5;
  this.headerPosition = 0;
  this.lastEnd = 0;
};

//appends a header block to all the written data since the last
//subsequent header or to the beginning if there is only one data block
Writer.prototype.addHeader = function(code, last) {
  var origOffset = this.offset;
  this.offset = this.headerPosition;
  this.buffer[this.offset++] = code;
  //length is everything in this packet minus the code
  this.addInt32(origOffset - (this.headerPosition+1));
  //set next header position
  this.headerPosition = origOffset;
  //make space for next header
  this.offset = origOffset;
  if(!last) {
    this._ensure(5);
    this.offset += 5;
  }
};

Writer.prototype.join = function(code) {
  if(code) {
    this.addHeader(code, true);
  }
  return this.buffer.slice(code ? 0 : 5, this.offset);
};

Writer.prototype.flush = function(code) {
  var result = this.join(code);
  this.clear();
  return result;
};


/***/ }),

/***/ "./node_modules/concat-map/index.js":
/*!******************************************!*\
  !*** ./node_modules/concat-map/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (xs, fn) {
    var res = [];
    for (var i = 0; i < xs.length; i++) {
        var x = fn(xs[i], i);
        if (isArray(x)) res.push.apply(res, x);
        else res.push(x);
    }
    return res;
};

var isArray = Array.isArray || function (xs) {
    return Object.prototype.toString.call(xs) === '[object Array]';
};


/***/ }),

/***/ "./node_modules/fs.realpath/index.js":
/*!*******************************************!*\
  !*** ./node_modules/fs.realpath/index.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = realpath
realpath.realpath = realpath
realpath.sync = realpathSync
realpath.realpathSync = realpathSync
realpath.monkeypatch = monkeypatch
realpath.unmonkeypatch = unmonkeypatch

var fs = __webpack_require__(/*! fs */ "fs")
var origRealpath = fs.realpath
var origRealpathSync = fs.realpathSync

var version = process.version
var ok = /^v[0-5]\./.test(version)
var old = __webpack_require__(/*! ./old.js */ "./node_modules/fs.realpath/old.js")

function newError (er) {
  return er && er.syscall === 'realpath' && (
    er.code === 'ELOOP' ||
    er.code === 'ENOMEM' ||
    er.code === 'ENAMETOOLONG'
  )
}

function realpath (p, cache, cb) {
  if (ok) {
    return origRealpath(p, cache, cb)
  }

  if (typeof cache === 'function') {
    cb = cache
    cache = null
  }
  origRealpath(p, cache, function (er, result) {
    if (newError(er)) {
      old.realpath(p, cache, cb)
    } else {
      cb(er, result)
    }
  })
}

function realpathSync (p, cache) {
  if (ok) {
    return origRealpathSync(p, cache)
  }

  try {
    return origRealpathSync(p, cache)
  } catch (er) {
    if (newError(er)) {
      return old.realpathSync(p, cache)
    } else {
      throw er
    }
  }
}

function monkeypatch () {
  fs.realpath = realpath
  fs.realpathSync = realpathSync
}

function unmonkeypatch () {
  fs.realpath = origRealpath
  fs.realpathSync = origRealpathSync
}


/***/ }),

/***/ "./node_modules/fs.realpath/old.js":
/*!*****************************************!*\
  !*** ./node_modules/fs.realpath/old.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var pathModule = __webpack_require__(/*! path */ "path");
var isWindows = process.platform === 'win32';
var fs = __webpack_require__(/*! fs */ "fs");

// JavaScript implementation of realpath, ported from node pre-v6

var DEBUG = process.env.NODE_DEBUG && /fs/.test(process.env.NODE_DEBUG);

function rethrow() {
  // Only enable in debug mode. A backtrace uses ~1000 bytes of heap space and
  // is fairly slow to generate.
  var callback;
  if (DEBUG) {
    var backtrace = new Error;
    callback = debugCallback;
  } else
    callback = missingCallback;

  return callback;

  function debugCallback(err) {
    if (err) {
      backtrace.message = err.message;
      err = backtrace;
      missingCallback(err);
    }
  }

  function missingCallback(err) {
    if (err) {
      if (process.throwDeprecation)
        throw err;  // Forgot a callback but don't know where? Use NODE_DEBUG=fs
      else if (!process.noDeprecation) {
        var msg = 'fs: missing callback ' + (err.stack || err.message);
        if (process.traceDeprecation)
          console.trace(msg);
        else
          console.error(msg);
      }
    }
  }
}

function maybeCallback(cb) {
  return typeof cb === 'function' ? cb : rethrow();
}

var normalize = pathModule.normalize;

// Regexp that finds the next partion of a (partial) path
// result is [base_with_slash, base], e.g. ['somedir/', 'somedir']
if (isWindows) {
  var nextPartRe = /(.*?)(?:[\/\\]+|$)/g;
} else {
  var nextPartRe = /(.*?)(?:[\/]+|$)/g;
}

// Regex to find the device root, including trailing slash. E.g. 'c:\\'.
if (isWindows) {
  var splitRootRe = /^(?:[a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/][^\\\/]+)?[\\\/]*/;
} else {
  var splitRootRe = /^[\/]*/;
}

exports.realpathSync = function realpathSync(p, cache) {
  // make p is absolute
  p = pathModule.resolve(p);

  if (cache && Object.prototype.hasOwnProperty.call(cache, p)) {
    return cache[p];
  }

  var original = p,
      seenLinks = {},
      knownHard = {};

  // current character position in p
  var pos;
  // the partial path so far, including a trailing slash if any
  var current;
  // the partial path without a trailing slash (except when pointing at a root)
  var base;
  // the partial path scanned in the previous round, with slash
  var previous;

  start();

  function start() {
    // Skip over roots
    var m = splitRootRe.exec(p);
    pos = m[0].length;
    current = m[0];
    base = m[0];
    previous = '';

    // On windows, check that the root exists. On unix there is no need.
    if (isWindows && !knownHard[base]) {
      fs.lstatSync(base);
      knownHard[base] = true;
    }
  }

  // walk down the path, swapping out linked pathparts for their real
  // values
  // NB: p.length changes.
  while (pos < p.length) {
    // find the next part
    nextPartRe.lastIndex = pos;
    var result = nextPartRe.exec(p);
    previous = current;
    current += result[0];
    base = previous + result[1];
    pos = nextPartRe.lastIndex;

    // continue if not a symlink
    if (knownHard[base] || (cache && cache[base] === base)) {
      continue;
    }

    var resolvedLink;
    if (cache && Object.prototype.hasOwnProperty.call(cache, base)) {
      // some known symbolic link.  no need to stat again.
      resolvedLink = cache[base];
    } else {
      var stat = fs.lstatSync(base);
      if (!stat.isSymbolicLink()) {
        knownHard[base] = true;
        if (cache) cache[base] = base;
        continue;
      }

      // read the link if it wasn't read before
      // dev/ino always return 0 on windows, so skip the check.
      var linkTarget = null;
      if (!isWindows) {
        var id = stat.dev.toString(32) + ':' + stat.ino.toString(32);
        if (seenLinks.hasOwnProperty(id)) {
          linkTarget = seenLinks[id];
        }
      }
      if (linkTarget === null) {
        fs.statSync(base);
        linkTarget = fs.readlinkSync(base);
      }
      resolvedLink = pathModule.resolve(previous, linkTarget);
      // track this, if given a cache.
      if (cache) cache[base] = resolvedLink;
      if (!isWindows) seenLinks[id] = linkTarget;
    }

    // resolve the link, then start over
    p = pathModule.resolve(resolvedLink, p.slice(pos));
    start();
  }

  if (cache) cache[original] = p;

  return p;
};


exports.realpath = function realpath(p, cache, cb) {
  if (typeof cb !== 'function') {
    cb = maybeCallback(cache);
    cache = null;
  }

  // make p is absolute
  p = pathModule.resolve(p);

  if (cache && Object.prototype.hasOwnProperty.call(cache, p)) {
    return process.nextTick(cb.bind(null, null, cache[p]));
  }

  var original = p,
      seenLinks = {},
      knownHard = {};

  // current character position in p
  var pos;
  // the partial path so far, including a trailing slash if any
  var current;
  // the partial path without a trailing slash (except when pointing at a root)
  var base;
  // the partial path scanned in the previous round, with slash
  var previous;

  start();

  function start() {
    // Skip over roots
    var m = splitRootRe.exec(p);
    pos = m[0].length;
    current = m[0];
    base = m[0];
    previous = '';

    // On windows, check that the root exists. On unix there is no need.
    if (isWindows && !knownHard[base]) {
      fs.lstat(base, function(err) {
        if (err) return cb(err);
        knownHard[base] = true;
        LOOP();
      });
    } else {
      process.nextTick(LOOP);
    }
  }

  // walk down the path, swapping out linked pathparts for their real
  // values
  function LOOP() {
    // stop if scanned past end of path
    if (pos >= p.length) {
      if (cache) cache[original] = p;
      return cb(null, p);
    }

    // find the next part
    nextPartRe.lastIndex = pos;
    var result = nextPartRe.exec(p);
    previous = current;
    current += result[0];
    base = previous + result[1];
    pos = nextPartRe.lastIndex;

    // continue if not a symlink
    if (knownHard[base] || (cache && cache[base] === base)) {
      return process.nextTick(LOOP);
    }

    if (cache && Object.prototype.hasOwnProperty.call(cache, base)) {
      // known symbolic link.  no need to stat again.
      return gotResolvedLink(cache[base]);
    }

    return fs.lstat(base, gotStat);
  }

  function gotStat(err, stat) {
    if (err) return cb(err);

    // if not a symlink, skip to the next path part
    if (!stat.isSymbolicLink()) {
      knownHard[base] = true;
      if (cache) cache[base] = base;
      return process.nextTick(LOOP);
    }

    // stat & read the link if not read before
    // call gotTarget as soon as the link target is known
    // dev/ino always return 0 on windows, so skip the check.
    if (!isWindows) {
      var id = stat.dev.toString(32) + ':' + stat.ino.toString(32);
      if (seenLinks.hasOwnProperty(id)) {
        return gotTarget(null, seenLinks[id], base);
      }
    }
    fs.stat(base, function(err) {
      if (err) return cb(err);

      fs.readlink(base, function(err, target) {
        if (!isWindows) seenLinks[id] = target;
        gotTarget(err, target);
      });
    });
  }

  function gotTarget(err, target, base) {
    if (err) return cb(err);

    var resolvedLink = pathModule.resolve(previous, target);
    if (cache) cache[base] = resolvedLink;
    gotResolvedLink(resolvedLink);
  }

  function gotResolvedLink(resolvedLink) {
    // resolve the link, then start over
    p = pathModule.resolve(resolvedLink, p.slice(pos));
    start();
  }
};


/***/ }),

/***/ "./node_modules/glob/common.js":
/*!*************************************!*\
  !*** ./node_modules/glob/common.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports.alphasort = alphasort
exports.alphasorti = alphasorti
exports.setopts = setopts
exports.ownProp = ownProp
exports.makeAbs = makeAbs
exports.finish = finish
exports.mark = mark
exports.isIgnored = isIgnored
exports.childrenIgnored = childrenIgnored

function ownProp (obj, field) {
  return Object.prototype.hasOwnProperty.call(obj, field)
}

var path = __webpack_require__(/*! path */ "path")
var minimatch = __webpack_require__(/*! minimatch */ "./node_modules/minimatch/minimatch.js")
var isAbsolute = __webpack_require__(/*! path-is-absolute */ "./node_modules/path-is-absolute/index.js")
var Minimatch = minimatch.Minimatch

function alphasorti (a, b) {
  return a.toLowerCase().localeCompare(b.toLowerCase())
}

function alphasort (a, b) {
  return a.localeCompare(b)
}

function setupIgnores (self, options) {
  self.ignore = options.ignore || []

  if (!Array.isArray(self.ignore))
    self.ignore = [self.ignore]

  if (self.ignore.length) {
    self.ignore = self.ignore.map(ignoreMap)
  }
}

// ignore patterns are always in dot:true mode.
function ignoreMap (pattern) {
  var gmatcher = null
  if (pattern.slice(-3) === '/**') {
    var gpattern = pattern.replace(/(\/\*\*)+$/, '')
    gmatcher = new Minimatch(gpattern, { dot: true })
  }

  return {
    matcher: new Minimatch(pattern, { dot: true }),
    gmatcher: gmatcher
  }
}

function setopts (self, pattern, options) {
  if (!options)
    options = {}

  // base-matching: just use globstar for that.
  if (options.matchBase && -1 === pattern.indexOf("/")) {
    if (options.noglobstar) {
      throw new Error("base matching requires globstar")
    }
    pattern = "**/" + pattern
  }

  self.silent = !!options.silent
  self.pattern = pattern
  self.strict = options.strict !== false
  self.realpath = !!options.realpath
  self.realpathCache = options.realpathCache || Object.create(null)
  self.follow = !!options.follow
  self.dot = !!options.dot
  self.mark = !!options.mark
  self.nodir = !!options.nodir
  if (self.nodir)
    self.mark = true
  self.sync = !!options.sync
  self.nounique = !!options.nounique
  self.nonull = !!options.nonull
  self.nosort = !!options.nosort
  self.nocase = !!options.nocase
  self.stat = !!options.stat
  self.noprocess = !!options.noprocess
  self.absolute = !!options.absolute

  self.maxLength = options.maxLength || Infinity
  self.cache = options.cache || Object.create(null)
  self.statCache = options.statCache || Object.create(null)
  self.symlinks = options.symlinks || Object.create(null)

  setupIgnores(self, options)

  self.changedCwd = false
  var cwd = process.cwd()
  if (!ownProp(options, "cwd"))
    self.cwd = cwd
  else {
    self.cwd = path.resolve(options.cwd)
    self.changedCwd = self.cwd !== cwd
  }

  self.root = options.root || path.resolve(self.cwd, "/")
  self.root = path.resolve(self.root)
  if (process.platform === "win32")
    self.root = self.root.replace(/\\/g, "/")

  // TODO: is an absolute `cwd` supposed to be resolved against `root`?
  // e.g. { cwd: '/test', root: __dirname } === path.join(__dirname, '/test')
  self.cwdAbs = isAbsolute(self.cwd) ? self.cwd : makeAbs(self, self.cwd)
  if (process.platform === "win32")
    self.cwdAbs = self.cwdAbs.replace(/\\/g, "/")
  self.nomount = !!options.nomount

  // disable comments and negation in Minimatch.
  // Note that they are not supported in Glob itself anyway.
  options.nonegate = true
  options.nocomment = true

  self.minimatch = new Minimatch(pattern, options)
  self.options = self.minimatch.options
}

function finish (self) {
  var nou = self.nounique
  var all = nou ? [] : Object.create(null)

  for (var i = 0, l = self.matches.length; i < l; i ++) {
    var matches = self.matches[i]
    if (!matches || Object.keys(matches).length === 0) {
      if (self.nonull) {
        // do like the shell, and spit out the literal glob
        var literal = self.minimatch.globSet[i]
        if (nou)
          all.push(literal)
        else
          all[literal] = true
      }
    } else {
      // had matches
      var m = Object.keys(matches)
      if (nou)
        all.push.apply(all, m)
      else
        m.forEach(function (m) {
          all[m] = true
        })
    }
  }

  if (!nou)
    all = Object.keys(all)

  if (!self.nosort)
    all = all.sort(self.nocase ? alphasorti : alphasort)

  // at *some* point we statted all of these
  if (self.mark) {
    for (var i = 0; i < all.length; i++) {
      all[i] = self._mark(all[i])
    }
    if (self.nodir) {
      all = all.filter(function (e) {
        var notDir = !(/\/$/.test(e))
        var c = self.cache[e] || self.cache[makeAbs(self, e)]
        if (notDir && c)
          notDir = c !== 'DIR' && !Array.isArray(c)
        return notDir
      })
    }
  }

  if (self.ignore.length)
    all = all.filter(function(m) {
      return !isIgnored(self, m)
    })

  self.found = all
}

function mark (self, p) {
  var abs = makeAbs(self, p)
  var c = self.cache[abs]
  var m = p
  if (c) {
    var isDir = c === 'DIR' || Array.isArray(c)
    var slash = p.slice(-1) === '/'

    if (isDir && !slash)
      m += '/'
    else if (!isDir && slash)
      m = m.slice(0, -1)

    if (m !== p) {
      var mabs = makeAbs(self, m)
      self.statCache[mabs] = self.statCache[abs]
      self.cache[mabs] = self.cache[abs]
    }
  }

  return m
}

// lotta situps...
function makeAbs (self, f) {
  var abs = f
  if (f.charAt(0) === '/') {
    abs = path.join(self.root, f)
  } else if (isAbsolute(f) || f === '') {
    abs = f
  } else if (self.changedCwd) {
    abs = path.resolve(self.cwd, f)
  } else {
    abs = path.resolve(f)
  }

  if (process.platform === 'win32')
    abs = abs.replace(/\\/g, '/')

  return abs
}


// Return true, if pattern ends with globstar '**', for the accompanying parent directory.
// Ex:- If node_modules/** is the pattern, add 'node_modules' to ignore list along with it's contents
function isIgnored (self, path) {
  if (!self.ignore.length)
    return false

  return self.ignore.some(function(item) {
    return item.matcher.match(path) || !!(item.gmatcher && item.gmatcher.match(path))
  })
}

function childrenIgnored (self, path) {
  if (!self.ignore.length)
    return false

  return self.ignore.some(function(item) {
    return !!(item.gmatcher && item.gmatcher.match(path))
  })
}


/***/ }),

/***/ "./node_modules/glob/glob.js":
/*!***********************************!*\
  !*** ./node_modules/glob/glob.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Approach:
//
// 1. Get the minimatch set
// 2. For each pattern in the set, PROCESS(pattern, false)
// 3. Store matches per-set, then uniq them
//
// PROCESS(pattern, inGlobStar)
// Get the first [n] items from pattern that are all strings
// Join these together.  This is PREFIX.
//   If there is no more remaining, then stat(PREFIX) and
//   add to matches if it succeeds.  END.
//
// If inGlobStar and PREFIX is symlink and points to dir
//   set ENTRIES = []
// else readdir(PREFIX) as ENTRIES
//   If fail, END
//
// with ENTRIES
//   If pattern[n] is GLOBSTAR
//     // handle the case where the globstar match is empty
//     // by pruning it out, and testing the resulting pattern
//     PROCESS(pattern[0..n] + pattern[n+1 .. $], false)
//     // handle other cases.
//     for ENTRY in ENTRIES (not dotfiles)
//       // attach globstar + tail onto the entry
//       // Mark that this entry is a globstar match
//       PROCESS(pattern[0..n] + ENTRY + pattern[n .. $], true)
//
//   else // not globstar
//     for ENTRY in ENTRIES (not dotfiles, unless pattern[n] is dot)
//       Test ENTRY against pattern[n]
//       If fails, continue
//       If passes, PROCESS(pattern[0..n] + item + pattern[n+1 .. $])
//
// Caveat:
//   Cache all stats and readdirs results to minimize syscall.  Since all
//   we ever care about is existence and directory-ness, we can just keep
//   `true` for files, and [children,...] for directories, or `false` for
//   things that don't exist.

module.exports = glob

var fs = __webpack_require__(/*! fs */ "fs")
var rp = __webpack_require__(/*! fs.realpath */ "./node_modules/fs.realpath/index.js")
var minimatch = __webpack_require__(/*! minimatch */ "./node_modules/minimatch/minimatch.js")
var Minimatch = minimatch.Minimatch
var inherits = __webpack_require__(/*! inherits */ "./node_modules/inherits/inherits.js")
var EE = __webpack_require__(/*! events */ "events").EventEmitter
var path = __webpack_require__(/*! path */ "path")
var assert = __webpack_require__(/*! assert */ "assert")
var isAbsolute = __webpack_require__(/*! path-is-absolute */ "./node_modules/path-is-absolute/index.js")
var globSync = __webpack_require__(/*! ./sync.js */ "./node_modules/glob/sync.js")
var common = __webpack_require__(/*! ./common.js */ "./node_modules/glob/common.js")
var alphasort = common.alphasort
var alphasorti = common.alphasorti
var setopts = common.setopts
var ownProp = common.ownProp
var inflight = __webpack_require__(/*! inflight */ "./node_modules/inflight/inflight.js")
var util = __webpack_require__(/*! util */ "util")
var childrenIgnored = common.childrenIgnored
var isIgnored = common.isIgnored

var once = __webpack_require__(/*! once */ "./node_modules/once/once.js")

function glob (pattern, options, cb) {
  if (typeof options === 'function') cb = options, options = {}
  if (!options) options = {}

  if (options.sync) {
    if (cb)
      throw new TypeError('callback provided to sync glob')
    return globSync(pattern, options)
  }

  return new Glob(pattern, options, cb)
}

glob.sync = globSync
var GlobSync = glob.GlobSync = globSync.GlobSync

// old api surface
glob.glob = glob

function extend (origin, add) {
  if (add === null || typeof add !== 'object') {
    return origin
  }

  var keys = Object.keys(add)
  var i = keys.length
  while (i--) {
    origin[keys[i]] = add[keys[i]]
  }
  return origin
}

glob.hasMagic = function (pattern, options_) {
  var options = extend({}, options_)
  options.noprocess = true

  var g = new Glob(pattern, options)
  var set = g.minimatch.set

  if (!pattern)
    return false

  if (set.length > 1)
    return true

  for (var j = 0; j < set[0].length; j++) {
    if (typeof set[0][j] !== 'string')
      return true
  }

  return false
}

glob.Glob = Glob
inherits(Glob, EE)
function Glob (pattern, options, cb) {
  if (typeof options === 'function') {
    cb = options
    options = null
  }

  if (options && options.sync) {
    if (cb)
      throw new TypeError('callback provided to sync glob')
    return new GlobSync(pattern, options)
  }

  if (!(this instanceof Glob))
    return new Glob(pattern, options, cb)

  setopts(this, pattern, options)
  this._didRealPath = false

  // process each pattern in the minimatch set
  var n = this.minimatch.set.length

  // The matches are stored as {<filename>: true,...} so that
  // duplicates are automagically pruned.
  // Later, we do an Object.keys() on these.
  // Keep them as a list so we can fill in when nonull is set.
  this.matches = new Array(n)

  if (typeof cb === 'function') {
    cb = once(cb)
    this.on('error', cb)
    this.on('end', function (matches) {
      cb(null, matches)
    })
  }

  var self = this
  this._processing = 0

  this._emitQueue = []
  this._processQueue = []
  this.paused = false

  if (this.noprocess)
    return this

  if (n === 0)
    return done()

  var sync = true
  for (var i = 0; i < n; i ++) {
    this._process(this.minimatch.set[i], i, false, done)
  }
  sync = false

  function done () {
    --self._processing
    if (self._processing <= 0) {
      if (sync) {
        process.nextTick(function () {
          self._finish()
        })
      } else {
        self._finish()
      }
    }
  }
}

Glob.prototype._finish = function () {
  assert(this instanceof Glob)
  if (this.aborted)
    return

  if (this.realpath && !this._didRealpath)
    return this._realpath()

  common.finish(this)
  this.emit('end', this.found)
}

Glob.prototype._realpath = function () {
  if (this._didRealpath)
    return

  this._didRealpath = true

  var n = this.matches.length
  if (n === 0)
    return this._finish()

  var self = this
  for (var i = 0; i < this.matches.length; i++)
    this._realpathSet(i, next)

  function next () {
    if (--n === 0)
      self._finish()
  }
}

Glob.prototype._realpathSet = function (index, cb) {
  var matchset = this.matches[index]
  if (!matchset)
    return cb()

  var found = Object.keys(matchset)
  var self = this
  var n = found.length

  if (n === 0)
    return cb()

  var set = this.matches[index] = Object.create(null)
  found.forEach(function (p, i) {
    // If there's a problem with the stat, then it means that
    // one or more of the links in the realpath couldn't be
    // resolved.  just return the abs value in that case.
    p = self._makeAbs(p)
    rp.realpath(p, self.realpathCache, function (er, real) {
      if (!er)
        set[real] = true
      else if (er.syscall === 'stat')
        set[p] = true
      else
        self.emit('error', er) // srsly wtf right here

      if (--n === 0) {
        self.matches[index] = set
        cb()
      }
    })
  })
}

Glob.prototype._mark = function (p) {
  return common.mark(this, p)
}

Glob.prototype._makeAbs = function (f) {
  return common.makeAbs(this, f)
}

Glob.prototype.abort = function () {
  this.aborted = true
  this.emit('abort')
}

Glob.prototype.pause = function () {
  if (!this.paused) {
    this.paused = true
    this.emit('pause')
  }
}

Glob.prototype.resume = function () {
  if (this.paused) {
    this.emit('resume')
    this.paused = false
    if (this._emitQueue.length) {
      var eq = this._emitQueue.slice(0)
      this._emitQueue.length = 0
      for (var i = 0; i < eq.length; i ++) {
        var e = eq[i]
        this._emitMatch(e[0], e[1])
      }
    }
    if (this._processQueue.length) {
      var pq = this._processQueue.slice(0)
      this._processQueue.length = 0
      for (var i = 0; i < pq.length; i ++) {
        var p = pq[i]
        this._processing--
        this._process(p[0], p[1], p[2], p[3])
      }
    }
  }
}

Glob.prototype._process = function (pattern, index, inGlobStar, cb) {
  assert(this instanceof Glob)
  assert(typeof cb === 'function')

  if (this.aborted)
    return

  this._processing++
  if (this.paused) {
    this._processQueue.push([pattern, index, inGlobStar, cb])
    return
  }

  //console.error('PROCESS %d', this._processing, pattern)

  // Get the first [n] parts of pattern that are all strings.
  var n = 0
  while (typeof pattern[n] === 'string') {
    n ++
  }
  // now n is the index of the first one that is *not* a string.

  // see if there's anything else
  var prefix
  switch (n) {
    // if not, then this is rather simple
    case pattern.length:
      this._processSimple(pattern.join('/'), index, cb)
      return

    case 0:
      // pattern *starts* with some non-trivial item.
      // going to readdir(cwd), but not include the prefix in matches.
      prefix = null
      break

    default:
      // pattern has some string bits in the front.
      // whatever it starts with, whether that's 'absolute' like /foo/bar,
      // or 'relative' like '../baz'
      prefix = pattern.slice(0, n).join('/')
      break
  }

  var remain = pattern.slice(n)

  // get the list of entries.
  var read
  if (prefix === null)
    read = '.'
  else if (isAbsolute(prefix) || isAbsolute(pattern.join('/'))) {
    if (!prefix || !isAbsolute(prefix))
      prefix = '/' + prefix
    read = prefix
  } else
    read = prefix

  var abs = this._makeAbs(read)

  //if ignored, skip _processing
  if (childrenIgnored(this, read))
    return cb()

  var isGlobStar = remain[0] === minimatch.GLOBSTAR
  if (isGlobStar)
    this._processGlobStar(prefix, read, abs, remain, index, inGlobStar, cb)
  else
    this._processReaddir(prefix, read, abs, remain, index, inGlobStar, cb)
}

Glob.prototype._processReaddir = function (prefix, read, abs, remain, index, inGlobStar, cb) {
  var self = this
  this._readdir(abs, inGlobStar, function (er, entries) {
    return self._processReaddir2(prefix, read, abs, remain, index, inGlobStar, entries, cb)
  })
}

Glob.prototype._processReaddir2 = function (prefix, read, abs, remain, index, inGlobStar, entries, cb) {

  // if the abs isn't a dir, then nothing can match!
  if (!entries)
    return cb()

  // It will only match dot entries if it starts with a dot, or if
  // dot is set.  Stuff like @(.foo|.bar) isn't allowed.
  var pn = remain[0]
  var negate = !!this.minimatch.negate
  var rawGlob = pn._glob
  var dotOk = this.dot || rawGlob.charAt(0) === '.'

  var matchedEntries = []
  for (var i = 0; i < entries.length; i++) {
    var e = entries[i]
    if (e.charAt(0) !== '.' || dotOk) {
      var m
      if (negate && !prefix) {
        m = !e.match(pn)
      } else {
        m = e.match(pn)
      }
      if (m)
        matchedEntries.push(e)
    }
  }

  //console.error('prd2', prefix, entries, remain[0]._glob, matchedEntries)

  var len = matchedEntries.length
  // If there are no matched entries, then nothing matches.
  if (len === 0)
    return cb()

  // if this is the last remaining pattern bit, then no need for
  // an additional stat *unless* the user has specified mark or
  // stat explicitly.  We know they exist, since readdir returned
  // them.

  if (remain.length === 1 && !this.mark && !this.stat) {
    if (!this.matches[index])
      this.matches[index] = Object.create(null)

    for (var i = 0; i < len; i ++) {
      var e = matchedEntries[i]
      if (prefix) {
        if (prefix !== '/')
          e = prefix + '/' + e
        else
          e = prefix + e
      }

      if (e.charAt(0) === '/' && !this.nomount) {
        e = path.join(this.root, e)
      }
      this._emitMatch(index, e)
    }
    // This was the last one, and no stats were needed
    return cb()
  }

  // now test all matched entries as stand-ins for that part
  // of the pattern.
  remain.shift()
  for (var i = 0; i < len; i ++) {
    var e = matchedEntries[i]
    var newPattern
    if (prefix) {
      if (prefix !== '/')
        e = prefix + '/' + e
      else
        e = prefix + e
    }
    this._process([e].concat(remain), index, inGlobStar, cb)
  }
  cb()
}

Glob.prototype._emitMatch = function (index, e) {
  if (this.aborted)
    return

  if (isIgnored(this, e))
    return

  if (this.paused) {
    this._emitQueue.push([index, e])
    return
  }

  var abs = isAbsolute(e) ? e : this._makeAbs(e)

  if (this.mark)
    e = this._mark(e)

  if (this.absolute)
    e = abs

  if (this.matches[index][e])
    return

  if (this.nodir) {
    var c = this.cache[abs]
    if (c === 'DIR' || Array.isArray(c))
      return
  }

  this.matches[index][e] = true

  var st = this.statCache[abs]
  if (st)
    this.emit('stat', e, st)

  this.emit('match', e)
}

Glob.prototype._readdirInGlobStar = function (abs, cb) {
  if (this.aborted)
    return

  // follow all symlinked directories forever
  // just proceed as if this is a non-globstar situation
  if (this.follow)
    return this._readdir(abs, false, cb)

  var lstatkey = 'lstat\0' + abs
  var self = this
  var lstatcb = inflight(lstatkey, lstatcb_)

  if (lstatcb)
    fs.lstat(abs, lstatcb)

  function lstatcb_ (er, lstat) {
    if (er && er.code === 'ENOENT')
      return cb()

    var isSym = lstat && lstat.isSymbolicLink()
    self.symlinks[abs] = isSym

    // If it's not a symlink or a dir, then it's definitely a regular file.
    // don't bother doing a readdir in that case.
    if (!isSym && lstat && !lstat.isDirectory()) {
      self.cache[abs] = 'FILE'
      cb()
    } else
      self._readdir(abs, false, cb)
  }
}

Glob.prototype._readdir = function (abs, inGlobStar, cb) {
  if (this.aborted)
    return

  cb = inflight('readdir\0'+abs+'\0'+inGlobStar, cb)
  if (!cb)
    return

  //console.error('RD %j %j', +inGlobStar, abs)
  if (inGlobStar && !ownProp(this.symlinks, abs))
    return this._readdirInGlobStar(abs, cb)

  if (ownProp(this.cache, abs)) {
    var c = this.cache[abs]
    if (!c || c === 'FILE')
      return cb()

    if (Array.isArray(c))
      return cb(null, c)
  }

  var self = this
  fs.readdir(abs, readdirCb(this, abs, cb))
}

function readdirCb (self, abs, cb) {
  return function (er, entries) {
    if (er)
      self._readdirError(abs, er, cb)
    else
      self._readdirEntries(abs, entries, cb)
  }
}

Glob.prototype._readdirEntries = function (abs, entries, cb) {
  if (this.aborted)
    return

  // if we haven't asked to stat everything, then just
  // assume that everything in there exists, so we can avoid
  // having to stat it a second time.
  if (!this.mark && !this.stat) {
    for (var i = 0; i < entries.length; i ++) {
      var e = entries[i]
      if (abs === '/')
        e = abs + e
      else
        e = abs + '/' + e
      this.cache[e] = true
    }
  }

  this.cache[abs] = entries
  return cb(null, entries)
}

Glob.prototype._readdirError = function (f, er, cb) {
  if (this.aborted)
    return

  // handle errors, and cache the information
  switch (er.code) {
    case 'ENOTSUP': // https://github.com/isaacs/node-glob/issues/205
    case 'ENOTDIR': // totally normal. means it *does* exist.
      var abs = this._makeAbs(f)
      this.cache[abs] = 'FILE'
      if (abs === this.cwdAbs) {
        var error = new Error(er.code + ' invalid cwd ' + this.cwd)
        error.path = this.cwd
        error.code = er.code
        this.emit('error', error)
        this.abort()
      }
      break

    case 'ENOENT': // not terribly unusual
    case 'ELOOP':
    case 'ENAMETOOLONG':
    case 'UNKNOWN':
      this.cache[this._makeAbs(f)] = false
      break

    default: // some unusual error.  Treat as failure.
      this.cache[this._makeAbs(f)] = false
      if (this.strict) {
        this.emit('error', er)
        // If the error is handled, then we abort
        // if not, we threw out of here
        this.abort()
      }
      if (!this.silent)
        console.error('glob error', er)
      break
  }

  return cb()
}

Glob.prototype._processGlobStar = function (prefix, read, abs, remain, index, inGlobStar, cb) {
  var self = this
  this._readdir(abs, inGlobStar, function (er, entries) {
    self._processGlobStar2(prefix, read, abs, remain, index, inGlobStar, entries, cb)
  })
}


Glob.prototype._processGlobStar2 = function (prefix, read, abs, remain, index, inGlobStar, entries, cb) {
  //console.error('pgs2', prefix, remain[0], entries)

  // no entries means not a dir, so it can never have matches
  // foo.txt/** doesn't match foo.txt
  if (!entries)
    return cb()

  // test without the globstar, and with every child both below
  // and replacing the globstar.
  var remainWithoutGlobStar = remain.slice(1)
  var gspref = prefix ? [ prefix ] : []
  var noGlobStar = gspref.concat(remainWithoutGlobStar)

  // the noGlobStar pattern exits the inGlobStar state
  this._process(noGlobStar, index, false, cb)

  var isSym = this.symlinks[abs]
  var len = entries.length

  // If it's a symlink, and we're in a globstar, then stop
  if (isSym && inGlobStar)
    return cb()

  for (var i = 0; i < len; i++) {
    var e = entries[i]
    if (e.charAt(0) === '.' && !this.dot)
      continue

    // these two cases enter the inGlobStar state
    var instead = gspref.concat(entries[i], remainWithoutGlobStar)
    this._process(instead, index, true, cb)

    var below = gspref.concat(entries[i], remain)
    this._process(below, index, true, cb)
  }

  cb()
}

Glob.prototype._processSimple = function (prefix, index, cb) {
  // XXX review this.  Shouldn't it be doing the mounting etc
  // before doing stat?  kinda weird?
  var self = this
  this._stat(prefix, function (er, exists) {
    self._processSimple2(prefix, index, er, exists, cb)
  })
}
Glob.prototype._processSimple2 = function (prefix, index, er, exists, cb) {

  //console.error('ps2', prefix, exists)

  if (!this.matches[index])
    this.matches[index] = Object.create(null)

  // If it doesn't exist, then just mark the lack of results
  if (!exists)
    return cb()

  if (prefix && isAbsolute(prefix) && !this.nomount) {
    var trail = /[\/\\]$/.test(prefix)
    if (prefix.charAt(0) === '/') {
      prefix = path.join(this.root, prefix)
    } else {
      prefix = path.resolve(this.root, prefix)
      if (trail)
        prefix += '/'
    }
  }

  if (process.platform === 'win32')
    prefix = prefix.replace(/\\/g, '/')

  // Mark this as a match
  this._emitMatch(index, prefix)
  cb()
}

// Returns either 'DIR', 'FILE', or false
Glob.prototype._stat = function (f, cb) {
  var abs = this._makeAbs(f)
  var needDir = f.slice(-1) === '/'

  if (f.length > this.maxLength)
    return cb()

  if (!this.stat && ownProp(this.cache, abs)) {
    var c = this.cache[abs]

    if (Array.isArray(c))
      c = 'DIR'

    // It exists, but maybe not how we need it
    if (!needDir || c === 'DIR')
      return cb(null, c)

    if (needDir && c === 'FILE')
      return cb()

    // otherwise we have to stat, because maybe c=true
    // if we know it exists, but not what it is.
  }

  var exists
  var stat = this.statCache[abs]
  if (stat !== undefined) {
    if (stat === false)
      return cb(null, stat)
    else {
      var type = stat.isDirectory() ? 'DIR' : 'FILE'
      if (needDir && type === 'FILE')
        return cb()
      else
        return cb(null, type, stat)
    }
  }

  var self = this
  var statcb = inflight('stat\0' + abs, lstatcb_)
  if (statcb)
    fs.lstat(abs, statcb)

  function lstatcb_ (er, lstat) {
    if (lstat && lstat.isSymbolicLink()) {
      // If it's a symlink, then treat it as the target, unless
      // the target does not exist, then treat it as a file.
      return fs.stat(abs, function (er, stat) {
        if (er)
          self._stat2(f, abs, null, lstat, cb)
        else
          self._stat2(f, abs, er, stat, cb)
      })
    } else {
      self._stat2(f, abs, er, lstat, cb)
    }
  }
}

Glob.prototype._stat2 = function (f, abs, er, stat, cb) {
  if (er && (er.code === 'ENOENT' || er.code === 'ENOTDIR')) {
    this.statCache[abs] = false
    return cb()
  }

  var needDir = f.slice(-1) === '/'
  this.statCache[abs] = stat

  if (abs.slice(-1) === '/' && stat && !stat.isDirectory())
    return cb(null, false, stat)

  var c = true
  if (stat)
    c = stat.isDirectory() ? 'DIR' : 'FILE'
  this.cache[abs] = this.cache[abs] || c

  if (needDir && c === 'FILE')
    return cb()

  return cb(null, c, stat)
}


/***/ }),

/***/ "./node_modules/glob/sync.js":
/*!***********************************!*\
  !*** ./node_modules/glob/sync.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = globSync
globSync.GlobSync = GlobSync

var fs = __webpack_require__(/*! fs */ "fs")
var rp = __webpack_require__(/*! fs.realpath */ "./node_modules/fs.realpath/index.js")
var minimatch = __webpack_require__(/*! minimatch */ "./node_modules/minimatch/minimatch.js")
var Minimatch = minimatch.Minimatch
var Glob = __webpack_require__(/*! ./glob.js */ "./node_modules/glob/glob.js").Glob
var util = __webpack_require__(/*! util */ "util")
var path = __webpack_require__(/*! path */ "path")
var assert = __webpack_require__(/*! assert */ "assert")
var isAbsolute = __webpack_require__(/*! path-is-absolute */ "./node_modules/path-is-absolute/index.js")
var common = __webpack_require__(/*! ./common.js */ "./node_modules/glob/common.js")
var alphasort = common.alphasort
var alphasorti = common.alphasorti
var setopts = common.setopts
var ownProp = common.ownProp
var childrenIgnored = common.childrenIgnored
var isIgnored = common.isIgnored

function globSync (pattern, options) {
  if (typeof options === 'function' || arguments.length === 3)
    throw new TypeError('callback provided to sync glob\n'+
                        'See: https://github.com/isaacs/node-glob/issues/167')

  return new GlobSync(pattern, options).found
}

function GlobSync (pattern, options) {
  if (!pattern)
    throw new Error('must provide pattern')

  if (typeof options === 'function' || arguments.length === 3)
    throw new TypeError('callback provided to sync glob\n'+
                        'See: https://github.com/isaacs/node-glob/issues/167')

  if (!(this instanceof GlobSync))
    return new GlobSync(pattern, options)

  setopts(this, pattern, options)

  if (this.noprocess)
    return this

  var n = this.minimatch.set.length
  this.matches = new Array(n)
  for (var i = 0; i < n; i ++) {
    this._process(this.minimatch.set[i], i, false)
  }
  this._finish()
}

GlobSync.prototype._finish = function () {
  assert(this instanceof GlobSync)
  if (this.realpath) {
    var self = this
    this.matches.forEach(function (matchset, index) {
      var set = self.matches[index] = Object.create(null)
      for (var p in matchset) {
        try {
          p = self._makeAbs(p)
          var real = rp.realpathSync(p, self.realpathCache)
          set[real] = true
        } catch (er) {
          if (er.syscall === 'stat')
            set[self._makeAbs(p)] = true
          else
            throw er
        }
      }
    })
  }
  common.finish(this)
}


GlobSync.prototype._process = function (pattern, index, inGlobStar) {
  assert(this instanceof GlobSync)

  // Get the first [n] parts of pattern that are all strings.
  var n = 0
  while (typeof pattern[n] === 'string') {
    n ++
  }
  // now n is the index of the first one that is *not* a string.

  // See if there's anything else
  var prefix
  switch (n) {
    // if not, then this is rather simple
    case pattern.length:
      this._processSimple(pattern.join('/'), index)
      return

    case 0:
      // pattern *starts* with some non-trivial item.
      // going to readdir(cwd), but not include the prefix in matches.
      prefix = null
      break

    default:
      // pattern has some string bits in the front.
      // whatever it starts with, whether that's 'absolute' like /foo/bar,
      // or 'relative' like '../baz'
      prefix = pattern.slice(0, n).join('/')
      break
  }

  var remain = pattern.slice(n)

  // get the list of entries.
  var read
  if (prefix === null)
    read = '.'
  else if (isAbsolute(prefix) || isAbsolute(pattern.join('/'))) {
    if (!prefix || !isAbsolute(prefix))
      prefix = '/' + prefix
    read = prefix
  } else
    read = prefix

  var abs = this._makeAbs(read)

  //if ignored, skip processing
  if (childrenIgnored(this, read))
    return

  var isGlobStar = remain[0] === minimatch.GLOBSTAR
  if (isGlobStar)
    this._processGlobStar(prefix, read, abs, remain, index, inGlobStar)
  else
    this._processReaddir(prefix, read, abs, remain, index, inGlobStar)
}


GlobSync.prototype._processReaddir = function (prefix, read, abs, remain, index, inGlobStar) {
  var entries = this._readdir(abs, inGlobStar)

  // if the abs isn't a dir, then nothing can match!
  if (!entries)
    return

  // It will only match dot entries if it starts with a dot, or if
  // dot is set.  Stuff like @(.foo|.bar) isn't allowed.
  var pn = remain[0]
  var negate = !!this.minimatch.negate
  var rawGlob = pn._glob
  var dotOk = this.dot || rawGlob.charAt(0) === '.'

  var matchedEntries = []
  for (var i = 0; i < entries.length; i++) {
    var e = entries[i]
    if (e.charAt(0) !== '.' || dotOk) {
      var m
      if (negate && !prefix) {
        m = !e.match(pn)
      } else {
        m = e.match(pn)
      }
      if (m)
        matchedEntries.push(e)
    }
  }

  var len = matchedEntries.length
  // If there are no matched entries, then nothing matches.
  if (len === 0)
    return

  // if this is the last remaining pattern bit, then no need for
  // an additional stat *unless* the user has specified mark or
  // stat explicitly.  We know they exist, since readdir returned
  // them.

  if (remain.length === 1 && !this.mark && !this.stat) {
    if (!this.matches[index])
      this.matches[index] = Object.create(null)

    for (var i = 0; i < len; i ++) {
      var e = matchedEntries[i]
      if (prefix) {
        if (prefix.slice(-1) !== '/')
          e = prefix + '/' + e
        else
          e = prefix + e
      }

      if (e.charAt(0) === '/' && !this.nomount) {
        e = path.join(this.root, e)
      }
      this._emitMatch(index, e)
    }
    // This was the last one, and no stats were needed
    return
  }

  // now test all matched entries as stand-ins for that part
  // of the pattern.
  remain.shift()
  for (var i = 0; i < len; i ++) {
    var e = matchedEntries[i]
    var newPattern
    if (prefix)
      newPattern = [prefix, e]
    else
      newPattern = [e]
    this._process(newPattern.concat(remain), index, inGlobStar)
  }
}


GlobSync.prototype._emitMatch = function (index, e) {
  if (isIgnored(this, e))
    return

  var abs = this._makeAbs(e)

  if (this.mark)
    e = this._mark(e)

  if (this.absolute) {
    e = abs
  }

  if (this.matches[index][e])
    return

  if (this.nodir) {
    var c = this.cache[abs]
    if (c === 'DIR' || Array.isArray(c))
      return
  }

  this.matches[index][e] = true

  if (this.stat)
    this._stat(e)
}


GlobSync.prototype._readdirInGlobStar = function (abs) {
  // follow all symlinked directories forever
  // just proceed as if this is a non-globstar situation
  if (this.follow)
    return this._readdir(abs, false)

  var entries
  var lstat
  var stat
  try {
    lstat = fs.lstatSync(abs)
  } catch (er) {
    if (er.code === 'ENOENT') {
      // lstat failed, doesn't exist
      return null
    }
  }

  var isSym = lstat && lstat.isSymbolicLink()
  this.symlinks[abs] = isSym

  // If it's not a symlink or a dir, then it's definitely a regular file.
  // don't bother doing a readdir in that case.
  if (!isSym && lstat && !lstat.isDirectory())
    this.cache[abs] = 'FILE'
  else
    entries = this._readdir(abs, false)

  return entries
}

GlobSync.prototype._readdir = function (abs, inGlobStar) {
  var entries

  if (inGlobStar && !ownProp(this.symlinks, abs))
    return this._readdirInGlobStar(abs)

  if (ownProp(this.cache, abs)) {
    var c = this.cache[abs]
    if (!c || c === 'FILE')
      return null

    if (Array.isArray(c))
      return c
  }

  try {
    return this._readdirEntries(abs, fs.readdirSync(abs))
  } catch (er) {
    this._readdirError(abs, er)
    return null
  }
}

GlobSync.prototype._readdirEntries = function (abs, entries) {
  // if we haven't asked to stat everything, then just
  // assume that everything in there exists, so we can avoid
  // having to stat it a second time.
  if (!this.mark && !this.stat) {
    for (var i = 0; i < entries.length; i ++) {
      var e = entries[i]
      if (abs === '/')
        e = abs + e
      else
        e = abs + '/' + e
      this.cache[e] = true
    }
  }

  this.cache[abs] = entries

  // mark and cache dir-ness
  return entries
}

GlobSync.prototype._readdirError = function (f, er) {
  // handle errors, and cache the information
  switch (er.code) {
    case 'ENOTSUP': // https://github.com/isaacs/node-glob/issues/205
    case 'ENOTDIR': // totally normal. means it *does* exist.
      var abs = this._makeAbs(f)
      this.cache[abs] = 'FILE'
      if (abs === this.cwdAbs) {
        var error = new Error(er.code + ' invalid cwd ' + this.cwd)
        error.path = this.cwd
        error.code = er.code
        throw error
      }
      break

    case 'ENOENT': // not terribly unusual
    case 'ELOOP':
    case 'ENAMETOOLONG':
    case 'UNKNOWN':
      this.cache[this._makeAbs(f)] = false
      break

    default: // some unusual error.  Treat as failure.
      this.cache[this._makeAbs(f)] = false
      if (this.strict)
        throw er
      if (!this.silent)
        console.error('glob error', er)
      break
  }
}

GlobSync.prototype._processGlobStar = function (prefix, read, abs, remain, index, inGlobStar) {

  var entries = this._readdir(abs, inGlobStar)

  // no entries means not a dir, so it can never have matches
  // foo.txt/** doesn't match foo.txt
  if (!entries)
    return

  // test without the globstar, and with every child both below
  // and replacing the globstar.
  var remainWithoutGlobStar = remain.slice(1)
  var gspref = prefix ? [ prefix ] : []
  var noGlobStar = gspref.concat(remainWithoutGlobStar)

  // the noGlobStar pattern exits the inGlobStar state
  this._process(noGlobStar, index, false)

  var len = entries.length
  var isSym = this.symlinks[abs]

  // If it's a symlink, and we're in a globstar, then stop
  if (isSym && inGlobStar)
    return

  for (var i = 0; i < len; i++) {
    var e = entries[i]
    if (e.charAt(0) === '.' && !this.dot)
      continue

    // these two cases enter the inGlobStar state
    var instead = gspref.concat(entries[i], remainWithoutGlobStar)
    this._process(instead, index, true)

    var below = gspref.concat(entries[i], remain)
    this._process(below, index, true)
  }
}

GlobSync.prototype._processSimple = function (prefix, index) {
  // XXX review this.  Shouldn't it be doing the mounting etc
  // before doing stat?  kinda weird?
  var exists = this._stat(prefix)

  if (!this.matches[index])
    this.matches[index] = Object.create(null)

  // If it doesn't exist, then just mark the lack of results
  if (!exists)
    return

  if (prefix && isAbsolute(prefix) && !this.nomount) {
    var trail = /[\/\\]$/.test(prefix)
    if (prefix.charAt(0) === '/') {
      prefix = path.join(this.root, prefix)
    } else {
      prefix = path.resolve(this.root, prefix)
      if (trail)
        prefix += '/'
    }
  }

  if (process.platform === 'win32')
    prefix = prefix.replace(/\\/g, '/')

  // Mark this as a match
  this._emitMatch(index, prefix)
}

// Returns either 'DIR', 'FILE', or false
GlobSync.prototype._stat = function (f) {
  var abs = this._makeAbs(f)
  var needDir = f.slice(-1) === '/'

  if (f.length > this.maxLength)
    return false

  if (!this.stat && ownProp(this.cache, abs)) {
    var c = this.cache[abs]

    if (Array.isArray(c))
      c = 'DIR'

    // It exists, but maybe not how we need it
    if (!needDir || c === 'DIR')
      return c

    if (needDir && c === 'FILE')
      return false

    // otherwise we have to stat, because maybe c=true
    // if we know it exists, but not what it is.
  }

  var exists
  var stat = this.statCache[abs]
  if (!stat) {
    var lstat
    try {
      lstat = fs.lstatSync(abs)
    } catch (er) {
      if (er && (er.code === 'ENOENT' || er.code === 'ENOTDIR')) {
        this.statCache[abs] = false
        return false
      }
    }

    if (lstat && lstat.isSymbolicLink()) {
      try {
        stat = fs.statSync(abs)
      } catch (er) {
        stat = lstat
      }
    } else {
      stat = lstat
    }
  }

  this.statCache[abs] = stat

  var c = true
  if (stat)
    c = stat.isDirectory() ? 'DIR' : 'FILE'

  this.cache[abs] = this.cache[abs] || c

  if (needDir && c === 'FILE')
    return false

  return c
}

GlobSync.prototype._mark = function (p) {
  return common.mark(this, p)
}

GlobSync.prototype._makeAbs = function (f) {
  return common.makeAbs(this, f)
}


/***/ }),

/***/ "./node_modules/inflight/inflight.js":
/*!*******************************************!*\
  !*** ./node_modules/inflight/inflight.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var wrappy = __webpack_require__(/*! wrappy */ "./node_modules/wrappy/wrappy.js")
var reqs = Object.create(null)
var once = __webpack_require__(/*! once */ "./node_modules/once/once.js")

module.exports = wrappy(inflight)

function inflight (key, cb) {
  if (reqs[key]) {
    reqs[key].push(cb)
    return null
  } else {
    reqs[key] = [cb]
    return makeres(key)
  }
}

function makeres (key) {
  return once(function RES () {
    var cbs = reqs[key]
    var len = cbs.length
    var args = slice(arguments)

    // XXX It's somewhat ambiguous whether a new callback added in this
    // pass should be queued for later execution if something in the
    // list of callbacks throws, or if it should just be discarded.
    // However, it's such an edge case that it hardly matters, and either
    // choice is likely as surprising as the other.
    // As it happens, we do go ahead and schedule it for later execution.
    try {
      for (var i = 0; i < len; i++) {
        cbs[i].apply(null, args)
      }
    } finally {
      if (cbs.length > len) {
        // added more in the interim.
        // de-zalgo, just in case, but don't call again.
        cbs.splice(0, len)
        process.nextTick(function () {
          RES.apply(null, args)
        })
      } else {
        delete reqs[key]
      }
    }
  })
}

function slice (args) {
  var length = args.length
  var array = []

  for (var i = 0; i < length; i++) array[i] = args[i]
  return array
}


/***/ }),

/***/ "./node_modules/inherits/inherits.js":
/*!*******************************************!*\
  !*** ./node_modules/inherits/inherits.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

try {
  var util = __webpack_require__(/*! util */ "util");
  if (typeof util.inherits !== 'function') throw '';
  module.exports = util.inherits;
} catch (e) {
  module.exports = __webpack_require__(/*! ./inherits_browser.js */ "./node_modules/inherits/inherits_browser.js");
}


/***/ }),

/***/ "./node_modules/inherits/inherits_browser.js":
/*!***************************************************!*\
  !*** ./node_modules/inherits/inherits_browser.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    ctor.prototype = Object.create(superCtor.prototype, {
      constructor: {
        value: ctor,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    var TempCtor = function () {}
    TempCtor.prototype = superCtor.prototype
    ctor.prototype = new TempCtor()
    ctor.prototype.constructor = ctor
  }
}


/***/ }),

/***/ "./node_modules/minimatch/minimatch.js":
/*!*********************************************!*\
  !*** ./node_modules/minimatch/minimatch.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = minimatch
minimatch.Minimatch = Minimatch

var path = { sep: '/' }
try {
  path = __webpack_require__(/*! path */ "path")
} catch (er) {}

var GLOBSTAR = minimatch.GLOBSTAR = Minimatch.GLOBSTAR = {}
var expand = __webpack_require__(/*! brace-expansion */ "./node_modules/brace-expansion/index.js")

var plTypes = {
  '!': { open: '(?:(?!(?:', close: '))[^/]*?)'},
  '?': { open: '(?:', close: ')?' },
  '+': { open: '(?:', close: ')+' },
  '*': { open: '(?:', close: ')*' },
  '@': { open: '(?:', close: ')' }
}

// any single thing other than /
// don't need to escape / when using new RegExp()
var qmark = '[^/]'

// * => any number of characters
var star = qmark + '*?'

// ** when dots are allowed.  Anything goes, except .. and .
// not (^ or / followed by one or two dots followed by $ or /),
// followed by anything, any number of times.
var twoStarDot = '(?:(?!(?:\\\/|^)(?:\\.{1,2})($|\\\/)).)*?'

// not a ^ or / followed by a dot,
// followed by anything, any number of times.
var twoStarNoDot = '(?:(?!(?:\\\/|^)\\.).)*?'

// characters that need to be escaped in RegExp.
var reSpecials = charSet('().*{}+?[]^$\\!')

// "abc" -> { a:true, b:true, c:true }
function charSet (s) {
  return s.split('').reduce(function (set, c) {
    set[c] = true
    return set
  }, {})
}

// normalizes slashes.
var slashSplit = /\/+/

minimatch.filter = filter
function filter (pattern, options) {
  options = options || {}
  return function (p, i, list) {
    return minimatch(p, pattern, options)
  }
}

function ext (a, b) {
  a = a || {}
  b = b || {}
  var t = {}
  Object.keys(b).forEach(function (k) {
    t[k] = b[k]
  })
  Object.keys(a).forEach(function (k) {
    t[k] = a[k]
  })
  return t
}

minimatch.defaults = function (def) {
  if (!def || !Object.keys(def).length) return minimatch

  var orig = minimatch

  var m = function minimatch (p, pattern, options) {
    return orig.minimatch(p, pattern, ext(def, options))
  }

  m.Minimatch = function Minimatch (pattern, options) {
    return new orig.Minimatch(pattern, ext(def, options))
  }

  return m
}

Minimatch.defaults = function (def) {
  if (!def || !Object.keys(def).length) return Minimatch
  return minimatch.defaults(def).Minimatch
}

function minimatch (p, pattern, options) {
  if (typeof pattern !== 'string') {
    throw new TypeError('glob pattern string required')
  }

  if (!options) options = {}

  // shortcut: comments match nothing.
  if (!options.nocomment && pattern.charAt(0) === '#') {
    return false
  }

  // "" only matches ""
  if (pattern.trim() === '') return p === ''

  return new Minimatch(pattern, options).match(p)
}

function Minimatch (pattern, options) {
  if (!(this instanceof Minimatch)) {
    return new Minimatch(pattern, options)
  }

  if (typeof pattern !== 'string') {
    throw new TypeError('glob pattern string required')
  }

  if (!options) options = {}
  pattern = pattern.trim()

  // windows support: need to use /, not \
  if (path.sep !== '/') {
    pattern = pattern.split(path.sep).join('/')
  }

  this.options = options
  this.set = []
  this.pattern = pattern
  this.regexp = null
  this.negate = false
  this.comment = false
  this.empty = false

  // make the set of regexps etc.
  this.make()
}

Minimatch.prototype.debug = function () {}

Minimatch.prototype.make = make
function make () {
  // don't do it more than once.
  if (this._made) return

  var pattern = this.pattern
  var options = this.options

  // empty patterns and comments match nothing.
  if (!options.nocomment && pattern.charAt(0) === '#') {
    this.comment = true
    return
  }
  if (!pattern) {
    this.empty = true
    return
  }

  // step 1: figure out negation, etc.
  this.parseNegate()

  // step 2: expand braces
  var set = this.globSet = this.braceExpand()

  if (options.debug) this.debug = console.error

  this.debug(this.pattern, set)

  // step 3: now we have a set, so turn each one into a series of path-portion
  // matching patterns.
  // These will be regexps, except in the case of "**", which is
  // set to the GLOBSTAR object for globstar behavior,
  // and will not contain any / characters
  set = this.globParts = set.map(function (s) {
    return s.split(slashSplit)
  })

  this.debug(this.pattern, set)

  // glob --> regexps
  set = set.map(function (s, si, set) {
    return s.map(this.parse, this)
  }, this)

  this.debug(this.pattern, set)

  // filter out everything that didn't compile properly.
  set = set.filter(function (s) {
    return s.indexOf(false) === -1
  })

  this.debug(this.pattern, set)

  this.set = set
}

Minimatch.prototype.parseNegate = parseNegate
function parseNegate () {
  var pattern = this.pattern
  var negate = false
  var options = this.options
  var negateOffset = 0

  if (options.nonegate) return

  for (var i = 0, l = pattern.length
    ; i < l && pattern.charAt(i) === '!'
    ; i++) {
    negate = !negate
    negateOffset++
  }

  if (negateOffset) this.pattern = pattern.substr(negateOffset)
  this.negate = negate
}

// Brace expansion:
// a{b,c}d -> abd acd
// a{b,}c -> abc ac
// a{0..3}d -> a0d a1d a2d a3d
// a{b,c{d,e}f}g -> abg acdfg acefg
// a{b,c}d{e,f}g -> abdeg acdeg abdeg abdfg
//
// Invalid sets are not expanded.
// a{2..}b -> a{2..}b
// a{b}c -> a{b}c
minimatch.braceExpand = function (pattern, options) {
  return braceExpand(pattern, options)
}

Minimatch.prototype.braceExpand = braceExpand

function braceExpand (pattern, options) {
  if (!options) {
    if (this instanceof Minimatch) {
      options = this.options
    } else {
      options = {}
    }
  }

  pattern = typeof pattern === 'undefined'
    ? this.pattern : pattern

  if (typeof pattern === 'undefined') {
    throw new TypeError('undefined pattern')
  }

  if (options.nobrace ||
    !pattern.match(/\{.*\}/)) {
    // shortcut. no need to expand.
    return [pattern]
  }

  return expand(pattern)
}

// parse a component of the expanded set.
// At this point, no pattern may contain "/" in it
// so we're going to return a 2d array, where each entry is the full
// pattern, split on '/', and then turned into a regular expression.
// A regexp is made at the end which joins each array with an
// escaped /, and another full one which joins each regexp with |.
//
// Following the lead of Bash 4.1, note that "**" only has special meaning
// when it is the *only* thing in a path portion.  Otherwise, any series
// of * is equivalent to a single *.  Globstar behavior is enabled by
// default, and can be disabled by setting options.noglobstar.
Minimatch.prototype.parse = parse
var SUBPARSE = {}
function parse (pattern, isSub) {
  if (pattern.length > 1024 * 64) {
    throw new TypeError('pattern is too long')
  }

  var options = this.options

  // shortcuts
  if (!options.noglobstar && pattern === '**') return GLOBSTAR
  if (pattern === '') return ''

  var re = ''
  var hasMagic = !!options.nocase
  var escaping = false
  // ? => one single character
  var patternListStack = []
  var negativeLists = []
  var stateChar
  var inClass = false
  var reClassStart = -1
  var classStart = -1
  // . and .. never match anything that doesn't start with .,
  // even when options.dot is set.
  var patternStart = pattern.charAt(0) === '.' ? '' // anything
  // not (start or / followed by . or .. followed by / or end)
  : options.dot ? '(?!(?:^|\\\/)\\.{1,2}(?:$|\\\/))'
  : '(?!\\.)'
  var self = this

  function clearStateChar () {
    if (stateChar) {
      // we had some state-tracking character
      // that wasn't consumed by this pass.
      switch (stateChar) {
        case '*':
          re += star
          hasMagic = true
        break
        case '?':
          re += qmark
          hasMagic = true
        break
        default:
          re += '\\' + stateChar
        break
      }
      self.debug('clearStateChar %j %j', stateChar, re)
      stateChar = false
    }
  }

  for (var i = 0, len = pattern.length, c
    ; (i < len) && (c = pattern.charAt(i))
    ; i++) {
    this.debug('%s\t%s %s %j', pattern, i, re, c)

    // skip over any that are escaped.
    if (escaping && reSpecials[c]) {
      re += '\\' + c
      escaping = false
      continue
    }

    switch (c) {
      case '/':
        // completely not allowed, even escaped.
        // Should already be path-split by now.
        return false

      case '\\':
        clearStateChar()
        escaping = true
      continue

      // the various stateChar values
      // for the "extglob" stuff.
      case '?':
      case '*':
      case '+':
      case '@':
      case '!':
        this.debug('%s\t%s %s %j <-- stateChar', pattern, i, re, c)

        // all of those are literals inside a class, except that
        // the glob [!a] means [^a] in regexp
        if (inClass) {
          this.debug('  in class')
          if (c === '!' && i === classStart + 1) c = '^'
          re += c
          continue
        }

        // if we already have a stateChar, then it means
        // that there was something like ** or +? in there.
        // Handle the stateChar, then proceed with this one.
        self.debug('call clearStateChar %j', stateChar)
        clearStateChar()
        stateChar = c
        // if extglob is disabled, then +(asdf|foo) isn't a thing.
        // just clear the statechar *now*, rather than even diving into
        // the patternList stuff.
        if (options.noext) clearStateChar()
      continue

      case '(':
        if (inClass) {
          re += '('
          continue
        }

        if (!stateChar) {
          re += '\\('
          continue
        }

        patternListStack.push({
          type: stateChar,
          start: i - 1,
          reStart: re.length,
          open: plTypes[stateChar].open,
          close: plTypes[stateChar].close
        })
        // negation is (?:(?!js)[^/]*)
        re += stateChar === '!' ? '(?:(?!(?:' : '(?:'
        this.debug('plType %j %j', stateChar, re)
        stateChar = false
      continue

      case ')':
        if (inClass || !patternListStack.length) {
          re += '\\)'
          continue
        }

        clearStateChar()
        hasMagic = true
        var pl = patternListStack.pop()
        // negation is (?:(?!js)[^/]*)
        // The others are (?:<pattern>)<type>
        re += pl.close
        if (pl.type === '!') {
          negativeLists.push(pl)
        }
        pl.reEnd = re.length
      continue

      case '|':
        if (inClass || !patternListStack.length || escaping) {
          re += '\\|'
          escaping = false
          continue
        }

        clearStateChar()
        re += '|'
      continue

      // these are mostly the same in regexp and glob
      case '[':
        // swallow any state-tracking char before the [
        clearStateChar()

        if (inClass) {
          re += '\\' + c
          continue
        }

        inClass = true
        classStart = i
        reClassStart = re.length
        re += c
      continue

      case ']':
        //  a right bracket shall lose its special
        //  meaning and represent itself in
        //  a bracket expression if it occurs
        //  first in the list.  -- POSIX.2 2.8.3.2
        if (i === classStart + 1 || !inClass) {
          re += '\\' + c
          escaping = false
          continue
        }

        // handle the case where we left a class open.
        // "[z-a]" is valid, equivalent to "\[z-a\]"
        if (inClass) {
          // split where the last [ was, make sure we don't have
          // an invalid re. if so, re-walk the contents of the
          // would-be class to re-translate any characters that
          // were passed through as-is
          // TODO: It would probably be faster to determine this
          // without a try/catch and a new RegExp, but it's tricky
          // to do safely.  For now, this is safe and works.
          var cs = pattern.substring(classStart + 1, i)
          try {
            RegExp('[' + cs + ']')
          } catch (er) {
            // not a valid class!
            var sp = this.parse(cs, SUBPARSE)
            re = re.substr(0, reClassStart) + '\\[' + sp[0] + '\\]'
            hasMagic = hasMagic || sp[1]
            inClass = false
            continue
          }
        }

        // finish up the class.
        hasMagic = true
        inClass = false
        re += c
      continue

      default:
        // swallow any state char that wasn't consumed
        clearStateChar()

        if (escaping) {
          // no need
          escaping = false
        } else if (reSpecials[c]
          && !(c === '^' && inClass)) {
          re += '\\'
        }

        re += c

    } // switch
  } // for

  // handle the case where we left a class open.
  // "[abc" is valid, equivalent to "\[abc"
  if (inClass) {
    // split where the last [ was, and escape it
    // this is a huge pita.  We now have to re-walk
    // the contents of the would-be class to re-translate
    // any characters that were passed through as-is
    cs = pattern.substr(classStart + 1)
    sp = this.parse(cs, SUBPARSE)
    re = re.substr(0, reClassStart) + '\\[' + sp[0]
    hasMagic = hasMagic || sp[1]
  }

  // handle the case where we had a +( thing at the *end*
  // of the pattern.
  // each pattern list stack adds 3 chars, and we need to go through
  // and escape any | chars that were passed through as-is for the regexp.
  // Go through and escape them, taking care not to double-escape any
  // | chars that were already escaped.
  for (pl = patternListStack.pop(); pl; pl = patternListStack.pop()) {
    var tail = re.slice(pl.reStart + pl.open.length)
    this.debug('setting tail', re, pl)
    // maybe some even number of \, then maybe 1 \, followed by a |
    tail = tail.replace(/((?:\\{2}){0,64})(\\?)\|/g, function (_, $1, $2) {
      if (!$2) {
        // the | isn't already escaped, so escape it.
        $2 = '\\'
      }

      // need to escape all those slashes *again*, without escaping the
      // one that we need for escaping the | character.  As it works out,
      // escaping an even number of slashes can be done by simply repeating
      // it exactly after itself.  That's why this trick works.
      //
      // I am sorry that you have to see this.
      return $1 + $1 + $2 + '|'
    })

    this.debug('tail=%j\n   %s', tail, tail, pl, re)
    var t = pl.type === '*' ? star
      : pl.type === '?' ? qmark
      : '\\' + pl.type

    hasMagic = true
    re = re.slice(0, pl.reStart) + t + '\\(' + tail
  }

  // handle trailing things that only matter at the very end.
  clearStateChar()
  if (escaping) {
    // trailing \\
    re += '\\\\'
  }

  // only need to apply the nodot start if the re starts with
  // something that could conceivably capture a dot
  var addPatternStart = false
  switch (re.charAt(0)) {
    case '.':
    case '[':
    case '(': addPatternStart = true
  }

  // Hack to work around lack of negative lookbehind in JS
  // A pattern like: *.!(x).!(y|z) needs to ensure that a name
  // like 'a.xyz.yz' doesn't match.  So, the first negative
  // lookahead, has to look ALL the way ahead, to the end of
  // the pattern.
  for (var n = negativeLists.length - 1; n > -1; n--) {
    var nl = negativeLists[n]

    var nlBefore = re.slice(0, nl.reStart)
    var nlFirst = re.slice(nl.reStart, nl.reEnd - 8)
    var nlLast = re.slice(nl.reEnd - 8, nl.reEnd)
    var nlAfter = re.slice(nl.reEnd)

    nlLast += nlAfter

    // Handle nested stuff like *(*.js|!(*.json)), where open parens
    // mean that we should *not* include the ) in the bit that is considered
    // "after" the negated section.
    var openParensBefore = nlBefore.split('(').length - 1
    var cleanAfter = nlAfter
    for (i = 0; i < openParensBefore; i++) {
      cleanAfter = cleanAfter.replace(/\)[+*?]?/, '')
    }
    nlAfter = cleanAfter

    var dollar = ''
    if (nlAfter === '' && isSub !== SUBPARSE) {
      dollar = '$'
    }
    var newRe = nlBefore + nlFirst + nlAfter + dollar + nlLast
    re = newRe
  }

  // if the re is not "" at this point, then we need to make sure
  // it doesn't match against an empty path part.
  // Otherwise a/* will match a/, which it should not.
  if (re !== '' && hasMagic) {
    re = '(?=.)' + re
  }

  if (addPatternStart) {
    re = patternStart + re
  }

  // parsing just a piece of a larger pattern.
  if (isSub === SUBPARSE) {
    return [re, hasMagic]
  }

  // skip the regexp for non-magical patterns
  // unescape anything in it, though, so that it'll be
  // an exact match against a file etc.
  if (!hasMagic) {
    return globUnescape(pattern)
  }

  var flags = options.nocase ? 'i' : ''
  try {
    var regExp = new RegExp('^' + re + '$', flags)
  } catch (er) {
    // If it was an invalid regular expression, then it can't match
    // anything.  This trick looks for a character after the end of
    // the string, which is of course impossible, except in multi-line
    // mode, but it's not a /m regex.
    return new RegExp('$.')
  }

  regExp._glob = pattern
  regExp._src = re

  return regExp
}

minimatch.makeRe = function (pattern, options) {
  return new Minimatch(pattern, options || {}).makeRe()
}

Minimatch.prototype.makeRe = makeRe
function makeRe () {
  if (this.regexp || this.regexp === false) return this.regexp

  // at this point, this.set is a 2d array of partial
  // pattern strings, or "**".
  //
  // It's better to use .match().  This function shouldn't
  // be used, really, but it's pretty convenient sometimes,
  // when you just want to work with a regex.
  var set = this.set

  if (!set.length) {
    this.regexp = false
    return this.regexp
  }
  var options = this.options

  var twoStar = options.noglobstar ? star
    : options.dot ? twoStarDot
    : twoStarNoDot
  var flags = options.nocase ? 'i' : ''

  var re = set.map(function (pattern) {
    return pattern.map(function (p) {
      return (p === GLOBSTAR) ? twoStar
      : (typeof p === 'string') ? regExpEscape(p)
      : p._src
    }).join('\\\/')
  }).join('|')

  // must match entire pattern
  // ending in a * or ** will make it less strict.
  re = '^(?:' + re + ')$'

  // can match anything, as long as it's not this.
  if (this.negate) re = '^(?!' + re + ').*$'

  try {
    this.regexp = new RegExp(re, flags)
  } catch (ex) {
    this.regexp = false
  }
  return this.regexp
}

minimatch.match = function (list, pattern, options) {
  options = options || {}
  var mm = new Minimatch(pattern, options)
  list = list.filter(function (f) {
    return mm.match(f)
  })
  if (mm.options.nonull && !list.length) {
    list.push(pattern)
  }
  return list
}

Minimatch.prototype.match = match
function match (f, partial) {
  this.debug('match', f, this.pattern)
  // short-circuit in the case of busted things.
  // comments, etc.
  if (this.comment) return false
  if (this.empty) return f === ''

  if (f === '/' && partial) return true

  var options = this.options

  // windows: need to use /, not \
  if (path.sep !== '/') {
    f = f.split(path.sep).join('/')
  }

  // treat the test path as a set of pathparts.
  f = f.split(slashSplit)
  this.debug(this.pattern, 'split', f)

  // just ONE of the pattern sets in this.set needs to match
  // in order for it to be valid.  If negating, then just one
  // match means that we have failed.
  // Either way, return on the first hit.

  var set = this.set
  this.debug(this.pattern, 'set', set)

  // Find the basename of the path by looking for the last non-empty segment
  var filename
  var i
  for (i = f.length - 1; i >= 0; i--) {
    filename = f[i]
    if (filename) break
  }

  for (i = 0; i < set.length; i++) {
    var pattern = set[i]
    var file = f
    if (options.matchBase && pattern.length === 1) {
      file = [filename]
    }
    var hit = this.matchOne(file, pattern, partial)
    if (hit) {
      if (options.flipNegate) return true
      return !this.negate
    }
  }

  // didn't get any hits.  this is success if it's a negative
  // pattern, failure otherwise.
  if (options.flipNegate) return false
  return this.negate
}

// set partial to true to test if, for example,
// "/a/b" matches the start of "/*/b/*/d"
// Partial means, if you run out of file before you run
// out of pattern, then that's fine, as long as all
// the parts match.
Minimatch.prototype.matchOne = function (file, pattern, partial) {
  var options = this.options

  this.debug('matchOne',
    { 'this': this, file: file, pattern: pattern })

  this.debug('matchOne', file.length, pattern.length)

  for (var fi = 0,
      pi = 0,
      fl = file.length,
      pl = pattern.length
      ; (fi < fl) && (pi < pl)
      ; fi++, pi++) {
    this.debug('matchOne loop')
    var p = pattern[pi]
    var f = file[fi]

    this.debug(pattern, p, f)

    // should be impossible.
    // some invalid regexp stuff in the set.
    if (p === false) return false

    if (p === GLOBSTAR) {
      this.debug('GLOBSTAR', [pattern, p, f])

      // "**"
      // a/**/b/**/c would match the following:
      // a/b/x/y/z/c
      // a/x/y/z/b/c
      // a/b/x/b/x/c
      // a/b/c
      // To do this, take the rest of the pattern after
      // the **, and see if it would match the file remainder.
      // If so, return success.
      // If not, the ** "swallows" a segment, and try again.
      // This is recursively awful.
      //
      // a/**/b/**/c matching a/b/x/y/z/c
      // - a matches a
      // - doublestar
      //   - matchOne(b/x/y/z/c, b/**/c)
      //     - b matches b
      //     - doublestar
      //       - matchOne(x/y/z/c, c) -> no
      //       - matchOne(y/z/c, c) -> no
      //       - matchOne(z/c, c) -> no
      //       - matchOne(c, c) yes, hit
      var fr = fi
      var pr = pi + 1
      if (pr === pl) {
        this.debug('** at the end')
        // a ** at the end will just swallow the rest.
        // We have found a match.
        // however, it will not swallow /.x, unless
        // options.dot is set.
        // . and .. are *never* matched by **, for explosively
        // exponential reasons.
        for (; fi < fl; fi++) {
          if (file[fi] === '.' || file[fi] === '..' ||
            (!options.dot && file[fi].charAt(0) === '.')) return false
        }
        return true
      }

      // ok, let's see if we can swallow whatever we can.
      while (fr < fl) {
        var swallowee = file[fr]

        this.debug('\nglobstar while', file, fr, pattern, pr, swallowee)

        // XXX remove this slice.  Just pass the start index.
        if (this.matchOne(file.slice(fr), pattern.slice(pr), partial)) {
          this.debug('globstar found match!', fr, fl, swallowee)
          // found a match.
          return true
        } else {
          // can't swallow "." or ".." ever.
          // can only swallow ".foo" when explicitly asked.
          if (swallowee === '.' || swallowee === '..' ||
            (!options.dot && swallowee.charAt(0) === '.')) {
            this.debug('dot detected!', file, fr, pattern, pr)
            break
          }

          // ** swallows a segment, and continue.
          this.debug('globstar swallow a segment, and continue')
          fr++
        }
      }

      // no match was found.
      // However, in partial mode, we can't say this is necessarily over.
      // If there's more *pattern* left, then
      if (partial) {
        // ran out of file
        this.debug('\n>>> no match, partial?', file, fr, pattern, pr)
        if (fr === fl) return true
      }
      return false
    }

    // something other than **
    // non-magic patterns just have to match exactly
    // patterns with magic have been turned into regexps.
    var hit
    if (typeof p === 'string') {
      if (options.nocase) {
        hit = f.toLowerCase() === p.toLowerCase()
      } else {
        hit = f === p
      }
      this.debug('string match', p, f, hit)
    } else {
      hit = f.match(p)
      this.debug('pattern match', p, f, hit)
    }

    if (!hit) return false
  }

  // Note: ending in / means that we'll get a final ""
  // at the end of the pattern.  This can only match a
  // corresponding "" at the end of the file.
  // If the file ends in /, then it can only match a
  // a pattern that ends in /, unless the pattern just
  // doesn't have any more for it. But, a/b/ should *not*
  // match "a/b/*", even though "" matches against the
  // [^/]*? pattern, except in partial mode, where it might
  // simply not be reached yet.
  // However, a/b/ should still satisfy a/*

  // now either we fell off the end of the pattern, or we're done.
  if (fi === fl && pi === pl) {
    // ran out of pattern and filename at the same time.
    // an exact hit!
    return true
  } else if (fi === fl) {
    // ran out of file, but still had pattern left.
    // this is ok if we're doing the match as part of
    // a glob fs traversal.
    return partial
  } else if (pi === pl) {
    // ran out of pattern, still have file left.
    // this is only acceptable if we're on the very last
    // empty segment of a file with a trailing slash.
    // a/* should match a/b/
    var emptyFileEnd = (fi === fl - 1) && (file[fi] === '')
    return emptyFileEnd
  }

  // should be unreachable.
  throw new Error('wtf?')
}

// replace stuff like \* with *
function globUnescape (s) {
  return s.replace(/\\(.)/g, '$1')
}

function regExpEscape (s) {
  return s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')
}


/***/ }),

/***/ "./node_modules/once/once.js":
/*!***********************************!*\
  !*** ./node_modules/once/once.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var wrappy = __webpack_require__(/*! wrappy */ "./node_modules/wrappy/wrappy.js")
module.exports = wrappy(once)
module.exports.strict = wrappy(onceStrict)

once.proto = once(function () {
  Object.defineProperty(Function.prototype, 'once', {
    value: function () {
      return once(this)
    },
    configurable: true
  })

  Object.defineProperty(Function.prototype, 'onceStrict', {
    value: function () {
      return onceStrict(this)
    },
    configurable: true
  })
})

function once (fn) {
  var f = function () {
    if (f.called) return f.value
    f.called = true
    return f.value = fn.apply(this, arguments)
  }
  f.called = false
  return f
}

function onceStrict (fn) {
  var f = function () {
    if (f.called)
      throw new Error(f.onceError)
    f.called = true
    return f.value = fn.apply(this, arguments)
  }
  var name = fn.name || 'Function wrapped with `once`'
  f.onceError = name + " shouldn't be called more than once"
  f.called = false
  return f
}


/***/ }),

/***/ "./node_modules/packet-reader/index.js":
/*!*********************************************!*\
  !*** ./node_modules/packet-reader/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assert = __webpack_require__(/*! assert */ "assert")

var Reader = module.exports = function(options) {
  //TODO - remove for version 1.0
  if(typeof options == 'number') {
    options = { headerSize: options }
  }
  options = options || {}
  this.offset = 0
  this.lastChunk = false
  this.chunk = null
  this.chunkLength = 0
  this.headerSize = options.headerSize || 0
  this.lengthPadding = options.lengthPadding || 0
  this.header = null
  assert(this.headerSize < 2, 'pre-length header of more than 1 byte length not currently supported')
}

Reader.prototype.addChunk = function(chunk) {
  if (!this.chunk || this.offset === this.chunkLength) {
    this.chunk = chunk
    this.chunkLength = chunk.length
    this.offset = 0
    return
  }

  var newChunkLength = chunk.length
  var newLength = this.chunkLength + newChunkLength

  if (newLength > this.chunk.length) {
    var newBufferLength = this.chunk.length * 2
    while (newLength >= newBufferLength) {
      newBufferLength *= 2
    }
    var newBuffer = new Buffer(newBufferLength)
    this.chunk.copy(newBuffer)
    this.chunk = newBuffer
  }
  chunk.copy(this.chunk, this.chunkLength)
  this.chunkLength = newLength
}

Reader.prototype.read = function() {
  if(this.chunkLength < (this.headerSize + 4 + this.offset)) {
    return false
  }

  if(this.headerSize) {
    this.header = this.chunk[this.offset]
  }

  //read length of next item
  var length = this.chunk.readUInt32BE(this.offset + this.headerSize) + this.lengthPadding

  //next item spans more chunks than we have
  var remaining = this.chunkLength - (this.offset + 4 + this.headerSize)
  if(length > remaining) {
    return false
  }

  this.offset += (this.headerSize + 4)
  var result = this.chunk.slice(this.offset, this.offset + length)
  this.offset += length
  return result
}


/***/ }),

/***/ "./node_modules/path-is-absolute/index.js":
/*!************************************************!*\
  !*** ./node_modules/path-is-absolute/index.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function posix(path) {
	return path.charAt(0) === '/';
}

function win32(path) {
	// https://github.com/nodejs/node/blob/b3fcc245fb25539909ef1d5eaa01dbf92e168633/lib/path.js#L56
	var splitDeviceRe = /^([a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/]+[^\\\/]+)?([\\\/])?([\s\S]*?)$/;
	var result = splitDeviceRe.exec(path);
	var device = result[1] || '';
	var isUnc = Boolean(device && device.charAt(1) !== ':');

	// UNC paths are always absolute
	return Boolean(result[2] || isUnc);
}

module.exports = process.platform === 'win32' ? win32 : posix;
module.exports.posix = posix;
module.exports.win32 = win32;


/***/ }),

/***/ "./node_modules/pg-connection-string/index.js":
/*!****************************************************!*\
  !*** ./node_modules/pg-connection-string/index.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var url = __webpack_require__(/*! url */ "url");

//Parse method copied from https://github.com/brianc/node-postgres
//Copyright (c) 2010-2014 Brian Carlson (brian.m.carlson@gmail.com)
//MIT License

//parses a connection string
function parse(str) {
  var config;
  //unix socket
  if(str.charAt(0) === '/') {
    config = str.split(' ');
    return { host: config[0], database: config[1] };
  }
  // url parse expects spaces encoded as %20
  if(/ |%[^a-f0-9]|%[a-f0-9][^a-f0-9]/i.test(str)) {
    str = encodeURI(str).replace(/\%25(\d\d)/g, "%$1");
  }
  var result = url.parse(str, true);
  config = {};

  if (result.query.application_name) {
    config.application_name = result.query.application_name;
  }
  if (result.query.fallback_application_name) {
    config.fallback_application_name = result.query.fallback_application_name;
  }

  config.port = result.port;
  if(result.protocol == 'socket:') {
    config.host = decodeURI(result.pathname);
    config.database = result.query.db;
    config.client_encoding = result.query.encoding;
    return config;
  }
  config.host = result.hostname;

  // result.pathname is not always guaranteed to have a '/' prefix (e.g. relative urls)
  // only strip the slash if it is present.
  var pathname = result.pathname;
  if (pathname && pathname.charAt(0) === '/') {
    pathname = result.pathname.slice(1) || null;
  }
  config.database = pathname && decodeURI(pathname);

  var auth = (result.auth || ':').split(':');
  config.user = auth[0];
  config.password = auth.splice(1).join(':');

  var ssl = result.query.ssl;
  if (ssl === 'true' || ssl === '1') {
    config.ssl = true;
  }

  return config;
}

module.exports = {
  parse: parse
};


/***/ }),

/***/ "./node_modules/pg-pool/index.js":
/*!***************************************!*\
  !*** ./node_modules/pg-pool/index.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const EventEmitter = __webpack_require__(/*! events */ "events").EventEmitter

const NOOP = function () { }

const removeWhere = (list, predicate) => {
  const i = list.findIndex(predicate)

  return i === -1
    ? undefined
    : list.splice(i, 1)[0]
}

class IdleItem {
  constructor (client, timeoutId) {
    this.client = client
    this.timeoutId = timeoutId
  }
}

function throwOnRelease () {
  throw new Error('Release called on client which has already been released to the pool.')
}

function release (client, err) {
  client.release = throwOnRelease
  if (err || this.ending) {
    this._remove(client)
    this._pulseQueue()
    return
  }

  // idle timeout
  let tid
  if (this.options.idleTimeoutMillis) {
    tid = setTimeout(() => {
      this.log('remove idle client')
      this._remove(client)
    }, this.options.idleTimeoutMillis)
  }

  this._idle.push(new IdleItem(client, tid))
  this._pulseQueue()
}

function promisify (Promise, callback) {
  if (callback) {
    return { callback: callback, result: undefined }
  }
  let rej
  let res
  const cb = function (err, client) {
    err ? rej(err) : res(client)
  }
  const result = new Promise(function (resolve, reject) {
    res = resolve
    rej = reject
  })
  return { callback: cb, result: result }
}

class Pool extends EventEmitter {
  constructor (options, Client) {
    super()
    this.options = Object.assign({}, options)
    this.options.max = this.options.max || this.options.poolSize || 10
    this.log = this.options.log || function () { }
    this.Client = this.options.Client || Client || __webpack_require__(/*! pg */ "./node_modules/pg/lib/index.js").Client
    this.Promise = this.options.Promise || global.Promise

    if (typeof this.options.idleTimeoutMillis === 'undefined') {
      this.options.idleTimeoutMillis = 10000
    }

    this._clients = []
    this._idle = []
    this._pendingQueue = []
    this._endCallback = undefined
    this.ending = false
  }

  _isFull () {
    return this._clients.length >= this.options.max
  }

  _pulseQueue () {
    this.log('pulse queue')
    if (this.ending) {
      this.log('pulse queue on ending')
      if (this._idle.length) {
        this._idle.slice().map(item => {
          this._remove(item.client)
        })
      }
      if (!this._clients.length) {
        this._endCallback()
      }
      return
    }
    // if we don't have any waiting, do nothing
    if (!this._pendingQueue.length) {
      this.log('no queued requests')
      return
    }
    // if we don't have any idle clients and we have no more room do nothing
    if (!this._idle.length && this._isFull()) {
      return
    }
    const waiter = this._pendingQueue.shift()
    if (this._idle.length) {
      const idleItem = this._idle.pop()
      clearTimeout(idleItem.timeoutId)
      const client = idleItem.client
      client.release = release.bind(this, client)
      this.emit('acquire', client)
      return waiter(undefined, client, client.release)
    }
    if (!this._isFull()) {
      return this.connect(waiter)
    }
    throw new Error('unexpected condition')
  }

  _remove (client) {
    const removed = removeWhere(
      this._idle,
      item => item.client === client
    )

    if (removed !== undefined) {
      clearTimeout(removed.timeoutId)
    }

    this._clients = this._clients.filter(c => c !== client)
    client.end()
    this.emit('remove', client)
  }

  connect (cb) {
    if (this.ending) {
      const err = new Error('Cannot use a pool after calling end on the pool')
      return cb ? cb(err) : this.Promise.reject(err)
    }

    // if we don't have to connect a new client, don't do so
    if (this._clients.length >= this.options.max || this._idle.length) {
      const response = promisify(this.Promise, cb)
      const result = response.result

      // if we have idle clients schedule a pulse immediately
      if (this._idle.length) {
        process.nextTick(() => this._pulseQueue())
      }

      if (!this.options.connectionTimeoutMillis) {
        this._pendingQueue.push(response.callback)
        return result
      }

      // set connection timeout on checking out an existing client
      const tid = setTimeout(() => {
        // remove the callback from pending waiters because
        // we're going to call it with a timeout error
        this._pendingQueue = this._pendingQueue.filter(cb => cb === response.callback)
        response.callback(new Error('timeout exceeded when trying to connect'))
      }, this.options.connectionTimeoutMillis)

      this._pendingQueue.push(function (err, res, done) {
        clearTimeout(tid)
        response.callback(err, res, done)
      })
      return result
    }

    const client = new this.Client(this.options)
    this._clients.push(client)
    const idleListener = (err) => {
      err.client = client
      client.removeListener('error', idleListener)
      client.on('error', () => {
        this.log('additional client error after disconnection due to error', err)
      })
      this._remove(client)
      // TODO - document that once the pool emits an error
      // the client has already been closed & purged and is unusable
      this.emit('error', err, client)
    }

    this.log('connecting new client')

    // connection timeout logic
    let tid
    let timeoutHit = false
    if (this.options.connectionTimeoutMillis) {
      tid = setTimeout(() => {
        this.log('ending client due to timeout')
        timeoutHit = true
        // force kill the node driver, and let libpq do its teardown
        client.connection ? client.connection.stream.destroy() : client.end()
      }, this.options.connectionTimeoutMillis)
    }

    const response = promisify(this.Promise, cb)
    cb = response.callback

    this.log('connecting new client')
    client.connect((err) => {
      this.log('new client connected')
      if (tid) {
        clearTimeout(tid)
      }
      client.on('error', idleListener)
      if (err) {
        // remove the dead client from our list of clients
        this._clients = this._clients.filter(c => c !== client)
        if (timeoutHit) {
          err.message = 'Connection terminiated due to connection timeout'
        }
        cb(err, undefined, NOOP)
      } else {
        client.release = release.bind(this, client)
        this.emit('connect', client)
        this.emit('acquire', client)
        if (this.options.verify) {
          this.options.verify(client, cb)
        } else {
          cb(undefined, client, client.release)
        }
      }
    })
    return response.result
  }

  query (text, values, cb) {
    // guard clause against passing a function as the first parameter
    if (typeof text === 'function') {
      const response = promisify(this.Promise, text)
      setImmediate(function () {
        return response.callback(new Error('Passing a function as the first parameter to pool.query is not supported'))
      })
      return response.result
    }

    // allow plain text query without values
    if (typeof values === 'function') {
      cb = values
      values = undefined
    }
    const response = promisify(this.Promise, cb)
    cb = response.callback
    this.connect((err, client) => {
      if (err) {
        return cb(err)
      }
      this.log('dispatching query')
      client.query(text, values, (err, res) => {
        this.log('query dispatched')
        client.release(err)
        if (err) {
          return cb(err)
        } else {
          return cb(undefined, res)
        }
      })
    })
    return response.result
  }

  end (cb) {
    this.log('ending')
    if (this.ending) {
      const err = new Error('Called end on pool more than once')
      return cb ? cb(err) : this.Promise.reject(err)
    }
    this.ending = true
    const promised = promisify(this.Promise, cb)
    this._endCallback = promised.callback
    this._pulseQueue()
    return promised.result
  }

  get waitingCount () {
    return this._pendingQueue.length
  }

  get idleCount () {
    return this._idle.length
  }

  get totalCount () {
    return this._clients.length
  }
}
module.exports = Pool


/***/ }),

/***/ "./node_modules/pg-types/index.js":
/*!****************************************!*\
  !*** ./node_modules/pg-types/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var textParsers = __webpack_require__(/*! ./lib/textParsers */ "./node_modules/pg-types/lib/textParsers.js");
var binaryParsers = __webpack_require__(/*! ./lib/binaryParsers */ "./node_modules/pg-types/lib/binaryParsers.js");
var arrayParser = __webpack_require__(/*! ./lib/arrayParser */ "./node_modules/pg-types/lib/arrayParser.js");

exports.getTypeParser = getTypeParser;
exports.setTypeParser = setTypeParser;
exports.arrayParser = arrayParser;

var typeParsers = {
  text: {},
  binary: {}
};

//the empty parse function
function noParse (val) {
  return String(val);
};

//returns a function used to convert a specific type (specified by
//oid) into a result javascript type
//note: the oid can be obtained via the following sql query:
//SELECT oid FROM pg_type WHERE typname = 'TYPE_NAME_HERE';
function getTypeParser (oid, format) {
  format = format || 'text';
  if (!typeParsers[format]) {
    return noParse;
  }
  return typeParsers[format][oid] || noParse;
};

function setTypeParser (oid, format, parseFn) {
  if(typeof format == 'function') {
    parseFn = format;
    format = 'text';
  }
  typeParsers[format][oid] = parseFn;
};

textParsers.init(function(oid, converter) {
  typeParsers.text[oid] = converter;
});

binaryParsers.init(function(oid, converter) {
  typeParsers.binary[oid] = converter;
});


/***/ }),

/***/ "./node_modules/pg-types/lib/arrayParser.js":
/*!**************************************************!*\
  !*** ./node_modules/pg-types/lib/arrayParser.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var array = __webpack_require__(/*! postgres-array */ "./node_modules/postgres-array/index.js");

module.exports = {
  create: function (source, transform) {
    return {
      parse: function() {
        return array.parse(source, transform);
      }
    };
  }
};


/***/ }),

/***/ "./node_modules/pg-types/lib/binaryParsers.js":
/*!****************************************************!*\
  !*** ./node_modules/pg-types/lib/binaryParsers.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var parseBits = function(data, bits, offset, invert, callback) {
  offset = offset || 0;
  invert = invert || false;
  callback = callback || function(lastValue, newValue, bits) { return (lastValue * Math.pow(2, bits)) + newValue; };
  var offsetBytes = offset >> 3;

  var inv = function(value) {
    if (invert) {
      return ~value & 0xff;
    }

    return value;
  };

  // read first (maybe partial) byte
  var mask = 0xff;
  var firstBits = 8 - (offset % 8);
  if (bits < firstBits) {
    mask = (0xff << (8 - bits)) & 0xff;
    firstBits = bits;
  }

  if (offset) {
    mask = mask >> (offset % 8);
  }

  var result = 0;
  if ((offset % 8) + bits >= 8) {
    result = callback(0, inv(data[offsetBytes]) & mask, firstBits);
  }

  // read bytes
  var bytes = (bits + offset) >> 3;
  for (var i = offsetBytes + 1; i < bytes; i++) {
    result = callback(result, inv(data[i]), 8);
  }

  // bits to read, that are not a complete byte
  var lastBits = (bits + offset) % 8;
  if (lastBits > 0) {
    result = callback(result, inv(data[bytes]) >> (8 - lastBits), lastBits);
  }

  return result;
};

var parseFloatFromBits = function(data, precisionBits, exponentBits) {
  var bias = Math.pow(2, exponentBits - 1) - 1;
  var sign = parseBits(data, 1);
  var exponent = parseBits(data, exponentBits, 1);

  if (exponent === 0) {
    return 0;
  }

  // parse mantissa
  var precisionBitsCounter = 1;
  var parsePrecisionBits = function(lastValue, newValue, bits) {
    if (lastValue === 0) {
      lastValue = 1;
    }

    for (var i = 1; i <= bits; i++) {
      precisionBitsCounter /= 2;
      if ((newValue & (0x1 << (bits - i))) > 0) {
        lastValue += precisionBitsCounter;
      }
    }

    return lastValue;
  };

  var mantissa = parseBits(data, precisionBits, exponentBits + 1, false, parsePrecisionBits);

  // special cases
  if (exponent == (Math.pow(2, exponentBits + 1) - 1)) {
    if (mantissa === 0) {
      return (sign === 0) ? Infinity : -Infinity;
    }

    return NaN;
  }

  // normale number
  return ((sign === 0) ? 1 : -1) * Math.pow(2, exponent - bias) * mantissa;
};

var parseInt16 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 15, 1, true) + 1);
  }

  return parseBits(value, 15, 1);
};

var parseInt32 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 31, 1, true) + 1);
  }

  return parseBits(value, 31, 1);
};

var parseFloat32 = function(value) {
  return parseFloatFromBits(value, 23, 8);
};

var parseFloat64 = function(value) {
  return parseFloatFromBits(value, 52, 11);
};

var parseNumeric = function(value) {
  var sign = parseBits(value, 16, 32);
  if (sign == 0xc000) {
    return NaN;
  }

  var weight = Math.pow(10000, parseBits(value, 16, 16));
  var result = 0;

  var digits = [];
  var ndigits = parseBits(value, 16);
  for (var i = 0; i < ndigits; i++) {
    result += parseBits(value, 16, 64 + (16 * i)) * weight;
    weight /= 10000;
  }

  var scale = Math.pow(10, parseBits(value, 16, 48));
  return ((sign === 0) ? 1 : -1) * Math.round(result * scale) / scale;
};

var parseDate = function(isUTC, value) {
  var sign = parseBits(value, 1);
  var rawValue = parseBits(value, 63, 1);

  // discard usecs and shift from 2000 to 1970
  var result = new Date((((sign === 0) ? 1 : -1) * rawValue / 1000) + 946684800000);

  if (!isUTC) {
    result.setTime(result.getTime() + result.getTimezoneOffset() * 60000);
  }

  // add microseconds to the date
  result.usec = rawValue % 1000;
  result.getMicroSeconds = function() {
    return this.usec;
  };
  result.setMicroSeconds = function(value) {
    this.usec = value;
  };
  result.getUTCMicroSeconds = function() {
    return this.usec;
  };

  return result;
};

var parseArray = function(value) {
  var dim = parseBits(value, 32);

  var flags = parseBits(value, 32, 32);
  var elementType = parseBits(value, 32, 64);

  var offset = 96;
  var dims = [];
  for (var i = 0; i < dim; i++) {
    // parse dimension
    dims[i] = parseBits(value, 32, offset);
    offset += 32;

    // ignore lower bounds
    offset += 32;
  }

  var parseElement = function(elementType) {
    // parse content length
    var length = parseBits(value, 32, offset);
    offset += 32;

    // parse null values
    if (length == 0xffffffff) {
      return null;
    }

    var result;
    if ((elementType == 0x17) || (elementType == 0x14)) {
      // int/bigint
      result = parseBits(value, length * 8, offset);
      offset += length * 8;
      return result;
    }
    else if (elementType == 0x19) {
      // string
      result = value.toString(this.encoding, offset >> 3, (offset += (length << 3)) >> 3);
      return result;
    }
    else {
      console.log("ERROR: ElementType not implemented: " + elementType);
    }
  };

  var parse = function(dimension, elementType) {
    var array = [];
    var i;

    if (dimension.length > 1) {
      var count = dimension.shift();
      for (i = 0; i < count; i++) {
        array[i] = parse(dimension, elementType);
      }
      dimension.unshift(count);
    }
    else {
      for (i = 0; i < dimension[0]; i++) {
        array[i] = parseElement(elementType);
      }
    }

    return array;
  };

  return parse(dims, elementType);
};

var parseText = function(value) {
  return value.toString('utf8');
};

var parseBool = function(value) {
  if(value === null) return null;
  return (parseBits(value, 8) > 0);
};

var init = function(register) {
  register(21, parseInt16);
  register(23, parseInt32);
  register(26, parseInt32);
  register(1700, parseNumeric);
  register(700, parseFloat32);
  register(701, parseFloat64);
  register(16, parseBool);
  register(1114, parseDate.bind(null, false));
  register(1184, parseDate.bind(null, true));
  register(1000, parseArray);
  register(1007, parseArray);
  register(1016, parseArray);
  register(1008, parseArray);
  register(1009, parseArray);
  register(25, parseText);
};

module.exports = {
  init: init
};


/***/ }),

/***/ "./node_modules/pg-types/lib/textParsers.js":
/*!**************************************************!*\
  !*** ./node_modules/pg-types/lib/textParsers.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var array = __webpack_require__(/*! postgres-array */ "./node_modules/postgres-array/index.js")
var arrayParser = __webpack_require__(/*! ./arrayParser */ "./node_modules/pg-types/lib/arrayParser.js");
var parseDate = __webpack_require__(/*! postgres-date */ "./node_modules/postgres-date/index.js");
var parseInterval = __webpack_require__(/*! postgres-interval */ "./node_modules/postgres-interval/index.js");
var parseByteA = __webpack_require__(/*! postgres-bytea */ "./node_modules/postgres-bytea/index.js");

function allowNull (fn) {
  return function nullAllowed (value) {
    if (value === null) return value
    return fn(value)
  }
}

function parseBool (value) {
  if (value === null) return value
  return value === 'TRUE' ||
    value === 't' ||
    value === 'true' ||
    value === 'y' ||
    value === 'yes' ||
    value === 'on' ||
    value === '1';
}

function parseBoolArray (value) {
  if (!value) return null
  return array.parse(value, parseBool)
}

function parseBaseTenInt (string) {
  return parseInt(string, 10)
}

function parseIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(parseBaseTenInt))
}

function parseBigIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(function (entry) {
    return parseBigInteger(entry).trim()
  }))
}

var parsePointArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parsePoint(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseFloatArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parseFloat(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseStringArray = function(value) {
  if(!value) { return null; }

  var p = arrayParser.create(value);
  return p.parse();
};

var parseDateArray = function(value) {
  if (!value) { return null; }

  var p = arrayParser.create(value, function(entry) {
    if (entry !== null) {
      entry = parseDate(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseByteAArray = function(value) {
  if (!value) { return null; }

  return array.parse(value, allowNull(parseByteA));
};

var parseInteger = function(value) {
  return parseInt(value, 10);
};

var parseBigInteger = function(value) {
  var valStr = String(value);
  if (/^\d+$/.test(valStr)) { return valStr; }
  return value;
};

var parseJsonArray = function(value) {
  var arr = parseStringArray(value);

  if (!arr) {
    return arr;
  }

  return arr.map(function(el) { return JSON.parse(el); });
};

var parsePoint = function(value) {
  if (value[0] !== '(') { return null; }

  value = value.substring( 1, value.length - 1 ).split(',');

  return {
    x: parseFloat(value[0])
  , y: parseFloat(value[1])
  };
};

var parseCircle = function(value) {
  if (value[0] !== '<' && value[1] !== '(') { return null; }

  var point = '(';
  var radius = '';
  var pointParsed = false;
  for (var i = 2; i < value.length - 1; i++){
    if (!pointParsed) {
      point += value[i];
    }

    if (value[i] === ')') {
      pointParsed = true;
      continue;
    } else if (!pointParsed) {
      continue;
    }

    if (value[i] === ','){
      continue;
    }

    radius += value[i];
  }
  var result = parsePoint(point);
  result.radius = parseFloat(radius);

  return result;
};

var init = function(register) {
  register(20, parseBigInteger); // int8
  register(21, parseInteger); // int2
  register(23, parseInteger); // int4
  register(26, parseInteger); // oid
  register(700, parseFloat); // float4/real
  register(701, parseFloat); // float8/double
  register(16, parseBool);
  register(1082, parseDate); // date
  register(1114, parseDate); // timestamp without timezone
  register(1184, parseDate); // timestamp
  register(600, parsePoint); // point
  register(651, parseStringArray); // cidr[]
  register(718, parseCircle); // circle
  register(1000, parseBoolArray);
  register(1001, parseByteAArray);
  register(1005, parseIntegerArray); // _int2
  register(1007, parseIntegerArray); // _int4
  register(1028, parseIntegerArray); // oid[]
  register(1016, parseBigIntegerArray); // _int8
  register(1017, parsePointArray); // point[]
  register(1021, parseFloatArray); // _float4
  register(1022, parseFloatArray); // _float8
  register(1231, parseFloatArray); // _numeric
  register(1014, parseStringArray); //char
  register(1015, parseStringArray); //varchar
  register(1008, parseStringArray);
  register(1009, parseStringArray);
  register(1040, parseStringArray); // macaddr[]
  register(1041, parseStringArray); // inet[]
  register(1115, parseDateArray); // timestamp without time zone[]
  register(1182, parseDateArray); // _date
  register(1185, parseDateArray); // timestamp with time zone[]
  register(1186, parseInterval);
  register(17, parseByteA);
  register(114, JSON.parse.bind(JSON)); // json
  register(3802, JSON.parse.bind(JSON)); // jsonb
  register(199, parseJsonArray); // json[]
  register(3807, parseJsonArray); // jsonb[]
  register(3907, parseStringArray); // numrange[]
  register(2951, parseStringArray); // uuid[]
  register(791, parseStringArray); // money[]
  register(1183, parseStringArray); // time[]
  register(1270, parseStringArray); // timetz[]
};

module.exports = {
  init: init
};


/***/ }),

/***/ "./node_modules/pg/lib/client.js":
/*!***************************************!*\
  !*** ./node_modules/pg/lib/client.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var EventEmitter = __webpack_require__(/*! events */ "events").EventEmitter
var util = __webpack_require__(/*! util */ "util")
var utils = __webpack_require__(/*! ./utils */ "./node_modules/pg/lib/utils.js")
var pgPass = __webpack_require__(/*! pgpass */ "./node_modules/pgpass/lib/index.js")
var TypeOverrides = __webpack_require__(/*! ./type-overrides */ "./node_modules/pg/lib/type-overrides.js")

var ConnectionParameters = __webpack_require__(/*! ./connection-parameters */ "./node_modules/pg/lib/connection-parameters.js")
var Query = __webpack_require__(/*! ./query */ "./node_modules/pg/lib/query.js")
var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/pg/lib/defaults.js")
var Connection = __webpack_require__(/*! ./connection */ "./node_modules/pg/lib/connection.js")

var Client = function (config) {
  EventEmitter.call(this)

  this.connectionParameters = new ConnectionParameters(config)
  this.user = this.connectionParameters.user
  this.database = this.connectionParameters.database
  this.port = this.connectionParameters.port
  this.host = this.connectionParameters.host
  this.password = this.connectionParameters.password
  this.replication = this.connectionParameters.replication

  var c = config || {}

  this._types = new TypeOverrides(c.types)
  this._ending = false
  this._connecting = false
  this._connected = false
  this._connectionError = false

  this.connection = c.connection || new Connection({
    stream: c.stream,
    ssl: this.connectionParameters.ssl,
    keepAlive: c.keepAlive || false,
    encoding: this.connectionParameters.client_encoding || 'utf8'
  })
  this.queryQueue = []
  this.binary = c.binary || defaults.binary
  this.processID = null
  this.secretKey = null
  this.ssl = this.connectionParameters.ssl || false
}

util.inherits(Client, EventEmitter)

Client.prototype.connect = function (callback) {
  var self = this
  var con = this.connection
  if (this._connecting || this._connected) {
    const err = new Error('Client has already been connected. You cannot reuse a client.')
    if (callback) {
      callback(err)
      return undefined
    }
    return Promise.reject(err)
  }
  this._connecting = true

  if (this.host && this.host.indexOf('/') === 0) {
    con.connect(this.host + '/.s.PGSQL.' + this.port)
  } else {
    con.connect(this.port, this.host)
  }

  // once connection is established send startup message
  con.on('connect', function () {
    if (self.ssl) {
      con.requestSsl()
    } else {
      con.startup(self.getStartupConf())
    }
  })

  con.on('sslconnect', function () {
    con.startup(self.getStartupConf())
  })

  function checkPgPass (cb) {
    return function (msg) {
      if (self.password !== null) {
        cb(msg)
      } else {
        pgPass(self.connectionParameters, function (pass) {
          if (undefined !== pass) {
            self.connectionParameters.password = self.password = pass
          }
          cb(msg)
        })
      }
    }
  }

  // password request handling
  con.on('authenticationCleartextPassword', checkPgPass(function () {
    con.password(self.password)
  }))

  // password request handling
  con.on('authenticationMD5Password', checkPgPass(function (msg) {
    con.password(utils.postgresMd5PasswordHash(self.user, self.password, msg.salt))
  }))

  con.once('backendKeyData', function (msg) {
    self.processID = msg.processID
    self.secretKey = msg.secretKey
  })

  const connectingErrorHandler = (err) => {
    if (this._connectionError) {
      return
    }
    this._connectionError = true
    if (callback) {
      return callback(err)
    }
    this.emit('error', err)
  }

  const connectedErrorHandler = (err) => {
    if (this.activeQuery) {
      var activeQuery = self.activeQuery
      this.activeQuery = null
      return activeQuery.handleError(err, con)
    }
    this.emit('error', err)
  }

  con.on('error', connectingErrorHandler)

  // hook up query handling events to connection
  // after the connection initially becomes ready for queries
  con.once('readyForQuery', function () {
    self._connecting = false
    self._connected = true
    self._attachListeners(con)
    con.removeListener('error', connectingErrorHandler)
    con.on('error', connectedErrorHandler)

    // process possible callback argument to Client#connect
    if (callback) {
      callback(null, self)
      // remove callback for proper error handling
      // after the connect event
      callback = null
    }
    self.emit('connect')
  })

  con.on('readyForQuery', function () {
    var activeQuery = self.activeQuery
    self.activeQuery = null
    self.readyForQuery = true
    if (activeQuery) {
      activeQuery.handleReadyForQuery(con)
    }
    self._pulseQueryQueue()
  })

  con.once('end', () => {
    if (this.activeQuery) {
      var disconnectError = new Error('Connection terminated')
      this.activeQuery.handleError(disconnectError, con)
      this.activeQuery = null
    }
    if (!this._ending) {
      // if the connection is ended without us calling .end()
      // on this client then we have an unexpected disconnection
      // treat this as an error unless we've already emitted an error
      // during connection.
      const error = new Error('Connection terminated unexpectedly')
      if (this._connecting && !this._connectionError) {
        if (callback) {
          callback(error)
        } else {
          this.emit('error', error)
        }
      } else if (!this._connectionError) {
        this.emit('error', error)
      }
    }
    this.emit('end')
  })

  con.on('notice', function (msg) {
    self.emit('notice', msg)
  })

  if (!callback) {
    return new global.Promise((resolve, reject) => {
      this.once('error', reject)
      this.once('connect', () => {
        this.removeListener('error', reject)
        resolve()
      })
    })
  }
}

Client.prototype._attachListeners = function (con) {
  const self = this
  // delegate rowDescription to active query
  con.on('rowDescription', function (msg) {
    self.activeQuery.handleRowDescription(msg)
  })

  // delegate dataRow to active query
  con.on('dataRow', function (msg) {
    self.activeQuery.handleDataRow(msg)
  })

  // delegate portalSuspended to active query
  con.on('portalSuspended', function (msg) {
    self.activeQuery.handlePortalSuspended(con)
  })

  // deletagate emptyQuery to active query
  con.on('emptyQuery', function (msg) {
    self.activeQuery.handleEmptyQuery(con)
  })

  // delegate commandComplete to active query
  con.on('commandComplete', function (msg) {
    self.activeQuery.handleCommandComplete(msg, con)
  })

  // if a prepared statement has a name and properly parses
  // we track that its already been executed so we don't parse
  // it again on the same client
  con.on('parseComplete', function (msg) {
    if (self.activeQuery.name) {
      con.parsedStatements[self.activeQuery.name] = true
    }
  })

  con.on('copyInResponse', function (msg) {
    self.activeQuery.handleCopyInResponse(self.connection)
  })

  con.on('copyData', function (msg) {
    self.activeQuery.handleCopyData(msg, self.connection)
  })

  con.on('notification', function (msg) {
    self.emit('notification', msg)
  })
}

Client.prototype.getStartupConf = function () {
  var params = this.connectionParameters

  var data = {
    user: params.user,
    database: params.database
  }

  var appName = params.application_name || params.fallback_application_name
  if (appName) {
    data.application_name = appName
  }
  if (params.replication) {
    data.replication = '' + params.replication
  }
  if (params.statement_timeout) {
    data.statement_timeout = String(parseInt(params.statement_timeout, 10))
  }

  return data
}

Client.prototype.cancel = function (client, query) {
  if (client.activeQuery === query) {
    var con = this.connection

    if (this.host && this.host.indexOf('/') === 0) {
      con.connect(this.host + '/.s.PGSQL.' + this.port)
    } else {
      con.connect(this.port, this.host)
    }

    // once connection is established send cancel message
    con.on('connect', function () {
      con.cancel(client.processID, client.secretKey)
    })
  } else if (client.queryQueue.indexOf(query) !== -1) {
    client.queryQueue.splice(client.queryQueue.indexOf(query), 1)
  }
}

Client.prototype.setTypeParser = function (oid, format, parseFn) {
  return this._types.setTypeParser(oid, format, parseFn)
}

Client.prototype.getTypeParser = function (oid, format) {
  return this._types.getTypeParser(oid, format)
}

// Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
Client.prototype.escapeIdentifier = function (str) {
  var escaped = '"'

  for (var i = 0; i < str.length; i++) {
    var c = str[i]
    if (c === '"') {
      escaped += c + c
    } else {
      escaped += c
    }
  }

  escaped += '"'

  return escaped
}

// Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
Client.prototype.escapeLiteral = function (str) {
  var hasBackslash = false
  var escaped = '\''

  for (var i = 0; i < str.length; i++) {
    var c = str[i]
    if (c === '\'') {
      escaped += c + c
    } else if (c === '\\') {
      escaped += c + c
      hasBackslash = true
    } else {
      escaped += c
    }
  }

  escaped += '\''

  if (hasBackslash === true) {
    escaped = ' E' + escaped
  }

  return escaped
}

Client.prototype._pulseQueryQueue = function () {
  if (this.readyForQuery === true) {
    this.activeQuery = this.queryQueue.shift()
    if (this.activeQuery) {
      this.readyForQuery = false
      this.hasExecuted = true
      this.activeQuery.submit(this.connection)
    } else if (this.hasExecuted) {
      this.activeQuery = null
      this.emit('drain')
    }
  }
}

Client.prototype.query = function (config, values, callback) {
  // can take in strings, config object or query object
  var query
  var result
  if (typeof config.submit === 'function') {
    result = query = config
    if (typeof values === 'function') {
      query.callback = query.callback || values
    }
  } else {
    query = new Query(config, values, callback)
    if (!query.callback) {
      let resolveOut, rejectOut
      result = new Promise((resolve, reject) => {
        resolveOut = resolve
        rejectOut = reject
      })
      query.callback = (err, res) => err ? rejectOut(err) : resolveOut(res)
    }
  }

  if (this.binary && !query.binary) {
    query.binary = true
  }
  if (query._result) {
    query._result._getTypeParser = this._types.getTypeParser.bind(this._types)
  }

  this.queryQueue.push(query)
  this._pulseQueryQueue()
  return result
}

Client.prototype.end = function (cb) {
  this._ending = true
  if (this.activeQuery) {
    // if we have an active query we need to force a disconnect
    // on the socket - otherwise a hung query could block end forever
    this.connection.stream.destroy(new Error('Connection terminated by user'))
    return cb ? cb() : Promise.resolve()
  }
  if (cb) {
    this.connection.end()
    this.connection.once('end', cb)
  } else {
    return new global.Promise((resolve, reject) => {
      this.connection.end()
      this.connection.once('end', resolve)
    })
  }
}

// expose a Query constructor
Client.Query = Query

module.exports = Client


/***/ }),

/***/ "./node_modules/pg/lib/connection-parameters.js":
/*!******************************************************!*\
  !*** ./node_modules/pg/lib/connection-parameters.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var dns = __webpack_require__(/*! dns */ "dns")

var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/pg/lib/defaults.js")

var parse = __webpack_require__(/*! pg-connection-string */ "./node_modules/pg-connection-string/index.js").parse // parses a connection string

var val = function (key, config, envVar) {
  if (envVar === undefined) {
    envVar = process.env[ 'PG' + key.toUpperCase() ]
  } else if (envVar === false) {
    // do nothing ... use false
  } else {
    envVar = process.env[ envVar ]
  }

  return config[key] ||
    envVar ||
    defaults[key]
}

var useSsl = function () {
  switch (process.env.PGSSLMODE) {
    case 'disable':
      return false
    case 'prefer':
    case 'require':
    case 'verify-ca':
    case 'verify-full':
      return true
  }
  return defaults.ssl
}

var ConnectionParameters = function (config) {
  // if a string is passed, it is a raw connection string so we parse it into a config
  config = typeof config === 'string' ? parse(config) : config || {}

  // if the config has a connectionString defined, parse IT into the config we use
  // this will override other default values with what is stored in connectionString
  if (config.connectionString) {
    config = Object.assign({}, config, parse(config.connectionString))
  }

  this.user = val('user', config)
  this.database = val('database', config)
  this.port = parseInt(val('port', config), 10)
  this.host = val('host', config)
  this.password = val('password', config)
  this.binary = val('binary', config)
  this.ssl = typeof config.ssl === 'undefined' ? useSsl() : config.ssl
  this.client_encoding = val('client_encoding', config)
  this.replication = val('replication', config)
  // a domain socket begins with '/'
  this.isDomainSocket = (!(this.host || '').indexOf('/'))

  this.application_name = val('application_name', config, 'PGAPPNAME')
  this.fallback_application_name = val('fallback_application_name', config, false)
  this.statement_timeout = val('statement_timeout', config, false)
}

// Convert arg to a string, surround in single quotes, and escape single quotes and backslashes
var quoteParamValue = function (value) {
  return "'" + ('' + value).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'"
}

var add = function (params, config, paramName) {
  var value = config[paramName]
  if (value) {
    params.push(paramName + '=' + quoteParamValue(value))
  }
}

ConnectionParameters.prototype.getLibpqConnectionString = function (cb) {
  var params = []
  add(params, this, 'user')
  add(params, this, 'password')
  add(params, this, 'port')
  add(params, this, 'application_name')
  add(params, this, 'fallback_application_name')

  var ssl = typeof this.ssl === 'object' ? this.ssl : {sslmode: this.ssl}
  add(params, ssl, 'sslmode')
  add(params, ssl, 'sslca')
  add(params, ssl, 'sslkey')
  add(params, ssl, 'sslcert')
  add(params, ssl, 'sslrootcert')

  if (this.database) {
    params.push('dbname=' + quoteParamValue(this.database))
  }
  if (this.replication) {
    params.push('replication=' + quoteParamValue(this.replication))
  }
  if (this.host) {
    params.push('host=' + quoteParamValue(this.host))
  }
  if (this.isDomainSocket) {
    return cb(null, params.join(' '))
  }
  if (this.client_encoding) {
    params.push('client_encoding=' + quoteParamValue(this.client_encoding))
  }
  dns.lookup(this.host, function (err, address) {
    if (err) return cb(err, null)
    params.push('hostaddr=' + quoteParamValue(address))
    return cb(null, params.join(' '))
  })
}

module.exports = ConnectionParameters


/***/ }),

/***/ "./node_modules/pg/lib/connection.js":
/*!*******************************************!*\
  !*** ./node_modules/pg/lib/connection.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var net = __webpack_require__(/*! net */ "net")
var EventEmitter = __webpack_require__(/*! events */ "events").EventEmitter
var util = __webpack_require__(/*! util */ "util")

var Writer = __webpack_require__(/*! buffer-writer */ "./node_modules/buffer-writer/index.js")
var Reader = __webpack_require__(/*! packet-reader */ "./node_modules/packet-reader/index.js")

var TEXT_MODE = 0
var BINARY_MODE = 1
var Connection = function (config) {
  EventEmitter.call(this)
  config = config || {}
  this.stream = config.stream || new net.Socket()
  this._keepAlive = config.keepAlive
  this.lastBuffer = false
  this.lastOffset = 0
  this.buffer = null
  this.offset = null
  this.encoding = config.encoding || 'utf8'
  this.parsedStatements = {}
  this.writer = new Writer()
  this.ssl = config.ssl || false
  this._ending = false
  this._mode = TEXT_MODE
  this._emitMessage = false
  this._reader = new Reader({
    headerSize: 1,
    lengthPadding: -4
  })
  var self = this
  this.on('newListener', function (eventName) {
    if (eventName === 'message') {
      self._emitMessage = true
    }
  })
}

util.inherits(Connection, EventEmitter)

Connection.prototype.connect = function (port, host) {
  if (this.stream.readyState === 'closed') {
    this.stream.connect(port, host)
  } else if (this.stream.readyState === 'open') {
    this.emit('connect')
  }

  var self = this

  this.stream.on('connect', function () {
    if (self._keepAlive) {
      self.stream.setKeepAlive(true)
    }
    self.emit('connect')
  })

  const reportStreamError = function (error) {
    // don't raise ECONNRESET errors - they can & should be ignored
    // during disconnect
    if (self._ending && error.code === 'ECONNRESET') {
      return
    }
    self.emit('error', error)
  }
  this.stream.on('error', reportStreamError)

  this.stream.on('close', function () {
    self.emit('end')
  })

  if (!this.ssl) {
    return this.attachListeners(this.stream)
  }

  this.stream.once('data', function (buffer) {
    var responseCode = buffer.toString('utf8')
    switch (responseCode) {
      case 'N': // Server does not support SSL connections
        return self.emit('error', new Error('The server does not support SSL connections'))
      case 'S': // Server supports SSL connections, continue with a secure connection
        break
      default: // Any other response byte, including 'E' (ErrorResponse) indicating a server error
        return self.emit('error', new Error('There was an error establishing an SSL connection'))
    }
    var tls = __webpack_require__(/*! tls */ "tls")
    self.stream = tls.connect({
      socket: self.stream,
      servername: host,
      checkServerIdentity: self.ssl.checkServerIdentity || tls.checkServerIdentity,
      rejectUnauthorized: self.ssl.rejectUnauthorized,
      ca: self.ssl.ca,
      pfx: self.ssl.pfx,
      key: self.ssl.key,
      passphrase: self.ssl.passphrase,
      cert: self.ssl.cert,
      NPNProtocols: self.ssl.NPNProtocols
    })
    self.attachListeners(self.stream)
    self.stream.on('error', reportStreamError)

    self.emit('sslconnect')
  })
}

Connection.prototype.attachListeners = function (stream) {
  var self = this
  stream.on('data', function (buff) {
    self._reader.addChunk(buff)
    var packet = self._reader.read()
    while (packet) {
      var msg = self.parseMessage(packet)
      if (self._emitMessage) {
        self.emit('message', msg)
      }
      self.emit(msg.name, msg)
      packet = self._reader.read()
    }
  })
  stream.on('end', function () {
    self.emit('end')
  })
}

Connection.prototype.requestSsl = function () {
  var bodyBuffer = this.writer
    .addInt16(0x04D2)
    .addInt16(0x162F).flush()

  var length = bodyBuffer.length + 4

  var buffer = new Writer()
    .addInt32(length)
    .add(bodyBuffer)
    .join()
  this.stream.write(buffer)
}

Connection.prototype.startup = function (config) {
  var writer = this.writer
    .addInt16(3)
    .addInt16(0)

  Object.keys(config).forEach(function (key) {
    var val = config[key]
    writer.addCString(key).addCString(val)
  })

  writer.addCString('client_encoding').addCString("'utf-8'")

  var bodyBuffer = writer.addCString('').flush()
  // this message is sent without a code

  var length = bodyBuffer.length + 4

  var buffer = new Writer()
    .addInt32(length)
    .add(bodyBuffer)
    .join()
  this.stream.write(buffer)
}

Connection.prototype.cancel = function (processID, secretKey) {
  var bodyBuffer = this.writer
    .addInt16(1234)
    .addInt16(5678)
    .addInt32(processID)
    .addInt32(secretKey)
    .flush()

  var length = bodyBuffer.length + 4

  var buffer = new Writer()
    .addInt32(length)
    .add(bodyBuffer)
    .join()
  this.stream.write(buffer)
}

Connection.prototype.password = function (password) {
  // 0x70 = 'p'
  this._send(0x70, this.writer.addCString(password))
}

Connection.prototype._send = function (code, more) {
  if (!this.stream.writable) {
    return false
  }
  if (more === true) {
    this.writer.addHeader(code)
  } else {
    return this.stream.write(this.writer.flush(code))
  }
}

Connection.prototype.query = function (text) {
  // 0x51 = Q
  this.stream.write(this.writer.addCString(text).flush(0x51))
}

// send parse message
// "more" === true to buffer the message until flush() is called
Connection.prototype.parse = function (query, more) {
  // expect something like this:
  // { name: 'queryName',
  //   text: 'select * from blah',
  //   types: ['int8', 'bool'] }

  // normalize missing query names to allow for null
  query.name = query.name || ''
  if (query.name.length > 63) {
    console.error('Warning! Postgres only supports 63 characters for query names.')
    console.error('You supplied', query.name, '(', query.name.length, ')')
    console.error('This can cause conflicts and silent errors executing queries')
  }
  // normalize null type array
  query.types = query.types || []
  var len = query.types.length
  var buffer = this.writer
    .addCString(query.name) // name of query
    .addCString(query.text) // actual query text
    .addInt16(len)
  for (var i = 0; i < len; i++) {
    buffer.addInt32(query.types[i])
  }

  var code = 0x50
  this._send(code, more)
}

// send bind message
// "more" === true to buffer the message until flush() is called
Connection.prototype.bind = function (config, more) {
  // normalize config
  config = config || {}
  config.portal = config.portal || ''
  config.statement = config.statement || ''
  config.binary = config.binary || false
  var values = config.values || []
  var len = values.length
  var useBinary = false
  for (var j = 0; j < len; j++) { useBinary |= values[j] instanceof Buffer }
  var buffer = this.writer
    .addCString(config.portal)
    .addCString(config.statement)
  if (!useBinary) { buffer.addInt16(0) } else {
    buffer.addInt16(len)
    for (j = 0; j < len; j++) { buffer.addInt16(values[j] instanceof Buffer) }
  }
  buffer.addInt16(len)
  for (var i = 0; i < len; i++) {
    var val = values[i]
    if (val === null || typeof val === 'undefined') {
      buffer.addInt32(-1)
    } else if (val instanceof Buffer) {
      buffer.addInt32(val.length)
      buffer.add(val)
    } else {
      buffer.addInt32(Buffer.byteLength(val))
      buffer.addString(val)
    }
  }

  if (config.binary) {
    buffer.addInt16(1) // format codes to use binary
    buffer.addInt16(1)
  } else {
    buffer.addInt16(0) // format codes to use text
  }
  // 0x42 = 'B'
  this._send(0x42, more)
}

// send execute message
// "more" === true to buffer the message until flush() is called
Connection.prototype.execute = function (config, more) {
  config = config || {}
  config.portal = config.portal || ''
  config.rows = config.rows || ''
  this.writer
    .addCString(config.portal)
    .addInt32(config.rows)

  // 0x45 = 'E'
  this._send(0x45, more)
}

var emptyBuffer = Buffer.alloc(0)

Connection.prototype.flush = function () {
  // 0x48 = 'H'
  this.writer.add(emptyBuffer)
  this._send(0x48)
}

Connection.prototype.sync = function () {
  // clear out any pending data in the writer
  this.writer.flush(0)

  this.writer.add(emptyBuffer)
  this._ending = true
  this._send(0x53)
}

const END_BUFFER = Buffer.from([0x58, 0x00, 0x00, 0x00, 0x04])

Connection.prototype.end = function () {
  // 0x58 = 'X'
  this.writer.add(emptyBuffer)
  this._ending = true
  return this.stream.write(END_BUFFER, () => {
    this.stream.end()
  })
}

Connection.prototype.close = function (msg, more) {
  this.writer.addCString(msg.type + (msg.name || ''))
  this._send(0x43, more)
}

Connection.prototype.describe = function (msg, more) {
  this.writer.addCString(msg.type + (msg.name || ''))
  this._send(0x44, more)
}

Connection.prototype.sendCopyFromChunk = function (chunk) {
  this.stream.write(this.writer.add(chunk).flush(0x64))
}

Connection.prototype.endCopyFrom = function () {
  this.stream.write(this.writer.add(emptyBuffer).flush(0x63))
}

Connection.prototype.sendCopyFail = function (msg) {
  // this.stream.write(this.writer.add(emptyBuffer).flush(0x66));
  this.writer.addCString(msg)
  this._send(0x66)
}

var Message = function (name, length) {
  this.name = name
  this.length = length
}

Connection.prototype.parseMessage = function (buffer) {
  this.offset = 0
  var length = buffer.length + 4
  switch (this._reader.header) {
    case 0x52: // R
      return this.parseR(buffer, length)

    case 0x53: // S
      return this.parseS(buffer, length)

    case 0x4b: // K
      return this.parseK(buffer, length)

    case 0x43: // C
      return this.parseC(buffer, length)

    case 0x5a: // Z
      return this.parseZ(buffer, length)

    case 0x54: // T
      return this.parseT(buffer, length)

    case 0x44: // D
      return this.parseD(buffer, length)

    case 0x45: // E
      return this.parseE(buffer, length)

    case 0x4e: // N
      return this.parseN(buffer, length)

    case 0x31: // 1
      return new Message('parseComplete', length)

    case 0x32: // 2
      return new Message('bindComplete', length)

    case 0x33: // 3
      return new Message('closeComplete', length)

    case 0x41: // A
      return this.parseA(buffer, length)

    case 0x6e: // n
      return new Message('noData', length)

    case 0x49: // I
      return new Message('emptyQuery', length)

    case 0x73: // s
      return new Message('portalSuspended', length)

    case 0x47: // G
      return this.parseG(buffer, length)

    case 0x48: // H
      return this.parseH(buffer, length)

    case 0x57: // W
      return new Message('replicationStart', length)

    case 0x63: // c
      return new Message('copyDone', length)

    case 0x64: // d
      return this.parsed(buffer, length)
  }
}

Connection.prototype.parseR = function (buffer, length) {
  var code = 0
  var msg = new Message('authenticationOk', length)
  if (msg.length === 8) {
    code = this.parseInt32(buffer)
    if (code === 3) {
      msg.name = 'authenticationCleartextPassword'
    }
    return msg
  }
  if (msg.length === 12) {
    code = this.parseInt32(buffer)
    if (code === 5) { // md5 required
      msg.name = 'authenticationMD5Password'
      msg.salt = Buffer.alloc(4)
      buffer.copy(msg.salt, 0, this.offset, this.offset + 4)
      this.offset += 4
      return msg
    }
  }
  throw new Error('Unknown authenticationOk message type' + util.inspect(msg))
}

Connection.prototype.parseS = function (buffer, length) {
  var msg = new Message('parameterStatus', length)
  msg.parameterName = this.parseCString(buffer)
  msg.parameterValue = this.parseCString(buffer)
  return msg
}

Connection.prototype.parseK = function (buffer, length) {
  var msg = new Message('backendKeyData', length)
  msg.processID = this.parseInt32(buffer)
  msg.secretKey = this.parseInt32(buffer)
  return msg
}

Connection.prototype.parseC = function (buffer, length) {
  var msg = new Message('commandComplete', length)
  msg.text = this.parseCString(buffer)
  return msg
}

Connection.prototype.parseZ = function (buffer, length) {
  var msg = new Message('readyForQuery', length)
  msg.name = 'readyForQuery'
  msg.status = this.readString(buffer, 1)
  return msg
}

var ROW_DESCRIPTION = 'rowDescription'
Connection.prototype.parseT = function (buffer, length) {
  var msg = new Message(ROW_DESCRIPTION, length)
  msg.fieldCount = this.parseInt16(buffer)
  var fields = []
  for (var i = 0; i < msg.fieldCount; i++) {
    fields.push(this.parseField(buffer))
  }
  msg.fields = fields
  return msg
}

var Field = function () {
  this.name = null
  this.tableID = null
  this.columnID = null
  this.dataTypeID = null
  this.dataTypeSize = null
  this.dataTypeModifier = null
  this.format = null
}

var FORMAT_TEXT = 'text'
var FORMAT_BINARY = 'binary'
Connection.prototype.parseField = function (buffer) {
  var field = new Field()
  field.name = this.parseCString(buffer)
  field.tableID = this.parseInt32(buffer)
  field.columnID = this.parseInt16(buffer)
  field.dataTypeID = this.parseInt32(buffer)
  field.dataTypeSize = this.parseInt16(buffer)
  field.dataTypeModifier = this.parseInt32(buffer)
  if (this.parseInt16(buffer) === TEXT_MODE) {
    this._mode = TEXT_MODE
    field.format = FORMAT_TEXT
  } else {
    this._mode = BINARY_MODE
    field.format = FORMAT_BINARY
  }
  return field
}

var DATA_ROW = 'dataRow'
var DataRowMessage = function (length, fieldCount) {
  this.name = DATA_ROW
  this.length = length
  this.fieldCount = fieldCount
  this.fields = []
}

// extremely hot-path code
Connection.prototype.parseD = function (buffer, length) {
  var fieldCount = this.parseInt16(buffer)
  var msg = new DataRowMessage(length, fieldCount)
  for (var i = 0; i < fieldCount; i++) {
    msg.fields.push(this._readValue(buffer))
  }
  return msg
}

// extremely hot-path code
Connection.prototype._readValue = function (buffer) {
  var length = this.parseInt32(buffer)
  if (length === -1) return null
  if (this._mode === TEXT_MODE) {
    return this.readString(buffer, length)
  }
  return this.readBytes(buffer, length)
}

// parses error
Connection.prototype.parseE = function (buffer, length) {
  var fields = {}
  var msg, item
  var input = new Message('error', length)
  var fieldType = this.readString(buffer, 1)
  while (fieldType !== '\0') {
    fields[fieldType] = this.parseCString(buffer)
    fieldType = this.readString(buffer, 1)
  }
  if (input.name === 'error') {
    // the msg is an Error instance
    msg = new Error(fields.M)
    for (item in input) {
      // copy input properties to the error
      if (input.hasOwnProperty(item)) {
        msg[item] = input[item]
      }
    }
  } else {
    // the msg is an object literal
    msg = input
    msg.message = fields.M
  }
  msg.severity = fields.S
  msg.code = fields.C
  msg.detail = fields.D
  msg.hint = fields.H
  msg.position = fields.P
  msg.internalPosition = fields.p
  msg.internalQuery = fields.q
  msg.where = fields.W
  msg.schema = fields.s
  msg.table = fields.t
  msg.column = fields.c
  msg.dataType = fields.d
  msg.constraint = fields.n
  msg.file = fields.F
  msg.line = fields.L
  msg.routine = fields.R
  return msg
}

// same thing, different name
Connection.prototype.parseN = function (buffer, length) {
  var msg = this.parseE(buffer, length)
  msg.name = 'notice'
  return msg
}

Connection.prototype.parseA = function (buffer, length) {
  var msg = new Message('notification', length)
  msg.processId = this.parseInt32(buffer)
  msg.channel = this.parseCString(buffer)
  msg.payload = this.parseCString(buffer)
  return msg
}

Connection.prototype.parseG = function (buffer, length) {
  var msg = new Message('copyInResponse', length)
  return this.parseGH(buffer, msg)
}

Connection.prototype.parseH = function (buffer, length) {
  var msg = new Message('copyOutResponse', length)
  return this.parseGH(buffer, msg)
}

Connection.prototype.parseGH = function (buffer, msg) {
  var isBinary = buffer[this.offset] !== 0
  this.offset++
  msg.binary = isBinary
  var columnCount = this.parseInt16(buffer)
  msg.columnTypes = []
  for (var i = 0; i < columnCount; i++) {
    msg.columnTypes.push(this.parseInt16(buffer))
  }
  return msg
}

Connection.prototype.parsed = function (buffer, length) {
  var msg = new Message('copyData', length)
  msg.chunk = this.readBytes(buffer, msg.length - 4)
  return msg
}

Connection.prototype.parseInt32 = function (buffer) {
  var value = buffer.readInt32BE(this.offset)
  this.offset += 4
  return value
}

Connection.prototype.parseInt16 = function (buffer) {
  var value = buffer.readInt16BE(this.offset)
  this.offset += 2
  return value
}

Connection.prototype.readString = function (buffer, length) {
  return buffer.toString(this.encoding, this.offset, (this.offset += length))
}

Connection.prototype.readBytes = function (buffer, length) {
  return buffer.slice(this.offset, (this.offset += length))
}

Connection.prototype.parseCString = function (buffer) {
  var start = this.offset
  var end = buffer.indexOf(0, start)
  this.offset = end + 1
  return buffer.toString(this.encoding, start, end)
}
// end parsing methods
module.exports = Connection


/***/ }),

/***/ "./node_modules/pg/lib/defaults.js":
/*!*****************************************!*\
  !*** ./node_modules/pg/lib/defaults.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

module.exports = {
  // database host. defaults to localhost
  host: 'localhost',

  // database user's name
  user: process.platform === 'win32' ? process.env.USERNAME : process.env.USER,

  // name of database to connect
  database: process.platform === 'win32' ? process.env.USERNAME : process.env.USER,

  // database user's password
  password: null,

  // a Postgres connection string to be used instead of setting individual connection items
  // NOTE:  Setting this value will cause it to override any other value (such as database or user) defined
  // in the defaults object.
  connectionString: undefined,

  // database port
  port: 5432,

  // number of rows to return at a time from a prepared statement's
  // portal. 0 will return all rows at once
  rows: 0,

  // binary result mode
  binary: false,

  // Connection pool options - see https://github.com/brianc/node-pg-pool

  // number of connections to use in connection pool
  // 0 will disable connection pooling
  max: 10,

  // max milliseconds a client can go unused before it is removed
  // from the pool and destroyed
  idleTimeoutMillis: 30000,

  client_encoding: '',

  ssl: false,

  application_name: undefined,
  fallback_application_name: undefined,

  parseInputDatesAsUTC: false,

  // max milliseconds any query using this connection will execute for before timing out in error. false=unlimited
  statement_timeout: false
}

var pgTypes = __webpack_require__(/*! pg-types */ "./node_modules/pg-types/index.js")
// save default parsers
var parseBigInteger = pgTypes.getTypeParser(20, 'text')
var parseBigIntegerArray = pgTypes.getTypeParser(1016, 'text')

// parse int8 so you can get your count values as actual numbers
module.exports.__defineSetter__('parseInt8', function (val) {
  pgTypes.setTypeParser(20, 'text', val ? pgTypes.getTypeParser(23, 'text') : parseBigInteger)
  pgTypes.setTypeParser(1016, 'text', val ? pgTypes.getTypeParser(1007, 'text') : parseBigIntegerArray)
})


/***/ }),

/***/ "./node_modules/pg/lib/index.js":
/*!**************************************!*\
  !*** ./node_modules/pg/lib/index.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var util = __webpack_require__(/*! util */ "util")
var Client = __webpack_require__(/*! ./client */ "./node_modules/pg/lib/client.js")
var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/pg/lib/defaults.js")
var Connection = __webpack_require__(/*! ./connection */ "./node_modules/pg/lib/connection.js")
var Pool = __webpack_require__(/*! pg-pool */ "./node_modules/pg-pool/index.js")

const poolFactory = (Client) => {
  var BoundPool = function (options) {
    var config = Object.assign({ Client: Client }, options)
    return new Pool(config)
  }

  util.inherits(BoundPool, Pool)

  return BoundPool
}

var PG = function (clientConstructor) {
  this.defaults = defaults
  this.Client = clientConstructor
  this.Query = this.Client.Query
  this.Pool = poolFactory(this.Client)
  this._pools = []
  this.Connection = Connection
  this.types = __webpack_require__(/*! pg-types */ "./node_modules/pg-types/index.js")
}

if (typeof process.env.NODE_PG_FORCE_NATIVE !== 'undefined') {
  module.exports = new PG(__webpack_require__(/*! ./native */ "./node_modules/pg/lib/native/index.js"))
} else {
  module.exports = new PG(Client)

  // lazy require native module...the native module may not have installed
  module.exports.__defineGetter__('native', function () {
    delete module.exports.native
    var native = null
    try {
      native = new PG(__webpack_require__(/*! ./native */ "./node_modules/pg/lib/native/index.js"))
    } catch (err) {
      if (err.code !== 'MODULE_NOT_FOUND') {
        throw err
      }
      console.error(err.message)
    }
    module.exports.native = native
    return native
  })
}


/***/ }),

/***/ "./node_modules/pg/lib/native/client.js":
/*!**********************************************!*\
  !*** ./node_modules/pg/lib/native/client.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var Native = __webpack_require__(/*! pg-native */ "pg-native")
var TypeOverrides = __webpack_require__(/*! ../type-overrides */ "./node_modules/pg/lib/type-overrides.js")
var semver = __webpack_require__(/*! semver */ "./node_modules/pg/node_modules/semver/semver.js")
var pkg = __webpack_require__(/*! ../../package.json */ "./node_modules/pg/package.json")
var assert = __webpack_require__(/*! assert */ "assert")
var EventEmitter = __webpack_require__(/*! events */ "events").EventEmitter
var util = __webpack_require__(/*! util */ "util")
var ConnectionParameters = __webpack_require__(/*! ../connection-parameters */ "./node_modules/pg/lib/connection-parameters.js")

var msg = 'Version >= ' + pkg.minNativeVersion + ' of pg-native required.'
assert(semver.gte(Native.version, pkg.minNativeVersion), msg)

var NativeQuery = __webpack_require__(/*! ./query */ "./node_modules/pg/lib/native/query.js")

var Client = module.exports = function (config) {
  EventEmitter.call(this)
  config = config || {}

  this._types = new TypeOverrides(config.types)

  this.native = new Native({
    types: this._types
  })

  this._queryQueue = []
  this._connected = false
  this._connecting = false

  // keep these on the object for legacy reasons
  // for the time being. TODO: deprecate all this jazz
  var cp = this.connectionParameters = new ConnectionParameters(config)
  this.user = cp.user
  this.password = cp.password
  this.database = cp.database
  this.host = cp.host
  this.port = cp.port

  // a hash to hold named queries
  this.namedQueries = {}
}

Client.Query = NativeQuery

util.inherits(Client, EventEmitter)

// connect to the backend
// pass an optional callback to be called once connected
// or with an error if there was a connection error
// if no callback is passed and there is a connection error
// the client will emit an error event.
Client.prototype.connect = function (cb) {
  var self = this

  var onError = function (err) {
    if (cb) return cb(err)
    return self.emit('error', err)
  }

  var result
  if (!cb) {
    var resolveOut, rejectOut
    cb = (err) => err ? rejectOut(err) : resolveOut()
    result = new global.Promise(function (resolve, reject) {
      resolveOut = resolve
      rejectOut = reject
    })
  }

  if (this._connecting) {
    process.nextTick(() => cb(new Error('Client has already been connected. You cannot reuse a client.')))
    return result
  }

  this._connecting = true

  this.connectionParameters.getLibpqConnectionString(function (err, conString) {
    if (err) return onError(err)
    self.native.connect(conString, function (err) {
      if (err) return onError(err)

      // set internal states to connected
      self._connected = true

      // handle connection errors from the native layer
      self.native.on('error', function (err) {
        // error will be handled by active query
        if (self._activeQuery && self._activeQuery.state !== 'end') {
          return
        }
        self.emit('error', err)
      })

      self.native.on('notification', function (msg) {
        self.emit('notification', {
          channel: msg.relname,
          payload: msg.extra
        })
      })

      // signal we are connected now
      self.emit('connect')
      self._pulseQueryQueue(true)

      // possibly call the optional callback
      if (cb) cb()
    })
  })

  return result
}

// send a query to the server
// this method is highly overloaded to take
// 1) string query, optional array of parameters, optional function callback
// 2) object query with {
//    string query
//    optional array values,
//    optional function callback instead of as a separate parameter
//    optional string name to name & cache the query plan
//    optional string rowMode = 'array' for an array of results
//  }
Client.prototype.query = function (config, values, callback) {
  if (typeof config.submit === 'function') {
    // accept query(new Query(...), (err, res) => { }) style
    if (typeof values === 'function') {
      config.callback = values
    }
    this._queryQueue.push(config)
    this._pulseQueryQueue()
    return config
  }

  var query = new NativeQuery(config, values, callback)
  var result
  if (!query.callback) {
    let resolveOut, rejectOut
    result = new Promise((resolve, reject) => {
      resolveOut = resolve
      rejectOut = reject
    })
    query.callback = (err, res) => err ? rejectOut(err) : resolveOut(res)
  }
  this._queryQueue.push(query)
  this._pulseQueryQueue()
  return result
}

// disconnect from the backend server
Client.prototype.end = function (cb) {
  var self = this
  if (!this._connected) {
    this.once('connect', this.end.bind(this, cb))
  }
  var result
  if (!cb) {
    var resolve, reject
    cb = (err) => err ? reject(err) : resolve()
    result = new global.Promise(function (res, rej) {
      resolve = res
      reject = rej
    })
  }
  this.native.end(function () {
    // send an error to the active query
    if (self._hasActiveQuery()) {
      var msg = 'Connection terminated'
      self._queryQueue.length = 0
      self._activeQuery.handleError(new Error(msg))
    }
    self.emit('end')
    if (cb) cb()
  })
  return result
}

Client.prototype._hasActiveQuery = function () {
  return this._activeQuery && this._activeQuery.state !== 'error' && this._activeQuery.state !== 'end'
}

Client.prototype._pulseQueryQueue = function (initialConnection) {
  if (!this._connected) {
    return
  }
  if (this._hasActiveQuery()) {
    return
  }
  var query = this._queryQueue.shift()
  if (!query) {
    if (!initialConnection) {
      this.emit('drain')
    }
    return
  }
  this._activeQuery = query
  query.submit(this)
  var self = this
  query.once('_done', function () {
    self._pulseQueryQueue()
  })
}

// attempt to cancel an in-progress query
Client.prototype.cancel = function (query) {
  if (this._activeQuery === query) {
    this.native.cancel(function () {})
  } else if (this._queryQueue.indexOf(query) !== -1) {
    this._queryQueue.splice(this._queryQueue.indexOf(query), 1)
  }
}

Client.prototype.setTypeParser = function (oid, format, parseFn) {
  return this._types.setTypeParser(oid, format, parseFn)
}

Client.prototype.getTypeParser = function (oid, format) {
  return this._types.getTypeParser(oid, format)
}


/***/ }),

/***/ "./node_modules/pg/lib/native/index.js":
/*!*********************************************!*\
  !*** ./node_modules/pg/lib/native/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = __webpack_require__(/*! ./client */ "./node_modules/pg/lib/native/client.js")


/***/ }),

/***/ "./node_modules/pg/lib/native/query.js":
/*!*********************************************!*\
  !*** ./node_modules/pg/lib/native/query.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var EventEmitter = __webpack_require__(/*! events */ "events").EventEmitter
var util = __webpack_require__(/*! util */ "util")
var utils = __webpack_require__(/*! ../utils */ "./node_modules/pg/lib/utils.js")

var NativeQuery = module.exports = function (config, values, callback) {
  EventEmitter.call(this)
  config = utils.normalizeQueryConfig(config, values, callback)
  this.text = config.text
  this.values = config.values
  this.name = config.name
  this.callback = config.callback
  this.state = 'new'
  this._arrayMode = config.rowMode === 'array'

  // if the 'row' event is listened for
  // then emit them as they come in
  // without setting singleRowMode to true
  // this has almost no meaning because libpq
  // reads all rows into memory befor returning any
  this._emitRowEvents = false
  this.on('newListener', function (event) {
    if (event === 'row') this._emitRowEvents = true
  }.bind(this))
}

util.inherits(NativeQuery, EventEmitter)

var errorFieldMap = {
  'sqlState': 'code',
  'statementPosition': 'position',
  'messagePrimary': 'message',
  'context': 'where',
  'schemaName': 'schema',
  'tableName': 'table',
  'columnName': 'column',
  'dataTypeName': 'dataType',
  'constraintName': 'constraint',
  'sourceFile': 'file',
  'sourceLine': 'line',
  'sourceFunction': 'routine'
}

NativeQuery.prototype.handleError = function (err) {
  // copy pq error fields into the error object
  var fields = this.native.pq.resultErrorFields()
  if (fields) {
    for (var key in fields) {
      var normalizedFieldName = errorFieldMap[key] || key
      err[normalizedFieldName] = fields[key]
    }
  }
  if (this.callback) {
    this.callback(err)
  } else {
    this.emit('error', err)
  }
  this.state = 'error'
}

NativeQuery.prototype.then = function (onSuccess, onFailure) {
  return this._getPromise().then(onSuccess, onFailure)
}

NativeQuery.prototype.catch = function (callback) {
  return this._getPromise().catch(callback)
}

NativeQuery.prototype._getPromise = function () {
  if (this._promise) return this._promise
  this._promise = new Promise(function (resolve, reject) {
    this._once('end', resolve)
    this._once('error', reject)
  }.bind(this))
  return this._promise
}

NativeQuery.prototype.submit = function (client) {
  this.state = 'running'
  var self = this
  this.native = client.native
  client.native.arrayMode = this._arrayMode

  var after = function (err, rows, results) {
    client.native.arrayMode = false
    setImmediate(function () {
      self.emit('_done')
    })

    // handle possible query error
    if (err) {
      return self.handleError(err)
    }

    // emit row events for each row in the result
    if (self._emitRowEvents) {
      if (results.length > 1) {
        rows.forEach((rowOfRows, i) => {
          rowOfRows.forEach(row => {
            self.emit('row', row, results[i])
          })
        })
      } else {
        rows.forEach(function (row) {
          self.emit('row', row, results)
        })
      }
    }

    // handle successful result
    self.state = 'end'
    self.emit('end', results)
    if (self.callback) {
      self.callback(null, results)
    }
  }

  if (process.domain) {
    after = process.domain.bind(after)
  }

  // named query
  if (this.name) {
    if (this.name.length > 63) {
      console.error('Warning! Postgres only supports 63 characters for query names.')
      console.error('You supplied', this.name, '(', this.name.length, ')')
      console.error('This can cause conflicts and silent errors executing queries')
    }
    var values = (this.values || []).map(utils.prepareValue)

    // check if the client has already executed this named query
    // if so...just execute it again - skip the planning phase
    if (client.namedQueries[this.name]) {
      return client.native.execute(this.name, values, after)
    }
    // plan the named query the first time, then execute it
    return client.native.prepare(this.name, this.text, values.length, function (err) {
      if (err) return after(err)
      client.namedQueries[self.name] = true
      return self.native.execute(self.name, values, after)
    })
  } else if (this.values) {
    if (!Array.isArray(this.values)) {
      const err = new Error('Query values must be an array')
      return after(err)
    }
    var vals = this.values.map(utils.prepareValue)
    client.native.query(this.text, vals, after)
  } else {
    client.native.query(this.text, after)
  }
}


/***/ }),

/***/ "./node_modules/pg/lib/query.js":
/*!**************************************!*\
  !*** ./node_modules/pg/lib/query.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var EventEmitter = __webpack_require__(/*! events */ "events").EventEmitter
var util = __webpack_require__(/*! util */ "util")

var Result = __webpack_require__(/*! ./result */ "./node_modules/pg/lib/result.js")
var utils = __webpack_require__(/*! ./utils */ "./node_modules/pg/lib/utils.js")

var Query = function (config, values, callback) {
  // use of "new" optional
  if (!(this instanceof Query)) { return new Query(config, values, callback) }

  config = utils.normalizeQueryConfig(config, values, callback)

  this.text = config.text
  this.values = config.values
  this.rows = config.rows
  this.types = config.types
  this.name = config.name
  this.binary = config.binary
  this.stream = config.stream
  // use unique portal name each time
  this.portal = config.portal || ''
  this.callback = config.callback
  this._rowMode = config.rowMode
  if (process.domain && config.callback) {
    this.callback = process.domain.bind(config.callback)
  }
  this._result = new Result(this._rowMode, this.types)

  // potential for multiple results
  this._results = this._result
  this.isPreparedStatement = false
  this._canceledDueToError = false
  this._promise = null
  EventEmitter.call(this)
}

util.inherits(Query, EventEmitter)

Query.prototype.requiresPreparation = function () {
  // named queries must always be prepared
  if (this.name) { return true }
  // always prepare if there are max number of rows expected per
  // portal execution
  if (this.rows) { return true }
  // don't prepare empty text queries
  if (!this.text) { return false }
  // prepare if there are values
  if (!this.values) { return false }
  return this.values.length > 0
}

Query.prototype._checkForMultirow = function () {
  // if we already have a result with a command property
  // then we've already executed one query in a multi-statement simple query
  // turn our results into an array of results
  if (this._result.command) {
    if (!Array.isArray(this._results)) {
      this._results = [this._result]
    }
    this._result = new Result(this._rowMode, this.types)
    this._results.push(this._result)
  }
}

// associates row metadata from the supplied
// message with this query object
// metadata used when parsing row results
Query.prototype.handleRowDescription = function (msg) {
  this._checkForMultirow()
  this._result.addFields(msg.fields)
  this._accumulateRows = this.callback || !this.listeners('row').length
}

Query.prototype.handleDataRow = function (msg) {
  var row

  if (this._canceledDueToError) {
    return
  }

  try {
    row = this._result.parseRow(msg.fields)
  } catch (err) {
    this._canceledDueToError = err
    return
  }

  this.emit('row', row, this._result)
  if (this._accumulateRows) {
    this._result.addRow(row)
  }
}

Query.prototype.handleCommandComplete = function (msg, con) {
  this._checkForMultirow()
  this._result.addCommandComplete(msg)
  // need to sync after each command complete of a prepared statement
  if (this.isPreparedStatement) {
    con.sync()
  }
}

// if a named prepared statement is created with empty query text
// the backend will send an emptyQuery message but *not* a command complete message
// execution on the connection will hang until the backend receives a sync message
Query.prototype.handleEmptyQuery = function (con) {
  if (this.isPreparedStatement) {
    con.sync()
  }
}

Query.prototype.handleReadyForQuery = function (con) {
  if (this._canceledDueToError) {
    return this.handleError(this._canceledDueToError, con)
  }
  if (this.callback) {
    this.callback(null, this._results)
  }
  this.emit('end', this._results)
}

Query.prototype.handleError = function (err, connection) {
  // need to sync after error during a prepared statement
  if (this.isPreparedStatement) {
    connection.sync()
  }
  if (this._canceledDueToError) {
    err = this._canceledDueToError
    this._canceledDueToError = false
  }
  // if callback supplied do not emit error event as uncaught error
  // events will bubble up to node process
  if (this.callback) {
    return this.callback(err)
  }
  this.emit('error', err)
}

Query.prototype.submit = function (connection) {
  if (typeof this.text !== 'string' && typeof this.name !== 'string') {
    const err = new Error('A query must have either text or a name. Supplying neither is unsupported.')
    connection.emit('error', err)
    connection.emit('readyForQuery')
    return
  }
  if (this.values && !Array.isArray(this.values)) {
    const err = new Error('Query values must be an array')
    connection.emit('error', err)
    connection.emit('readyForQuery')
    return
  }
  if (this.requiresPreparation()) {
    this.prepare(connection)
  } else {
    connection.query(this.text)
  }
}

Query.prototype.hasBeenParsed = function (connection) {
  return this.name && connection.parsedStatements[this.name]
}

Query.prototype.handlePortalSuspended = function (connection) {
  this._getRows(connection, this.rows)
}

Query.prototype._getRows = function (connection, rows) {
  connection.execute({
    portal: this.portal,
    rows: rows
  }, true)
  connection.flush()
}

Query.prototype.prepare = function (connection) {
  var self = this
  // prepared statements need sync to be called after each command
  // complete or when an error is encountered
  this.isPreparedStatement = true
  // TODO refactor this poor encapsulation
  if (!this.hasBeenParsed(connection)) {
    connection.parse({
      text: self.text,
      name: self.name,
      types: self.types
    }, true)
  }

  if (self.values) {
    self.values = self.values.map(utils.prepareValue)
  }

  // http://developer.postgresql.org/pgdocs/postgres/protocol-flow.html#PROTOCOL-FLOW-EXT-QUERY
  connection.bind({
    portal: self.portal,
    statement: self.name,
    values: self.values,
    binary: self.binary
  }, true)

  connection.describe({
    type: 'P',
    name: self.portal || ''
  }, true)

  this._getRows(connection, this.rows)
}

Query.prototype.handleCopyInResponse = function (connection) {
  if (this.stream) this.stream.startStreamingToConnection(connection)
  else connection.sendCopyFail('No source stream defined')
}

Query.prototype.handleCopyData = function (msg, connection) {
  var chunk = msg.chunk
  if (this.stream) {
    this.stream.handleChunk(chunk)
  }
  // if there are no stream (for example when copy to query was sent by
  // query method instead of copyTo) error will be handled
  // on copyOutResponse event, so silently ignore this error here
}
module.exports = Query


/***/ }),

/***/ "./node_modules/pg/lib/result.js":
/*!***************************************!*\
  !*** ./node_modules/pg/lib/result.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var types = __webpack_require__(/*! pg-types */ "./node_modules/pg-types/index.js")

// result object returned from query
// in the 'end' event and also
// passed as second argument to provided callback
var Result = function (rowMode) {
  this.command = null
  this.rowCount = null
  this.oid = null
  this.rows = []
  this.fields = []
  this._parsers = []
  this.RowCtor = null
  this.rowAsArray = rowMode === 'array'
  if (this.rowAsArray) {
    this.parseRow = this._parseRowAsArray
  }
}

var matchRegexp = /^([A-Za-z]+)(?: (\d+))?(?: (\d+))?/

// adds a command complete message
Result.prototype.addCommandComplete = function (msg) {
  var match
  if (msg.text) {
    // pure javascript
    match = matchRegexp.exec(msg.text)
  } else {
    // native bindings
    match = matchRegexp.exec(msg.command)
  }
  if (match) {
    this.command = match[1]
    if (match[3]) {
      // COMMMAND OID ROWS
      this.oid = parseInt(match[2], 10)
      this.rowCount = parseInt(match[3], 10)
    } else if (match[2]) {
      // COMMAND ROWS
      this.rowCount = parseInt(match[2], 10)
    }
  }
}

Result.prototype._parseRowAsArray = function (rowData) {
  var row = []
  for (var i = 0, len = rowData.length; i < len; i++) {
    var rawValue = rowData[i]
    if (rawValue !== null) {
      row.push(this._parsers[i](rawValue))
    } else {
      row.push(null)
    }
  }
  return row
}

Result.prototype.parseRow = function (rowData) {
  var row = {}
  for (var i = 0, len = rowData.length; i < len; i++) {
    var rawValue = rowData[i]
    var field = this.fields[i].name
    if (rawValue !== null) {
      row[field] = this._parsers[i](rawValue)
    } else {
      row[field] = null
    }
  }
  return row
}

Result.prototype.addRow = function (row) {
  this.rows.push(row)
}

Result.prototype.addFields = function (fieldDescriptions) {
  // clears field definitions
  // multiple query statements in 1 action can result in multiple sets
  // of rowDescriptions...eg: 'select NOW(); select 1::int;'
  // you need to reset the fields
  if (this.fields.length) {
    this.fields = []
    this._parsers = []
  }
  for (var i = 0; i < fieldDescriptions.length; i++) {
    var desc = fieldDescriptions[i]
    this.fields.push(desc)
    var parser = this._getTypeParser(desc.dataTypeID, desc.format || 'text')
    this._parsers.push(parser)
  }
}

Result.prototype._getTypeParser = types.getTypeParser

module.exports = Result


/***/ }),

/***/ "./node_modules/pg/lib/type-overrides.js":
/*!***********************************************!*\
  !*** ./node_modules/pg/lib/type-overrides.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

var types = __webpack_require__(/*! pg-types */ "./node_modules/pg-types/index.js")

function TypeOverrides (userTypes) {
  this._types = userTypes || types
  this.text = {}
  this.binary = {}
}

TypeOverrides.prototype.getOverrides = function (format) {
  switch (format) {
    case 'text': return this.text
    case 'binary': return this.binary
    default: return {}
  }
}

TypeOverrides.prototype.setTypeParser = function (oid, format, parseFn) {
  if (typeof format === 'function') {
    parseFn = format
    format = 'text'
  }
  this.getOverrides(format)[oid] = parseFn
}

TypeOverrides.prototype.getTypeParser = function (oid, format) {
  format = format || 'text'
  return this.getOverrides(format)[oid] || this._types.getTypeParser(oid, format)
}

module.exports = TypeOverrides


/***/ }),

/***/ "./node_modules/pg/lib/utils.js":
/*!**************************************!*\
  !*** ./node_modules/pg/lib/utils.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2010-2017 Brian Carlson (brian.m.carlson@gmail.com)
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * README.md file in the root directory of this source tree.
 */

const crypto = __webpack_require__(/*! crypto */ "crypto")

const defaults = __webpack_require__(/*! ./defaults */ "./node_modules/pg/lib/defaults.js")

function escapeElement (elementRepresentation) {
  var escaped = elementRepresentation
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')

  return '"' + escaped + '"'
}

// convert a JS array to a postgres array literal
// uses comma separator so won't work for types like box that use
// a different array separator.
function arrayString (val) {
  var result = '{'
  for (var i = 0; i < val.length; i++) {
    if (i > 0) {
      result = result + ','
    }
    if (val[i] === null || typeof val[i] === 'undefined') {
      result = result + 'NULL'
    } else if (Array.isArray(val[i])) {
      result = result + arrayString(val[i])
    } else if (val[i] instanceof Buffer) {
      result += '\\\\x' + val[i].toString('hex')
    } else {
      result += escapeElement(prepareValue(val[i]))
    }
  }
  result = result + '}'
  return result
}

// converts values from javascript types
// to their 'raw' counterparts for use as a postgres parameter
// note: you can override this function to provide your own conversion mechanism
// for complex types, etc...
var prepareValue = function (val, seen) {
  if (val instanceof Buffer) {
    return val
  }
  if (ArrayBuffer.isView(val)) {
    var buf = Buffer.from(val.buffer, val.byteOffset, val.byteLength)
    if (buf.length === val.byteLength) {
      return buf
    }
    return buf.slice(val.byteOffset, val.byteOffset + val.byteLength) // Node.js v4 does not support those Buffer.from params
  }
  if (val instanceof Date) {
    if (defaults.parseInputDatesAsUTC) {
      return dateToStringUTC(val)
    } else {
      return dateToString(val)
    }
  }
  if (Array.isArray(val)) {
    return arrayString(val)
  }
  if (val === null || typeof val === 'undefined') {
    return null
  }
  if (typeof val === 'object') {
    return prepareObject(val, seen)
  }
  return val.toString()
}

function prepareObject (val, seen) {
  if (val && typeof val.toPostgres === 'function') {
    seen = seen || []
    if (seen.indexOf(val) !== -1) {
      throw new Error('circular reference detected while preparing "' + val + '" for query')
    }
    seen.push(val)

    return prepareValue(val.toPostgres(prepareValue), seen)
  }
  return JSON.stringify(val)
}

function pad (number, digits) {
  number = '' + number
  while (number.length < digits) { number = '0' + number }
  return number
}

function dateToString (date) {
  var offset = -date.getTimezoneOffset()
  var ret = pad(date.getFullYear(), 4) + '-' +
    pad(date.getMonth() + 1, 2) + '-' +
    pad(date.getDate(), 2) + 'T' +
    pad(date.getHours(), 2) + ':' +
    pad(date.getMinutes(), 2) + ':' +
    pad(date.getSeconds(), 2) + '.' +
    pad(date.getMilliseconds(), 3)

  if (offset < 0) {
    ret += '-'
    offset *= -1
  } else { ret += '+' }

  return ret + pad(Math.floor(offset / 60), 2) + ':' + pad(offset % 60, 2)
}

function dateToStringUTC (date) {
  var ret = pad(date.getUTCFullYear(), 4) + '-' +
    pad(date.getUTCMonth() + 1, 2) + '-' +
    pad(date.getUTCDate(), 2) + 'T' +
    pad(date.getUTCHours(), 2) + ':' +
    pad(date.getUTCMinutes(), 2) + ':' +
    pad(date.getUTCSeconds(), 2) + '.' +
    pad(date.getUTCMilliseconds(), 3)

  return ret + '+00:00'
}

function normalizeQueryConfig (config, values, callback) {
  // can take in strings or config objects
  config = (typeof (config) === 'string') ? { text: config } : config
  if (values) {
    if (typeof values === 'function') {
      config.callback = values
    } else {
      config.values = values
    }
  }
  if (callback) {
    config.callback = callback
  }
  return config
}

const md5 = function (string) {
  return crypto.createHash('md5').update(string, 'utf-8').digest('hex')
}

// See AuthenticationMD5Password at https://www.postgresql.org/docs/current/static/protocol-flow.html
const postgresMd5PasswordHash = function (user, password, salt) {
  var inner = md5(password + user)
  var outer = md5(Buffer.concat([Buffer.from(inner), salt]))
  return 'md5' + outer
}

module.exports = {
  prepareValue: function prepareValueWrapper (value) {
    // this ensures that extra arguments do not get passed into prepareValue
    // by accident, eg: from calling values.map(utils.prepareValue)
    return prepareValue(value)
  },
  normalizeQueryConfig,
  postgresMd5PasswordHash,
  md5
}


/***/ }),

/***/ "./node_modules/pg/node_modules/semver/semver.js":
/*!*******************************************************!*\
  !*** ./node_modules/pg/node_modules/semver/semver.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;// export the class if we are in a Node-like system.
if (typeof module === 'object' && module.exports === exports)
  exports = module.exports = SemVer;

// The debug function is excluded entirely from the minified version.
/* nomin */ var debug;
/* nomin */ if (typeof process === 'object' &&
    /* nomin */ process.env &&
    /* nomin */ process.env.NODE_DEBUG &&
    /* nomin */ /\bsemver\b/i.test(process.env.NODE_DEBUG))
  /* nomin */ debug = function() {
    /* nomin */ var args = Array.prototype.slice.call(arguments, 0);
    /* nomin */ args.unshift('SEMVER');
    /* nomin */ console.log.apply(console, args);
    /* nomin */ };
/* nomin */ else
  /* nomin */ debug = function() {};

// Note: this is the semver.org version of the spec that it implements
// Not necessarily the package version of this code.
exports.SEMVER_SPEC_VERSION = '2.0.0';

var MAX_LENGTH = 256;
var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;

// The actual regexps go on exports.re
var re = exports.re = [];
var src = exports.src = [];
var R = 0;

// The following Regular Expressions can be used for tokenizing,
// validating, and parsing SemVer version strings.

// ## Numeric Identifier
// A single `0`, or a non-zero digit followed by zero or more digits.

var NUMERICIDENTIFIER = R++;
src[NUMERICIDENTIFIER] = '0|[1-9]\\d*';
var NUMERICIDENTIFIERLOOSE = R++;
src[NUMERICIDENTIFIERLOOSE] = '[0-9]+';


// ## Non-numeric Identifier
// Zero or more digits, followed by a letter or hyphen, and then zero or
// more letters, digits, or hyphens.

var NONNUMERICIDENTIFIER = R++;
src[NONNUMERICIDENTIFIER] = '\\d*[a-zA-Z-][a-zA-Z0-9-]*';


// ## Main Version
// Three dot-separated numeric identifiers.

var MAINVERSION = R++;
src[MAINVERSION] = '(' + src[NUMERICIDENTIFIER] + ')\\.' +
                   '(' + src[NUMERICIDENTIFIER] + ')\\.' +
                   '(' + src[NUMERICIDENTIFIER] + ')';

var MAINVERSIONLOOSE = R++;
src[MAINVERSIONLOOSE] = '(' + src[NUMERICIDENTIFIERLOOSE] + ')\\.' +
                        '(' + src[NUMERICIDENTIFIERLOOSE] + ')\\.' +
                        '(' + src[NUMERICIDENTIFIERLOOSE] + ')';

// ## Pre-release Version Identifier
// A numeric identifier, or a non-numeric identifier.

var PRERELEASEIDENTIFIER = R++;
src[PRERELEASEIDENTIFIER] = '(?:' + src[NUMERICIDENTIFIER] +
                            '|' + src[NONNUMERICIDENTIFIER] + ')';

var PRERELEASEIDENTIFIERLOOSE = R++;
src[PRERELEASEIDENTIFIERLOOSE] = '(?:' + src[NUMERICIDENTIFIERLOOSE] +
                                 '|' + src[NONNUMERICIDENTIFIER] + ')';


// ## Pre-release Version
// Hyphen, followed by one or more dot-separated pre-release version
// identifiers.

var PRERELEASE = R++;
src[PRERELEASE] = '(?:-(' + src[PRERELEASEIDENTIFIER] +
                  '(?:\\.' + src[PRERELEASEIDENTIFIER] + ')*))';

var PRERELEASELOOSE = R++;
src[PRERELEASELOOSE] = '(?:-?(' + src[PRERELEASEIDENTIFIERLOOSE] +
                       '(?:\\.' + src[PRERELEASEIDENTIFIERLOOSE] + ')*))';

// ## Build Metadata Identifier
// Any combination of digits, letters, or hyphens.

var BUILDIDENTIFIER = R++;
src[BUILDIDENTIFIER] = '[0-9A-Za-z-]+';

// ## Build Metadata
// Plus sign, followed by one or more period-separated build metadata
// identifiers.

var BUILD = R++;
src[BUILD] = '(?:\\+(' + src[BUILDIDENTIFIER] +
             '(?:\\.' + src[BUILDIDENTIFIER] + ')*))';


// ## Full Version String
// A main version, followed optionally by a pre-release version and
// build metadata.

// Note that the only major, minor, patch, and pre-release sections of
// the version string are capturing groups.  The build metadata is not a
// capturing group, because it should not ever be used in version
// comparison.

var FULL = R++;
var FULLPLAIN = 'v?' + src[MAINVERSION] +
                src[PRERELEASE] + '?' +
                src[BUILD] + '?';

src[FULL] = '^' + FULLPLAIN + '$';

// like full, but allows v1.2.3 and =1.2.3, which people do sometimes.
// also, 1.0.0alpha1 (prerelease without the hyphen) which is pretty
// common in the npm registry.
var LOOSEPLAIN = '[v=\\s]*' + src[MAINVERSIONLOOSE] +
                 src[PRERELEASELOOSE] + '?' +
                 src[BUILD] + '?';

var LOOSE = R++;
src[LOOSE] = '^' + LOOSEPLAIN + '$';

var GTLT = R++;
src[GTLT] = '((?:<|>)?=?)';

// Something like "2.*" or "1.2.x".
// Note that "x.x" is a valid xRange identifer, meaning "any version"
// Only the first item is strictly required.
var XRANGEIDENTIFIERLOOSE = R++;
src[XRANGEIDENTIFIERLOOSE] = src[NUMERICIDENTIFIERLOOSE] + '|x|X|\\*';
var XRANGEIDENTIFIER = R++;
src[XRANGEIDENTIFIER] = src[NUMERICIDENTIFIER] + '|x|X|\\*';

var XRANGEPLAIN = R++;
src[XRANGEPLAIN] = '[v=\\s]*(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:\\.(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:\\.(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:' + src[PRERELEASE] + ')?' +
                   src[BUILD] + '?' +
                   ')?)?';

var XRANGEPLAINLOOSE = R++;
src[XRANGEPLAINLOOSE] = '[v=\\s]*(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:\\.(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:\\.(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:' + src[PRERELEASELOOSE] + ')?' +
                        src[BUILD] + '?' +
                        ')?)?';

var XRANGE = R++;
src[XRANGE] = '^' + src[GTLT] + '\\s*' + src[XRANGEPLAIN] + '$';
var XRANGELOOSE = R++;
src[XRANGELOOSE] = '^' + src[GTLT] + '\\s*' + src[XRANGEPLAINLOOSE] + '$';

// Tilde ranges.
// Meaning is "reasonably at or greater than"
var LONETILDE = R++;
src[LONETILDE] = '(?:~>?)';

var TILDETRIM = R++;
src[TILDETRIM] = '(\\s*)' + src[LONETILDE] + '\\s+';
re[TILDETRIM] = new RegExp(src[TILDETRIM], 'g');
var tildeTrimReplace = '$1~';

var TILDE = R++;
src[TILDE] = '^' + src[LONETILDE] + src[XRANGEPLAIN] + '$';
var TILDELOOSE = R++;
src[TILDELOOSE] = '^' + src[LONETILDE] + src[XRANGEPLAINLOOSE] + '$';

// Caret ranges.
// Meaning is "at least and backwards compatible with"
var LONECARET = R++;
src[LONECARET] = '(?:\\^)';

var CARETTRIM = R++;
src[CARETTRIM] = '(\\s*)' + src[LONECARET] + '\\s+';
re[CARETTRIM] = new RegExp(src[CARETTRIM], 'g');
var caretTrimReplace = '$1^';

var CARET = R++;
src[CARET] = '^' + src[LONECARET] + src[XRANGEPLAIN] + '$';
var CARETLOOSE = R++;
src[CARETLOOSE] = '^' + src[LONECARET] + src[XRANGEPLAINLOOSE] + '$';

// A simple gt/lt/eq thing, or just "" to indicate "any version"
var COMPARATORLOOSE = R++;
src[COMPARATORLOOSE] = '^' + src[GTLT] + '\\s*(' + LOOSEPLAIN + ')$|^$';
var COMPARATOR = R++;
src[COMPARATOR] = '^' + src[GTLT] + '\\s*(' + FULLPLAIN + ')$|^$';


// An expression to strip any whitespace between the gtlt and the thing
// it modifies, so that `> 1.2.3` ==> `>1.2.3`
var COMPARATORTRIM = R++;
src[COMPARATORTRIM] = '(\\s*)' + src[GTLT] +
                      '\\s*(' + LOOSEPLAIN + '|' + src[XRANGEPLAIN] + ')';

// this one has to use the /g flag
re[COMPARATORTRIM] = new RegExp(src[COMPARATORTRIM], 'g');
var comparatorTrimReplace = '$1$2$3';


// Something like `1.2.3 - 1.2.4`
// Note that these all use the loose form, because they'll be
// checked against either the strict or loose comparator form
// later.
var HYPHENRANGE = R++;
src[HYPHENRANGE] = '^\\s*(' + src[XRANGEPLAIN] + ')' +
                   '\\s+-\\s+' +
                   '(' + src[XRANGEPLAIN] + ')' +
                   '\\s*$';

var HYPHENRANGELOOSE = R++;
src[HYPHENRANGELOOSE] = '^\\s*(' + src[XRANGEPLAINLOOSE] + ')' +
                        '\\s+-\\s+' +
                        '(' + src[XRANGEPLAINLOOSE] + ')' +
                        '\\s*$';

// Star ranges basically just allow anything at all.
var STAR = R++;
src[STAR] = '(<|>)?=?\\s*\\*';

// Compile to actual regexp objects.
// All are flag-free, unless they were created above with a flag.
for (var i = 0; i < R; i++) {
  debug(i, src[i]);
  if (!re[i])
    re[i] = new RegExp(src[i]);
}

exports.parse = parse;
function parse(version, loose) {
  if (version.length > MAX_LENGTH)
    return null;

  var r = loose ? re[LOOSE] : re[FULL];
  if (!r.test(version))
    return null;

  try {
    return new SemVer(version, loose);
  } catch (er) {
    return null;
  }
}

exports.valid = valid;
function valid(version, loose) {
  var v = parse(version, loose);
  return v ? v.version : null;
}


exports.clean = clean;
function clean(version, loose) {
  var s = parse(version.trim().replace(/^[=v]+/, ''), loose);
  return s ? s.version : null;
}

exports.SemVer = SemVer;

function SemVer(version, loose) {
  if (version instanceof SemVer) {
    if (version.loose === loose)
      return version;
    else
      version = version.version;
  } else if (typeof version !== 'string') {
    throw new TypeError('Invalid Version: ' + version);
  }

  if (version.length > MAX_LENGTH)
    throw new TypeError('version is longer than ' + MAX_LENGTH + ' characters')

  if (!(this instanceof SemVer))
    return new SemVer(version, loose);

  debug('SemVer', version, loose);
  this.loose = loose;
  var m = version.trim().match(loose ? re[LOOSE] : re[FULL]);

  if (!m)
    throw new TypeError('Invalid Version: ' + version);

  this.raw = version;

  // these are actually numbers
  this.major = +m[1];
  this.minor = +m[2];
  this.patch = +m[3];

  if (this.major > MAX_SAFE_INTEGER || this.major < 0)
    throw new TypeError('Invalid major version')

  if (this.minor > MAX_SAFE_INTEGER || this.minor < 0)
    throw new TypeError('Invalid minor version')

  if (this.patch > MAX_SAFE_INTEGER || this.patch < 0)
    throw new TypeError('Invalid patch version')

  // numberify any prerelease numeric ids
  if (!m[4])
    this.prerelease = [];
  else
    this.prerelease = m[4].split('.').map(function(id) {
      return (/^[0-9]+$/.test(id)) ? +id : id;
    });

  this.build = m[5] ? m[5].split('.') : [];
  this.format();
}

SemVer.prototype.format = function() {
  this.version = this.major + '.' + this.minor + '.' + this.patch;
  if (this.prerelease.length)
    this.version += '-' + this.prerelease.join('.');
  return this.version;
};

SemVer.prototype.inspect = function() {
  return '<SemVer "' + this + '">';
};

SemVer.prototype.toString = function() {
  return this.version;
};

SemVer.prototype.compare = function(other) {
  debug('SemVer.compare', this.version, this.loose, other);
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  return this.compareMain(other) || this.comparePre(other);
};

SemVer.prototype.compareMain = function(other) {
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  return compareIdentifiers(this.major, other.major) ||
         compareIdentifiers(this.minor, other.minor) ||
         compareIdentifiers(this.patch, other.patch);
};

SemVer.prototype.comparePre = function(other) {
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  // NOT having a prerelease is > having one
  if (this.prerelease.length && !other.prerelease.length)
    return -1;
  else if (!this.prerelease.length && other.prerelease.length)
    return 1;
  else if (!this.prerelease.length && !other.prerelease.length)
    return 0;

  var i = 0;
  do {
    var a = this.prerelease[i];
    var b = other.prerelease[i];
    debug('prerelease compare', i, a, b);
    if (a === undefined && b === undefined)
      return 0;
    else if (b === undefined)
      return 1;
    else if (a === undefined)
      return -1;
    else if (a === b)
      continue;
    else
      return compareIdentifiers(a, b);
  } while (++i);
};

// preminor will bump the version up to the next minor release, and immediately
// down to pre-release. premajor and prepatch work the same way.
SemVer.prototype.inc = function(release, identifier) {
  switch (release) {
    case 'premajor':
      this.prerelease.length = 0;
      this.patch = 0;
      this.minor = 0;
      this.major++;
      this.inc('pre', identifier);
      break;
    case 'preminor':
      this.prerelease.length = 0;
      this.patch = 0;
      this.minor++;
      this.inc('pre', identifier);
      break;
    case 'prepatch':
      // If this is already a prerelease, it will bump to the next version
      // drop any prereleases that might already exist, since they are not
      // relevant at this point.
      this.prerelease.length = 0;
      this.inc('patch', identifier);
      this.inc('pre', identifier);
      break;
    // If the input is a non-prerelease version, this acts the same as
    // prepatch.
    case 'prerelease':
      if (this.prerelease.length === 0)
        this.inc('patch', identifier);
      this.inc('pre', identifier);
      break;

    case 'major':
      // If this is a pre-major version, bump up to the same major version.
      // Otherwise increment major.
      // 1.0.0-5 bumps to 1.0.0
      // 1.1.0 bumps to 2.0.0
      if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0)
        this.major++;
      this.minor = 0;
      this.patch = 0;
      this.prerelease = [];
      break;
    case 'minor':
      // If this is a pre-minor version, bump up to the same minor version.
      // Otherwise increment minor.
      // 1.2.0-5 bumps to 1.2.0
      // 1.2.1 bumps to 1.3.0
      if (this.patch !== 0 || this.prerelease.length === 0)
        this.minor++;
      this.patch = 0;
      this.prerelease = [];
      break;
    case 'patch':
      // If this is not a pre-release version, it will increment the patch.
      // If it is a pre-release it will bump up to the same patch version.
      // 1.2.0-5 patches to 1.2.0
      // 1.2.0 patches to 1.2.1
      if (this.prerelease.length === 0)
        this.patch++;
      this.prerelease = [];
      break;
    // This probably shouldn't be used publicly.
    // 1.0.0 "pre" would become 1.0.0-0 which is the wrong direction.
    case 'pre':
      if (this.prerelease.length === 0)
        this.prerelease = [0];
      else {
        var i = this.prerelease.length;
        while (--i >= 0) {
          if (typeof this.prerelease[i] === 'number') {
            this.prerelease[i]++;
            i = -2;
          }
        }
        if (i === -1) // didn't increment anything
          this.prerelease.push(0);
      }
      if (identifier) {
        // 1.2.0-beta.1 bumps to 1.2.0-beta.2,
        // 1.2.0-beta.fooblz or 1.2.0-beta bumps to 1.2.0-beta.0
        if (this.prerelease[0] === identifier) {
          if (isNaN(this.prerelease[1]))
            this.prerelease = [identifier, 0];
        } else
          this.prerelease = [identifier, 0];
      }
      break;

    default:
      throw new Error('invalid increment argument: ' + release);
  }
  this.format();
  return this;
};

exports.inc = inc;
function inc(version, release, loose, identifier) {
  if (typeof(loose) === 'string') {
    identifier = loose;
    loose = undefined;
  }

  try {
    return new SemVer(version, loose).inc(release, identifier).version;
  } catch (er) {
    return null;
  }
}

exports.diff = diff;
function diff(version1, version2) {
  if (eq(version1, version2)) {
    return null;
  } else {
    var v1 = parse(version1);
    var v2 = parse(version2);
    if (v1.prerelease.length || v2.prerelease.length) {
      for (var key in v1) {
        if (key === 'major' || key === 'minor' || key === 'patch') {
          if (v1[key] !== v2[key]) {
            return 'pre'+key;
          }
        }
      }
      return 'prerelease';
    }
    for (var key in v1) {
      if (key === 'major' || key === 'minor' || key === 'patch') {
        if (v1[key] !== v2[key]) {
          return key;
        }
      }
    }
  }
}

exports.compareIdentifiers = compareIdentifiers;

var numeric = /^[0-9]+$/;
function compareIdentifiers(a, b) {
  var anum = numeric.test(a);
  var bnum = numeric.test(b);

  if (anum && bnum) {
    a = +a;
    b = +b;
  }

  return (anum && !bnum) ? -1 :
         (bnum && !anum) ? 1 :
         a < b ? -1 :
         a > b ? 1 :
         0;
}

exports.rcompareIdentifiers = rcompareIdentifiers;
function rcompareIdentifiers(a, b) {
  return compareIdentifiers(b, a);
}

exports.major = major;
function major(a, loose) {
  return new SemVer(a, loose).major;
}

exports.minor = minor;
function minor(a, loose) {
  return new SemVer(a, loose).minor;
}

exports.patch = patch;
function patch(a, loose) {
  return new SemVer(a, loose).patch;
}

exports.compare = compare;
function compare(a, b, loose) {
  return new SemVer(a, loose).compare(b);
}

exports.compareLoose = compareLoose;
function compareLoose(a, b) {
  return compare(a, b, true);
}

exports.rcompare = rcompare;
function rcompare(a, b, loose) {
  return compare(b, a, loose);
}

exports.sort = sort;
function sort(list, loose) {
  return list.sort(function(a, b) {
    return exports.compare(a, b, loose);
  });
}

exports.rsort = rsort;
function rsort(list, loose) {
  return list.sort(function(a, b) {
    return exports.rcompare(a, b, loose);
  });
}

exports.gt = gt;
function gt(a, b, loose) {
  return compare(a, b, loose) > 0;
}

exports.lt = lt;
function lt(a, b, loose) {
  return compare(a, b, loose) < 0;
}

exports.eq = eq;
function eq(a, b, loose) {
  return compare(a, b, loose) === 0;
}

exports.neq = neq;
function neq(a, b, loose) {
  return compare(a, b, loose) !== 0;
}

exports.gte = gte;
function gte(a, b, loose) {
  return compare(a, b, loose) >= 0;
}

exports.lte = lte;
function lte(a, b, loose) {
  return compare(a, b, loose) <= 0;
}

exports.cmp = cmp;
function cmp(a, op, b, loose) {
  var ret;
  switch (op) {
    case '===':
      if (typeof a === 'object') a = a.version;
      if (typeof b === 'object') b = b.version;
      ret = a === b;
      break;
    case '!==':
      if (typeof a === 'object') a = a.version;
      if (typeof b === 'object') b = b.version;
      ret = a !== b;
      break;
    case '': case '=': case '==': ret = eq(a, b, loose); break;
    case '!=': ret = neq(a, b, loose); break;
    case '>': ret = gt(a, b, loose); break;
    case '>=': ret = gte(a, b, loose); break;
    case '<': ret = lt(a, b, loose); break;
    case '<=': ret = lte(a, b, loose); break;
    default: throw new TypeError('Invalid operator: ' + op);
  }
  return ret;
}

exports.Comparator = Comparator;
function Comparator(comp, loose) {
  if (comp instanceof Comparator) {
    if (comp.loose === loose)
      return comp;
    else
      comp = comp.value;
  }

  if (!(this instanceof Comparator))
    return new Comparator(comp, loose);

  debug('comparator', comp, loose);
  this.loose = loose;
  this.parse(comp);

  if (this.semver === ANY)
    this.value = '';
  else
    this.value = this.operator + this.semver.version;

  debug('comp', this);
}

var ANY = {};
Comparator.prototype.parse = function(comp) {
  var r = this.loose ? re[COMPARATORLOOSE] : re[COMPARATOR];
  var m = comp.match(r);

  if (!m)
    throw new TypeError('Invalid comparator: ' + comp);

  this.operator = m[1];
  if (this.operator === '=')
    this.operator = '';

  // if it literally is just '>' or '' then allow anything.
  if (!m[2])
    this.semver = ANY;
  else
    this.semver = new SemVer(m[2], this.loose);
};

Comparator.prototype.inspect = function() {
  return '<SemVer Comparator "' + this + '">';
};

Comparator.prototype.toString = function() {
  return this.value;
};

Comparator.prototype.test = function(version) {
  debug('Comparator.test', version, this.loose);

  if (this.semver === ANY)
    return true;

  if (typeof version === 'string')
    version = new SemVer(version, this.loose);

  return cmp(version, this.operator, this.semver, this.loose);
};


exports.Range = Range;
function Range(range, loose) {
  if ((range instanceof Range) && range.loose === loose)
    return range;

  if (!(this instanceof Range))
    return new Range(range, loose);

  this.loose = loose;

  // First, split based on boolean or ||
  this.raw = range;
  this.set = range.split(/\s*\|\|\s*/).map(function(range) {
    return this.parseRange(range.trim());
  }, this).filter(function(c) {
    // throw out any that are not relevant for whatever reason
    return c.length;
  });

  if (!this.set.length) {
    throw new TypeError('Invalid SemVer Range: ' + range);
  }

  this.format();
}

Range.prototype.inspect = function() {
  return '<SemVer Range "' + this.range + '">';
};

Range.prototype.format = function() {
  this.range = this.set.map(function(comps) {
    return comps.join(' ').trim();
  }).join('||').trim();
  return this.range;
};

Range.prototype.toString = function() {
  return this.range;
};

Range.prototype.parseRange = function(range) {
  var loose = this.loose;
  range = range.trim();
  debug('range', range, loose);
  // `1.2.3 - 1.2.4` => `>=1.2.3 <=1.2.4`
  var hr = loose ? re[HYPHENRANGELOOSE] : re[HYPHENRANGE];
  range = range.replace(hr, hyphenReplace);
  debug('hyphen replace', range);
  // `> 1.2.3 < 1.2.5` => `>1.2.3 <1.2.5`
  range = range.replace(re[COMPARATORTRIM], comparatorTrimReplace);
  debug('comparator trim', range, re[COMPARATORTRIM]);

  // `~ 1.2.3` => `~1.2.3`
  range = range.replace(re[TILDETRIM], tildeTrimReplace);

  // `^ 1.2.3` => `^1.2.3`
  range = range.replace(re[CARETTRIM], caretTrimReplace);

  // normalize spaces
  range = range.split(/\s+/).join(' ');

  // At this point, the range is completely trimmed and
  // ready to be split into comparators.

  var compRe = loose ? re[COMPARATORLOOSE] : re[COMPARATOR];
  var set = range.split(' ').map(function(comp) {
    return parseComparator(comp, loose);
  }).join(' ').split(/\s+/);
  if (this.loose) {
    // in loose mode, throw out any that are not valid comparators
    set = set.filter(function(comp) {
      return !!comp.match(compRe);
    });
  }
  set = set.map(function(comp) {
    return new Comparator(comp, loose);
  });

  return set;
};

// Mostly just for testing and legacy API reasons
exports.toComparators = toComparators;
function toComparators(range, loose) {
  return new Range(range, loose).set.map(function(comp) {
    return comp.map(function(c) {
      return c.value;
    }).join(' ').trim().split(' ');
  });
}

// comprised of xranges, tildes, stars, and gtlt's at this point.
// already replaced the hyphen ranges
// turn into a set of JUST comparators.
function parseComparator(comp, loose) {
  debug('comp', comp);
  comp = replaceCarets(comp, loose);
  debug('caret', comp);
  comp = replaceTildes(comp, loose);
  debug('tildes', comp);
  comp = replaceXRanges(comp, loose);
  debug('xrange', comp);
  comp = replaceStars(comp, loose);
  debug('stars', comp);
  return comp;
}

function isX(id) {
  return !id || id.toLowerCase() === 'x' || id === '*';
}

// ~, ~> --> * (any, kinda silly)
// ~2, ~2.x, ~2.x.x, ~>2, ~>2.x ~>2.x.x --> >=2.0.0 <3.0.0
// ~2.0, ~2.0.x, ~>2.0, ~>2.0.x --> >=2.0.0 <2.1.0
// ~1.2, ~1.2.x, ~>1.2, ~>1.2.x --> >=1.2.0 <1.3.0
// ~1.2.3, ~>1.2.3 --> >=1.2.3 <1.3.0
// ~1.2.0, ~>1.2.0 --> >=1.2.0 <1.3.0
function replaceTildes(comp, loose) {
  return comp.trim().split(/\s+/).map(function(comp) {
    return replaceTilde(comp, loose);
  }).join(' ');
}

function replaceTilde(comp, loose) {
  var r = loose ? re[TILDELOOSE] : re[TILDE];
  return comp.replace(r, function(_, M, m, p, pr) {
    debug('tilde', comp, _, M, m, p, pr);
    var ret;

    if (isX(M))
      ret = '';
    else if (isX(m))
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    else if (isX(p))
      // ~1.2 == >=1.2.0- <1.3.0-
      ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
    else if (pr) {
      debug('replaceTilde pr', pr);
      if (pr.charAt(0) !== '-')
        pr = '-' + pr;
      ret = '>=' + M + '.' + m + '.' + p + pr +
            ' <' + M + '.' + (+m + 1) + '.0';
    } else
      // ~1.2.3 == >=1.2.3 <1.3.0
      ret = '>=' + M + '.' + m + '.' + p +
            ' <' + M + '.' + (+m + 1) + '.0';

    debug('tilde return', ret);
    return ret;
  });
}

// ^ --> * (any, kinda silly)
// ^2, ^2.x, ^2.x.x --> >=2.0.0 <3.0.0
// ^2.0, ^2.0.x --> >=2.0.0 <3.0.0
// ^1.2, ^1.2.x --> >=1.2.0 <2.0.0
// ^1.2.3 --> >=1.2.3 <2.0.0
// ^1.2.0 --> >=1.2.0 <2.0.0
function replaceCarets(comp, loose) {
  return comp.trim().split(/\s+/).map(function(comp) {
    return replaceCaret(comp, loose);
  }).join(' ');
}

function replaceCaret(comp, loose) {
  debug('caret', comp, loose);
  var r = loose ? re[CARETLOOSE] : re[CARET];
  return comp.replace(r, function(_, M, m, p, pr) {
    debug('caret', comp, _, M, m, p, pr);
    var ret;

    if (isX(M))
      ret = '';
    else if (isX(m))
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    else if (isX(p)) {
      if (M === '0')
        ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
      else
        ret = '>=' + M + '.' + m + '.0 <' + (+M + 1) + '.0.0';
    } else if (pr) {
      debug('replaceCaret pr', pr);
      if (pr.charAt(0) !== '-')
        pr = '-' + pr;
      if (M === '0') {
        if (m === '0')
          ret = '>=' + M + '.' + m + '.' + p + pr +
                ' <' + M + '.' + m + '.' + (+p + 1);
        else
          ret = '>=' + M + '.' + m + '.' + p + pr +
                ' <' + M + '.' + (+m + 1) + '.0';
      } else
        ret = '>=' + M + '.' + m + '.' + p + pr +
              ' <' + (+M + 1) + '.0.0';
    } else {
      debug('no pr');
      if (M === '0') {
        if (m === '0')
          ret = '>=' + M + '.' + m + '.' + p +
                ' <' + M + '.' + m + '.' + (+p + 1);
        else
          ret = '>=' + M + '.' + m + '.' + p +
                ' <' + M + '.' + (+m + 1) + '.0';
      } else
        ret = '>=' + M + '.' + m + '.' + p +
              ' <' + (+M + 1) + '.0.0';
    }

    debug('caret return', ret);
    return ret;
  });
}

function replaceXRanges(comp, loose) {
  debug('replaceXRanges', comp, loose);
  return comp.split(/\s+/).map(function(comp) {
    return replaceXRange(comp, loose);
  }).join(' ');
}

function replaceXRange(comp, loose) {
  comp = comp.trim();
  var r = loose ? re[XRANGELOOSE] : re[XRANGE];
  return comp.replace(r, function(ret, gtlt, M, m, p, pr) {
    debug('xRange', comp, ret, gtlt, M, m, p, pr);
    var xM = isX(M);
    var xm = xM || isX(m);
    var xp = xm || isX(p);
    var anyX = xp;

    if (gtlt === '=' && anyX)
      gtlt = '';

    if (xM) {
      if (gtlt === '>' || gtlt === '<') {
        // nothing is allowed
        ret = '<0.0.0';
      } else {
        // nothing is forbidden
        ret = '*';
      }
    } else if (gtlt && anyX) {
      // replace X with 0
      if (xm)
        m = 0;
      if (xp)
        p = 0;

      if (gtlt === '>') {
        // >1 => >=2.0.0
        // >1.2 => >=1.3.0
        // >1.2.3 => >= 1.2.4
        gtlt = '>=';
        if (xm) {
          M = +M + 1;
          m = 0;
          p = 0;
        } else if (xp) {
          m = +m + 1;
          p = 0;
        }
      } else if (gtlt === '<=') {
        // <=0.7.x is actually <0.8.0, since any 0.7.x should
        // pass.  Similarly, <=7.x is actually <8.0.0, etc.
        gtlt = '<'
        if (xm)
          M = +M + 1
        else
          m = +m + 1
      }

      ret = gtlt + M + '.' + m + '.' + p;
    } else if (xm) {
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    } else if (xp) {
      ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
    }

    debug('xRange return', ret);

    return ret;
  });
}

// Because * is AND-ed with everything else in the comparator,
// and '' means "any version", just remove the *s entirely.
function replaceStars(comp, loose) {
  debug('replaceStars', comp, loose);
  // Looseness is ignored here.  star is always as loose as it gets!
  return comp.trim().replace(re[STAR], '');
}

// This function is passed to string.replace(re[HYPHENRANGE])
// M, m, patch, prerelease, build
// 1.2 - 3.4.5 => >=1.2.0 <=3.4.5
// 1.2.3 - 3.4 => >=1.2.0 <3.5.0 Any 3.4.x will do
// 1.2 - 3.4 => >=1.2.0 <3.5.0
function hyphenReplace($0,
                       from, fM, fm, fp, fpr, fb,
                       to, tM, tm, tp, tpr, tb) {

  if (isX(fM))
    from = '';
  else if (isX(fm))
    from = '>=' + fM + '.0.0';
  else if (isX(fp))
    from = '>=' + fM + '.' + fm + '.0';
  else
    from = '>=' + from;

  if (isX(tM))
    to = '';
  else if (isX(tm))
    to = '<' + (+tM + 1) + '.0.0';
  else if (isX(tp))
    to = '<' + tM + '.' + (+tm + 1) + '.0';
  else if (tpr)
    to = '<=' + tM + '.' + tm + '.' + tp + '-' + tpr;
  else
    to = '<=' + to;

  return (from + ' ' + to).trim();
}


// if ANY of the sets match ALL of its comparators, then pass
Range.prototype.test = function(version) {
  if (!version)
    return false;

  if (typeof version === 'string')
    version = new SemVer(version, this.loose);

  for (var i = 0; i < this.set.length; i++) {
    if (testSet(this.set[i], version))
      return true;
  }
  return false;
};

function testSet(set, version) {
  for (var i = 0; i < set.length; i++) {
    if (!set[i].test(version))
      return false;
  }

  if (version.prerelease.length) {
    // Find the set of versions that are allowed to have prereleases
    // For example, ^1.2.3-pr.1 desugars to >=1.2.3-pr.1 <2.0.0
    // That should allow `1.2.3-pr.2` to pass.
    // However, `1.2.4-alpha.notready` should NOT be allowed,
    // even though it's within the range set by the comparators.
    for (var i = 0; i < set.length; i++) {
      debug(set[i].semver);
      if (set[i].semver === ANY)
        return true;

      if (set[i].semver.prerelease.length > 0) {
        var allowed = set[i].semver;
        if (allowed.major === version.major &&
            allowed.minor === version.minor &&
            allowed.patch === version.patch)
          return true;
      }
    }

    // Version has a -pre, but it's not one of the ones we like.
    return false;
  }

  return true;
}

exports.satisfies = satisfies;
function satisfies(version, range, loose) {
  try {
    range = new Range(range, loose);
  } catch (er) {
    return false;
  }
  return range.test(version);
}

exports.maxSatisfying = maxSatisfying;
function maxSatisfying(versions, range, loose) {
  return versions.filter(function(version) {
    return satisfies(version, range, loose);
  }).sort(function(a, b) {
    return rcompare(a, b, loose);
  })[0] || null;
}

exports.validRange = validRange;
function validRange(range, loose) {
  try {
    // Return '*' instead of '' so that truthiness works.
    // This will throw if it's invalid anyway
    return new Range(range, loose).range || '*';
  } catch (er) {
    return null;
  }
}

// Determine if version is less than all the versions possible in the range
exports.ltr = ltr;
function ltr(version, range, loose) {
  return outside(version, range, '<', loose);
}

// Determine if version is greater than all the versions possible in the range.
exports.gtr = gtr;
function gtr(version, range, loose) {
  return outside(version, range, '>', loose);
}

exports.outside = outside;
function outside(version, range, hilo, loose) {
  version = new SemVer(version, loose);
  range = new Range(range, loose);

  var gtfn, ltefn, ltfn, comp, ecomp;
  switch (hilo) {
    case '>':
      gtfn = gt;
      ltefn = lte;
      ltfn = lt;
      comp = '>';
      ecomp = '>=';
      break;
    case '<':
      gtfn = lt;
      ltefn = gte;
      ltfn = gt;
      comp = '<';
      ecomp = '<=';
      break;
    default:
      throw new TypeError('Must provide a hilo val of "<" or ">"');
  }

  // If it satisifes the range it is not outside
  if (satisfies(version, range, loose)) {
    return false;
  }

  // From now on, variable terms are as if we're in "gtr" mode.
  // but note that everything is flipped for the "ltr" function.

  for (var i = 0; i < range.set.length; ++i) {
    var comparators = range.set[i];

    var high = null;
    var low = null;

    comparators.forEach(function(comparator) {
      high = high || comparator;
      low = low || comparator;
      if (gtfn(comparator.semver, high.semver, loose)) {
        high = comparator;
      } else if (ltfn(comparator.semver, low.semver, loose)) {
        low = comparator;
      }
    });

    // If the edge version comparator has a operator then our version
    // isn't outside it
    if (high.operator === comp || high.operator === ecomp) {
      return false;
    }

    // If the lowest version comparator has an operator and our version
    // is less than it then it isn't higher than the range
    if ((!low.operator || low.operator === comp) &&
        ltefn(version, low.semver)) {
      return false;
    } else if (low.operator === ecomp && ltfn(version, low.semver)) {
      return false;
    }
  }
  return true;
}

// Use the define() function if we're in AMD land
if (true)
  !(__WEBPACK_AMD_DEFINE_FACTORY__ = (exports),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) :
				__WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ "./node_modules/pg/package.json":
/*!**************************************!*\
  !*** ./node_modules/pg/package.json ***!
  \**************************************/
/*! exports provided: _args, _from, _id, _inBundle, _integrity, _location, _phantomChildren, _requested, _requiredBy, _resolved, _spec, _where, author, bugs, dependencies, description, devDependencies, engines, homepage, keywords, license, main, minNativeVersion, name, repository, scripts, version, default */
/***/ (function(module) {

module.exports = {"_args":[["pg@7.4.3","C:\\code\\WazeCCPProcessor\\code\\lambda-functions\\waze-db-initialize"]],"_from":"pg@7.4.3","_id":"pg@7.4.3","_inBundle":false,"_integrity":"sha1-97b5P1NA7MJZavu5ShPj1rYJg0s=","_location":"/pg","_phantomChildren":{},"_requested":{"type":"version","registry":true,"raw":"pg@7.4.3","name":"pg","escapedName":"pg","rawSpec":"7.4.3","saveSpec":null,"fetchSpec":"7.4.3"},"_requiredBy":["/"],"_resolved":"https://registry.npmjs.org/pg/-/pg-7.4.3.tgz","_spec":"7.4.3","_where":"C:\\code\\WazeCCPProcessor\\code\\lambda-functions\\waze-db-initialize","author":{"name":"Brian Carlson","email":"brian.m.carlson@gmail.com"},"bugs":{"url":"https://github.com/brianc/node-postgres/issues"},"dependencies":{"buffer-writer":"1.0.1","packet-reader":"0.3.1","pg-connection-string":"0.1.3","pg-pool":"~2.0.3","pg-types":"~1.12.1","pgpass":"1.x","semver":"4.3.2"},"description":"PostgreSQL client - pure javascript & libpq with the same API","devDependencies":{"async":"0.9.0","co":"4.6.0","eslint":"4.2.0","eslint-config-standard":"10.2.1","eslint-plugin-import":"2.7.0","eslint-plugin-node":"5.1.0","eslint-plugin-promise":"3.5.0","eslint-plugin-standard":"3.0.1","pg-copy-streams":"0.3.0"},"engines":{"node":">= 4.5.0"},"homepage":"http://github.com/brianc/node-postgres","keywords":["database","libpq","pg","postgre","postgres","postgresql","rdbms"],"license":"MIT","main":"./lib","minNativeVersion":"2.0.0","name":"pg","repository":{"type":"git","url":"git://github.com/brianc/node-postgres.git"},"scripts":{"test":"make test-all"},"version":"7.4.3"};

/***/ }),

/***/ "./node_modules/pgpass/lib/helper.js":
/*!*******************************************!*\
  !*** ./node_modules/pgpass/lib/helper.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var path = __webpack_require__(/*! path */ "path")
  , Stream = __webpack_require__(/*! stream */ "stream").Stream
  , Split = __webpack_require__(/*! split */ "./node_modules/split/index.js")
  , util = __webpack_require__(/*! util */ "util")
  , defaultPort = 5432
  , isWin = (process.platform === 'win32')
  , warnStream = process.stderr
;


var S_IRWXG = 56     //    00070(8)
  , S_IRWXO = 7      //    00007(8)
  , S_IFMT  = 61440  // 00170000(8)
  , S_IFREG = 32768  //  0100000(8)
;
function isRegFile(mode) {
    return ((mode & S_IFMT) == S_IFREG);
}

var fieldNames = [ 'host', 'port', 'database', 'user', 'password' ];
var nrOfFields = fieldNames.length;
var passKey = fieldNames[ nrOfFields -1 ];


function warn() {
    var isWritable = (
        warnStream instanceof Stream &&
          true === warnStream.writable
    );

    if (isWritable) {
        var args = Array.prototype.slice.call(arguments).concat("\n");
        warnStream.write( util.format.apply(util, args) );
    }
}


Object.defineProperty(module.exports, 'isWin', {
    get : function() {
        return isWin;
    } ,
    set : function(val) {
        isWin = val;
    }
});


module.exports.warnTo = function(stream) {
    var old = warnStream;
    warnStream = stream;
    return old;
};

module.exports.getFileName = function(env){
    env = env || process.env;
    var file = env.PGPASSFILE || (
        isWin ?
          path.join( env.APPDATA , 'postgresql', 'pgpass.conf' ) :
          path.join( env.HOME, '.pgpass' )
    );
    return file;
};

module.exports.usePgPass = function(stats, fname) {
    if (Object.prototype.hasOwnProperty.call(process.env, 'PGPASSWORD')) {
        return false;
    }

    if (isWin) {
        return true;
    }

    fname = fname || '<unkn>';

    if (! isRegFile(stats.mode)) {
        warn('WARNING: password file "%s" is not a plain file', fname);
        return false;
    }

    if (stats.mode & (S_IRWXG | S_IRWXO)) {
        /* If password file is insecure, alert the user and ignore it. */
        warn('WARNING: password file "%s" has group or world access; permissions should be u=rw (0600) or less', fname);
        return false;
    }

    return true;
};


var matcher = module.exports.match = function(connInfo, entry) {
    return fieldNames.slice(0, -1).reduce(function(prev, field, idx){
        if (idx == 1) {
            // the port
            if ( Number( connInfo[field] || defaultPort ) === Number( entry[field] ) ) {
                return prev && true;
            }
        }
        return prev && (
            entry[field] === '*' ||
              entry[field] === connInfo[field]
        );
    }, true);
};


module.exports.getPassword = function(connInfo, stream, cb) {
    var pass;
    var lineStream = stream.pipe(new Split());

    function onLine(line) {
        var entry = parseLine(line);
        if (entry && isValidEntry(entry) && matcher(connInfo, entry)) {
            pass = entry[passKey];
            lineStream.end(); // -> calls onEnd(), but pass is set now
        }
    }

    var onEnd = function() {
        stream.destroy();
        cb(pass);
    };

    var onErr = function(err) {
        stream.destroy();
        warn('WARNING: error on reading file: %s', err);
        cb(undefined);
    };

    stream.on('error', onErr);
    lineStream
        .on('data', onLine)
        .on('end', onEnd)
        .on('error', onErr)
    ;

};


var parseLine = module.exports.parseLine = function(line) {
    if (line.length < 11 || line.match(/^\s+#/)) {
        return null;
    }

    var curChar = '';
    var prevChar = '';
    var fieldIdx = 0;
    var startIdx = 0;
    var endIdx = 0;
    var obj = {};
    var isLastField = false;
    var addToObj = function(idx, i0, i1) {
        var field = line.substring(i0, i1);

        if (! Object.hasOwnProperty.call(process.env, 'PGPASS_NO_DEESCAPE')) {
            field = field.replace(/\\([:\\])/g, '$1');
        }

        obj[ fieldNames[idx] ] = field;
    };

    for (var i = 0 ; i < line.length-1 ; i += 1) {
        curChar = line.charAt(i+1);
        prevChar = line.charAt(i);

        isLastField = (fieldIdx == nrOfFields-1);

        if (isLastField) {
            addToObj(fieldIdx, startIdx);
            break;
        }

        if (i >= 0 && curChar == ':' && prevChar !== '\\') {
            addToObj(fieldIdx, startIdx, i+1);

            startIdx = i+2;
            fieldIdx += 1;
        }
    }

    obj = ( Object.keys(obj).length === nrOfFields ) ? obj : null;

    return obj;
};


var isValidEntry = module.exports.isValidEntry = function(entry){
    var rules = {
        // host
        0 : function(x){
            return x.length > 0;
        } ,
        // port
        1 : function(x){
            if (x === '*') {
                return true;
            }
            x = Number(x);
            return (
                isFinite(x) &&
                  x > 0 &&
                  x < 9007199254740992 &&
                  Math.floor(x) === x
            );
        } ,
        // database
        2 : function(x){
            return x.length > 0;
        } ,
        // username
        3 : function(x){
            return x.length > 0;
        } ,
        // password
        4 : function(x){
            return x.length > 0;
        }
    };

    for (var idx = 0 ; idx < fieldNames.length ; idx += 1) {
        var rule = rules[idx];
        var value = entry[ fieldNames[idx] ] || '';

        var res = rule(value);
        if (!res) {
            return false;
        }
    }

    return true;
};



/***/ }),

/***/ "./node_modules/pgpass/lib/index.js":
/*!******************************************!*\
  !*** ./node_modules/pgpass/lib/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var path = __webpack_require__(/*! path */ "path")
  , fs = __webpack_require__(/*! fs */ "fs")
  , helper = __webpack_require__(/*! ./helper.js */ "./node_modules/pgpass/lib/helper.js")
;


module.exports = function(connInfo, cb) {
    var file = helper.getFileName();
    
    fs.stat(file, function(err, stat){
        if (err || !helper.usePgPass(stat, file)) {
            return cb(undefined);
        }

        var st = fs.createReadStream(file);

        helper.getPassword(connInfo, st, cb);
    });
};

module.exports.warnTo = helper.warnTo;


/***/ }),

/***/ "./node_modules/postgres-array/index.js":
/*!**********************************************!*\
  !*** ./node_modules/postgres-array/index.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.parse = function (source, transform) {
  return new ArrayParser(source, transform).parse()
}

function ArrayParser (source, transform) {
  this.source = source
  this.transform = transform || identity
  this.position = 0
  this.entries = []
  this.recorded = []
  this.dimension = 0
}

ArrayParser.prototype.isEof = function () {
  return this.position >= this.source.length
}

ArrayParser.prototype.nextCharacter = function () {
  var character = this.source[this.position++]
  if (character === '\\') {
    return {
      value: this.source[this.position++],
      escaped: true
    }
  }
  return {
    value: character,
    escaped: false
  }
}

ArrayParser.prototype.record = function (character) {
  this.recorded.push(character)
}

ArrayParser.prototype.newEntry = function (includeEmpty) {
  var entry
  if (this.recorded.length > 0 || includeEmpty) {
    entry = this.recorded.join('')
    if (entry === 'NULL' && !includeEmpty) {
      entry = null
    }
    if (entry !== null) entry = this.transform(entry)
    this.entries.push(entry)
    this.recorded = []
  }
}

ArrayParser.prototype.parse = function (nested) {
  var character, parser, quote
  while (!this.isEof()) {
    character = this.nextCharacter()
    if (character.value === '{' && !quote) {
      this.dimension++
      if (this.dimension > 1) {
        parser = new ArrayParser(this.source.substr(this.position - 1), this.transform)
        this.entries.push(parser.parse(true))
        this.position += parser.position - 2
      }
    } else if (character.value === '}' && !quote) {
      this.dimension--
      if (!this.dimension) {
        this.newEntry()
        if (nested) return this.entries
      }
    } else if (character.value === '"' && !character.escaped) {
      if (quote) this.newEntry(true)
      quote = !quote
    } else if (character.value === ',' && !quote) {
      this.newEntry()
    } else {
      this.record(character.value)
    }
  }
  if (this.dimension !== 0) {
    throw new Error('array dimension not balanced')
  }
  return this.entries
}

function identity (value) {
  return value
}


/***/ }),

/***/ "./node_modules/postgres-bytea/index.js":
/*!**********************************************!*\
  !*** ./node_modules/postgres-bytea/index.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function parseBytea (input) {
  if (/^\\x/.test(input)) {
    // new 'hex' style response (pg >9.0)
    return new Buffer(input.substr(2), 'hex')
  }
  var output = ''
  var i = 0
  while (i < input.length) {
    if (input[i] !== '\\') {
      output += input[i]
      ++i
    } else {
      if (/[0-7]{3}/.test(input.substr(i + 1, 3))) {
        output += String.fromCharCode(parseInt(input.substr(i + 1, 3), 8))
        i += 4
      } else {
        var backslashes = 1
        while (i + backslashes < input.length && input[i + backslashes] === '\\') {
          backslashes++
        }
        for (var k = 0; k < Math.floor(backslashes / 2); ++k) {
          output += '\\'
        }
        i += Math.floor(backslashes / 2) * 2
      }
    }
  }
  return new Buffer(output, 'binary')
}


/***/ }),

/***/ "./node_modules/postgres-date/index.js":
/*!*********************************************!*\
  !*** ./node_modules/postgres-date/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var DATE_TIME = /(\d{1,})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d{1,})?/
var DATE = /^(\d{1,})-(\d{2})-(\d{2})$/
var TIME_ZONE = /([Z+-])(\d{2})?:?(\d{2})?:?(\d{2})?/
var BC = /BC$/
var INFINITY = /^-?infinity$/

module.exports = function parseDate (isoDate) {
  if (INFINITY.test(isoDate)) {
    // Capitalize to Infinity before passing to Number
    return Number(isoDate.replace('i', 'I'))
  }
  var matches = DATE_TIME.exec(isoDate)

  if (!matches) {
    // Force YYYY-MM-DD dates to be parsed as local time
    return DATE.test(isoDate) ?
      getDate(isoDate) :
      null
  }

  var isBC = BC.test(isoDate)
  var year = parseInt(matches[1], 10)
  var isFirstCentury = year > 0 && year < 100
  year = (isBC ? '-' : '') + year

  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  var hour = parseInt(matches[4], 10)
  var minute = parseInt(matches[5], 10)
  var second = parseInt(matches[6], 10)

  var ms = matches[7]
  ms = ms ? 1000 * parseFloat(ms) : 0

  var date
  var offset = timeZoneOffset(isoDate)
  if (offset != null) {
    var utc = Date.UTC(year, month, day, hour, minute, second, ms)
    date = new Date(utc - offset)
  } else {
    date = new Date(year, month, day, hour, minute, second, ms)
  }

  if (isFirstCentury) {
    date.setUTCFullYear(year)
  }

  return date
}

function getDate (isoDate) {
  var matches = DATE.exec(isoDate)
  var year = parseInt(matches[1], 10)
  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  // YYYY-MM-DD will be parsed as local time
  var date = new Date(year, month, day)
  date.setFullYear(year)
  return date
}

// match timezones:
// Z (UTC)
// -05
// +06:30
function timeZoneOffset (isoDate) {
  var zone = TIME_ZONE.exec(isoDate.split(' ')[1])
  if (!zone) return
  var type = zone[1]

  if (type === 'Z') {
    return 0
  }
  var sign = type === '-' ? -1 : 1
  var offset = parseInt(zone[2], 10) * 3600 +
    parseInt(zone[3] || 0, 10) * 60 +
    parseInt(zone[4] || 0, 10)

  return offset * sign * 1000
}


/***/ }),

/***/ "./node_modules/postgres-interval/index.js":
/*!*************************************************!*\
  !*** ./node_modules/postgres-interval/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var extend = __webpack_require__(/*! xtend/mutable */ "./node_modules/xtend/mutable.js")

module.exports = PostgresInterval

function PostgresInterval (raw) {
  if (!(this instanceof PostgresInterval)) {
    return new PostgresInterval(raw)
  }
  extend(this, parse(raw))
}
var properties = ['seconds', 'minutes', 'hours', 'days', 'months', 'years']
PostgresInterval.prototype.toPostgres = function () {
  var filtered = properties.filter(this.hasOwnProperty, this)

  // In addition to `properties`, we need to account for fractions of seconds.
  if (this.milliseconds && filtered.indexOf('seconds') < 0) {
    filtered.push('seconds')
  }

  if (filtered.length === 0) return '0'
  return filtered
    .map(function (property) {
      var value = this[property] || 0

      // Account for fractional part of seconds,
      // remove trailing zeroes.
      if (property === 'seconds' && this.milliseconds) {
        value = (value + this.milliseconds / 1000).toFixed(6).replace(/\.?0+$/, '')
      }

      return value + ' ' + property
    }, this)
    .join(' ')
}

var propertiesISOEquivalent = {
  years: 'Y',
  months: 'M',
  days: 'D',
  hours: 'H',
  minutes: 'M',
  seconds: 'S'
}
var dateProperties = ['years', 'months', 'days']
var timeProperties = ['hours', 'minutes', 'seconds']
// according to ISO 8601
PostgresInterval.prototype.toISO = function () {
  var datePart = dateProperties
    .map(buildProperty, this)
    .join('')

  var timePart = timeProperties
    .map(buildProperty, this)
    .join('')

  return 'P' + datePart + 'T' + timePart

  function buildProperty (property) {
    var value = this[property] || 0

    // Account for fractional part of seconds,
    // remove trailing zeroes.
    if (property === 'seconds' && this.milliseconds) {
      value = (value + this.milliseconds / 1000).toFixed(6).replace(/0+$/, '')
    }

    return value + propertiesISOEquivalent[property]
  }

}

var NUMBER = '([+-]?\\d+)'
var YEAR = NUMBER + '\\s+years?'
var MONTH = NUMBER + '\\s+mons?'
var DAY = NUMBER + '\\s+days?'
var TIME = '([+-])?([\\d]*):(\\d\\d):(\\d\\d)\.?(\\d{1,6})?'
var INTERVAL = new RegExp([YEAR, MONTH, DAY, TIME].map(function (regexString) {
  return '(' + regexString + ')?'
})
.join('\\s*'))

// Positions of values in regex match
var positions = {
  years: 2,
  months: 4,
  days: 6,
  hours: 9,
  minutes: 10,
  seconds: 11,
  milliseconds: 12
}
// We can use negative time
var negatives = ['hours', 'minutes', 'seconds', 'milliseconds']

function parseMilliseconds (fraction) {
  // add omitted zeroes
  var microseconds = fraction + '000000'.slice(fraction.length)
  return parseInt(microseconds, 10) / 1000
}

function parse (interval) {
  if (!interval) return {}
  var matches = INTERVAL.exec(interval)
  var isNegative = matches[8] === '-'
  return Object.keys(positions)
    .reduce(function (parsed, property) {
      var position = positions[property]
      var value = matches[position]
      // no empty string
      if (!value) return parsed
      // milliseconds are actually microseconds (up to 6 digits)
      // with omitted trailing zeroes.
      value = property === 'milliseconds'
        ? parseMilliseconds(value)
        : parseInt(value, 10)
      // no zeros
      if (!value) return parsed
      if (isNegative && ~negatives.indexOf(property)) {
        value *= -1
      }
      parsed[property] = value
      return parsed
    }, {})
}


/***/ }),

/***/ "./node_modules/split/index.js":
/*!*************************************!*\
  !*** ./node_modules/split/index.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

//filter will reemit the data if cb(err,pass) pass is truthy

// reduce is more tricky
// maybe we want to group the reductions or emit progress updates occasionally
// the most basic reduce just emits one 'data' event after it has recieved 'end'


var through = __webpack_require__(/*! through */ "./node_modules/through/index.js")
var Decoder = __webpack_require__(/*! string_decoder */ "string_decoder").StringDecoder

module.exports = split

//TODO pass in a function to map across the lines.

function split (matcher, mapper, options) {
  var decoder = new Decoder()
  var soFar = ''
  var maxLength = options && options.maxLength;
  var trailing = options && options.trailing === false ? false : true
  if('function' === typeof matcher)
    mapper = matcher, matcher = null
  if (!matcher)
    matcher = /\r?\n/

  function emit(stream, piece) {
    if(mapper) {
      try {
        piece = mapper(piece)
      }
      catch (err) {
        return stream.emit('error', err)
      }
      if('undefined' !== typeof piece)
        stream.queue(piece)
    }
    else
      stream.queue(piece)
  }

  function next (stream, buffer) {
    var pieces = ((soFar != null ? soFar : '') + buffer).split(matcher)
    soFar = pieces.pop()

    if (maxLength && soFar.length > maxLength)
      return stream.emit('error', new Error('maximum buffer reached'))

    for (var i = 0; i < pieces.length; i++) {
      var piece = pieces[i]
      emit(stream, piece)
    }
  }

  return through(function (b) {
    next(this, decoder.write(b))
  },
  function () {
    if(decoder.end)
      next(this, decoder.end())
    if(trailing && soFar != null)
      emit(this, soFar)
    this.queue(null)
  })
}


/***/ }),

/***/ "./node_modules/through/index.js":
/*!***************************************!*\
  !*** ./node_modules/through/index.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Stream = __webpack_require__(/*! stream */ "stream")

// through
//
// a stream that does nothing but re-emit the input.
// useful for aggregating a series of changing but not ending streams into one stream)

exports = module.exports = through
through.through = through

//create a readable writable stream.

function through (write, end, opts) {
  write = write || function (data) { this.queue(data) }
  end = end || function () { this.queue(null) }

  var ended = false, destroyed = false, buffer = [], _ended = false
  var stream = new Stream()
  stream.readable = stream.writable = true
  stream.paused = false

//  stream.autoPause   = !(opts && opts.autoPause   === false)
  stream.autoDestroy = !(opts && opts.autoDestroy === false)

  stream.write = function (data) {
    write.call(this, data)
    return !stream.paused
  }

  function drain() {
    while(buffer.length && !stream.paused) {
      var data = buffer.shift()
      if(null === data)
        return stream.emit('end')
      else
        stream.emit('data', data)
    }
  }

  stream.queue = stream.push = function (data) {
//    console.error(ended)
    if(_ended) return stream
    if(data === null) _ended = true
    buffer.push(data)
    drain()
    return stream
  }

  //this will be registered as the first 'end' listener
  //must call destroy next tick, to make sure we're after any
  //stream piped from here.
  //this is only a problem if end is not emitted synchronously.
  //a nicer way to do this is to make sure this is the last listener for 'end'

  stream.on('end', function () {
    stream.readable = false
    if(!stream.writable && stream.autoDestroy)
      process.nextTick(function () {
        stream.destroy()
      })
  })

  function _end () {
    stream.writable = false
    end.call(stream)
    if(!stream.readable && stream.autoDestroy)
      stream.destroy()
  }

  stream.end = function (data) {
    if(ended) return
    ended = true
    if(arguments.length) stream.write(data)
    _end() // will emit or queue
    return stream
  }

  stream.destroy = function () {
    if(destroyed) return
    destroyed = true
    ended = true
    buffer.length = 0
    stream.writable = stream.readable = false
    stream.emit('close')
    return stream
  }

  stream.pause = function () {
    if(stream.paused) return
    stream.paused = true
    return stream
  }

  stream.resume = function () {
    if(stream.paused) {
      stream.paused = false
      stream.emit('resume')
    }
    drain()
    //may have become paused again,
    //as drain emits 'data'.
    if(!stream.paused)
      stream.emit('drain')
    return stream
  }
  return stream
}



/***/ }),

/***/ "./node_modules/wrappy/wrappy.js":
/*!***************************************!*\
  !*** ./node_modules/wrappy/wrappy.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Returns a wrapper function that returns a wrapped callback
// The wrapper function should do some stuff, and return a
// presumably different callback function.
// This makes sure that own properties are retained, so that
// decorations and such are not lost along the way.
module.exports = wrappy
function wrappy (fn, cb) {
  if (fn && cb) return wrappy(fn)(cb)

  if (typeof fn !== 'function')
    throw new TypeError('need wrapper function')

  Object.keys(fn).forEach(function (k) {
    wrapper[k] = fn[k]
  })

  return wrapper

  function wrapper() {
    var args = new Array(arguments.length)
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i]
    }
    var ret = fn.apply(this, args)
    var cb = args[args.length-1]
    if (typeof ret === 'function' && ret !== cb) {
      Object.keys(cb).forEach(function (k) {
        ret[k] = cb[k]
      })
    }
    return ret
  }
}


/***/ }),

/***/ "./node_modules/xtend/mutable.js":
/*!***************************************!*\
  !*** ./node_modules/xtend/mutable.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = extend

var hasOwnProperty = Object.prototype.hasOwnProperty;

function extend(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i]

        for (var key in source) {
            if (hasOwnProperty.call(source, key)) {
                target[key] = source[key]
            }
        }
    }

    return target
}


/***/ }),

/***/ "./src/waze-db-initialize.ts":
/*!***********************************!*\
  !*** ./src/waze-db-initialize.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const pg = __webpack_require__(/*! pg */ "./node_modules/pg/lib/index.js");
const fs = __webpack_require__(/*! fs */ "fs");
const glob = __webpack_require__(/*! glob */ "./node_modules/glob/glob.js");
const initializeDatabase = (event, context, callback) => __awaiter(this, void 0, void 0, function* () {
    try {
        var dbClient = new pg.Client();
        yield dbClient.connect();
        let lambda_username = process.env.LAMBDAPGUSER;
        let lambda_password = process.env.LAMBDAPGPASSWORD;
        let readonly_username = process.env.READONLYPGUSER;
        let readonly_password = process.env.READONLYPASSWORD;
        let current_version = process.env.CURRENTVERSION;
        var fileNames = glob.sync("*.sql", {});
        for (let fileName of fileNames) {
            if (!fileName.match(/^\d/)) {
                console.log("Skipping " + fileName + " because it doesn't start with a digit");
                continue;
            }
            let fileContent = fs.readFileSync(fileName, 'utf-8');
            fileContent = fileContent.replace(/^\uFEFF/, '');
            const lambdaUserPlaceholder = 'LAMBDA_ROLE_NAME_PLACEHOLDER';
            const lambdaPassPlaceholder = 'LAMBDA_ROLE_PASSWORD_PLACEHOLDER';
            const readonlyUserPlaceholder = 'READONLY_ROLE_NAME_PLACEHOLDER';
            const readonlyPassPlaceholder = 'READONLY_ROLE_PASSWORD_PLACEHOLDER';
            let replacedFileContent = fileContent.replace(new RegExp(lambdaUserPlaceholder, 'g'), lambda_username)
                .replace(new RegExp(lambdaPassPlaceholder, 'g'), lambda_password)
                .replace(new RegExp(readonlyUserPlaceholder, 'g'), readonly_username)
                .replace(new RegExp(readonlyPassPlaceholder, 'g'), readonly_password);
            let wasReplaced = "";
            if (fileContent != replacedFileContent) {
                wasReplaced = " (with replacements)";
            }
            console.log("Executing " + fileName + wasReplaced);
            let results = yield dbClient.query(replacedFileContent);
            for (let index in results) {
                let result = results[index];
                console.log(index + ". " + result.command + " " + (result.rowCount === null ? "" : result.rowCount));
            }
        }
        console.log('Database intialization succeeded');
        return { response: "Database intialization succeeded" };
    }
    catch (err) {
        console.error(err);
        callback(err);
        return err;
    }
    finally {
        yield dbClient.end();
    }
});
exports.initializeDatabase = initializeDatabase;
function formatTerraformWarning(warningMessage) {
    return `
    
    WARNING! ********************* WARNING! ********************* WARNING!
    ${warningMessage}
    WARNING! ********************* WARNING! ********************* WARNING!

    `;
}
console.log("test 9:53am");
initializeDatabase(null, null, (r) => console.log("callback: " + JSON.stringify(r)));


/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("assert");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),

/***/ "dns":
/*!**********************!*\
  !*** external "dns" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("dns");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("net");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),

/***/ "pg-native":
/*!****************************!*\
  !*** external "pg-native" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("pg-native");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("string_decoder");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ })));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2JhbGFuY2VkLW1hdGNoL2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9icmFjZS1leHBhbnNpb24vaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2J1ZmZlci13cml0ZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2NvbmNhdC1tYXAvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2ZzLnJlYWxwYXRoL2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9mcy5yZWFscGF0aC9vbGQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2dsb2IvY29tbW9uLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9nbG9iL2dsb2IuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2dsb2Ivc3luYy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvaW5mbGlnaHQvaW5mbGlnaHQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2luaGVyaXRzL2luaGVyaXRzLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9pbmhlcml0cy9pbmhlcml0c19icm93c2VyLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9taW5pbWF0Y2gvbWluaW1hdGNoLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9vbmNlL29uY2UuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3BhY2tldC1yZWFkZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3BhdGgtaXMtYWJzb2x1dGUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3BnLWNvbm5lY3Rpb24tc3RyaW5nL2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy1wb29sL2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy10eXBlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcGctdHlwZXMvbGliL2FycmF5UGFyc2VyLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy10eXBlcy9saWIvYmluYXJ5UGFyc2Vycy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcGctdHlwZXMvbGliL3RleHRQYXJzZXJzLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9saWIvY2xpZW50LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9saWIvY29ubmVjdGlvbi1wYXJhbWV0ZXJzLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9saWIvY29ubmVjdGlvbi5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcGcvbGliL2RlZmF1bHRzLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9saWIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9uYXRpdmUvY2xpZW50LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9saWIvbmF0aXZlL2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9saWIvbmF0aXZlL3F1ZXJ5LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9saWIvcXVlcnkuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9yZXN1bHQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi90eXBlLW92ZXJyaWRlcy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcGcvbGliL3V0aWxzLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wZy9ub2RlX21vZHVsZXMvc2VtdmVyL3NlbXZlci5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcGdwYXNzL2xpYi9oZWxwZXIuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3BncGFzcy9saWIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3Bvc3RncmVzLWFycmF5L2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9wb3N0Z3Jlcy1ieXRlYS9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcG9zdGdyZXMtZGF0ZS9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcG9zdGdyZXMtaW50ZXJ2YWwvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3NwbGl0L2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy90aHJvdWdoL2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy93cmFwcHkvd3JhcHB5LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy94dGVuZC9tdXRhYmxlLmpzIiwid2VicGFjazovLy8uL3NyYy93YXplLWRiLWluaXRpYWxpemUudHMiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiYXNzZXJ0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiY3J5cHRvXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZG5zXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZXZlbnRzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZnNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJwYXRoXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicGctbmF0aXZlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwic3RyZWFtXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwic3RyaW5nX2RlY29kZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJ0bHNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJ1cmxcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJ1dGlsXCIiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esa0RBQTBDLGdDQUFnQztBQUMxRTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdFQUF3RCxrQkFBa0I7QUFDMUU7QUFDQSx5REFBaUQsY0FBYztBQUMvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQXlDLGlDQUFpQztBQUMxRSx3SEFBZ0gsbUJBQW1CLEVBQUU7QUFDckk7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBMkIsMEJBQTBCLEVBQUU7QUFDdkQseUNBQWlDLGVBQWU7QUFDaEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0EsOERBQXNELCtEQUErRDs7QUFFckg7QUFDQTs7O0FBR0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7Ozs7Ozs7QUMxREE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHVCQUF1QjtBQUN2Qix1QkFBdUI7QUFDdkI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxtQ0FBbUM7QUFDbkMsb0NBQW9DO0FBQ3BDO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBLHdDQUF3QyxHQUFHLElBQUk7QUFDL0M7QUFDQTtBQUNBOztBQUVBO0FBQ0EscUJBQXFCLEtBQUs7O0FBRTFCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEscUJBQXFCLGFBQWE7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhCQUE4QjtBQUM5Qix1Q0FBdUMsR0FBRztBQUMxQyxZQUFZLEdBQUcseUJBQXlCO0FBQ3hDO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUIsY0FBYyxHQUFHO0FBQ2pCOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsV0FBVyxZQUFZO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLHFCQUFxQixLQUFLO0FBQzFCOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLEVBQUU7QUFDViwyQkFBMkI7QUFDM0Isc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsWUFBWSxLQUFLLFFBQVEsRUFBRSxJQUFJLEVBQUU7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBLG1CQUFtQixZQUFZO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxtQ0FBbUMsMkJBQTJCO0FBQzlEOztBQUVBLGlCQUFpQixjQUFjO0FBQy9CLG1CQUFtQixpQkFBaUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDdk1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTs7QUFFQSxpQ0FBaUM7QUFDakM7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDaElBO0FBQ0E7QUFDQSxtQkFBbUIsZUFBZTtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDakVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsMENBQTBDLEVBQUU7QUFDNUMsQ0FBQztBQUNEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLG9CQUFvQjtBQUNwQjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLG9CQUFvQjtBQUNwQjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQzlTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsWUFBWTtBQUNwRDs7QUFFQTtBQUNBLHFDQUFxQyxZQUFZO0FBQ2pEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFdBQVcsZ0NBQWdDO0FBQzNDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUEsMENBQTBDLE9BQU87QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG1CQUFtQixnQkFBZ0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSzs7QUFFTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEdBQUc7QUFDSDs7Ozs7Ozs7Ozs7O0FDL09BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHlCQUF5QjtBQUN6Qjs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSxpQkFBaUIsbUJBQW1CO0FBQ3BDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsZ0NBQWdDLHFCQUFxQjtBQUNyRDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLGlCQUFpQixPQUFPO0FBQ3hCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGlCQUFpQix5QkFBeUI7QUFDMUM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsZUFBZTtBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixlQUFlO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxpQkFBaUIsb0JBQW9CO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSxtQkFBbUIsU0FBUztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixTQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLG9CQUFvQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLGlCQUFpQixTQUFTO0FBQzFCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7O0FDcnhCQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGlCQUFpQixPQUFPO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGlCQUFpQixvQkFBb0I7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLG1CQUFtQixTQUFTO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFNBQVM7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixvQkFBb0I7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSxpQkFBaUIsU0FBUztBQUMxQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3JlQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixTQUFTO0FBQzlCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBOztBQUVBLGlCQUFpQixZQUFZO0FBQzdCO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3JEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBOzs7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDdEJBO0FBQ0E7O0FBRUEsWUFBWTtBQUNaO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7O0FBRUE7QUFDQSxRQUFRLHVDQUF1QztBQUMvQyxRQUFRLDJCQUEyQjtBQUNuQyxRQUFRLDJCQUEyQjtBQUNuQyxRQUFRLDJCQUEyQjtBQUNuQyxRQUFRO0FBQ1I7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLElBQUk7O0FBRTdDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGdDQUFnQzs7QUFFaEMsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRyxJQUFJO0FBQ1A7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxLQUFLO0FBQ0wsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxLQUFLLElBQUk7QUFDVCxLQUFLLEdBQUc7QUFDUixLQUFLLEtBQUs7QUFDVixLQUFLLElBQUksSUFBSSxFQUFFO0FBQ2YsS0FBSyxJQUFJLEVBQUUsSUFBSTtBQUNmO0FBQ0E7QUFDQSxLQUFLLElBQUksT0FBTyxJQUFJO0FBQ3BCLEtBQUssRUFBRSxPQUFPLEVBQUU7QUFDaEI7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHNCQUFzQixJQUFJO0FBQzFCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsSUFBSTtBQUN4QztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLEtBQUs7QUFDTCxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQSxLQUFLO0FBQ0wsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLElBQUk7QUFDdkM7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLEVBQUUsRUFBRSxLQUFLO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSzs7QUFFTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxRQUFRO0FBQ2hEOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLHNCQUFzQjtBQUNyQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSw2Q0FBNkM7QUFDN0M7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHOztBQUVIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixRQUFRO0FBQ2hDO0FBQ0E7QUFDQTs7QUFFQSxhQUFhLGdCQUFnQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxLQUFLLDZDQUE2Qzs7QUFFbEQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsT0FBTztBQUNQO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxTQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSwyQkFBMkI7QUFDM0I7Ozs7Ozs7Ozs7OztBQzE1QkE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxHQUFHO0FBQ0gsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUN6Q0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDaEVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EseUNBQXlDLEVBQUU7QUFDM0M7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNuQkE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUM3REE7QUFDQTs7QUFFQSwwQkFBMEI7O0FBRTFCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILFVBQVU7QUFDVjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUM7QUFDbkM7QUFDQSxnREFBZ0Q7QUFDaEQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTzs7QUFFUDtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDclNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxVQUFVO0FBQ1Y7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7QUM1Q0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWQTtBQUNBO0FBQ0E7QUFDQSw4REFBOEQsbURBQW1EO0FBQ2pIOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSwrQkFBK0IsV0FBVztBQUMxQztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLG1CQUFtQixXQUFXO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUJBQWlCLGFBQWE7QUFDOUI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUJBQWlCLFNBQVM7QUFDMUI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGlCQUFpQixXQUFXO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsa0JBQWtCO0FBQ25DO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUM3UEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0EsY0FBYyxhQUFhO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7O0FBRUE7QUFDQSxjQUFjLGFBQWE7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTs7QUFFQTtBQUNBLGNBQWMsYUFBYTs7QUFFM0I7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZUFBZSxhQUFhOztBQUU1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBOztBQUVBO0FBQ0EsZUFBZSxhQUFhOztBQUU1QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsNkJBQTZCLGVBQWU7QUFDNUM7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSwrQkFBK0IsdUJBQXVCLEVBQUU7QUFDeEQ7O0FBRUE7QUFDQSx5QkFBeUIsYUFBYTs7QUFFdEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDZDQUE2QyxhQUFhOztBQUUxRDtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsc0JBQXNCO0FBQ3ZDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLGdDQUFnQztBQUNoQyw2QkFBNkI7QUFDN0IsNkJBQTZCO0FBQzdCLDZCQUE2QjtBQUM3Qiw0QkFBNEI7QUFDNUIsNEJBQTRCO0FBQzVCO0FBQ0EsNEJBQTRCO0FBQzVCLDRCQUE0QjtBQUM1Qiw0QkFBNEI7QUFDNUIsNEJBQTRCO0FBQzVCLGtDQUFrQztBQUNsQyw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBLG9DQUFvQztBQUNwQyxvQ0FBb0M7QUFDcEMsb0NBQW9DO0FBQ3BDLHVDQUF1QztBQUN2QyxrQ0FBa0M7QUFDbEMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEMsbUNBQW1DO0FBQ25DLG1DQUFtQztBQUNuQztBQUNBO0FBQ0EsbUNBQW1DO0FBQ25DLG1DQUFtQztBQUNuQyxpQ0FBaUM7QUFDakMsaUNBQWlDO0FBQ2pDLGlDQUFpQztBQUNqQztBQUNBO0FBQ0EsdUNBQXVDO0FBQ3ZDLHdDQUF3QztBQUN4QyxnQ0FBZ0M7QUFDaEMsaUNBQWlDO0FBQ2pDLG1DQUFtQztBQUNuQyxtQ0FBbUM7QUFDbkMsa0NBQWtDO0FBQ2xDLG1DQUFtQztBQUNuQyxtQ0FBbUM7QUFDbkM7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDNU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLGlCQUFpQixnQkFBZ0I7QUFDakM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGlCQUFpQixnQkFBZ0I7QUFDakM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7OztBQ2xhQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHVEQUF1RDtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDdEhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFNBQVM7QUFDMUI7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixTQUFTLE9BQU87QUFDakM7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLHFCQUFxQjtBQUN4QztBQUNBLGVBQWUsU0FBUyxPQUFPO0FBQy9CO0FBQ0E7QUFDQSxpQkFBaUIsU0FBUztBQUMxQjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsb0JBQW9CO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsZ0JBQWdCO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLGlCQUFpQjtBQUNsQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUM3b0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7QUNyRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxnQ0FBZ0MsaUJBQWlCO0FBQ2pEO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLENBQUM7QUFDRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7Ozs7QUN4REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTzs7QUFFUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxPQUFPOztBQUVQO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7O0FBRUg7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsRUFBRTtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2pPQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLOztBQUVMO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWCxTQUFTO0FBQ1QsT0FBTztBQUNQO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQy9KQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUNBQWlDOztBQUVqQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDdk9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSx1Q0FBdUMsU0FBUztBQUNoRDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsdUNBQXVDLFNBQVM7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLGVBQWU7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQiw4QkFBOEI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDdkdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7OztBQ3RDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsaUJBQWlCLGdCQUFnQjtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRyxPQUFPOztBQUVWO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSw2Q0FBNkMsZUFBZTtBQUM1RDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ25LQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxlQUFlLE9BQU87QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7O0FBRUw7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3REFBd0Q7QUFDeEQsc0NBQXNDO0FBQ3RDLG9DQUFvQztBQUNwQyxzQ0FBc0M7QUFDdEMsb0NBQW9DO0FBQ3BDLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsaUJBQWlCLHFCQUFxQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsaUJBQWlCLGdCQUFnQjtBQUNqQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLGdCQUFnQjtBQUNuQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLGlCQUFpQixzQkFBc0I7QUFDdkM7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxLQUFLOztBQUVMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0cUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7QUFHRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG9FQUFvRTtBQUNwRTtBQUNBOztBQUVBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7O0FBR0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7OztBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSxvQkFBb0Isb0JBQW9CO0FBQ3hDO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsc0JBQXNCLDBCQUEwQjtBQUNoRDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7QUN2T0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7Ozs7Ozs7Ozs7Ozs7QUN0QkE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSyxnQ0FBZ0M7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDcEZBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsaUJBQWlCLEVBQUU7QUFDbkI7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixpQ0FBaUM7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQzlCQTs7QUFFQSxxQkFBcUIsR0FBRyxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sR0FBRztBQUMxRSxpQkFBaUIsR0FBRyxNQUFNLEVBQUUsTUFBTSxFQUFFO0FBQ3BDLDRCQUE0QixFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUU7QUFDbEQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDakZBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxJQUFJO0FBQ3pEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLLElBQUk7QUFDVDs7Ozs7Ozs7Ozs7O0FDN0hBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSxtQkFBbUIsbUJBQW1CO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOzs7Ozs7Ozs7Ozs7QUM5REE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLG9DQUFvQztBQUNwQyw0QkFBNEI7O0FBRTVCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUMxR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHOztBQUVIOztBQUVBO0FBQ0E7QUFDQSxtQkFBbUIsaUJBQWlCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNoQ0E7O0FBRUE7O0FBRUE7QUFDQSxtQkFBbUIsc0JBQXNCO0FBQ3pDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RBLDJFQUEwQjtBQUMxQiwrQ0FBMEI7QUFDMUIsNEVBQThCO0FBRTlCLE1BQU0sa0JBQWtCLEdBQVksQ0FBTyxLQUFVLEVBQUUsT0FBZ0IsRUFBRSxRQUFrQixFQUFFLEVBQUU7SUFDM0YsSUFBSTtRQUdBLElBQUksUUFBUSxHQUFHLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRy9CLE1BQU0sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBR3pCLElBQUksZUFBZSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBQy9DLElBQUksZUFBZSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7UUFDbkQsSUFBSSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQztRQUNuRCxJQUFJLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7UUFDckQsSUFBSSxlQUFlLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUEwRWpELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRXZDLEtBQUssSUFBSSxRQUFRLElBQUksU0FBUyxFQUFFO1lBQzVCLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBQyxRQUFRLEdBQUMsd0NBQXdDLENBQUMsQ0FBQztnQkFDM0UsU0FBUzthQUNaO1lBRUQsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFckQsV0FBVyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBSWpELE1BQU0scUJBQXFCLEdBQUcsOEJBQThCLENBQUM7WUFDN0QsTUFBTSxxQkFBcUIsR0FBRyxrQ0FBa0MsQ0FBQztZQUNqRSxNQUFNLHVCQUF1QixHQUFHLGdDQUFnQyxDQUFDO1lBQ2pFLE1BQU0sdUJBQXVCLEdBQUcsb0NBQW9DLENBQUM7WUFHckUsSUFBSSxtQkFBbUIsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxFQUFFLGVBQWUsQ0FBQztpQkFDakcsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxFQUFFLGVBQWUsQ0FBQztpQkFDaEUsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLHVCQUF1QixFQUFFLEdBQUcsQ0FBQyxFQUFFLGlCQUFpQixDQUFDO2lCQUNwRSxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsdUJBQXVCLEVBQUUsR0FBRyxDQUFDLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztZQUUxRSxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7WUFDckIsSUFBSSxXQUFXLElBQUksbUJBQW1CLEVBQUU7Z0JBQ3BDLFdBQVcsR0FBRyxzQkFBc0IsQ0FBQzthQUN4QztZQUdELE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLFFBQVEsR0FBRyxXQUFXLENBQUMsQ0FBQztZQUNuRCxJQUFJLE9BQU8sR0FBRyxNQUFNLFFBQVEsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUN4RCxLQUFJLElBQUksS0FBSyxJQUFJLE9BQWMsRUFBRTtnQkFDN0IsSUFBSSxNQUFNLEdBQUksT0FBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUVyQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxJQUFJLEdBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRSxHQUFHLEdBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzthQUNuRztTQUNKO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO1FBQ2hELE9BQU8sRUFBRSxRQUFRLEVBQUUsa0NBQWtDLEVBQUU7S0FDMUQ7SUFDRCxPQUFPLEdBQUcsRUFBRTtRQUNSLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbkIsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsT0FBTyxHQUFHLENBQUM7S0FDZDtZQUNPO1FBRUosTUFBTSxRQUFRLENBQUMsR0FBRyxFQUFFLENBQUM7S0FDeEI7QUFDTCxDQUFDLEVBQUM7QUFFTyxnREFBa0I7QUFHM0IsZ0NBQWdDLGNBQXNCO0lBQ2xELE9BQU87OztNQUdMLGNBQWM7OztLQUdmLENBQUM7QUFDTixDQUFDO0FBR0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUMzQixrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0FDbktyRixtQzs7Ozs7Ozs7Ozs7QUNBQSxtQzs7Ozs7Ozs7Ozs7QUNBQSxnQzs7Ozs7Ozs7Ozs7QUNBQSxtQzs7Ozs7Ozs7Ozs7QUNBQSwrQjs7Ozs7Ozs7Ozs7QUNBQSxnQzs7Ozs7Ozs7Ozs7QUNBQSxpQzs7Ozs7Ozs7Ozs7QUNBQSxzQzs7Ozs7Ozs7Ozs7QUNBQSxtQzs7Ozs7Ozs7Ozs7QUNBQSwyQzs7Ozs7Ozs7Ozs7QUNBQSxnQzs7Ozs7Ozs7Ozs7QUNBQSxnQzs7Ozs7Ozs7Ozs7QUNBQSxpQyIsImZpbGUiOiJ3YXplLWRiLWluaXRpYWxpemUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy93YXplLWRiLWluaXRpYWxpemUudHNcIik7XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGJhbGFuY2VkO1xuZnVuY3Rpb24gYmFsYW5jZWQoYSwgYiwgc3RyKSB7XG4gIGlmIChhIGluc3RhbmNlb2YgUmVnRXhwKSBhID0gbWF5YmVNYXRjaChhLCBzdHIpO1xuICBpZiAoYiBpbnN0YW5jZW9mIFJlZ0V4cCkgYiA9IG1heWJlTWF0Y2goYiwgc3RyKTtcblxuICB2YXIgciA9IHJhbmdlKGEsIGIsIHN0cik7XG5cbiAgcmV0dXJuIHIgJiYge1xuICAgIHN0YXJ0OiByWzBdLFxuICAgIGVuZDogclsxXSxcbiAgICBwcmU6IHN0ci5zbGljZSgwLCByWzBdKSxcbiAgICBib2R5OiBzdHIuc2xpY2UoclswXSArIGEubGVuZ3RoLCByWzFdKSxcbiAgICBwb3N0OiBzdHIuc2xpY2UoclsxXSArIGIubGVuZ3RoKVxuICB9O1xufVxuXG5mdW5jdGlvbiBtYXliZU1hdGNoKHJlZywgc3RyKSB7XG4gIHZhciBtID0gc3RyLm1hdGNoKHJlZyk7XG4gIHJldHVybiBtID8gbVswXSA6IG51bGw7XG59XG5cbmJhbGFuY2VkLnJhbmdlID0gcmFuZ2U7XG5mdW5jdGlvbiByYW5nZShhLCBiLCBzdHIpIHtcbiAgdmFyIGJlZ3MsIGJlZywgbGVmdCwgcmlnaHQsIHJlc3VsdDtcbiAgdmFyIGFpID0gc3RyLmluZGV4T2YoYSk7XG4gIHZhciBiaSA9IHN0ci5pbmRleE9mKGIsIGFpICsgMSk7XG4gIHZhciBpID0gYWk7XG5cbiAgaWYgKGFpID49IDAgJiYgYmkgPiAwKSB7XG4gICAgYmVncyA9IFtdO1xuICAgIGxlZnQgPSBzdHIubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGkgPj0gMCAmJiAhcmVzdWx0KSB7XG4gICAgICBpZiAoaSA9PSBhaSkge1xuICAgICAgICBiZWdzLnB1c2goaSk7XG4gICAgICAgIGFpID0gc3RyLmluZGV4T2YoYSwgaSArIDEpO1xuICAgICAgfSBlbHNlIGlmIChiZWdzLmxlbmd0aCA9PSAxKSB7XG4gICAgICAgIHJlc3VsdCA9IFsgYmVncy5wb3AoKSwgYmkgXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJlZyA9IGJlZ3MucG9wKCk7XG4gICAgICAgIGlmIChiZWcgPCBsZWZ0KSB7XG4gICAgICAgICAgbGVmdCA9IGJlZztcbiAgICAgICAgICByaWdodCA9IGJpO1xuICAgICAgICB9XG5cbiAgICAgICAgYmkgPSBzdHIuaW5kZXhPZihiLCBpICsgMSk7XG4gICAgICB9XG5cbiAgICAgIGkgPSBhaSA8IGJpICYmIGFpID49IDAgPyBhaSA6IGJpO1xuICAgIH1cblxuICAgIGlmIChiZWdzLmxlbmd0aCkge1xuICAgICAgcmVzdWx0ID0gWyBsZWZ0LCByaWdodCBdO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59XG4iLCJ2YXIgY29uY2F0TWFwID0gcmVxdWlyZSgnY29uY2F0LW1hcCcpO1xudmFyIGJhbGFuY2VkID0gcmVxdWlyZSgnYmFsYW5jZWQtbWF0Y2gnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBleHBhbmRUb3A7XG5cbnZhciBlc2NTbGFzaCA9ICdcXDBTTEFTSCcrTWF0aC5yYW5kb20oKSsnXFwwJztcbnZhciBlc2NPcGVuID0gJ1xcME9QRU4nK01hdGgucmFuZG9tKCkrJ1xcMCc7XG52YXIgZXNjQ2xvc2UgPSAnXFwwQ0xPU0UnK01hdGgucmFuZG9tKCkrJ1xcMCc7XG52YXIgZXNjQ29tbWEgPSAnXFwwQ09NTUEnK01hdGgucmFuZG9tKCkrJ1xcMCc7XG52YXIgZXNjUGVyaW9kID0gJ1xcMFBFUklPRCcrTWF0aC5yYW5kb20oKSsnXFwwJztcblxuZnVuY3Rpb24gbnVtZXJpYyhzdHIpIHtcbiAgcmV0dXJuIHBhcnNlSW50KHN0ciwgMTApID09IHN0clxuICAgID8gcGFyc2VJbnQoc3RyLCAxMClcbiAgICA6IHN0ci5jaGFyQ29kZUF0KDApO1xufVxuXG5mdW5jdGlvbiBlc2NhcGVCcmFjZXMoc3RyKSB7XG4gIHJldHVybiBzdHIuc3BsaXQoJ1xcXFxcXFxcJykuam9pbihlc2NTbGFzaClcbiAgICAgICAgICAgIC5zcGxpdCgnXFxcXHsnKS5qb2luKGVzY09wZW4pXG4gICAgICAgICAgICAuc3BsaXQoJ1xcXFx9Jykuam9pbihlc2NDbG9zZSlcbiAgICAgICAgICAgIC5zcGxpdCgnXFxcXCwnKS5qb2luKGVzY0NvbW1hKVxuICAgICAgICAgICAgLnNwbGl0KCdcXFxcLicpLmpvaW4oZXNjUGVyaW9kKTtcbn1cblxuZnVuY3Rpb24gdW5lc2NhcGVCcmFjZXMoc3RyKSB7XG4gIHJldHVybiBzdHIuc3BsaXQoZXNjU2xhc2gpLmpvaW4oJ1xcXFwnKVxuICAgICAgICAgICAgLnNwbGl0KGVzY09wZW4pLmpvaW4oJ3snKVxuICAgICAgICAgICAgLnNwbGl0KGVzY0Nsb3NlKS5qb2luKCd9JylcbiAgICAgICAgICAgIC5zcGxpdChlc2NDb21tYSkuam9pbignLCcpXG4gICAgICAgICAgICAuc3BsaXQoZXNjUGVyaW9kKS5qb2luKCcuJyk7XG59XG5cblxuLy8gQmFzaWNhbGx5IGp1c3Qgc3RyLnNwbGl0KFwiLFwiKSwgYnV0IGhhbmRsaW5nIGNhc2VzXG4vLyB3aGVyZSB3ZSBoYXZlIG5lc3RlZCBicmFjZWQgc2VjdGlvbnMsIHdoaWNoIHNob3VsZCBiZVxuLy8gdHJlYXRlZCBhcyBpbmRpdmlkdWFsIG1lbWJlcnMsIGxpa2Uge2Ese2IsY30sZH1cbmZ1bmN0aW9uIHBhcnNlQ29tbWFQYXJ0cyhzdHIpIHtcbiAgaWYgKCFzdHIpXG4gICAgcmV0dXJuIFsnJ107XG5cbiAgdmFyIHBhcnRzID0gW107XG4gIHZhciBtID0gYmFsYW5jZWQoJ3snLCAnfScsIHN0cik7XG5cbiAgaWYgKCFtKVxuICAgIHJldHVybiBzdHIuc3BsaXQoJywnKTtcblxuICB2YXIgcHJlID0gbS5wcmU7XG4gIHZhciBib2R5ID0gbS5ib2R5O1xuICB2YXIgcG9zdCA9IG0ucG9zdDtcbiAgdmFyIHAgPSBwcmUuc3BsaXQoJywnKTtcblxuICBwW3AubGVuZ3RoLTFdICs9ICd7JyArIGJvZHkgKyAnfSc7XG4gIHZhciBwb3N0UGFydHMgPSBwYXJzZUNvbW1hUGFydHMocG9zdCk7XG4gIGlmIChwb3N0Lmxlbmd0aCkge1xuICAgIHBbcC5sZW5ndGgtMV0gKz0gcG9zdFBhcnRzLnNoaWZ0KCk7XG4gICAgcC5wdXNoLmFwcGx5KHAsIHBvc3RQYXJ0cyk7XG4gIH1cblxuICBwYXJ0cy5wdXNoLmFwcGx5KHBhcnRzLCBwKTtcblxuICByZXR1cm4gcGFydHM7XG59XG5cbmZ1bmN0aW9uIGV4cGFuZFRvcChzdHIpIHtcbiAgaWYgKCFzdHIpXG4gICAgcmV0dXJuIFtdO1xuXG4gIC8vIEkgZG9uJ3Qga25vdyB3aHkgQmFzaCA0LjMgZG9lcyB0aGlzLCBidXQgaXQgZG9lcy5cbiAgLy8gQW55dGhpbmcgc3RhcnRpbmcgd2l0aCB7fSB3aWxsIGhhdmUgdGhlIGZpcnN0IHR3byBieXRlcyBwcmVzZXJ2ZWRcbiAgLy8gYnV0ICpvbmx5KiBhdCB0aGUgdG9wIGxldmVsLCBzbyB7fSxhfWIgd2lsbCBub3QgZXhwYW5kIHRvIGFueXRoaW5nLFxuICAvLyBidXQgYXt9LGJ9YyB3aWxsIGJlIGV4cGFuZGVkIHRvIFthfWMsYWJjXS5cbiAgLy8gT25lIGNvdWxkIGFyZ3VlIHRoYXQgdGhpcyBpcyBhIGJ1ZyBpbiBCYXNoLCBidXQgc2luY2UgdGhlIGdvYWwgb2ZcbiAgLy8gdGhpcyBtb2R1bGUgaXMgdG8gbWF0Y2ggQmFzaCdzIHJ1bGVzLCB3ZSBlc2NhcGUgYSBsZWFkaW5nIHt9XG4gIGlmIChzdHIuc3Vic3RyKDAsIDIpID09PSAne30nKSB7XG4gICAgc3RyID0gJ1xcXFx7XFxcXH0nICsgc3RyLnN1YnN0cigyKTtcbiAgfVxuXG4gIHJldHVybiBleHBhbmQoZXNjYXBlQnJhY2VzKHN0ciksIHRydWUpLm1hcCh1bmVzY2FwZUJyYWNlcyk7XG59XG5cbmZ1bmN0aW9uIGlkZW50aXR5KGUpIHtcbiAgcmV0dXJuIGU7XG59XG5cbmZ1bmN0aW9uIGVtYnJhY2Uoc3RyKSB7XG4gIHJldHVybiAneycgKyBzdHIgKyAnfSc7XG59XG5mdW5jdGlvbiBpc1BhZGRlZChlbCkge1xuICByZXR1cm4gL14tPzBcXGQvLnRlc3QoZWwpO1xufVxuXG5mdW5jdGlvbiBsdGUoaSwgeSkge1xuICByZXR1cm4gaSA8PSB5O1xufVxuZnVuY3Rpb24gZ3RlKGksIHkpIHtcbiAgcmV0dXJuIGkgPj0geTtcbn1cblxuZnVuY3Rpb24gZXhwYW5kKHN0ciwgaXNUb3ApIHtcbiAgdmFyIGV4cGFuc2lvbnMgPSBbXTtcblxuICB2YXIgbSA9IGJhbGFuY2VkKCd7JywgJ30nLCBzdHIpO1xuICBpZiAoIW0gfHwgL1xcJCQvLnRlc3QobS5wcmUpKSByZXR1cm4gW3N0cl07XG5cbiAgdmFyIGlzTnVtZXJpY1NlcXVlbmNlID0gL14tP1xcZCtcXC5cXC4tP1xcZCsoPzpcXC5cXC4tP1xcZCspPyQvLnRlc3QobS5ib2R5KTtcbiAgdmFyIGlzQWxwaGFTZXF1ZW5jZSA9IC9eW2EtekEtWl1cXC5cXC5bYS16QS1aXSg/OlxcLlxcLi0/XFxkKyk/JC8udGVzdChtLmJvZHkpO1xuICB2YXIgaXNTZXF1ZW5jZSA9IGlzTnVtZXJpY1NlcXVlbmNlIHx8IGlzQWxwaGFTZXF1ZW5jZTtcbiAgdmFyIGlzT3B0aW9ucyA9IG0uYm9keS5pbmRleE9mKCcsJykgPj0gMDtcbiAgaWYgKCFpc1NlcXVlbmNlICYmICFpc09wdGlvbnMpIHtcbiAgICAvLyB7YX0sYn1cbiAgICBpZiAobS5wb3N0Lm1hdGNoKC8sLipcXH0vKSkge1xuICAgICAgc3RyID0gbS5wcmUgKyAneycgKyBtLmJvZHkgKyBlc2NDbG9zZSArIG0ucG9zdDtcbiAgICAgIHJldHVybiBleHBhbmQoc3RyKTtcbiAgICB9XG4gICAgcmV0dXJuIFtzdHJdO1xuICB9XG5cbiAgdmFyIG47XG4gIGlmIChpc1NlcXVlbmNlKSB7XG4gICAgbiA9IG0uYm9keS5zcGxpdCgvXFwuXFwuLyk7XG4gIH0gZWxzZSB7XG4gICAgbiA9IHBhcnNlQ29tbWFQYXJ0cyhtLmJvZHkpO1xuICAgIGlmIChuLmxlbmd0aCA9PT0gMSkge1xuICAgICAgLy8geHt7YSxifX15ID09PiB4e2F9eSB4e2J9eVxuICAgICAgbiA9IGV4cGFuZChuWzBdLCBmYWxzZSkubWFwKGVtYnJhY2UpO1xuICAgICAgaWYgKG4ubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHZhciBwb3N0ID0gbS5wb3N0Lmxlbmd0aFxuICAgICAgICAgID8gZXhwYW5kKG0ucG9zdCwgZmFsc2UpXG4gICAgICAgICAgOiBbJyddO1xuICAgICAgICByZXR1cm4gcG9zdC5tYXAoZnVuY3Rpb24ocCkge1xuICAgICAgICAgIHJldHVybiBtLnByZSArIG5bMF0gKyBwO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBhdCB0aGlzIHBvaW50LCBuIGlzIHRoZSBwYXJ0cywgYW5kIHdlIGtub3cgaXQncyBub3QgYSBjb21tYSBzZXRcbiAgLy8gd2l0aCBhIHNpbmdsZSBlbnRyeS5cblxuICAvLyBubyBuZWVkIHRvIGV4cGFuZCBwcmUsIHNpbmNlIGl0IGlzIGd1YXJhbnRlZWQgdG8gYmUgZnJlZSBvZiBicmFjZS1zZXRzXG4gIHZhciBwcmUgPSBtLnByZTtcbiAgdmFyIHBvc3QgPSBtLnBvc3QubGVuZ3RoXG4gICAgPyBleHBhbmQobS5wb3N0LCBmYWxzZSlcbiAgICA6IFsnJ107XG5cbiAgdmFyIE47XG5cbiAgaWYgKGlzU2VxdWVuY2UpIHtcbiAgICB2YXIgeCA9IG51bWVyaWMoblswXSk7XG4gICAgdmFyIHkgPSBudW1lcmljKG5bMV0pO1xuICAgIHZhciB3aWR0aCA9IE1hdGgubWF4KG5bMF0ubGVuZ3RoLCBuWzFdLmxlbmd0aClcbiAgICB2YXIgaW5jciA9IG4ubGVuZ3RoID09IDNcbiAgICAgID8gTWF0aC5hYnMobnVtZXJpYyhuWzJdKSlcbiAgICAgIDogMTtcbiAgICB2YXIgdGVzdCA9IGx0ZTtcbiAgICB2YXIgcmV2ZXJzZSA9IHkgPCB4O1xuICAgIGlmIChyZXZlcnNlKSB7XG4gICAgICBpbmNyICo9IC0xO1xuICAgICAgdGVzdCA9IGd0ZTtcbiAgICB9XG4gICAgdmFyIHBhZCA9IG4uc29tZShpc1BhZGRlZCk7XG5cbiAgICBOID0gW107XG5cbiAgICBmb3IgKHZhciBpID0geDsgdGVzdChpLCB5KTsgaSArPSBpbmNyKSB7XG4gICAgICB2YXIgYztcbiAgICAgIGlmIChpc0FscGhhU2VxdWVuY2UpIHtcbiAgICAgICAgYyA9IFN0cmluZy5mcm9tQ2hhckNvZGUoaSk7XG4gICAgICAgIGlmIChjID09PSAnXFxcXCcpXG4gICAgICAgICAgYyA9ICcnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYyA9IFN0cmluZyhpKTtcbiAgICAgICAgaWYgKHBhZCkge1xuICAgICAgICAgIHZhciBuZWVkID0gd2lkdGggLSBjLmxlbmd0aDtcbiAgICAgICAgICBpZiAobmVlZCA+IDApIHtcbiAgICAgICAgICAgIHZhciB6ID0gbmV3IEFycmF5KG5lZWQgKyAxKS5qb2luKCcwJyk7XG4gICAgICAgICAgICBpZiAoaSA8IDApXG4gICAgICAgICAgICAgIGMgPSAnLScgKyB6ICsgYy5zbGljZSgxKTtcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgYyA9IHogKyBjO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgTi5wdXNoKGMpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBOID0gY29uY2F0TWFwKG4sIGZ1bmN0aW9uKGVsKSB7IHJldHVybiBleHBhbmQoZWwsIGZhbHNlKSB9KTtcbiAgfVxuXG4gIGZvciAodmFyIGogPSAwOyBqIDwgTi5sZW5ndGg7IGorKykge1xuICAgIGZvciAodmFyIGsgPSAwOyBrIDwgcG9zdC5sZW5ndGg7IGsrKykge1xuICAgICAgdmFyIGV4cGFuc2lvbiA9IHByZSArIE5bal0gKyBwb3N0W2tdO1xuICAgICAgaWYgKCFpc1RvcCB8fCBpc1NlcXVlbmNlIHx8IGV4cGFuc2lvbilcbiAgICAgICAgZXhwYW5zaW9ucy5wdXNoKGV4cGFuc2lvbik7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGV4cGFuc2lvbnM7XG59XG5cbiIsIi8vYmluYXJ5IGRhdGEgd3JpdGVyIHR1bmVkIGZvciBjcmVhdGluZ1xuLy9wb3N0Z3JlcyBtZXNzYWdlIHBhY2tldHMgYXMgZWZmZWNpZW50bHkgYXMgcG9zc2libGUgYnkgcmV1c2luZyB0aGVcbi8vc2FtZSBidWZmZXIgdG8gYXZvaWQgbWVtY3B5IGFuZCBsaW1pdCBtZW1vcnkgYWxsb2NhdGlvbnNcbnZhciBXcml0ZXIgPSBtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKHNpemUpIHtcbiAgdGhpcy5zaXplID0gc2l6ZSB8fCAxMDI0O1xuICB0aGlzLmJ1ZmZlciA9IEJ1ZmZlcih0aGlzLnNpemUgKyA1KTtcbiAgdGhpcy5vZmZzZXQgPSA1O1xuICB0aGlzLmhlYWRlclBvc2l0aW9uID0gMDtcbn07XG5cbi8vcmVzaXplcyBpbnRlcm5hbCBidWZmZXIgaWYgbm90IGVub3VnaCBzaXplIGxlZnRcbldyaXRlci5wcm90b3R5cGUuX2Vuc3VyZSA9IGZ1bmN0aW9uKHNpemUpIHtcbiAgdmFyIHJlbWFpbmluZyA9IHRoaXMuYnVmZmVyLmxlbmd0aCAtIHRoaXMub2Zmc2V0O1xuICBpZihyZW1haW5pbmcgPCBzaXplKSB7XG4gICAgdmFyIG9sZEJ1ZmZlciA9IHRoaXMuYnVmZmVyO1xuICAgIC8vIGV4cG9uZW50aWFsIGdyb3d0aCBmYWN0b3Igb2YgYXJvdW5kIH4gMS41XG4gICAgLy8gaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMjI2OTA2My9idWZmZXItZ3Jvd3RoLXN0cmF0ZWd5XG4gICAgdmFyIG5ld1NpemUgPSBvbGRCdWZmZXIubGVuZ3RoICsgKG9sZEJ1ZmZlci5sZW5ndGggPj4gMSkgKyBzaXplO1xuICAgIHRoaXMuYnVmZmVyID0gbmV3IEJ1ZmZlcihuZXdTaXplKTtcbiAgICBvbGRCdWZmZXIuY29weSh0aGlzLmJ1ZmZlcik7XG4gIH1cbn07XG5cbldyaXRlci5wcm90b3R5cGUuYWRkSW50MzIgPSBmdW5jdGlvbihudW0pIHtcbiAgdGhpcy5fZW5zdXJlKDQpO1xuICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+IDI0ICYgMHhGRik7XG4gIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gMTYgJiAweEZGKTtcbiAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiAgOCAmIDB4RkYpO1xuICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+ICAwICYgMHhGRik7XG4gIHJldHVybiB0aGlzO1xufTtcblxuV3JpdGVyLnByb3RvdHlwZS5hZGRJbnQxNiA9IGZ1bmN0aW9uKG51bSkge1xuICB0aGlzLl9lbnN1cmUoMik7XG4gIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gIDggJiAweEZGKTtcbiAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiAgMCAmIDB4RkYpO1xuICByZXR1cm4gdGhpcztcbn07XG5cbi8vZm9yIHZlcnNpb25zIG9mIG5vZGUgcmVxdWlyaW5nICdsZW5ndGgnIGFzIDNyZCBhcmd1bWVudCB0byBidWZmZXIud3JpdGVcbnZhciB3cml0ZVN0cmluZyA9IGZ1bmN0aW9uKGJ1ZmZlciwgc3RyaW5nLCBvZmZzZXQsIGxlbikge1xuICBidWZmZXIud3JpdGUoc3RyaW5nLCBvZmZzZXQsIGxlbik7XG59O1xuXG4vL292ZXJ3cml0ZSBmdW5jdGlvbiBmb3Igb2xkZXIgdmVyc2lvbnMgb2Ygbm9kZVxuaWYoQnVmZmVyLnByb3RvdHlwZS53cml0ZS5sZW5ndGggPT09IDMpIHtcbiAgd3JpdGVTdHJpbmcgPSBmdW5jdGlvbihidWZmZXIsIHN0cmluZywgb2Zmc2V0LCBsZW4pIHtcbiAgICBidWZmZXIud3JpdGUoc3RyaW5nLCBvZmZzZXQpO1xuICB9O1xufVxuXG5Xcml0ZXIucHJvdG90eXBlLmFkZENTdHJpbmcgPSBmdW5jdGlvbihzdHJpbmcpIHtcbiAgLy9qdXN0IHdyaXRlIGEgMCBmb3IgZW1wdHkgb3IgbnVsbCBzdHJpbmdzXG4gIGlmKCFzdHJpbmcpIHtcbiAgICB0aGlzLl9lbnN1cmUoMSk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIGxlbiA9IEJ1ZmZlci5ieXRlTGVuZ3RoKHN0cmluZyk7XG4gICAgdGhpcy5fZW5zdXJlKGxlbiArIDEpOyAvLysxIGZvciBudWxsIHRlcm1pbmF0b3JcbiAgICB3cml0ZVN0cmluZyh0aGlzLmJ1ZmZlciwgc3RyaW5nLCB0aGlzLm9mZnNldCwgbGVuKTtcbiAgICB0aGlzLm9mZnNldCArPSBsZW47XG4gIH1cblxuICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IDA7IC8vIG51bGwgdGVybWluYXRvclxuICByZXR1cm4gdGhpcztcbn07XG5cbldyaXRlci5wcm90b3R5cGUuYWRkQ2hhciA9IGZ1bmN0aW9uKGMpIHtcbiAgdGhpcy5fZW5zdXJlKDEpO1xuICB3cml0ZVN0cmluZyh0aGlzLmJ1ZmZlciwgYywgdGhpcy5vZmZzZXQsIDEpO1xuICB0aGlzLm9mZnNldCsrO1xuICByZXR1cm4gdGhpcztcbn07XG5cbldyaXRlci5wcm90b3R5cGUuYWRkU3RyaW5nID0gZnVuY3Rpb24oc3RyaW5nKSB7XG4gIHN0cmluZyA9IHN0cmluZyB8fCBcIlwiO1xuICB2YXIgbGVuID0gQnVmZmVyLmJ5dGVMZW5ndGgoc3RyaW5nKTtcbiAgdGhpcy5fZW5zdXJlKGxlbik7XG4gIHRoaXMuYnVmZmVyLndyaXRlKHN0cmluZywgdGhpcy5vZmZzZXQpO1xuICB0aGlzLm9mZnNldCArPSBsZW47XG4gIHJldHVybiB0aGlzO1xufTtcblxuV3JpdGVyLnByb3RvdHlwZS5nZXRCeXRlTGVuZ3RoID0gZnVuY3Rpb24oKSB7XG4gIHJldHVybiB0aGlzLm9mZnNldCAtIDU7XG59O1xuXG5Xcml0ZXIucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uKG90aGVyQnVmZmVyKSB7XG4gIHRoaXMuX2Vuc3VyZShvdGhlckJ1ZmZlci5sZW5ndGgpO1xuICBvdGhlckJ1ZmZlci5jb3B5KHRoaXMuYnVmZmVyLCB0aGlzLm9mZnNldCk7XG4gIHRoaXMub2Zmc2V0ICs9IG90aGVyQnVmZmVyLmxlbmd0aDtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5Xcml0ZXIucHJvdG90eXBlLmNsZWFyID0gZnVuY3Rpb24oKSB7XG4gIHRoaXMub2Zmc2V0ID0gNTtcbiAgdGhpcy5oZWFkZXJQb3NpdGlvbiA9IDA7XG4gIHRoaXMubGFzdEVuZCA9IDA7XG59O1xuXG4vL2FwcGVuZHMgYSBoZWFkZXIgYmxvY2sgdG8gYWxsIHRoZSB3cml0dGVuIGRhdGEgc2luY2UgdGhlIGxhc3Rcbi8vc3Vic2VxdWVudCBoZWFkZXIgb3IgdG8gdGhlIGJlZ2lubmluZyBpZiB0aGVyZSBpcyBvbmx5IG9uZSBkYXRhIGJsb2NrXG5Xcml0ZXIucHJvdG90eXBlLmFkZEhlYWRlciA9IGZ1bmN0aW9uKGNvZGUsIGxhc3QpIHtcbiAgdmFyIG9yaWdPZmZzZXQgPSB0aGlzLm9mZnNldDtcbiAgdGhpcy5vZmZzZXQgPSB0aGlzLmhlYWRlclBvc2l0aW9uO1xuICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IGNvZGU7XG4gIC8vbGVuZ3RoIGlzIGV2ZXJ5dGhpbmcgaW4gdGhpcyBwYWNrZXQgbWludXMgdGhlIGNvZGVcbiAgdGhpcy5hZGRJbnQzMihvcmlnT2Zmc2V0IC0gKHRoaXMuaGVhZGVyUG9zaXRpb24rMSkpO1xuICAvL3NldCBuZXh0IGhlYWRlciBwb3NpdGlvblxuICB0aGlzLmhlYWRlclBvc2l0aW9uID0gb3JpZ09mZnNldDtcbiAgLy9tYWtlIHNwYWNlIGZvciBuZXh0IGhlYWRlclxuICB0aGlzLm9mZnNldCA9IG9yaWdPZmZzZXQ7XG4gIGlmKCFsYXN0KSB7XG4gICAgdGhpcy5fZW5zdXJlKDUpO1xuICAgIHRoaXMub2Zmc2V0ICs9IDU7XG4gIH1cbn07XG5cbldyaXRlci5wcm90b3R5cGUuam9pbiA9IGZ1bmN0aW9uKGNvZGUpIHtcbiAgaWYoY29kZSkge1xuICAgIHRoaXMuYWRkSGVhZGVyKGNvZGUsIHRydWUpO1xuICB9XG4gIHJldHVybiB0aGlzLmJ1ZmZlci5zbGljZShjb2RlID8gMCA6IDUsIHRoaXMub2Zmc2V0KTtcbn07XG5cbldyaXRlci5wcm90b3R5cGUuZmx1c2ggPSBmdW5jdGlvbihjb2RlKSB7XG4gIHZhciByZXN1bHQgPSB0aGlzLmpvaW4oY29kZSk7XG4gIHRoaXMuY2xlYXIoKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uICh4cywgZm4pIHtcbiAgICB2YXIgcmVzID0gW107XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCB4cy5sZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgeCA9IGZuKHhzW2ldLCBpKTtcbiAgICAgICAgaWYgKGlzQXJyYXkoeCkpIHJlcy5wdXNoLmFwcGx5KHJlcywgeCk7XG4gICAgICAgIGVsc2UgcmVzLnB1c2goeCk7XG4gICAgfVxuICAgIHJldHVybiByZXM7XG59O1xuXG52YXIgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkgfHwgZnVuY3Rpb24gKHhzKSB7XG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh4cykgPT09ICdbb2JqZWN0IEFycmF5XSc7XG59O1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZWFscGF0aFxucmVhbHBhdGgucmVhbHBhdGggPSByZWFscGF0aFxucmVhbHBhdGguc3luYyA9IHJlYWxwYXRoU3luY1xucmVhbHBhdGgucmVhbHBhdGhTeW5jID0gcmVhbHBhdGhTeW5jXG5yZWFscGF0aC5tb25rZXlwYXRjaCA9IG1vbmtleXBhdGNoXG5yZWFscGF0aC51bm1vbmtleXBhdGNoID0gdW5tb25rZXlwYXRjaFxuXG52YXIgZnMgPSByZXF1aXJlKCdmcycpXG52YXIgb3JpZ1JlYWxwYXRoID0gZnMucmVhbHBhdGhcbnZhciBvcmlnUmVhbHBhdGhTeW5jID0gZnMucmVhbHBhdGhTeW5jXG5cbnZhciB2ZXJzaW9uID0gcHJvY2Vzcy52ZXJzaW9uXG52YXIgb2sgPSAvXnZbMC01XVxcLi8udGVzdCh2ZXJzaW9uKVxudmFyIG9sZCA9IHJlcXVpcmUoJy4vb2xkLmpzJylcblxuZnVuY3Rpb24gbmV3RXJyb3IgKGVyKSB7XG4gIHJldHVybiBlciAmJiBlci5zeXNjYWxsID09PSAncmVhbHBhdGgnICYmIChcbiAgICBlci5jb2RlID09PSAnRUxPT1AnIHx8XG4gICAgZXIuY29kZSA9PT0gJ0VOT01FTScgfHxcbiAgICBlci5jb2RlID09PSAnRU5BTUVUT09MT05HJ1xuICApXG59XG5cbmZ1bmN0aW9uIHJlYWxwYXRoIChwLCBjYWNoZSwgY2IpIHtcbiAgaWYgKG9rKSB7XG4gICAgcmV0dXJuIG9yaWdSZWFscGF0aChwLCBjYWNoZSwgY2IpXG4gIH1cblxuICBpZiAodHlwZW9mIGNhY2hlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgY2IgPSBjYWNoZVxuICAgIGNhY2hlID0gbnVsbFxuICB9XG4gIG9yaWdSZWFscGF0aChwLCBjYWNoZSwgZnVuY3Rpb24gKGVyLCByZXN1bHQpIHtcbiAgICBpZiAobmV3RXJyb3IoZXIpKSB7XG4gICAgICBvbGQucmVhbHBhdGgocCwgY2FjaGUsIGNiKVxuICAgIH0gZWxzZSB7XG4gICAgICBjYihlciwgcmVzdWx0KVxuICAgIH1cbiAgfSlcbn1cblxuZnVuY3Rpb24gcmVhbHBhdGhTeW5jIChwLCBjYWNoZSkge1xuICBpZiAob2spIHtcbiAgICByZXR1cm4gb3JpZ1JlYWxwYXRoU3luYyhwLCBjYWNoZSlcbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIG9yaWdSZWFscGF0aFN5bmMocCwgY2FjaGUpXG4gIH0gY2F0Y2ggKGVyKSB7XG4gICAgaWYgKG5ld0Vycm9yKGVyKSkge1xuICAgICAgcmV0dXJuIG9sZC5yZWFscGF0aFN5bmMocCwgY2FjaGUpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IGVyXG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIG1vbmtleXBhdGNoICgpIHtcbiAgZnMucmVhbHBhdGggPSByZWFscGF0aFxuICBmcy5yZWFscGF0aFN5bmMgPSByZWFscGF0aFN5bmNcbn1cblxuZnVuY3Rpb24gdW5tb25rZXlwYXRjaCAoKSB7XG4gIGZzLnJlYWxwYXRoID0gb3JpZ1JlYWxwYXRoXG4gIGZzLnJlYWxwYXRoU3luYyA9IG9yaWdSZWFscGF0aFN5bmNcbn1cbiIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG52YXIgcGF0aE1vZHVsZSA9IHJlcXVpcmUoJ3BhdGgnKTtcbnZhciBpc1dpbmRvd3MgPSBwcm9jZXNzLnBsYXRmb3JtID09PSAnd2luMzInO1xudmFyIGZzID0gcmVxdWlyZSgnZnMnKTtcblxuLy8gSmF2YVNjcmlwdCBpbXBsZW1lbnRhdGlvbiBvZiByZWFscGF0aCwgcG9ydGVkIGZyb20gbm9kZSBwcmUtdjZcblxudmFyIERFQlVHID0gcHJvY2Vzcy5lbnYuTk9ERV9ERUJVRyAmJiAvZnMvLnRlc3QocHJvY2Vzcy5lbnYuTk9ERV9ERUJVRyk7XG5cbmZ1bmN0aW9uIHJldGhyb3coKSB7XG4gIC8vIE9ubHkgZW5hYmxlIGluIGRlYnVnIG1vZGUuIEEgYmFja3RyYWNlIHVzZXMgfjEwMDAgYnl0ZXMgb2YgaGVhcCBzcGFjZSBhbmRcbiAgLy8gaXMgZmFpcmx5IHNsb3cgdG8gZ2VuZXJhdGUuXG4gIHZhciBjYWxsYmFjaztcbiAgaWYgKERFQlVHKSB7XG4gICAgdmFyIGJhY2t0cmFjZSA9IG5ldyBFcnJvcjtcbiAgICBjYWxsYmFjayA9IGRlYnVnQ2FsbGJhY2s7XG4gIH0gZWxzZVxuICAgIGNhbGxiYWNrID0gbWlzc2luZ0NhbGxiYWNrO1xuXG4gIHJldHVybiBjYWxsYmFjaztcblxuICBmdW5jdGlvbiBkZWJ1Z0NhbGxiYWNrKGVycikge1xuICAgIGlmIChlcnIpIHtcbiAgICAgIGJhY2t0cmFjZS5tZXNzYWdlID0gZXJyLm1lc3NhZ2U7XG4gICAgICBlcnIgPSBiYWNrdHJhY2U7XG4gICAgICBtaXNzaW5nQ2FsbGJhY2soZXJyKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBtaXNzaW5nQ2FsbGJhY2soZXJyKSB7XG4gICAgaWYgKGVycikge1xuICAgICAgaWYgKHByb2Nlc3MudGhyb3dEZXByZWNhdGlvbilcbiAgICAgICAgdGhyb3cgZXJyOyAgLy8gRm9yZ290IGEgY2FsbGJhY2sgYnV0IGRvbid0IGtub3cgd2hlcmU/IFVzZSBOT0RFX0RFQlVHPWZzXG4gICAgICBlbHNlIGlmICghcHJvY2Vzcy5ub0RlcHJlY2F0aW9uKSB7XG4gICAgICAgIHZhciBtc2cgPSAnZnM6IG1pc3NpbmcgY2FsbGJhY2sgJyArIChlcnIuc3RhY2sgfHwgZXJyLm1lc3NhZ2UpO1xuICAgICAgICBpZiAocHJvY2Vzcy50cmFjZURlcHJlY2F0aW9uKVxuICAgICAgICAgIGNvbnNvbGUudHJhY2UobXNnKTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IobXNnKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gbWF5YmVDYWxsYmFjayhjYikge1xuICByZXR1cm4gdHlwZW9mIGNiID09PSAnZnVuY3Rpb24nID8gY2IgOiByZXRocm93KCk7XG59XG5cbnZhciBub3JtYWxpemUgPSBwYXRoTW9kdWxlLm5vcm1hbGl6ZTtcblxuLy8gUmVnZXhwIHRoYXQgZmluZHMgdGhlIG5leHQgcGFydGlvbiBvZiBhIChwYXJ0aWFsKSBwYXRoXG4vLyByZXN1bHQgaXMgW2Jhc2Vfd2l0aF9zbGFzaCwgYmFzZV0sIGUuZy4gWydzb21lZGlyLycsICdzb21lZGlyJ11cbmlmIChpc1dpbmRvd3MpIHtcbiAgdmFyIG5leHRQYXJ0UmUgPSAvKC4qPykoPzpbXFwvXFxcXF0rfCQpL2c7XG59IGVsc2Uge1xuICB2YXIgbmV4dFBhcnRSZSA9IC8oLio/KSg/OltcXC9dK3wkKS9nO1xufVxuXG4vLyBSZWdleCB0byBmaW5kIHRoZSBkZXZpY2Ugcm9vdCwgaW5jbHVkaW5nIHRyYWlsaW5nIHNsYXNoLiBFLmcuICdjOlxcXFwnLlxuaWYgKGlzV2luZG93cykge1xuICB2YXIgc3BsaXRSb290UmUgPSAvXig/OlthLXpBLVpdOnxbXFxcXFxcL117Mn1bXlxcXFxcXC9dK1tcXFxcXFwvXVteXFxcXFxcL10rKT9bXFxcXFxcL10qLztcbn0gZWxzZSB7XG4gIHZhciBzcGxpdFJvb3RSZSA9IC9eW1xcL10qLztcbn1cblxuZXhwb3J0cy5yZWFscGF0aFN5bmMgPSBmdW5jdGlvbiByZWFscGF0aFN5bmMocCwgY2FjaGUpIHtcbiAgLy8gbWFrZSBwIGlzIGFic29sdXRlXG4gIHAgPSBwYXRoTW9kdWxlLnJlc29sdmUocCk7XG5cbiAgaWYgKGNhY2hlICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChjYWNoZSwgcCkpIHtcbiAgICByZXR1cm4gY2FjaGVbcF07XG4gIH1cblxuICB2YXIgb3JpZ2luYWwgPSBwLFxuICAgICAgc2VlbkxpbmtzID0ge30sXG4gICAgICBrbm93bkhhcmQgPSB7fTtcblxuICAvLyBjdXJyZW50IGNoYXJhY3RlciBwb3NpdGlvbiBpbiBwXG4gIHZhciBwb3M7XG4gIC8vIHRoZSBwYXJ0aWFsIHBhdGggc28gZmFyLCBpbmNsdWRpbmcgYSB0cmFpbGluZyBzbGFzaCBpZiBhbnlcbiAgdmFyIGN1cnJlbnQ7XG4gIC8vIHRoZSBwYXJ0aWFsIHBhdGggd2l0aG91dCBhIHRyYWlsaW5nIHNsYXNoIChleGNlcHQgd2hlbiBwb2ludGluZyBhdCBhIHJvb3QpXG4gIHZhciBiYXNlO1xuICAvLyB0aGUgcGFydGlhbCBwYXRoIHNjYW5uZWQgaW4gdGhlIHByZXZpb3VzIHJvdW5kLCB3aXRoIHNsYXNoXG4gIHZhciBwcmV2aW91cztcblxuICBzdGFydCgpO1xuXG4gIGZ1bmN0aW9uIHN0YXJ0KCkge1xuICAgIC8vIFNraXAgb3ZlciByb290c1xuICAgIHZhciBtID0gc3BsaXRSb290UmUuZXhlYyhwKTtcbiAgICBwb3MgPSBtWzBdLmxlbmd0aDtcbiAgICBjdXJyZW50ID0gbVswXTtcbiAgICBiYXNlID0gbVswXTtcbiAgICBwcmV2aW91cyA9ICcnO1xuXG4gICAgLy8gT24gd2luZG93cywgY2hlY2sgdGhhdCB0aGUgcm9vdCBleGlzdHMuIE9uIHVuaXggdGhlcmUgaXMgbm8gbmVlZC5cbiAgICBpZiAoaXNXaW5kb3dzICYmICFrbm93bkhhcmRbYmFzZV0pIHtcbiAgICAgIGZzLmxzdGF0U3luYyhiYXNlKTtcbiAgICAgIGtub3duSGFyZFtiYXNlXSA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgLy8gd2FsayBkb3duIHRoZSBwYXRoLCBzd2FwcGluZyBvdXQgbGlua2VkIHBhdGhwYXJ0cyBmb3IgdGhlaXIgcmVhbFxuICAvLyB2YWx1ZXNcbiAgLy8gTkI6IHAubGVuZ3RoIGNoYW5nZXMuXG4gIHdoaWxlIChwb3MgPCBwLmxlbmd0aCkge1xuICAgIC8vIGZpbmQgdGhlIG5leHQgcGFydFxuICAgIG5leHRQYXJ0UmUubGFzdEluZGV4ID0gcG9zO1xuICAgIHZhciByZXN1bHQgPSBuZXh0UGFydFJlLmV4ZWMocCk7XG4gICAgcHJldmlvdXMgPSBjdXJyZW50O1xuICAgIGN1cnJlbnQgKz0gcmVzdWx0WzBdO1xuICAgIGJhc2UgPSBwcmV2aW91cyArIHJlc3VsdFsxXTtcbiAgICBwb3MgPSBuZXh0UGFydFJlLmxhc3RJbmRleDtcblxuICAgIC8vIGNvbnRpbnVlIGlmIG5vdCBhIHN5bWxpbmtcbiAgICBpZiAoa25vd25IYXJkW2Jhc2VdIHx8IChjYWNoZSAmJiBjYWNoZVtiYXNlXSA9PT0gYmFzZSkpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIHZhciByZXNvbHZlZExpbms7XG4gICAgaWYgKGNhY2hlICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChjYWNoZSwgYmFzZSkpIHtcbiAgICAgIC8vIHNvbWUga25vd24gc3ltYm9saWMgbGluay4gIG5vIG5lZWQgdG8gc3RhdCBhZ2Fpbi5cbiAgICAgIHJlc29sdmVkTGluayA9IGNhY2hlW2Jhc2VdO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YXIgc3RhdCA9IGZzLmxzdGF0U3luYyhiYXNlKTtcbiAgICAgIGlmICghc3RhdC5pc1N5bWJvbGljTGluaygpKSB7XG4gICAgICAgIGtub3duSGFyZFtiYXNlXSA9IHRydWU7XG4gICAgICAgIGlmIChjYWNoZSkgY2FjaGVbYmFzZV0gPSBiYXNlO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgLy8gcmVhZCB0aGUgbGluayBpZiBpdCB3YXNuJ3QgcmVhZCBiZWZvcmVcbiAgICAgIC8vIGRldi9pbm8gYWx3YXlzIHJldHVybiAwIG9uIHdpbmRvd3MsIHNvIHNraXAgdGhlIGNoZWNrLlxuICAgICAgdmFyIGxpbmtUYXJnZXQgPSBudWxsO1xuICAgICAgaWYgKCFpc1dpbmRvd3MpIHtcbiAgICAgICAgdmFyIGlkID0gc3RhdC5kZXYudG9TdHJpbmcoMzIpICsgJzonICsgc3RhdC5pbm8udG9TdHJpbmcoMzIpO1xuICAgICAgICBpZiAoc2VlbkxpbmtzLmhhc093blByb3BlcnR5KGlkKSkge1xuICAgICAgICAgIGxpbmtUYXJnZXQgPSBzZWVuTGlua3NbaWRdO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAobGlua1RhcmdldCA9PT0gbnVsbCkge1xuICAgICAgICBmcy5zdGF0U3luYyhiYXNlKTtcbiAgICAgICAgbGlua1RhcmdldCA9IGZzLnJlYWRsaW5rU3luYyhiYXNlKTtcbiAgICAgIH1cbiAgICAgIHJlc29sdmVkTGluayA9IHBhdGhNb2R1bGUucmVzb2x2ZShwcmV2aW91cywgbGlua1RhcmdldCk7XG4gICAgICAvLyB0cmFjayB0aGlzLCBpZiBnaXZlbiBhIGNhY2hlLlxuICAgICAgaWYgKGNhY2hlKSBjYWNoZVtiYXNlXSA9IHJlc29sdmVkTGluaztcbiAgICAgIGlmICghaXNXaW5kb3dzKSBzZWVuTGlua3NbaWRdID0gbGlua1RhcmdldDtcbiAgICB9XG5cbiAgICAvLyByZXNvbHZlIHRoZSBsaW5rLCB0aGVuIHN0YXJ0IG92ZXJcbiAgICBwID0gcGF0aE1vZHVsZS5yZXNvbHZlKHJlc29sdmVkTGluaywgcC5zbGljZShwb3MpKTtcbiAgICBzdGFydCgpO1xuICB9XG5cbiAgaWYgKGNhY2hlKSBjYWNoZVtvcmlnaW5hbF0gPSBwO1xuXG4gIHJldHVybiBwO1xufTtcblxuXG5leHBvcnRzLnJlYWxwYXRoID0gZnVuY3Rpb24gcmVhbHBhdGgocCwgY2FjaGUsIGNiKSB7XG4gIGlmICh0eXBlb2YgY2IgIT09ICdmdW5jdGlvbicpIHtcbiAgICBjYiA9IG1heWJlQ2FsbGJhY2soY2FjaGUpO1xuICAgIGNhY2hlID0gbnVsbDtcbiAgfVxuXG4gIC8vIG1ha2UgcCBpcyBhYnNvbHV0ZVxuICBwID0gcGF0aE1vZHVsZS5yZXNvbHZlKHApO1xuXG4gIGlmIChjYWNoZSAmJiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoY2FjaGUsIHApKSB7XG4gICAgcmV0dXJuIHByb2Nlc3MubmV4dFRpY2soY2IuYmluZChudWxsLCBudWxsLCBjYWNoZVtwXSkpO1xuICB9XG5cbiAgdmFyIG9yaWdpbmFsID0gcCxcbiAgICAgIHNlZW5MaW5rcyA9IHt9LFxuICAgICAga25vd25IYXJkID0ge307XG5cbiAgLy8gY3VycmVudCBjaGFyYWN0ZXIgcG9zaXRpb24gaW4gcFxuICB2YXIgcG9zO1xuICAvLyB0aGUgcGFydGlhbCBwYXRoIHNvIGZhciwgaW5jbHVkaW5nIGEgdHJhaWxpbmcgc2xhc2ggaWYgYW55XG4gIHZhciBjdXJyZW50O1xuICAvLyB0aGUgcGFydGlhbCBwYXRoIHdpdGhvdXQgYSB0cmFpbGluZyBzbGFzaCAoZXhjZXB0IHdoZW4gcG9pbnRpbmcgYXQgYSByb290KVxuICB2YXIgYmFzZTtcbiAgLy8gdGhlIHBhcnRpYWwgcGF0aCBzY2FubmVkIGluIHRoZSBwcmV2aW91cyByb3VuZCwgd2l0aCBzbGFzaFxuICB2YXIgcHJldmlvdXM7XG5cbiAgc3RhcnQoKTtcblxuICBmdW5jdGlvbiBzdGFydCgpIHtcbiAgICAvLyBTa2lwIG92ZXIgcm9vdHNcbiAgICB2YXIgbSA9IHNwbGl0Um9vdFJlLmV4ZWMocCk7XG4gICAgcG9zID0gbVswXS5sZW5ndGg7XG4gICAgY3VycmVudCA9IG1bMF07XG4gICAgYmFzZSA9IG1bMF07XG4gICAgcHJldmlvdXMgPSAnJztcblxuICAgIC8vIE9uIHdpbmRvd3MsIGNoZWNrIHRoYXQgdGhlIHJvb3QgZXhpc3RzLiBPbiB1bml4IHRoZXJlIGlzIG5vIG5lZWQuXG4gICAgaWYgKGlzV2luZG93cyAmJiAha25vd25IYXJkW2Jhc2VdKSB7XG4gICAgICBmcy5sc3RhdChiYXNlLCBmdW5jdGlvbihlcnIpIHtcbiAgICAgICAgaWYgKGVycikgcmV0dXJuIGNiKGVycik7XG4gICAgICAgIGtub3duSGFyZFtiYXNlXSA9IHRydWU7XG4gICAgICAgIExPT1AoKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKExPT1ApO1xuICAgIH1cbiAgfVxuXG4gIC8vIHdhbGsgZG93biB0aGUgcGF0aCwgc3dhcHBpbmcgb3V0IGxpbmtlZCBwYXRocGFydHMgZm9yIHRoZWlyIHJlYWxcbiAgLy8gdmFsdWVzXG4gIGZ1bmN0aW9uIExPT1AoKSB7XG4gICAgLy8gc3RvcCBpZiBzY2FubmVkIHBhc3QgZW5kIG9mIHBhdGhcbiAgICBpZiAocG9zID49IHAubGVuZ3RoKSB7XG4gICAgICBpZiAoY2FjaGUpIGNhY2hlW29yaWdpbmFsXSA9IHA7XG4gICAgICByZXR1cm4gY2IobnVsbCwgcCk7XG4gICAgfVxuXG4gICAgLy8gZmluZCB0aGUgbmV4dCBwYXJ0XG4gICAgbmV4dFBhcnRSZS5sYXN0SW5kZXggPSBwb3M7XG4gICAgdmFyIHJlc3VsdCA9IG5leHRQYXJ0UmUuZXhlYyhwKTtcbiAgICBwcmV2aW91cyA9IGN1cnJlbnQ7XG4gICAgY3VycmVudCArPSByZXN1bHRbMF07XG4gICAgYmFzZSA9IHByZXZpb3VzICsgcmVzdWx0WzFdO1xuICAgIHBvcyA9IG5leHRQYXJ0UmUubGFzdEluZGV4O1xuXG4gICAgLy8gY29udGludWUgaWYgbm90IGEgc3ltbGlua1xuICAgIGlmIChrbm93bkhhcmRbYmFzZV0gfHwgKGNhY2hlICYmIGNhY2hlW2Jhc2VdID09PSBiYXNlKSkge1xuICAgICAgcmV0dXJuIHByb2Nlc3MubmV4dFRpY2soTE9PUCk7XG4gICAgfVxuXG4gICAgaWYgKGNhY2hlICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChjYWNoZSwgYmFzZSkpIHtcbiAgICAgIC8vIGtub3duIHN5bWJvbGljIGxpbmsuICBubyBuZWVkIHRvIHN0YXQgYWdhaW4uXG4gICAgICByZXR1cm4gZ290UmVzb2x2ZWRMaW5rKGNhY2hlW2Jhc2VdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZnMubHN0YXQoYmFzZSwgZ290U3RhdCk7XG4gIH1cblxuICBmdW5jdGlvbiBnb3RTdGF0KGVyciwgc3RhdCkge1xuICAgIGlmIChlcnIpIHJldHVybiBjYihlcnIpO1xuXG4gICAgLy8gaWYgbm90IGEgc3ltbGluaywgc2tpcCB0byB0aGUgbmV4dCBwYXRoIHBhcnRcbiAgICBpZiAoIXN0YXQuaXNTeW1ib2xpY0xpbmsoKSkge1xuICAgICAga25vd25IYXJkW2Jhc2VdID0gdHJ1ZTtcbiAgICAgIGlmIChjYWNoZSkgY2FjaGVbYmFzZV0gPSBiYXNlO1xuICAgICAgcmV0dXJuIHByb2Nlc3MubmV4dFRpY2soTE9PUCk7XG4gICAgfVxuXG4gICAgLy8gc3RhdCAmIHJlYWQgdGhlIGxpbmsgaWYgbm90IHJlYWQgYmVmb3JlXG4gICAgLy8gY2FsbCBnb3RUYXJnZXQgYXMgc29vbiBhcyB0aGUgbGluayB0YXJnZXQgaXMga25vd25cbiAgICAvLyBkZXYvaW5vIGFsd2F5cyByZXR1cm4gMCBvbiB3aW5kb3dzLCBzbyBza2lwIHRoZSBjaGVjay5cbiAgICBpZiAoIWlzV2luZG93cykge1xuICAgICAgdmFyIGlkID0gc3RhdC5kZXYudG9TdHJpbmcoMzIpICsgJzonICsgc3RhdC5pbm8udG9TdHJpbmcoMzIpO1xuICAgICAgaWYgKHNlZW5MaW5rcy5oYXNPd25Qcm9wZXJ0eShpZCkpIHtcbiAgICAgICAgcmV0dXJuIGdvdFRhcmdldChudWxsLCBzZWVuTGlua3NbaWRdLCBiYXNlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZnMuc3RhdChiYXNlLCBmdW5jdGlvbihlcnIpIHtcbiAgICAgIGlmIChlcnIpIHJldHVybiBjYihlcnIpO1xuXG4gICAgICBmcy5yZWFkbGluayhiYXNlLCBmdW5jdGlvbihlcnIsIHRhcmdldCkge1xuICAgICAgICBpZiAoIWlzV2luZG93cykgc2VlbkxpbmtzW2lkXSA9IHRhcmdldDtcbiAgICAgICAgZ290VGFyZ2V0KGVyciwgdGFyZ2V0KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gZ290VGFyZ2V0KGVyciwgdGFyZ2V0LCBiYXNlKSB7XG4gICAgaWYgKGVycikgcmV0dXJuIGNiKGVycik7XG5cbiAgICB2YXIgcmVzb2x2ZWRMaW5rID0gcGF0aE1vZHVsZS5yZXNvbHZlKHByZXZpb3VzLCB0YXJnZXQpO1xuICAgIGlmIChjYWNoZSkgY2FjaGVbYmFzZV0gPSByZXNvbHZlZExpbms7XG4gICAgZ290UmVzb2x2ZWRMaW5rKHJlc29sdmVkTGluayk7XG4gIH1cblxuICBmdW5jdGlvbiBnb3RSZXNvbHZlZExpbmsocmVzb2x2ZWRMaW5rKSB7XG4gICAgLy8gcmVzb2x2ZSB0aGUgbGluaywgdGhlbiBzdGFydCBvdmVyXG4gICAgcCA9IHBhdGhNb2R1bGUucmVzb2x2ZShyZXNvbHZlZExpbmssIHAuc2xpY2UocG9zKSk7XG4gICAgc3RhcnQoKTtcbiAgfVxufTtcbiIsImV4cG9ydHMuYWxwaGFzb3J0ID0gYWxwaGFzb3J0XG5leHBvcnRzLmFscGhhc29ydGkgPSBhbHBoYXNvcnRpXG5leHBvcnRzLnNldG9wdHMgPSBzZXRvcHRzXG5leHBvcnRzLm93blByb3AgPSBvd25Qcm9wXG5leHBvcnRzLm1ha2VBYnMgPSBtYWtlQWJzXG5leHBvcnRzLmZpbmlzaCA9IGZpbmlzaFxuZXhwb3J0cy5tYXJrID0gbWFya1xuZXhwb3J0cy5pc0lnbm9yZWQgPSBpc0lnbm9yZWRcbmV4cG9ydHMuY2hpbGRyZW5JZ25vcmVkID0gY2hpbGRyZW5JZ25vcmVkXG5cbmZ1bmN0aW9uIG93blByb3AgKG9iaiwgZmllbGQpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIGZpZWxkKVxufVxuXG52YXIgcGF0aCA9IHJlcXVpcmUoXCJwYXRoXCIpXG52YXIgbWluaW1hdGNoID0gcmVxdWlyZShcIm1pbmltYXRjaFwiKVxudmFyIGlzQWJzb2x1dGUgPSByZXF1aXJlKFwicGF0aC1pcy1hYnNvbHV0ZVwiKVxudmFyIE1pbmltYXRjaCA9IG1pbmltYXRjaC5NaW5pbWF0Y2hcblxuZnVuY3Rpb24gYWxwaGFzb3J0aSAoYSwgYikge1xuICByZXR1cm4gYS50b0xvd2VyQ2FzZSgpLmxvY2FsZUNvbXBhcmUoYi50b0xvd2VyQ2FzZSgpKVxufVxuXG5mdW5jdGlvbiBhbHBoYXNvcnQgKGEsIGIpIHtcbiAgcmV0dXJuIGEubG9jYWxlQ29tcGFyZShiKVxufVxuXG5mdW5jdGlvbiBzZXR1cElnbm9yZXMgKHNlbGYsIG9wdGlvbnMpIHtcbiAgc2VsZi5pZ25vcmUgPSBvcHRpb25zLmlnbm9yZSB8fCBbXVxuXG4gIGlmICghQXJyYXkuaXNBcnJheShzZWxmLmlnbm9yZSkpXG4gICAgc2VsZi5pZ25vcmUgPSBbc2VsZi5pZ25vcmVdXG5cbiAgaWYgKHNlbGYuaWdub3JlLmxlbmd0aCkge1xuICAgIHNlbGYuaWdub3JlID0gc2VsZi5pZ25vcmUubWFwKGlnbm9yZU1hcClcbiAgfVxufVxuXG4vLyBpZ25vcmUgcGF0dGVybnMgYXJlIGFsd2F5cyBpbiBkb3Q6dHJ1ZSBtb2RlLlxuZnVuY3Rpb24gaWdub3JlTWFwIChwYXR0ZXJuKSB7XG4gIHZhciBnbWF0Y2hlciA9IG51bGxcbiAgaWYgKHBhdHRlcm4uc2xpY2UoLTMpID09PSAnLyoqJykge1xuICAgIHZhciBncGF0dGVybiA9IHBhdHRlcm4ucmVwbGFjZSgvKFxcL1xcKlxcKikrJC8sICcnKVxuICAgIGdtYXRjaGVyID0gbmV3IE1pbmltYXRjaChncGF0dGVybiwgeyBkb3Q6IHRydWUgfSlcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgbWF0Y2hlcjogbmV3IE1pbmltYXRjaChwYXR0ZXJuLCB7IGRvdDogdHJ1ZSB9KSxcbiAgICBnbWF0Y2hlcjogZ21hdGNoZXJcbiAgfVxufVxuXG5mdW5jdGlvbiBzZXRvcHRzIChzZWxmLCBwYXR0ZXJuLCBvcHRpb25zKSB7XG4gIGlmICghb3B0aW9ucylcbiAgICBvcHRpb25zID0ge31cblxuICAvLyBiYXNlLW1hdGNoaW5nOiBqdXN0IHVzZSBnbG9ic3RhciBmb3IgdGhhdC5cbiAgaWYgKG9wdGlvbnMubWF0Y2hCYXNlICYmIC0xID09PSBwYXR0ZXJuLmluZGV4T2YoXCIvXCIpKSB7XG4gICAgaWYgKG9wdGlvbnMubm9nbG9ic3Rhcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYmFzZSBtYXRjaGluZyByZXF1aXJlcyBnbG9ic3RhclwiKVxuICAgIH1cbiAgICBwYXR0ZXJuID0gXCIqKi9cIiArIHBhdHRlcm5cbiAgfVxuXG4gIHNlbGYuc2lsZW50ID0gISFvcHRpb25zLnNpbGVudFxuICBzZWxmLnBhdHRlcm4gPSBwYXR0ZXJuXG4gIHNlbGYuc3RyaWN0ID0gb3B0aW9ucy5zdHJpY3QgIT09IGZhbHNlXG4gIHNlbGYucmVhbHBhdGggPSAhIW9wdGlvbnMucmVhbHBhdGhcbiAgc2VsZi5yZWFscGF0aENhY2hlID0gb3B0aW9ucy5yZWFscGF0aENhY2hlIHx8IE9iamVjdC5jcmVhdGUobnVsbClcbiAgc2VsZi5mb2xsb3cgPSAhIW9wdGlvbnMuZm9sbG93XG4gIHNlbGYuZG90ID0gISFvcHRpb25zLmRvdFxuICBzZWxmLm1hcmsgPSAhIW9wdGlvbnMubWFya1xuICBzZWxmLm5vZGlyID0gISFvcHRpb25zLm5vZGlyXG4gIGlmIChzZWxmLm5vZGlyKVxuICAgIHNlbGYubWFyayA9IHRydWVcbiAgc2VsZi5zeW5jID0gISFvcHRpb25zLnN5bmNcbiAgc2VsZi5ub3VuaXF1ZSA9ICEhb3B0aW9ucy5ub3VuaXF1ZVxuICBzZWxmLm5vbnVsbCA9ICEhb3B0aW9ucy5ub251bGxcbiAgc2VsZi5ub3NvcnQgPSAhIW9wdGlvbnMubm9zb3J0XG4gIHNlbGYubm9jYXNlID0gISFvcHRpb25zLm5vY2FzZVxuICBzZWxmLnN0YXQgPSAhIW9wdGlvbnMuc3RhdFxuICBzZWxmLm5vcHJvY2VzcyA9ICEhb3B0aW9ucy5ub3Byb2Nlc3NcbiAgc2VsZi5hYnNvbHV0ZSA9ICEhb3B0aW9ucy5hYnNvbHV0ZVxuXG4gIHNlbGYubWF4TGVuZ3RoID0gb3B0aW9ucy5tYXhMZW5ndGggfHwgSW5maW5pdHlcbiAgc2VsZi5jYWNoZSA9IG9wdGlvbnMuY2FjaGUgfHwgT2JqZWN0LmNyZWF0ZShudWxsKVxuICBzZWxmLnN0YXRDYWNoZSA9IG9wdGlvbnMuc3RhdENhY2hlIHx8IE9iamVjdC5jcmVhdGUobnVsbClcbiAgc2VsZi5zeW1saW5rcyA9IG9wdGlvbnMuc3ltbGlua3MgfHwgT2JqZWN0LmNyZWF0ZShudWxsKVxuXG4gIHNldHVwSWdub3JlcyhzZWxmLCBvcHRpb25zKVxuXG4gIHNlbGYuY2hhbmdlZEN3ZCA9IGZhbHNlXG4gIHZhciBjd2QgPSBwcm9jZXNzLmN3ZCgpXG4gIGlmICghb3duUHJvcChvcHRpb25zLCBcImN3ZFwiKSlcbiAgICBzZWxmLmN3ZCA9IGN3ZFxuICBlbHNlIHtcbiAgICBzZWxmLmN3ZCA9IHBhdGgucmVzb2x2ZShvcHRpb25zLmN3ZClcbiAgICBzZWxmLmNoYW5nZWRDd2QgPSBzZWxmLmN3ZCAhPT0gY3dkXG4gIH1cblxuICBzZWxmLnJvb3QgPSBvcHRpb25zLnJvb3QgfHwgcGF0aC5yZXNvbHZlKHNlbGYuY3dkLCBcIi9cIilcbiAgc2VsZi5yb290ID0gcGF0aC5yZXNvbHZlKHNlbGYucm9vdClcbiAgaWYgKHByb2Nlc3MucGxhdGZvcm0gPT09IFwid2luMzJcIilcbiAgICBzZWxmLnJvb3QgPSBzZWxmLnJvb3QucmVwbGFjZSgvXFxcXC9nLCBcIi9cIilcblxuICAvLyBUT0RPOiBpcyBhbiBhYnNvbHV0ZSBgY3dkYCBzdXBwb3NlZCB0byBiZSByZXNvbHZlZCBhZ2FpbnN0IGByb290YD9cbiAgLy8gZS5nLiB7IGN3ZDogJy90ZXN0Jywgcm9vdDogX19kaXJuYW1lIH0gPT09IHBhdGguam9pbihfX2Rpcm5hbWUsICcvdGVzdCcpXG4gIHNlbGYuY3dkQWJzID0gaXNBYnNvbHV0ZShzZWxmLmN3ZCkgPyBzZWxmLmN3ZCA6IG1ha2VBYnMoc2VsZiwgc2VsZi5jd2QpXG4gIGlmIChwcm9jZXNzLnBsYXRmb3JtID09PSBcIndpbjMyXCIpXG4gICAgc2VsZi5jd2RBYnMgPSBzZWxmLmN3ZEFicy5yZXBsYWNlKC9cXFxcL2csIFwiL1wiKVxuICBzZWxmLm5vbW91bnQgPSAhIW9wdGlvbnMubm9tb3VudFxuXG4gIC8vIGRpc2FibGUgY29tbWVudHMgYW5kIG5lZ2F0aW9uIGluIE1pbmltYXRjaC5cbiAgLy8gTm90ZSB0aGF0IHRoZXkgYXJlIG5vdCBzdXBwb3J0ZWQgaW4gR2xvYiBpdHNlbGYgYW55d2F5LlxuICBvcHRpb25zLm5vbmVnYXRlID0gdHJ1ZVxuICBvcHRpb25zLm5vY29tbWVudCA9IHRydWVcblxuICBzZWxmLm1pbmltYXRjaCA9IG5ldyBNaW5pbWF0Y2gocGF0dGVybiwgb3B0aW9ucylcbiAgc2VsZi5vcHRpb25zID0gc2VsZi5taW5pbWF0Y2gub3B0aW9uc1xufVxuXG5mdW5jdGlvbiBmaW5pc2ggKHNlbGYpIHtcbiAgdmFyIG5vdSA9IHNlbGYubm91bmlxdWVcbiAgdmFyIGFsbCA9IG5vdSA/IFtdIDogT2JqZWN0LmNyZWF0ZShudWxsKVxuXG4gIGZvciAodmFyIGkgPSAwLCBsID0gc2VsZi5tYXRjaGVzLmxlbmd0aDsgaSA8IGw7IGkgKyspIHtcbiAgICB2YXIgbWF0Y2hlcyA9IHNlbGYubWF0Y2hlc1tpXVxuICAgIGlmICghbWF0Y2hlcyB8fCBPYmplY3Qua2V5cyhtYXRjaGVzKS5sZW5ndGggPT09IDApIHtcbiAgICAgIGlmIChzZWxmLm5vbnVsbCkge1xuICAgICAgICAvLyBkbyBsaWtlIHRoZSBzaGVsbCwgYW5kIHNwaXQgb3V0IHRoZSBsaXRlcmFsIGdsb2JcbiAgICAgICAgdmFyIGxpdGVyYWwgPSBzZWxmLm1pbmltYXRjaC5nbG9iU2V0W2ldXG4gICAgICAgIGlmIChub3UpXG4gICAgICAgICAgYWxsLnB1c2gobGl0ZXJhbClcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGFsbFtsaXRlcmFsXSA9IHRydWVcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gaGFkIG1hdGNoZXNcbiAgICAgIHZhciBtID0gT2JqZWN0LmtleXMobWF0Y2hlcylcbiAgICAgIGlmIChub3UpXG4gICAgICAgIGFsbC5wdXNoLmFwcGx5KGFsbCwgbSlcbiAgICAgIGVsc2VcbiAgICAgICAgbS5mb3JFYWNoKGZ1bmN0aW9uIChtKSB7XG4gICAgICAgICAgYWxsW21dID0gdHJ1ZVxuICAgICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGlmICghbm91KVxuICAgIGFsbCA9IE9iamVjdC5rZXlzKGFsbClcblxuICBpZiAoIXNlbGYubm9zb3J0KVxuICAgIGFsbCA9IGFsbC5zb3J0KHNlbGYubm9jYXNlID8gYWxwaGFzb3J0aSA6IGFscGhhc29ydClcblxuICAvLyBhdCAqc29tZSogcG9pbnQgd2Ugc3RhdHRlZCBhbGwgb2YgdGhlc2VcbiAgaWYgKHNlbGYubWFyaykge1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsLmxlbmd0aDsgaSsrKSB7XG4gICAgICBhbGxbaV0gPSBzZWxmLl9tYXJrKGFsbFtpXSlcbiAgICB9XG4gICAgaWYgKHNlbGYubm9kaXIpIHtcbiAgICAgIGFsbCA9IGFsbC5maWx0ZXIoZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgdmFyIG5vdERpciA9ICEoL1xcLyQvLnRlc3QoZSkpXG4gICAgICAgIHZhciBjID0gc2VsZi5jYWNoZVtlXSB8fCBzZWxmLmNhY2hlW21ha2VBYnMoc2VsZiwgZSldXG4gICAgICAgIGlmIChub3REaXIgJiYgYylcbiAgICAgICAgICBub3REaXIgPSBjICE9PSAnRElSJyAmJiAhQXJyYXkuaXNBcnJheShjKVxuICAgICAgICByZXR1cm4gbm90RGlyXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGlmIChzZWxmLmlnbm9yZS5sZW5ndGgpXG4gICAgYWxsID0gYWxsLmZpbHRlcihmdW5jdGlvbihtKSB7XG4gICAgICByZXR1cm4gIWlzSWdub3JlZChzZWxmLCBtKVxuICAgIH0pXG5cbiAgc2VsZi5mb3VuZCA9IGFsbFxufVxuXG5mdW5jdGlvbiBtYXJrIChzZWxmLCBwKSB7XG4gIHZhciBhYnMgPSBtYWtlQWJzKHNlbGYsIHApXG4gIHZhciBjID0gc2VsZi5jYWNoZVthYnNdXG4gIHZhciBtID0gcFxuICBpZiAoYykge1xuICAgIHZhciBpc0RpciA9IGMgPT09ICdESVInIHx8IEFycmF5LmlzQXJyYXkoYylcbiAgICB2YXIgc2xhc2ggPSBwLnNsaWNlKC0xKSA9PT0gJy8nXG5cbiAgICBpZiAoaXNEaXIgJiYgIXNsYXNoKVxuICAgICAgbSArPSAnLydcbiAgICBlbHNlIGlmICghaXNEaXIgJiYgc2xhc2gpXG4gICAgICBtID0gbS5zbGljZSgwLCAtMSlcblxuICAgIGlmIChtICE9PSBwKSB7XG4gICAgICB2YXIgbWFicyA9IG1ha2VBYnMoc2VsZiwgbSlcbiAgICAgIHNlbGYuc3RhdENhY2hlW21hYnNdID0gc2VsZi5zdGF0Q2FjaGVbYWJzXVxuICAgICAgc2VsZi5jYWNoZVttYWJzXSA9IHNlbGYuY2FjaGVbYWJzXVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBtXG59XG5cbi8vIGxvdHRhIHNpdHVwcy4uLlxuZnVuY3Rpb24gbWFrZUFicyAoc2VsZiwgZikge1xuICB2YXIgYWJzID0gZlxuICBpZiAoZi5jaGFyQXQoMCkgPT09ICcvJykge1xuICAgIGFicyA9IHBhdGguam9pbihzZWxmLnJvb3QsIGYpXG4gIH0gZWxzZSBpZiAoaXNBYnNvbHV0ZShmKSB8fCBmID09PSAnJykge1xuICAgIGFicyA9IGZcbiAgfSBlbHNlIGlmIChzZWxmLmNoYW5nZWRDd2QpIHtcbiAgICBhYnMgPSBwYXRoLnJlc29sdmUoc2VsZi5jd2QsIGYpXG4gIH0gZWxzZSB7XG4gICAgYWJzID0gcGF0aC5yZXNvbHZlKGYpXG4gIH1cblxuICBpZiAocHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ3dpbjMyJylcbiAgICBhYnMgPSBhYnMucmVwbGFjZSgvXFxcXC9nLCAnLycpXG5cbiAgcmV0dXJuIGFic1xufVxuXG5cbi8vIFJldHVybiB0cnVlLCBpZiBwYXR0ZXJuIGVuZHMgd2l0aCBnbG9ic3RhciAnKionLCBmb3IgdGhlIGFjY29tcGFueWluZyBwYXJlbnQgZGlyZWN0b3J5LlxuLy8gRXg6LSBJZiBub2RlX21vZHVsZXMvKiogaXMgdGhlIHBhdHRlcm4sIGFkZCAnbm9kZV9tb2R1bGVzJyB0byBpZ25vcmUgbGlzdCBhbG9uZyB3aXRoIGl0J3MgY29udGVudHNcbmZ1bmN0aW9uIGlzSWdub3JlZCAoc2VsZiwgcGF0aCkge1xuICBpZiAoIXNlbGYuaWdub3JlLmxlbmd0aClcbiAgICByZXR1cm4gZmFsc2VcblxuICByZXR1cm4gc2VsZi5pZ25vcmUuc29tZShmdW5jdGlvbihpdGVtKSB7XG4gICAgcmV0dXJuIGl0ZW0ubWF0Y2hlci5tYXRjaChwYXRoKSB8fCAhIShpdGVtLmdtYXRjaGVyICYmIGl0ZW0uZ21hdGNoZXIubWF0Y2gocGF0aCkpXG4gIH0pXG59XG5cbmZ1bmN0aW9uIGNoaWxkcmVuSWdub3JlZCAoc2VsZiwgcGF0aCkge1xuICBpZiAoIXNlbGYuaWdub3JlLmxlbmd0aClcbiAgICByZXR1cm4gZmFsc2VcblxuICByZXR1cm4gc2VsZi5pZ25vcmUuc29tZShmdW5jdGlvbihpdGVtKSB7XG4gICAgcmV0dXJuICEhKGl0ZW0uZ21hdGNoZXIgJiYgaXRlbS5nbWF0Y2hlci5tYXRjaChwYXRoKSlcbiAgfSlcbn1cbiIsIi8vIEFwcHJvYWNoOlxuLy9cbi8vIDEuIEdldCB0aGUgbWluaW1hdGNoIHNldFxuLy8gMi4gRm9yIGVhY2ggcGF0dGVybiBpbiB0aGUgc2V0LCBQUk9DRVNTKHBhdHRlcm4sIGZhbHNlKVxuLy8gMy4gU3RvcmUgbWF0Y2hlcyBwZXItc2V0LCB0aGVuIHVuaXEgdGhlbVxuLy9cbi8vIFBST0NFU1MocGF0dGVybiwgaW5HbG9iU3Rhcilcbi8vIEdldCB0aGUgZmlyc3QgW25dIGl0ZW1zIGZyb20gcGF0dGVybiB0aGF0IGFyZSBhbGwgc3RyaW5nc1xuLy8gSm9pbiB0aGVzZSB0b2dldGhlci4gIFRoaXMgaXMgUFJFRklYLlxuLy8gICBJZiB0aGVyZSBpcyBubyBtb3JlIHJlbWFpbmluZywgdGhlbiBzdGF0KFBSRUZJWCkgYW5kXG4vLyAgIGFkZCB0byBtYXRjaGVzIGlmIGl0IHN1Y2NlZWRzLiAgRU5ELlxuLy9cbi8vIElmIGluR2xvYlN0YXIgYW5kIFBSRUZJWCBpcyBzeW1saW5rIGFuZCBwb2ludHMgdG8gZGlyXG4vLyAgIHNldCBFTlRSSUVTID0gW11cbi8vIGVsc2UgcmVhZGRpcihQUkVGSVgpIGFzIEVOVFJJRVNcbi8vICAgSWYgZmFpbCwgRU5EXG4vL1xuLy8gd2l0aCBFTlRSSUVTXG4vLyAgIElmIHBhdHRlcm5bbl0gaXMgR0xPQlNUQVJcbi8vICAgICAvLyBoYW5kbGUgdGhlIGNhc2Ugd2hlcmUgdGhlIGdsb2JzdGFyIG1hdGNoIGlzIGVtcHR5XG4vLyAgICAgLy8gYnkgcHJ1bmluZyBpdCBvdXQsIGFuZCB0ZXN0aW5nIHRoZSByZXN1bHRpbmcgcGF0dGVyblxuLy8gICAgIFBST0NFU1MocGF0dGVyblswLi5uXSArIHBhdHRlcm5bbisxIC4uICRdLCBmYWxzZSlcbi8vICAgICAvLyBoYW5kbGUgb3RoZXIgY2FzZXMuXG4vLyAgICAgZm9yIEVOVFJZIGluIEVOVFJJRVMgKG5vdCBkb3RmaWxlcylcbi8vICAgICAgIC8vIGF0dGFjaCBnbG9ic3RhciArIHRhaWwgb250byB0aGUgZW50cnlcbi8vICAgICAgIC8vIE1hcmsgdGhhdCB0aGlzIGVudHJ5IGlzIGEgZ2xvYnN0YXIgbWF0Y2hcbi8vICAgICAgIFBST0NFU1MocGF0dGVyblswLi5uXSArIEVOVFJZICsgcGF0dGVybltuIC4uICRdLCB0cnVlKVxuLy9cbi8vICAgZWxzZSAvLyBub3QgZ2xvYnN0YXJcbi8vICAgICBmb3IgRU5UUlkgaW4gRU5UUklFUyAobm90IGRvdGZpbGVzLCB1bmxlc3MgcGF0dGVybltuXSBpcyBkb3QpXG4vLyAgICAgICBUZXN0IEVOVFJZIGFnYWluc3QgcGF0dGVybltuXVxuLy8gICAgICAgSWYgZmFpbHMsIGNvbnRpbnVlXG4vLyAgICAgICBJZiBwYXNzZXMsIFBST0NFU1MocGF0dGVyblswLi5uXSArIGl0ZW0gKyBwYXR0ZXJuW24rMSAuLiAkXSlcbi8vXG4vLyBDYXZlYXQ6XG4vLyAgIENhY2hlIGFsbCBzdGF0cyBhbmQgcmVhZGRpcnMgcmVzdWx0cyB0byBtaW5pbWl6ZSBzeXNjYWxsLiAgU2luY2UgYWxsXG4vLyAgIHdlIGV2ZXIgY2FyZSBhYm91dCBpcyBleGlzdGVuY2UgYW5kIGRpcmVjdG9yeS1uZXNzLCB3ZSBjYW4ganVzdCBrZWVwXG4vLyAgIGB0cnVlYCBmb3IgZmlsZXMsIGFuZCBbY2hpbGRyZW4sLi4uXSBmb3IgZGlyZWN0b3JpZXMsIG9yIGBmYWxzZWAgZm9yXG4vLyAgIHRoaW5ncyB0aGF0IGRvbid0IGV4aXN0LlxuXG5tb2R1bGUuZXhwb3J0cyA9IGdsb2JcblxudmFyIGZzID0gcmVxdWlyZSgnZnMnKVxudmFyIHJwID0gcmVxdWlyZSgnZnMucmVhbHBhdGgnKVxudmFyIG1pbmltYXRjaCA9IHJlcXVpcmUoJ21pbmltYXRjaCcpXG52YXIgTWluaW1hdGNoID0gbWluaW1hdGNoLk1pbmltYXRjaFxudmFyIGluaGVyaXRzID0gcmVxdWlyZSgnaW5oZXJpdHMnKVxudmFyIEVFID0gcmVxdWlyZSgnZXZlbnRzJykuRXZlbnRFbWl0dGVyXG52YXIgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxudmFyIGFzc2VydCA9IHJlcXVpcmUoJ2Fzc2VydCcpXG52YXIgaXNBYnNvbHV0ZSA9IHJlcXVpcmUoJ3BhdGgtaXMtYWJzb2x1dGUnKVxudmFyIGdsb2JTeW5jID0gcmVxdWlyZSgnLi9zeW5jLmpzJylcbnZhciBjb21tb24gPSByZXF1aXJlKCcuL2NvbW1vbi5qcycpXG52YXIgYWxwaGFzb3J0ID0gY29tbW9uLmFscGhhc29ydFxudmFyIGFscGhhc29ydGkgPSBjb21tb24uYWxwaGFzb3J0aVxudmFyIHNldG9wdHMgPSBjb21tb24uc2V0b3B0c1xudmFyIG93blByb3AgPSBjb21tb24ub3duUHJvcFxudmFyIGluZmxpZ2h0ID0gcmVxdWlyZSgnaW5mbGlnaHQnKVxudmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbnZhciBjaGlsZHJlbklnbm9yZWQgPSBjb21tb24uY2hpbGRyZW5JZ25vcmVkXG52YXIgaXNJZ25vcmVkID0gY29tbW9uLmlzSWdub3JlZFxuXG52YXIgb25jZSA9IHJlcXVpcmUoJ29uY2UnKVxuXG5mdW5jdGlvbiBnbG9iIChwYXR0ZXJuLCBvcHRpb25zLCBjYikge1xuICBpZiAodHlwZW9mIG9wdGlvbnMgPT09ICdmdW5jdGlvbicpIGNiID0gb3B0aW9ucywgb3B0aW9ucyA9IHt9XG4gIGlmICghb3B0aW9ucykgb3B0aW9ucyA9IHt9XG5cbiAgaWYgKG9wdGlvbnMuc3luYykge1xuICAgIGlmIChjYilcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2NhbGxiYWNrIHByb3ZpZGVkIHRvIHN5bmMgZ2xvYicpXG4gICAgcmV0dXJuIGdsb2JTeW5jKHBhdHRlcm4sIG9wdGlvbnMpXG4gIH1cblxuICByZXR1cm4gbmV3IEdsb2IocGF0dGVybiwgb3B0aW9ucywgY2IpXG59XG5cbmdsb2Iuc3luYyA9IGdsb2JTeW5jXG52YXIgR2xvYlN5bmMgPSBnbG9iLkdsb2JTeW5jID0gZ2xvYlN5bmMuR2xvYlN5bmNcblxuLy8gb2xkIGFwaSBzdXJmYWNlXG5nbG9iLmdsb2IgPSBnbG9iXG5cbmZ1bmN0aW9uIGV4dGVuZCAob3JpZ2luLCBhZGQpIHtcbiAgaWYgKGFkZCA9PT0gbnVsbCB8fCB0eXBlb2YgYWRkICE9PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiBvcmlnaW5cbiAgfVxuXG4gIHZhciBrZXlzID0gT2JqZWN0LmtleXMoYWRkKVxuICB2YXIgaSA9IGtleXMubGVuZ3RoXG4gIHdoaWxlIChpLS0pIHtcbiAgICBvcmlnaW5ba2V5c1tpXV0gPSBhZGRba2V5c1tpXV1cbiAgfVxuICByZXR1cm4gb3JpZ2luXG59XG5cbmdsb2IuaGFzTWFnaWMgPSBmdW5jdGlvbiAocGF0dGVybiwgb3B0aW9uc18pIHtcbiAgdmFyIG9wdGlvbnMgPSBleHRlbmQoe30sIG9wdGlvbnNfKVxuICBvcHRpb25zLm5vcHJvY2VzcyA9IHRydWVcblxuICB2YXIgZyA9IG5ldyBHbG9iKHBhdHRlcm4sIG9wdGlvbnMpXG4gIHZhciBzZXQgPSBnLm1pbmltYXRjaC5zZXRcblxuICBpZiAoIXBhdHRlcm4pXG4gICAgcmV0dXJuIGZhbHNlXG5cbiAgaWYgKHNldC5sZW5ndGggPiAxKVxuICAgIHJldHVybiB0cnVlXG5cbiAgZm9yICh2YXIgaiA9IDA7IGogPCBzZXRbMF0ubGVuZ3RoOyBqKyspIHtcbiAgICBpZiAodHlwZW9mIHNldFswXVtqXSAhPT0gJ3N0cmluZycpXG4gICAgICByZXR1cm4gdHJ1ZVxuICB9XG5cbiAgcmV0dXJuIGZhbHNlXG59XG5cbmdsb2IuR2xvYiA9IEdsb2JcbmluaGVyaXRzKEdsb2IsIEVFKVxuZnVuY3Rpb24gR2xvYiAocGF0dGVybiwgb3B0aW9ucywgY2IpIHtcbiAgaWYgKHR5cGVvZiBvcHRpb25zID09PSAnZnVuY3Rpb24nKSB7XG4gICAgY2IgPSBvcHRpb25zXG4gICAgb3B0aW9ucyA9IG51bGxcbiAgfVxuXG4gIGlmIChvcHRpb25zICYmIG9wdGlvbnMuc3luYykge1xuICAgIGlmIChjYilcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2NhbGxiYWNrIHByb3ZpZGVkIHRvIHN5bmMgZ2xvYicpXG4gICAgcmV0dXJuIG5ldyBHbG9iU3luYyhwYXR0ZXJuLCBvcHRpb25zKVxuICB9XG5cbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIEdsb2IpKVxuICAgIHJldHVybiBuZXcgR2xvYihwYXR0ZXJuLCBvcHRpb25zLCBjYilcblxuICBzZXRvcHRzKHRoaXMsIHBhdHRlcm4sIG9wdGlvbnMpXG4gIHRoaXMuX2RpZFJlYWxQYXRoID0gZmFsc2VcblxuICAvLyBwcm9jZXNzIGVhY2ggcGF0dGVybiBpbiB0aGUgbWluaW1hdGNoIHNldFxuICB2YXIgbiA9IHRoaXMubWluaW1hdGNoLnNldC5sZW5ndGhcblxuICAvLyBUaGUgbWF0Y2hlcyBhcmUgc3RvcmVkIGFzIHs8ZmlsZW5hbWU+OiB0cnVlLC4uLn0gc28gdGhhdFxuICAvLyBkdXBsaWNhdGVzIGFyZSBhdXRvbWFnaWNhbGx5IHBydW5lZC5cbiAgLy8gTGF0ZXIsIHdlIGRvIGFuIE9iamVjdC5rZXlzKCkgb24gdGhlc2UuXG4gIC8vIEtlZXAgdGhlbSBhcyBhIGxpc3Qgc28gd2UgY2FuIGZpbGwgaW4gd2hlbiBub251bGwgaXMgc2V0LlxuICB0aGlzLm1hdGNoZXMgPSBuZXcgQXJyYXkobilcblxuICBpZiAodHlwZW9mIGNiID09PSAnZnVuY3Rpb24nKSB7XG4gICAgY2IgPSBvbmNlKGNiKVxuICAgIHRoaXMub24oJ2Vycm9yJywgY2IpXG4gICAgdGhpcy5vbignZW5kJywgZnVuY3Rpb24gKG1hdGNoZXMpIHtcbiAgICAgIGNiKG51bGwsIG1hdGNoZXMpXG4gICAgfSlcbiAgfVxuXG4gIHZhciBzZWxmID0gdGhpc1xuICB0aGlzLl9wcm9jZXNzaW5nID0gMFxuXG4gIHRoaXMuX2VtaXRRdWV1ZSA9IFtdXG4gIHRoaXMuX3Byb2Nlc3NRdWV1ZSA9IFtdXG4gIHRoaXMucGF1c2VkID0gZmFsc2VcblxuICBpZiAodGhpcy5ub3Byb2Nlc3MpXG4gICAgcmV0dXJuIHRoaXNcblxuICBpZiAobiA9PT0gMClcbiAgICByZXR1cm4gZG9uZSgpXG5cbiAgdmFyIHN5bmMgPSB0cnVlXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbjsgaSArKykge1xuICAgIHRoaXMuX3Byb2Nlc3ModGhpcy5taW5pbWF0Y2guc2V0W2ldLCBpLCBmYWxzZSwgZG9uZSlcbiAgfVxuICBzeW5jID0gZmFsc2VcblxuICBmdW5jdGlvbiBkb25lICgpIHtcbiAgICAtLXNlbGYuX3Byb2Nlc3NpbmdcbiAgICBpZiAoc2VsZi5fcHJvY2Vzc2luZyA8PSAwKSB7XG4gICAgICBpZiAoc3luYykge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBzZWxmLl9maW5pc2goKVxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2VsZi5fZmluaXNoKClcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuR2xvYi5wcm90b3R5cGUuX2ZpbmlzaCA9IGZ1bmN0aW9uICgpIHtcbiAgYXNzZXJ0KHRoaXMgaW5zdGFuY2VvZiBHbG9iKVxuICBpZiAodGhpcy5hYm9ydGVkKVxuICAgIHJldHVyblxuXG4gIGlmICh0aGlzLnJlYWxwYXRoICYmICF0aGlzLl9kaWRSZWFscGF0aClcbiAgICByZXR1cm4gdGhpcy5fcmVhbHBhdGgoKVxuXG4gIGNvbW1vbi5maW5pc2godGhpcylcbiAgdGhpcy5lbWl0KCdlbmQnLCB0aGlzLmZvdW5kKVxufVxuXG5HbG9iLnByb3RvdHlwZS5fcmVhbHBhdGggPSBmdW5jdGlvbiAoKSB7XG4gIGlmICh0aGlzLl9kaWRSZWFscGF0aClcbiAgICByZXR1cm5cblxuICB0aGlzLl9kaWRSZWFscGF0aCA9IHRydWVcblxuICB2YXIgbiA9IHRoaXMubWF0Y2hlcy5sZW5ndGhcbiAgaWYgKG4gPT09IDApXG4gICAgcmV0dXJuIHRoaXMuX2ZpbmlzaCgpXG5cbiAgdmFyIHNlbGYgPSB0aGlzXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5tYXRjaGVzLmxlbmd0aDsgaSsrKVxuICAgIHRoaXMuX3JlYWxwYXRoU2V0KGksIG5leHQpXG5cbiAgZnVuY3Rpb24gbmV4dCAoKSB7XG4gICAgaWYgKC0tbiA9PT0gMClcbiAgICAgIHNlbGYuX2ZpbmlzaCgpXG4gIH1cbn1cblxuR2xvYi5wcm90b3R5cGUuX3JlYWxwYXRoU2V0ID0gZnVuY3Rpb24gKGluZGV4LCBjYikge1xuICB2YXIgbWF0Y2hzZXQgPSB0aGlzLm1hdGNoZXNbaW5kZXhdXG4gIGlmICghbWF0Y2hzZXQpXG4gICAgcmV0dXJuIGNiKClcblxuICB2YXIgZm91bmQgPSBPYmplY3Qua2V5cyhtYXRjaHNldClcbiAgdmFyIHNlbGYgPSB0aGlzXG4gIHZhciBuID0gZm91bmQubGVuZ3RoXG5cbiAgaWYgKG4gPT09IDApXG4gICAgcmV0dXJuIGNiKClcblxuICB2YXIgc2V0ID0gdGhpcy5tYXRjaGVzW2luZGV4XSA9IE9iamVjdC5jcmVhdGUobnVsbClcbiAgZm91bmQuZm9yRWFjaChmdW5jdGlvbiAocCwgaSkge1xuICAgIC8vIElmIHRoZXJlJ3MgYSBwcm9ibGVtIHdpdGggdGhlIHN0YXQsIHRoZW4gaXQgbWVhbnMgdGhhdFxuICAgIC8vIG9uZSBvciBtb3JlIG9mIHRoZSBsaW5rcyBpbiB0aGUgcmVhbHBhdGggY291bGRuJ3QgYmVcbiAgICAvLyByZXNvbHZlZC4gIGp1c3QgcmV0dXJuIHRoZSBhYnMgdmFsdWUgaW4gdGhhdCBjYXNlLlxuICAgIHAgPSBzZWxmLl9tYWtlQWJzKHApXG4gICAgcnAucmVhbHBhdGgocCwgc2VsZi5yZWFscGF0aENhY2hlLCBmdW5jdGlvbiAoZXIsIHJlYWwpIHtcbiAgICAgIGlmICghZXIpXG4gICAgICAgIHNldFtyZWFsXSA9IHRydWVcbiAgICAgIGVsc2UgaWYgKGVyLnN5c2NhbGwgPT09ICdzdGF0JylcbiAgICAgICAgc2V0W3BdID0gdHJ1ZVxuICAgICAgZWxzZVxuICAgICAgICBzZWxmLmVtaXQoJ2Vycm9yJywgZXIpIC8vIHNyc2x5IHd0ZiByaWdodCBoZXJlXG5cbiAgICAgIGlmICgtLW4gPT09IDApIHtcbiAgICAgICAgc2VsZi5tYXRjaGVzW2luZGV4XSA9IHNldFxuICAgICAgICBjYigpXG4gICAgICB9XG4gICAgfSlcbiAgfSlcbn1cblxuR2xvYi5wcm90b3R5cGUuX21hcmsgPSBmdW5jdGlvbiAocCkge1xuICByZXR1cm4gY29tbW9uLm1hcmsodGhpcywgcClcbn1cblxuR2xvYi5wcm90b3R5cGUuX21ha2VBYnMgPSBmdW5jdGlvbiAoZikge1xuICByZXR1cm4gY29tbW9uLm1ha2VBYnModGhpcywgZilcbn1cblxuR2xvYi5wcm90b3R5cGUuYWJvcnQgPSBmdW5jdGlvbiAoKSB7XG4gIHRoaXMuYWJvcnRlZCA9IHRydWVcbiAgdGhpcy5lbWl0KCdhYm9ydCcpXG59XG5cbkdsb2IucHJvdG90eXBlLnBhdXNlID0gZnVuY3Rpb24gKCkge1xuICBpZiAoIXRoaXMucGF1c2VkKSB7XG4gICAgdGhpcy5wYXVzZWQgPSB0cnVlXG4gICAgdGhpcy5lbWl0KCdwYXVzZScpXG4gIH1cbn1cblxuR2xvYi5wcm90b3R5cGUucmVzdW1lID0gZnVuY3Rpb24gKCkge1xuICBpZiAodGhpcy5wYXVzZWQpIHtcbiAgICB0aGlzLmVtaXQoJ3Jlc3VtZScpXG4gICAgdGhpcy5wYXVzZWQgPSBmYWxzZVxuICAgIGlmICh0aGlzLl9lbWl0UXVldWUubGVuZ3RoKSB7XG4gICAgICB2YXIgZXEgPSB0aGlzLl9lbWl0UXVldWUuc2xpY2UoMClcbiAgICAgIHRoaXMuX2VtaXRRdWV1ZS5sZW5ndGggPSAwXG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGVxLmxlbmd0aDsgaSArKykge1xuICAgICAgICB2YXIgZSA9IGVxW2ldXG4gICAgICAgIHRoaXMuX2VtaXRNYXRjaChlWzBdLCBlWzFdKVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGhpcy5fcHJvY2Vzc1F1ZXVlLmxlbmd0aCkge1xuICAgICAgdmFyIHBxID0gdGhpcy5fcHJvY2Vzc1F1ZXVlLnNsaWNlKDApXG4gICAgICB0aGlzLl9wcm9jZXNzUXVldWUubGVuZ3RoID0gMFxuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwcS5sZW5ndGg7IGkgKyspIHtcbiAgICAgICAgdmFyIHAgPSBwcVtpXVxuICAgICAgICB0aGlzLl9wcm9jZXNzaW5nLS1cbiAgICAgICAgdGhpcy5fcHJvY2VzcyhwWzBdLCBwWzFdLCBwWzJdLCBwWzNdKVxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5HbG9iLnByb3RvdHlwZS5fcHJvY2VzcyA9IGZ1bmN0aW9uIChwYXR0ZXJuLCBpbmRleCwgaW5HbG9iU3RhciwgY2IpIHtcbiAgYXNzZXJ0KHRoaXMgaW5zdGFuY2VvZiBHbG9iKVxuICBhc3NlcnQodHlwZW9mIGNiID09PSAnZnVuY3Rpb24nKVxuXG4gIGlmICh0aGlzLmFib3J0ZWQpXG4gICAgcmV0dXJuXG5cbiAgdGhpcy5fcHJvY2Vzc2luZysrXG4gIGlmICh0aGlzLnBhdXNlZCkge1xuICAgIHRoaXMuX3Byb2Nlc3NRdWV1ZS5wdXNoKFtwYXR0ZXJuLCBpbmRleCwgaW5HbG9iU3RhciwgY2JdKVxuICAgIHJldHVyblxuICB9XG5cbiAgLy9jb25zb2xlLmVycm9yKCdQUk9DRVNTICVkJywgdGhpcy5fcHJvY2Vzc2luZywgcGF0dGVybilcblxuICAvLyBHZXQgdGhlIGZpcnN0IFtuXSBwYXJ0cyBvZiBwYXR0ZXJuIHRoYXQgYXJlIGFsbCBzdHJpbmdzLlxuICB2YXIgbiA9IDBcbiAgd2hpbGUgKHR5cGVvZiBwYXR0ZXJuW25dID09PSAnc3RyaW5nJykge1xuICAgIG4gKytcbiAgfVxuICAvLyBub3cgbiBpcyB0aGUgaW5kZXggb2YgdGhlIGZpcnN0IG9uZSB0aGF0IGlzICpub3QqIGEgc3RyaW5nLlxuXG4gIC8vIHNlZSBpZiB0aGVyZSdzIGFueXRoaW5nIGVsc2VcbiAgdmFyIHByZWZpeFxuICBzd2l0Y2ggKG4pIHtcbiAgICAvLyBpZiBub3QsIHRoZW4gdGhpcyBpcyByYXRoZXIgc2ltcGxlXG4gICAgY2FzZSBwYXR0ZXJuLmxlbmd0aDpcbiAgICAgIHRoaXMuX3Byb2Nlc3NTaW1wbGUocGF0dGVybi5qb2luKCcvJyksIGluZGV4LCBjYilcbiAgICAgIHJldHVyblxuXG4gICAgY2FzZSAwOlxuICAgICAgLy8gcGF0dGVybiAqc3RhcnRzKiB3aXRoIHNvbWUgbm9uLXRyaXZpYWwgaXRlbS5cbiAgICAgIC8vIGdvaW5nIHRvIHJlYWRkaXIoY3dkKSwgYnV0IG5vdCBpbmNsdWRlIHRoZSBwcmVmaXggaW4gbWF0Y2hlcy5cbiAgICAgIHByZWZpeCA9IG51bGxcbiAgICAgIGJyZWFrXG5cbiAgICBkZWZhdWx0OlxuICAgICAgLy8gcGF0dGVybiBoYXMgc29tZSBzdHJpbmcgYml0cyBpbiB0aGUgZnJvbnQuXG4gICAgICAvLyB3aGF0ZXZlciBpdCBzdGFydHMgd2l0aCwgd2hldGhlciB0aGF0J3MgJ2Fic29sdXRlJyBsaWtlIC9mb28vYmFyLFxuICAgICAgLy8gb3IgJ3JlbGF0aXZlJyBsaWtlICcuLi9iYXonXG4gICAgICBwcmVmaXggPSBwYXR0ZXJuLnNsaWNlKDAsIG4pLmpvaW4oJy8nKVxuICAgICAgYnJlYWtcbiAgfVxuXG4gIHZhciByZW1haW4gPSBwYXR0ZXJuLnNsaWNlKG4pXG5cbiAgLy8gZ2V0IHRoZSBsaXN0IG9mIGVudHJpZXMuXG4gIHZhciByZWFkXG4gIGlmIChwcmVmaXggPT09IG51bGwpXG4gICAgcmVhZCA9ICcuJ1xuICBlbHNlIGlmIChpc0Fic29sdXRlKHByZWZpeCkgfHwgaXNBYnNvbHV0ZShwYXR0ZXJuLmpvaW4oJy8nKSkpIHtcbiAgICBpZiAoIXByZWZpeCB8fCAhaXNBYnNvbHV0ZShwcmVmaXgpKVxuICAgICAgcHJlZml4ID0gJy8nICsgcHJlZml4XG4gICAgcmVhZCA9IHByZWZpeFxuICB9IGVsc2VcbiAgICByZWFkID0gcHJlZml4XG5cbiAgdmFyIGFicyA9IHRoaXMuX21ha2VBYnMocmVhZClcblxuICAvL2lmIGlnbm9yZWQsIHNraXAgX3Byb2Nlc3NpbmdcbiAgaWYgKGNoaWxkcmVuSWdub3JlZCh0aGlzLCByZWFkKSlcbiAgICByZXR1cm4gY2IoKVxuXG4gIHZhciBpc0dsb2JTdGFyID0gcmVtYWluWzBdID09PSBtaW5pbWF0Y2guR0xPQlNUQVJcbiAgaWYgKGlzR2xvYlN0YXIpXG4gICAgdGhpcy5fcHJvY2Vzc0dsb2JTdGFyKHByZWZpeCwgcmVhZCwgYWJzLCByZW1haW4sIGluZGV4LCBpbkdsb2JTdGFyLCBjYilcbiAgZWxzZVxuICAgIHRoaXMuX3Byb2Nlc3NSZWFkZGlyKHByZWZpeCwgcmVhZCwgYWJzLCByZW1haW4sIGluZGV4LCBpbkdsb2JTdGFyLCBjYilcbn1cblxuR2xvYi5wcm90b3R5cGUuX3Byb2Nlc3NSZWFkZGlyID0gZnVuY3Rpb24gKHByZWZpeCwgcmVhZCwgYWJzLCByZW1haW4sIGluZGV4LCBpbkdsb2JTdGFyLCBjYikge1xuICB2YXIgc2VsZiA9IHRoaXNcbiAgdGhpcy5fcmVhZGRpcihhYnMsIGluR2xvYlN0YXIsIGZ1bmN0aW9uIChlciwgZW50cmllcykge1xuICAgIHJldHVybiBzZWxmLl9wcm9jZXNzUmVhZGRpcjIocHJlZml4LCByZWFkLCBhYnMsIHJlbWFpbiwgaW5kZXgsIGluR2xvYlN0YXIsIGVudHJpZXMsIGNiKVxuICB9KVxufVxuXG5HbG9iLnByb3RvdHlwZS5fcHJvY2Vzc1JlYWRkaXIyID0gZnVuY3Rpb24gKHByZWZpeCwgcmVhZCwgYWJzLCByZW1haW4sIGluZGV4LCBpbkdsb2JTdGFyLCBlbnRyaWVzLCBjYikge1xuXG4gIC8vIGlmIHRoZSBhYnMgaXNuJ3QgYSBkaXIsIHRoZW4gbm90aGluZyBjYW4gbWF0Y2ghXG4gIGlmICghZW50cmllcylcbiAgICByZXR1cm4gY2IoKVxuXG4gIC8vIEl0IHdpbGwgb25seSBtYXRjaCBkb3QgZW50cmllcyBpZiBpdCBzdGFydHMgd2l0aCBhIGRvdCwgb3IgaWZcbiAgLy8gZG90IGlzIHNldC4gIFN0dWZmIGxpa2UgQCguZm9vfC5iYXIpIGlzbid0IGFsbG93ZWQuXG4gIHZhciBwbiA9IHJlbWFpblswXVxuICB2YXIgbmVnYXRlID0gISF0aGlzLm1pbmltYXRjaC5uZWdhdGVcbiAgdmFyIHJhd0dsb2IgPSBwbi5fZ2xvYlxuICB2YXIgZG90T2sgPSB0aGlzLmRvdCB8fCByYXdHbG9iLmNoYXJBdCgwKSA9PT0gJy4nXG5cbiAgdmFyIG1hdGNoZWRFbnRyaWVzID0gW11cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBlbnRyaWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIGUgPSBlbnRyaWVzW2ldXG4gICAgaWYgKGUuY2hhckF0KDApICE9PSAnLicgfHwgZG90T2spIHtcbiAgICAgIHZhciBtXG4gICAgICBpZiAobmVnYXRlICYmICFwcmVmaXgpIHtcbiAgICAgICAgbSA9ICFlLm1hdGNoKHBuKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbSA9IGUubWF0Y2gocG4pXG4gICAgICB9XG4gICAgICBpZiAobSlcbiAgICAgICAgbWF0Y2hlZEVudHJpZXMucHVzaChlKVxuICAgIH1cbiAgfVxuXG4gIC8vY29uc29sZS5lcnJvcigncHJkMicsIHByZWZpeCwgZW50cmllcywgcmVtYWluWzBdLl9nbG9iLCBtYXRjaGVkRW50cmllcylcblxuICB2YXIgbGVuID0gbWF0Y2hlZEVudHJpZXMubGVuZ3RoXG4gIC8vIElmIHRoZXJlIGFyZSBubyBtYXRjaGVkIGVudHJpZXMsIHRoZW4gbm90aGluZyBtYXRjaGVzLlxuICBpZiAobGVuID09PSAwKVxuICAgIHJldHVybiBjYigpXG5cbiAgLy8gaWYgdGhpcyBpcyB0aGUgbGFzdCByZW1haW5pbmcgcGF0dGVybiBiaXQsIHRoZW4gbm8gbmVlZCBmb3JcbiAgLy8gYW4gYWRkaXRpb25hbCBzdGF0ICp1bmxlc3MqIHRoZSB1c2VyIGhhcyBzcGVjaWZpZWQgbWFyayBvclxuICAvLyBzdGF0IGV4cGxpY2l0bHkuICBXZSBrbm93IHRoZXkgZXhpc3QsIHNpbmNlIHJlYWRkaXIgcmV0dXJuZWRcbiAgLy8gdGhlbS5cblxuICBpZiAocmVtYWluLmxlbmd0aCA9PT0gMSAmJiAhdGhpcy5tYXJrICYmICF0aGlzLnN0YXQpIHtcbiAgICBpZiAoIXRoaXMubWF0Y2hlc1tpbmRleF0pXG4gICAgICB0aGlzLm1hdGNoZXNbaW5kZXhdID0gT2JqZWN0LmNyZWF0ZShudWxsKVxuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkgKyspIHtcbiAgICAgIHZhciBlID0gbWF0Y2hlZEVudHJpZXNbaV1cbiAgICAgIGlmIChwcmVmaXgpIHtcbiAgICAgICAgaWYgKHByZWZpeCAhPT0gJy8nKVxuICAgICAgICAgIGUgPSBwcmVmaXggKyAnLycgKyBlXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBlID0gcHJlZml4ICsgZVxuICAgICAgfVxuXG4gICAgICBpZiAoZS5jaGFyQXQoMCkgPT09ICcvJyAmJiAhdGhpcy5ub21vdW50KSB7XG4gICAgICAgIGUgPSBwYXRoLmpvaW4odGhpcy5yb290LCBlKVxuICAgICAgfVxuICAgICAgdGhpcy5fZW1pdE1hdGNoKGluZGV4LCBlKVxuICAgIH1cbiAgICAvLyBUaGlzIHdhcyB0aGUgbGFzdCBvbmUsIGFuZCBubyBzdGF0cyB3ZXJlIG5lZWRlZFxuICAgIHJldHVybiBjYigpXG4gIH1cblxuICAvLyBub3cgdGVzdCBhbGwgbWF0Y2hlZCBlbnRyaWVzIGFzIHN0YW5kLWlucyBmb3IgdGhhdCBwYXJ0XG4gIC8vIG9mIHRoZSBwYXR0ZXJuLlxuICByZW1haW4uc2hpZnQoKVxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSArKykge1xuICAgIHZhciBlID0gbWF0Y2hlZEVudHJpZXNbaV1cbiAgICB2YXIgbmV3UGF0dGVyblxuICAgIGlmIChwcmVmaXgpIHtcbiAgICAgIGlmIChwcmVmaXggIT09ICcvJylcbiAgICAgICAgZSA9IHByZWZpeCArICcvJyArIGVcbiAgICAgIGVsc2VcbiAgICAgICAgZSA9IHByZWZpeCArIGVcbiAgICB9XG4gICAgdGhpcy5fcHJvY2VzcyhbZV0uY29uY2F0KHJlbWFpbiksIGluZGV4LCBpbkdsb2JTdGFyLCBjYilcbiAgfVxuICBjYigpXG59XG5cbkdsb2IucHJvdG90eXBlLl9lbWl0TWF0Y2ggPSBmdW5jdGlvbiAoaW5kZXgsIGUpIHtcbiAgaWYgKHRoaXMuYWJvcnRlZClcbiAgICByZXR1cm5cblxuICBpZiAoaXNJZ25vcmVkKHRoaXMsIGUpKVxuICAgIHJldHVyblxuXG4gIGlmICh0aGlzLnBhdXNlZCkge1xuICAgIHRoaXMuX2VtaXRRdWV1ZS5wdXNoKFtpbmRleCwgZV0pXG4gICAgcmV0dXJuXG4gIH1cblxuICB2YXIgYWJzID0gaXNBYnNvbHV0ZShlKSA/IGUgOiB0aGlzLl9tYWtlQWJzKGUpXG5cbiAgaWYgKHRoaXMubWFyaylcbiAgICBlID0gdGhpcy5fbWFyayhlKVxuXG4gIGlmICh0aGlzLmFic29sdXRlKVxuICAgIGUgPSBhYnNcblxuICBpZiAodGhpcy5tYXRjaGVzW2luZGV4XVtlXSlcbiAgICByZXR1cm5cblxuICBpZiAodGhpcy5ub2Rpcikge1xuICAgIHZhciBjID0gdGhpcy5jYWNoZVthYnNdXG4gICAgaWYgKGMgPT09ICdESVInIHx8IEFycmF5LmlzQXJyYXkoYykpXG4gICAgICByZXR1cm5cbiAgfVxuXG4gIHRoaXMubWF0Y2hlc1tpbmRleF1bZV0gPSB0cnVlXG5cbiAgdmFyIHN0ID0gdGhpcy5zdGF0Q2FjaGVbYWJzXVxuICBpZiAoc3QpXG4gICAgdGhpcy5lbWl0KCdzdGF0JywgZSwgc3QpXG5cbiAgdGhpcy5lbWl0KCdtYXRjaCcsIGUpXG59XG5cbkdsb2IucHJvdG90eXBlLl9yZWFkZGlySW5HbG9iU3RhciA9IGZ1bmN0aW9uIChhYnMsIGNiKSB7XG4gIGlmICh0aGlzLmFib3J0ZWQpXG4gICAgcmV0dXJuXG5cbiAgLy8gZm9sbG93IGFsbCBzeW1saW5rZWQgZGlyZWN0b3JpZXMgZm9yZXZlclxuICAvLyBqdXN0IHByb2NlZWQgYXMgaWYgdGhpcyBpcyBhIG5vbi1nbG9ic3RhciBzaXR1YXRpb25cbiAgaWYgKHRoaXMuZm9sbG93KVxuICAgIHJldHVybiB0aGlzLl9yZWFkZGlyKGFicywgZmFsc2UsIGNiKVxuXG4gIHZhciBsc3RhdGtleSA9ICdsc3RhdFxcMCcgKyBhYnNcbiAgdmFyIHNlbGYgPSB0aGlzXG4gIHZhciBsc3RhdGNiID0gaW5mbGlnaHQobHN0YXRrZXksIGxzdGF0Y2JfKVxuXG4gIGlmIChsc3RhdGNiKVxuICAgIGZzLmxzdGF0KGFicywgbHN0YXRjYilcblxuICBmdW5jdGlvbiBsc3RhdGNiXyAoZXIsIGxzdGF0KSB7XG4gICAgaWYgKGVyICYmIGVyLmNvZGUgPT09ICdFTk9FTlQnKVxuICAgICAgcmV0dXJuIGNiKClcblxuICAgIHZhciBpc1N5bSA9IGxzdGF0ICYmIGxzdGF0LmlzU3ltYm9saWNMaW5rKClcbiAgICBzZWxmLnN5bWxpbmtzW2Fic10gPSBpc1N5bVxuXG4gICAgLy8gSWYgaXQncyBub3QgYSBzeW1saW5rIG9yIGEgZGlyLCB0aGVuIGl0J3MgZGVmaW5pdGVseSBhIHJlZ3VsYXIgZmlsZS5cbiAgICAvLyBkb24ndCBib3RoZXIgZG9pbmcgYSByZWFkZGlyIGluIHRoYXQgY2FzZS5cbiAgICBpZiAoIWlzU3ltICYmIGxzdGF0ICYmICFsc3RhdC5pc0RpcmVjdG9yeSgpKSB7XG4gICAgICBzZWxmLmNhY2hlW2Fic10gPSAnRklMRSdcbiAgICAgIGNiKClcbiAgICB9IGVsc2VcbiAgICAgIHNlbGYuX3JlYWRkaXIoYWJzLCBmYWxzZSwgY2IpXG4gIH1cbn1cblxuR2xvYi5wcm90b3R5cGUuX3JlYWRkaXIgPSBmdW5jdGlvbiAoYWJzLCBpbkdsb2JTdGFyLCBjYikge1xuICBpZiAodGhpcy5hYm9ydGVkKVxuICAgIHJldHVyblxuXG4gIGNiID0gaW5mbGlnaHQoJ3JlYWRkaXJcXDAnK2FicysnXFwwJytpbkdsb2JTdGFyLCBjYilcbiAgaWYgKCFjYilcbiAgICByZXR1cm5cblxuICAvL2NvbnNvbGUuZXJyb3IoJ1JEICVqICVqJywgK2luR2xvYlN0YXIsIGFicylcbiAgaWYgKGluR2xvYlN0YXIgJiYgIW93blByb3AodGhpcy5zeW1saW5rcywgYWJzKSlcbiAgICByZXR1cm4gdGhpcy5fcmVhZGRpckluR2xvYlN0YXIoYWJzLCBjYilcblxuICBpZiAob3duUHJvcCh0aGlzLmNhY2hlLCBhYnMpKSB7XG4gICAgdmFyIGMgPSB0aGlzLmNhY2hlW2Fic11cbiAgICBpZiAoIWMgfHwgYyA9PT0gJ0ZJTEUnKVxuICAgICAgcmV0dXJuIGNiKClcblxuICAgIGlmIChBcnJheS5pc0FycmF5KGMpKVxuICAgICAgcmV0dXJuIGNiKG51bGwsIGMpXG4gIH1cblxuICB2YXIgc2VsZiA9IHRoaXNcbiAgZnMucmVhZGRpcihhYnMsIHJlYWRkaXJDYih0aGlzLCBhYnMsIGNiKSlcbn1cblxuZnVuY3Rpb24gcmVhZGRpckNiIChzZWxmLCBhYnMsIGNiKSB7XG4gIHJldHVybiBmdW5jdGlvbiAoZXIsIGVudHJpZXMpIHtcbiAgICBpZiAoZXIpXG4gICAgICBzZWxmLl9yZWFkZGlyRXJyb3IoYWJzLCBlciwgY2IpXG4gICAgZWxzZVxuICAgICAgc2VsZi5fcmVhZGRpckVudHJpZXMoYWJzLCBlbnRyaWVzLCBjYilcbiAgfVxufVxuXG5HbG9iLnByb3RvdHlwZS5fcmVhZGRpckVudHJpZXMgPSBmdW5jdGlvbiAoYWJzLCBlbnRyaWVzLCBjYikge1xuICBpZiAodGhpcy5hYm9ydGVkKVxuICAgIHJldHVyblxuXG4gIC8vIGlmIHdlIGhhdmVuJ3QgYXNrZWQgdG8gc3RhdCBldmVyeXRoaW5nLCB0aGVuIGp1c3RcbiAgLy8gYXNzdW1lIHRoYXQgZXZlcnl0aGluZyBpbiB0aGVyZSBleGlzdHMsIHNvIHdlIGNhbiBhdm9pZFxuICAvLyBoYXZpbmcgdG8gc3RhdCBpdCBhIHNlY29uZCB0aW1lLlxuICBpZiAoIXRoaXMubWFyayAmJiAhdGhpcy5zdGF0KSB7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBlbnRyaWVzLmxlbmd0aDsgaSArKykge1xuICAgICAgdmFyIGUgPSBlbnRyaWVzW2ldXG4gICAgICBpZiAoYWJzID09PSAnLycpXG4gICAgICAgIGUgPSBhYnMgKyBlXG4gICAgICBlbHNlXG4gICAgICAgIGUgPSBhYnMgKyAnLycgKyBlXG4gICAgICB0aGlzLmNhY2hlW2VdID0gdHJ1ZVxuICAgIH1cbiAgfVxuXG4gIHRoaXMuY2FjaGVbYWJzXSA9IGVudHJpZXNcbiAgcmV0dXJuIGNiKG51bGwsIGVudHJpZXMpXG59XG5cbkdsb2IucHJvdG90eXBlLl9yZWFkZGlyRXJyb3IgPSBmdW5jdGlvbiAoZiwgZXIsIGNiKSB7XG4gIGlmICh0aGlzLmFib3J0ZWQpXG4gICAgcmV0dXJuXG5cbiAgLy8gaGFuZGxlIGVycm9ycywgYW5kIGNhY2hlIHRoZSBpbmZvcm1hdGlvblxuICBzd2l0Y2ggKGVyLmNvZGUpIHtcbiAgICBjYXNlICdFTk9UU1VQJzogLy8gaHR0cHM6Ly9naXRodWIuY29tL2lzYWFjcy9ub2RlLWdsb2IvaXNzdWVzLzIwNVxuICAgIGNhc2UgJ0VOT1RESVInOiAvLyB0b3RhbGx5IG5vcm1hbC4gbWVhbnMgaXQgKmRvZXMqIGV4aXN0LlxuICAgICAgdmFyIGFicyA9IHRoaXMuX21ha2VBYnMoZilcbiAgICAgIHRoaXMuY2FjaGVbYWJzXSA9ICdGSUxFJ1xuICAgICAgaWYgKGFicyA9PT0gdGhpcy5jd2RBYnMpIHtcbiAgICAgICAgdmFyIGVycm9yID0gbmV3IEVycm9yKGVyLmNvZGUgKyAnIGludmFsaWQgY3dkICcgKyB0aGlzLmN3ZClcbiAgICAgICAgZXJyb3IucGF0aCA9IHRoaXMuY3dkXG4gICAgICAgIGVycm9yLmNvZGUgPSBlci5jb2RlXG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnJvcilcbiAgICAgICAgdGhpcy5hYm9ydCgpXG4gICAgICB9XG4gICAgICBicmVha1xuXG4gICAgY2FzZSAnRU5PRU5UJzogLy8gbm90IHRlcnJpYmx5IHVudXN1YWxcbiAgICBjYXNlICdFTE9PUCc6XG4gICAgY2FzZSAnRU5BTUVUT09MT05HJzpcbiAgICBjYXNlICdVTktOT1dOJzpcbiAgICAgIHRoaXMuY2FjaGVbdGhpcy5fbWFrZUFicyhmKV0gPSBmYWxzZVxuICAgICAgYnJlYWtcblxuICAgIGRlZmF1bHQ6IC8vIHNvbWUgdW51c3VhbCBlcnJvci4gIFRyZWF0IGFzIGZhaWx1cmUuXG4gICAgICB0aGlzLmNhY2hlW3RoaXMuX21ha2VBYnMoZildID0gZmFsc2VcbiAgICAgIGlmICh0aGlzLnN0cmljdCkge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXIpXG4gICAgICAgIC8vIElmIHRoZSBlcnJvciBpcyBoYW5kbGVkLCB0aGVuIHdlIGFib3J0XG4gICAgICAgIC8vIGlmIG5vdCwgd2UgdGhyZXcgb3V0IG9mIGhlcmVcbiAgICAgICAgdGhpcy5hYm9ydCgpXG4gICAgICB9XG4gICAgICBpZiAoIXRoaXMuc2lsZW50KVxuICAgICAgICBjb25zb2xlLmVycm9yKCdnbG9iIGVycm9yJywgZXIpXG4gICAgICBicmVha1xuICB9XG5cbiAgcmV0dXJuIGNiKClcbn1cblxuR2xvYi5wcm90b3R5cGUuX3Byb2Nlc3NHbG9iU3RhciA9IGZ1bmN0aW9uIChwcmVmaXgsIHJlYWQsIGFicywgcmVtYWluLCBpbmRleCwgaW5HbG9iU3RhciwgY2IpIHtcbiAgdmFyIHNlbGYgPSB0aGlzXG4gIHRoaXMuX3JlYWRkaXIoYWJzLCBpbkdsb2JTdGFyLCBmdW5jdGlvbiAoZXIsIGVudHJpZXMpIHtcbiAgICBzZWxmLl9wcm9jZXNzR2xvYlN0YXIyKHByZWZpeCwgcmVhZCwgYWJzLCByZW1haW4sIGluZGV4LCBpbkdsb2JTdGFyLCBlbnRyaWVzLCBjYilcbiAgfSlcbn1cblxuXG5HbG9iLnByb3RvdHlwZS5fcHJvY2Vzc0dsb2JTdGFyMiA9IGZ1bmN0aW9uIChwcmVmaXgsIHJlYWQsIGFicywgcmVtYWluLCBpbmRleCwgaW5HbG9iU3RhciwgZW50cmllcywgY2IpIHtcbiAgLy9jb25zb2xlLmVycm9yKCdwZ3MyJywgcHJlZml4LCByZW1haW5bMF0sIGVudHJpZXMpXG5cbiAgLy8gbm8gZW50cmllcyBtZWFucyBub3QgYSBkaXIsIHNvIGl0IGNhbiBuZXZlciBoYXZlIG1hdGNoZXNcbiAgLy8gZm9vLnR4dC8qKiBkb2Vzbid0IG1hdGNoIGZvby50eHRcbiAgaWYgKCFlbnRyaWVzKVxuICAgIHJldHVybiBjYigpXG5cbiAgLy8gdGVzdCB3aXRob3V0IHRoZSBnbG9ic3RhciwgYW5kIHdpdGggZXZlcnkgY2hpbGQgYm90aCBiZWxvd1xuICAvLyBhbmQgcmVwbGFjaW5nIHRoZSBnbG9ic3Rhci5cbiAgdmFyIHJlbWFpbldpdGhvdXRHbG9iU3RhciA9IHJlbWFpbi5zbGljZSgxKVxuICB2YXIgZ3NwcmVmID0gcHJlZml4ID8gWyBwcmVmaXggXSA6IFtdXG4gIHZhciBub0dsb2JTdGFyID0gZ3NwcmVmLmNvbmNhdChyZW1haW5XaXRob3V0R2xvYlN0YXIpXG5cbiAgLy8gdGhlIG5vR2xvYlN0YXIgcGF0dGVybiBleGl0cyB0aGUgaW5HbG9iU3RhciBzdGF0ZVxuICB0aGlzLl9wcm9jZXNzKG5vR2xvYlN0YXIsIGluZGV4LCBmYWxzZSwgY2IpXG5cbiAgdmFyIGlzU3ltID0gdGhpcy5zeW1saW5rc1thYnNdXG4gIHZhciBsZW4gPSBlbnRyaWVzLmxlbmd0aFxuXG4gIC8vIElmIGl0J3MgYSBzeW1saW5rLCBhbmQgd2UncmUgaW4gYSBnbG9ic3RhciwgdGhlbiBzdG9wXG4gIGlmIChpc1N5bSAmJiBpbkdsb2JTdGFyKVxuICAgIHJldHVybiBjYigpXG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIHZhciBlID0gZW50cmllc1tpXVxuICAgIGlmIChlLmNoYXJBdCgwKSA9PT0gJy4nICYmICF0aGlzLmRvdClcbiAgICAgIGNvbnRpbnVlXG5cbiAgICAvLyB0aGVzZSB0d28gY2FzZXMgZW50ZXIgdGhlIGluR2xvYlN0YXIgc3RhdGVcbiAgICB2YXIgaW5zdGVhZCA9IGdzcHJlZi5jb25jYXQoZW50cmllc1tpXSwgcmVtYWluV2l0aG91dEdsb2JTdGFyKVxuICAgIHRoaXMuX3Byb2Nlc3MoaW5zdGVhZCwgaW5kZXgsIHRydWUsIGNiKVxuXG4gICAgdmFyIGJlbG93ID0gZ3NwcmVmLmNvbmNhdChlbnRyaWVzW2ldLCByZW1haW4pXG4gICAgdGhpcy5fcHJvY2VzcyhiZWxvdywgaW5kZXgsIHRydWUsIGNiKVxuICB9XG5cbiAgY2IoKVxufVxuXG5HbG9iLnByb3RvdHlwZS5fcHJvY2Vzc1NpbXBsZSA9IGZ1bmN0aW9uIChwcmVmaXgsIGluZGV4LCBjYikge1xuICAvLyBYWFggcmV2aWV3IHRoaXMuICBTaG91bGRuJ3QgaXQgYmUgZG9pbmcgdGhlIG1vdW50aW5nIGV0Y1xuICAvLyBiZWZvcmUgZG9pbmcgc3RhdD8gIGtpbmRhIHdlaXJkP1xuICB2YXIgc2VsZiA9IHRoaXNcbiAgdGhpcy5fc3RhdChwcmVmaXgsIGZ1bmN0aW9uIChlciwgZXhpc3RzKSB7XG4gICAgc2VsZi5fcHJvY2Vzc1NpbXBsZTIocHJlZml4LCBpbmRleCwgZXIsIGV4aXN0cywgY2IpXG4gIH0pXG59XG5HbG9iLnByb3RvdHlwZS5fcHJvY2Vzc1NpbXBsZTIgPSBmdW5jdGlvbiAocHJlZml4LCBpbmRleCwgZXIsIGV4aXN0cywgY2IpIHtcblxuICAvL2NvbnNvbGUuZXJyb3IoJ3BzMicsIHByZWZpeCwgZXhpc3RzKVxuXG4gIGlmICghdGhpcy5tYXRjaGVzW2luZGV4XSlcbiAgICB0aGlzLm1hdGNoZXNbaW5kZXhdID0gT2JqZWN0LmNyZWF0ZShudWxsKVxuXG4gIC8vIElmIGl0IGRvZXNuJ3QgZXhpc3QsIHRoZW4ganVzdCBtYXJrIHRoZSBsYWNrIG9mIHJlc3VsdHNcbiAgaWYgKCFleGlzdHMpXG4gICAgcmV0dXJuIGNiKClcblxuICBpZiAocHJlZml4ICYmIGlzQWJzb2x1dGUocHJlZml4KSAmJiAhdGhpcy5ub21vdW50KSB7XG4gICAgdmFyIHRyYWlsID0gL1tcXC9cXFxcXSQvLnRlc3QocHJlZml4KVxuICAgIGlmIChwcmVmaXguY2hhckF0KDApID09PSAnLycpIHtcbiAgICAgIHByZWZpeCA9IHBhdGguam9pbih0aGlzLnJvb3QsIHByZWZpeClcbiAgICB9IGVsc2Uge1xuICAgICAgcHJlZml4ID0gcGF0aC5yZXNvbHZlKHRoaXMucm9vdCwgcHJlZml4KVxuICAgICAgaWYgKHRyYWlsKVxuICAgICAgICBwcmVmaXggKz0gJy8nXG4gICAgfVxuICB9XG5cbiAgaWYgKHByb2Nlc3MucGxhdGZvcm0gPT09ICd3aW4zMicpXG4gICAgcHJlZml4ID0gcHJlZml4LnJlcGxhY2UoL1xcXFwvZywgJy8nKVxuXG4gIC8vIE1hcmsgdGhpcyBhcyBhIG1hdGNoXG4gIHRoaXMuX2VtaXRNYXRjaChpbmRleCwgcHJlZml4KVxuICBjYigpXG59XG5cbi8vIFJldHVybnMgZWl0aGVyICdESVInLCAnRklMRScsIG9yIGZhbHNlXG5HbG9iLnByb3RvdHlwZS5fc3RhdCA9IGZ1bmN0aW9uIChmLCBjYikge1xuICB2YXIgYWJzID0gdGhpcy5fbWFrZUFicyhmKVxuICB2YXIgbmVlZERpciA9IGYuc2xpY2UoLTEpID09PSAnLydcblxuICBpZiAoZi5sZW5ndGggPiB0aGlzLm1heExlbmd0aClcbiAgICByZXR1cm4gY2IoKVxuXG4gIGlmICghdGhpcy5zdGF0ICYmIG93blByb3AodGhpcy5jYWNoZSwgYWJzKSkge1xuICAgIHZhciBjID0gdGhpcy5jYWNoZVthYnNdXG5cbiAgICBpZiAoQXJyYXkuaXNBcnJheShjKSlcbiAgICAgIGMgPSAnRElSJ1xuXG4gICAgLy8gSXQgZXhpc3RzLCBidXQgbWF5YmUgbm90IGhvdyB3ZSBuZWVkIGl0XG4gICAgaWYgKCFuZWVkRGlyIHx8IGMgPT09ICdESVInKVxuICAgICAgcmV0dXJuIGNiKG51bGwsIGMpXG5cbiAgICBpZiAobmVlZERpciAmJiBjID09PSAnRklMRScpXG4gICAgICByZXR1cm4gY2IoKVxuXG4gICAgLy8gb3RoZXJ3aXNlIHdlIGhhdmUgdG8gc3RhdCwgYmVjYXVzZSBtYXliZSBjPXRydWVcbiAgICAvLyBpZiB3ZSBrbm93IGl0IGV4aXN0cywgYnV0IG5vdCB3aGF0IGl0IGlzLlxuICB9XG5cbiAgdmFyIGV4aXN0c1xuICB2YXIgc3RhdCA9IHRoaXMuc3RhdENhY2hlW2Fic11cbiAgaWYgKHN0YXQgIT09IHVuZGVmaW5lZCkge1xuICAgIGlmIChzdGF0ID09PSBmYWxzZSlcbiAgICAgIHJldHVybiBjYihudWxsLCBzdGF0KVxuICAgIGVsc2Uge1xuICAgICAgdmFyIHR5cGUgPSBzdGF0LmlzRGlyZWN0b3J5KCkgPyAnRElSJyA6ICdGSUxFJ1xuICAgICAgaWYgKG5lZWREaXIgJiYgdHlwZSA9PT0gJ0ZJTEUnKVxuICAgICAgICByZXR1cm4gY2IoKVxuICAgICAgZWxzZVxuICAgICAgICByZXR1cm4gY2IobnVsbCwgdHlwZSwgc3RhdClcbiAgICB9XG4gIH1cblxuICB2YXIgc2VsZiA9IHRoaXNcbiAgdmFyIHN0YXRjYiA9IGluZmxpZ2h0KCdzdGF0XFwwJyArIGFicywgbHN0YXRjYl8pXG4gIGlmIChzdGF0Y2IpXG4gICAgZnMubHN0YXQoYWJzLCBzdGF0Y2IpXG5cbiAgZnVuY3Rpb24gbHN0YXRjYl8gKGVyLCBsc3RhdCkge1xuICAgIGlmIChsc3RhdCAmJiBsc3RhdC5pc1N5bWJvbGljTGluaygpKSB7XG4gICAgICAvLyBJZiBpdCdzIGEgc3ltbGluaywgdGhlbiB0cmVhdCBpdCBhcyB0aGUgdGFyZ2V0LCB1bmxlc3NcbiAgICAgIC8vIHRoZSB0YXJnZXQgZG9lcyBub3QgZXhpc3QsIHRoZW4gdHJlYXQgaXQgYXMgYSBmaWxlLlxuICAgICAgcmV0dXJuIGZzLnN0YXQoYWJzLCBmdW5jdGlvbiAoZXIsIHN0YXQpIHtcbiAgICAgICAgaWYgKGVyKVxuICAgICAgICAgIHNlbGYuX3N0YXQyKGYsIGFicywgbnVsbCwgbHN0YXQsIGNiKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgc2VsZi5fc3RhdDIoZiwgYWJzLCBlciwgc3RhdCwgY2IpXG4gICAgICB9KVxuICAgIH0gZWxzZSB7XG4gICAgICBzZWxmLl9zdGF0MihmLCBhYnMsIGVyLCBsc3RhdCwgY2IpXG4gICAgfVxuICB9XG59XG5cbkdsb2IucHJvdG90eXBlLl9zdGF0MiA9IGZ1bmN0aW9uIChmLCBhYnMsIGVyLCBzdGF0LCBjYikge1xuICBpZiAoZXIgJiYgKGVyLmNvZGUgPT09ICdFTk9FTlQnIHx8IGVyLmNvZGUgPT09ICdFTk9URElSJykpIHtcbiAgICB0aGlzLnN0YXRDYWNoZVthYnNdID0gZmFsc2VcbiAgICByZXR1cm4gY2IoKVxuICB9XG5cbiAgdmFyIG5lZWREaXIgPSBmLnNsaWNlKC0xKSA9PT0gJy8nXG4gIHRoaXMuc3RhdENhY2hlW2Fic10gPSBzdGF0XG5cbiAgaWYgKGFicy5zbGljZSgtMSkgPT09ICcvJyAmJiBzdGF0ICYmICFzdGF0LmlzRGlyZWN0b3J5KCkpXG4gICAgcmV0dXJuIGNiKG51bGwsIGZhbHNlLCBzdGF0KVxuXG4gIHZhciBjID0gdHJ1ZVxuICBpZiAoc3RhdClcbiAgICBjID0gc3RhdC5pc0RpcmVjdG9yeSgpID8gJ0RJUicgOiAnRklMRSdcbiAgdGhpcy5jYWNoZVthYnNdID0gdGhpcy5jYWNoZVthYnNdIHx8IGNcblxuICBpZiAobmVlZERpciAmJiBjID09PSAnRklMRScpXG4gICAgcmV0dXJuIGNiKClcblxuICByZXR1cm4gY2IobnVsbCwgYywgc3RhdClcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gZ2xvYlN5bmNcbmdsb2JTeW5jLkdsb2JTeW5jID0gR2xvYlN5bmNcblxudmFyIGZzID0gcmVxdWlyZSgnZnMnKVxudmFyIHJwID0gcmVxdWlyZSgnZnMucmVhbHBhdGgnKVxudmFyIG1pbmltYXRjaCA9IHJlcXVpcmUoJ21pbmltYXRjaCcpXG52YXIgTWluaW1hdGNoID0gbWluaW1hdGNoLk1pbmltYXRjaFxudmFyIEdsb2IgPSByZXF1aXJlKCcuL2dsb2IuanMnKS5HbG9iXG52YXIgdXRpbCA9IHJlcXVpcmUoJ3V0aWwnKVxudmFyIHBhdGggPSByZXF1aXJlKCdwYXRoJylcbnZhciBhc3NlcnQgPSByZXF1aXJlKCdhc3NlcnQnKVxudmFyIGlzQWJzb2x1dGUgPSByZXF1aXJlKCdwYXRoLWlzLWFic29sdXRlJylcbnZhciBjb21tb24gPSByZXF1aXJlKCcuL2NvbW1vbi5qcycpXG52YXIgYWxwaGFzb3J0ID0gY29tbW9uLmFscGhhc29ydFxudmFyIGFscGhhc29ydGkgPSBjb21tb24uYWxwaGFzb3J0aVxudmFyIHNldG9wdHMgPSBjb21tb24uc2V0b3B0c1xudmFyIG93blByb3AgPSBjb21tb24ub3duUHJvcFxudmFyIGNoaWxkcmVuSWdub3JlZCA9IGNvbW1vbi5jaGlsZHJlbklnbm9yZWRcbnZhciBpc0lnbm9yZWQgPSBjb21tb24uaXNJZ25vcmVkXG5cbmZ1bmN0aW9uIGdsb2JTeW5jIChwYXR0ZXJuLCBvcHRpb25zKSB7XG4gIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ2Z1bmN0aW9uJyB8fCBhcmd1bWVudHMubGVuZ3RoID09PSAzKVxuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2NhbGxiYWNrIHByb3ZpZGVkIHRvIHN5bmMgZ2xvYlxcbicrXG4gICAgICAgICAgICAgICAgICAgICAgICAnU2VlOiBodHRwczovL2dpdGh1Yi5jb20vaXNhYWNzL25vZGUtZ2xvYi9pc3N1ZXMvMTY3JylcblxuICByZXR1cm4gbmV3IEdsb2JTeW5jKHBhdHRlcm4sIG9wdGlvbnMpLmZvdW5kXG59XG5cbmZ1bmN0aW9uIEdsb2JTeW5jIChwYXR0ZXJuLCBvcHRpb25zKSB7XG4gIGlmICghcGF0dGVybilcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ211c3QgcHJvdmlkZSBwYXR0ZXJuJylcblxuICBpZiAodHlwZW9mIG9wdGlvbnMgPT09ICdmdW5jdGlvbicgfHwgYXJndW1lbnRzLmxlbmd0aCA9PT0gMylcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdjYWxsYmFjayBwcm92aWRlZCB0byBzeW5jIGdsb2JcXG4nK1xuICAgICAgICAgICAgICAgICAgICAgICAgJ1NlZTogaHR0cHM6Ly9naXRodWIuY29tL2lzYWFjcy9ub2RlLWdsb2IvaXNzdWVzLzE2NycpXG5cbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIEdsb2JTeW5jKSlcbiAgICByZXR1cm4gbmV3IEdsb2JTeW5jKHBhdHRlcm4sIG9wdGlvbnMpXG5cbiAgc2V0b3B0cyh0aGlzLCBwYXR0ZXJuLCBvcHRpb25zKVxuXG4gIGlmICh0aGlzLm5vcHJvY2VzcylcbiAgICByZXR1cm4gdGhpc1xuXG4gIHZhciBuID0gdGhpcy5taW5pbWF0Y2guc2V0Lmxlbmd0aFxuICB0aGlzLm1hdGNoZXMgPSBuZXcgQXJyYXkobilcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBuOyBpICsrKSB7XG4gICAgdGhpcy5fcHJvY2Vzcyh0aGlzLm1pbmltYXRjaC5zZXRbaV0sIGksIGZhbHNlKVxuICB9XG4gIHRoaXMuX2ZpbmlzaCgpXG59XG5cbkdsb2JTeW5jLnByb3RvdHlwZS5fZmluaXNoID0gZnVuY3Rpb24gKCkge1xuICBhc3NlcnQodGhpcyBpbnN0YW5jZW9mIEdsb2JTeW5jKVxuICBpZiAodGhpcy5yZWFscGF0aCkge1xuICAgIHZhciBzZWxmID0gdGhpc1xuICAgIHRoaXMubWF0Y2hlcy5mb3JFYWNoKGZ1bmN0aW9uIChtYXRjaHNldCwgaW5kZXgpIHtcbiAgICAgIHZhciBzZXQgPSBzZWxmLm1hdGNoZXNbaW5kZXhdID0gT2JqZWN0LmNyZWF0ZShudWxsKVxuICAgICAgZm9yICh2YXIgcCBpbiBtYXRjaHNldCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHAgPSBzZWxmLl9tYWtlQWJzKHApXG4gICAgICAgICAgdmFyIHJlYWwgPSBycC5yZWFscGF0aFN5bmMocCwgc2VsZi5yZWFscGF0aENhY2hlKVxuICAgICAgICAgIHNldFtyZWFsXSA9IHRydWVcbiAgICAgICAgfSBjYXRjaCAoZXIpIHtcbiAgICAgICAgICBpZiAoZXIuc3lzY2FsbCA9PT0gJ3N0YXQnKVxuICAgICAgICAgICAgc2V0W3NlbGYuX21ha2VBYnMocCldID0gdHJ1ZVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHRocm93IGVyXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuICB9XG4gIGNvbW1vbi5maW5pc2godGhpcylcbn1cblxuXG5HbG9iU3luYy5wcm90b3R5cGUuX3Byb2Nlc3MgPSBmdW5jdGlvbiAocGF0dGVybiwgaW5kZXgsIGluR2xvYlN0YXIpIHtcbiAgYXNzZXJ0KHRoaXMgaW5zdGFuY2VvZiBHbG9iU3luYylcblxuICAvLyBHZXQgdGhlIGZpcnN0IFtuXSBwYXJ0cyBvZiBwYXR0ZXJuIHRoYXQgYXJlIGFsbCBzdHJpbmdzLlxuICB2YXIgbiA9IDBcbiAgd2hpbGUgKHR5cGVvZiBwYXR0ZXJuW25dID09PSAnc3RyaW5nJykge1xuICAgIG4gKytcbiAgfVxuICAvLyBub3cgbiBpcyB0aGUgaW5kZXggb2YgdGhlIGZpcnN0IG9uZSB0aGF0IGlzICpub3QqIGEgc3RyaW5nLlxuXG4gIC8vIFNlZSBpZiB0aGVyZSdzIGFueXRoaW5nIGVsc2VcbiAgdmFyIHByZWZpeFxuICBzd2l0Y2ggKG4pIHtcbiAgICAvLyBpZiBub3QsIHRoZW4gdGhpcyBpcyByYXRoZXIgc2ltcGxlXG4gICAgY2FzZSBwYXR0ZXJuLmxlbmd0aDpcbiAgICAgIHRoaXMuX3Byb2Nlc3NTaW1wbGUocGF0dGVybi5qb2luKCcvJyksIGluZGV4KVxuICAgICAgcmV0dXJuXG5cbiAgICBjYXNlIDA6XG4gICAgICAvLyBwYXR0ZXJuICpzdGFydHMqIHdpdGggc29tZSBub24tdHJpdmlhbCBpdGVtLlxuICAgICAgLy8gZ29pbmcgdG8gcmVhZGRpcihjd2QpLCBidXQgbm90IGluY2x1ZGUgdGhlIHByZWZpeCBpbiBtYXRjaGVzLlxuICAgICAgcHJlZml4ID0gbnVsbFxuICAgICAgYnJlYWtcblxuICAgIGRlZmF1bHQ6XG4gICAgICAvLyBwYXR0ZXJuIGhhcyBzb21lIHN0cmluZyBiaXRzIGluIHRoZSBmcm9udC5cbiAgICAgIC8vIHdoYXRldmVyIGl0IHN0YXJ0cyB3aXRoLCB3aGV0aGVyIHRoYXQncyAnYWJzb2x1dGUnIGxpa2UgL2Zvby9iYXIsXG4gICAgICAvLyBvciAncmVsYXRpdmUnIGxpa2UgJy4uL2JheidcbiAgICAgIHByZWZpeCA9IHBhdHRlcm4uc2xpY2UoMCwgbikuam9pbignLycpXG4gICAgICBicmVha1xuICB9XG5cbiAgdmFyIHJlbWFpbiA9IHBhdHRlcm4uc2xpY2UobilcblxuICAvLyBnZXQgdGhlIGxpc3Qgb2YgZW50cmllcy5cbiAgdmFyIHJlYWRcbiAgaWYgKHByZWZpeCA9PT0gbnVsbClcbiAgICByZWFkID0gJy4nXG4gIGVsc2UgaWYgKGlzQWJzb2x1dGUocHJlZml4KSB8fCBpc0Fic29sdXRlKHBhdHRlcm4uam9pbignLycpKSkge1xuICAgIGlmICghcHJlZml4IHx8ICFpc0Fic29sdXRlKHByZWZpeCkpXG4gICAgICBwcmVmaXggPSAnLycgKyBwcmVmaXhcbiAgICByZWFkID0gcHJlZml4XG4gIH0gZWxzZVxuICAgIHJlYWQgPSBwcmVmaXhcblxuICB2YXIgYWJzID0gdGhpcy5fbWFrZUFicyhyZWFkKVxuXG4gIC8vaWYgaWdub3JlZCwgc2tpcCBwcm9jZXNzaW5nXG4gIGlmIChjaGlsZHJlbklnbm9yZWQodGhpcywgcmVhZCkpXG4gICAgcmV0dXJuXG5cbiAgdmFyIGlzR2xvYlN0YXIgPSByZW1haW5bMF0gPT09IG1pbmltYXRjaC5HTE9CU1RBUlxuICBpZiAoaXNHbG9iU3RhcilcbiAgICB0aGlzLl9wcm9jZXNzR2xvYlN0YXIocHJlZml4LCByZWFkLCBhYnMsIHJlbWFpbiwgaW5kZXgsIGluR2xvYlN0YXIpXG4gIGVsc2VcbiAgICB0aGlzLl9wcm9jZXNzUmVhZGRpcihwcmVmaXgsIHJlYWQsIGFicywgcmVtYWluLCBpbmRleCwgaW5HbG9iU3Rhcilcbn1cblxuXG5HbG9iU3luYy5wcm90b3R5cGUuX3Byb2Nlc3NSZWFkZGlyID0gZnVuY3Rpb24gKHByZWZpeCwgcmVhZCwgYWJzLCByZW1haW4sIGluZGV4LCBpbkdsb2JTdGFyKSB7XG4gIHZhciBlbnRyaWVzID0gdGhpcy5fcmVhZGRpcihhYnMsIGluR2xvYlN0YXIpXG5cbiAgLy8gaWYgdGhlIGFicyBpc24ndCBhIGRpciwgdGhlbiBub3RoaW5nIGNhbiBtYXRjaCFcbiAgaWYgKCFlbnRyaWVzKVxuICAgIHJldHVyblxuXG4gIC8vIEl0IHdpbGwgb25seSBtYXRjaCBkb3QgZW50cmllcyBpZiBpdCBzdGFydHMgd2l0aCBhIGRvdCwgb3IgaWZcbiAgLy8gZG90IGlzIHNldC4gIFN0dWZmIGxpa2UgQCguZm9vfC5iYXIpIGlzbid0IGFsbG93ZWQuXG4gIHZhciBwbiA9IHJlbWFpblswXVxuICB2YXIgbmVnYXRlID0gISF0aGlzLm1pbmltYXRjaC5uZWdhdGVcbiAgdmFyIHJhd0dsb2IgPSBwbi5fZ2xvYlxuICB2YXIgZG90T2sgPSB0aGlzLmRvdCB8fCByYXdHbG9iLmNoYXJBdCgwKSA9PT0gJy4nXG5cbiAgdmFyIG1hdGNoZWRFbnRyaWVzID0gW11cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBlbnRyaWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIGUgPSBlbnRyaWVzW2ldXG4gICAgaWYgKGUuY2hhckF0KDApICE9PSAnLicgfHwgZG90T2spIHtcbiAgICAgIHZhciBtXG4gICAgICBpZiAobmVnYXRlICYmICFwcmVmaXgpIHtcbiAgICAgICAgbSA9ICFlLm1hdGNoKHBuKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbSA9IGUubWF0Y2gocG4pXG4gICAgICB9XG4gICAgICBpZiAobSlcbiAgICAgICAgbWF0Y2hlZEVudHJpZXMucHVzaChlKVxuICAgIH1cbiAgfVxuXG4gIHZhciBsZW4gPSBtYXRjaGVkRW50cmllcy5sZW5ndGhcbiAgLy8gSWYgdGhlcmUgYXJlIG5vIG1hdGNoZWQgZW50cmllcywgdGhlbiBub3RoaW5nIG1hdGNoZXMuXG4gIGlmIChsZW4gPT09IDApXG4gICAgcmV0dXJuXG5cbiAgLy8gaWYgdGhpcyBpcyB0aGUgbGFzdCByZW1haW5pbmcgcGF0dGVybiBiaXQsIHRoZW4gbm8gbmVlZCBmb3JcbiAgLy8gYW4gYWRkaXRpb25hbCBzdGF0ICp1bmxlc3MqIHRoZSB1c2VyIGhhcyBzcGVjaWZpZWQgbWFyayBvclxuICAvLyBzdGF0IGV4cGxpY2l0bHkuICBXZSBrbm93IHRoZXkgZXhpc3QsIHNpbmNlIHJlYWRkaXIgcmV0dXJuZWRcbiAgLy8gdGhlbS5cblxuICBpZiAocmVtYWluLmxlbmd0aCA9PT0gMSAmJiAhdGhpcy5tYXJrICYmICF0aGlzLnN0YXQpIHtcbiAgICBpZiAoIXRoaXMubWF0Y2hlc1tpbmRleF0pXG4gICAgICB0aGlzLm1hdGNoZXNbaW5kZXhdID0gT2JqZWN0LmNyZWF0ZShudWxsKVxuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkgKyspIHtcbiAgICAgIHZhciBlID0gbWF0Y2hlZEVudHJpZXNbaV1cbiAgICAgIGlmIChwcmVmaXgpIHtcbiAgICAgICAgaWYgKHByZWZpeC5zbGljZSgtMSkgIT09ICcvJylcbiAgICAgICAgICBlID0gcHJlZml4ICsgJy8nICsgZVxuICAgICAgICBlbHNlXG4gICAgICAgICAgZSA9IHByZWZpeCArIGVcbiAgICAgIH1cblxuICAgICAgaWYgKGUuY2hhckF0KDApID09PSAnLycgJiYgIXRoaXMubm9tb3VudCkge1xuICAgICAgICBlID0gcGF0aC5qb2luKHRoaXMucm9vdCwgZSlcbiAgICAgIH1cbiAgICAgIHRoaXMuX2VtaXRNYXRjaChpbmRleCwgZSlcbiAgICB9XG4gICAgLy8gVGhpcyB3YXMgdGhlIGxhc3Qgb25lLCBhbmQgbm8gc3RhdHMgd2VyZSBuZWVkZWRcbiAgICByZXR1cm5cbiAgfVxuXG4gIC8vIG5vdyB0ZXN0IGFsbCBtYXRjaGVkIGVudHJpZXMgYXMgc3RhbmQtaW5zIGZvciB0aGF0IHBhcnRcbiAgLy8gb2YgdGhlIHBhdHRlcm4uXG4gIHJlbWFpbi5zaGlmdCgpXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpICsrKSB7XG4gICAgdmFyIGUgPSBtYXRjaGVkRW50cmllc1tpXVxuICAgIHZhciBuZXdQYXR0ZXJuXG4gICAgaWYgKHByZWZpeClcbiAgICAgIG5ld1BhdHRlcm4gPSBbcHJlZml4LCBlXVxuICAgIGVsc2VcbiAgICAgIG5ld1BhdHRlcm4gPSBbZV1cbiAgICB0aGlzLl9wcm9jZXNzKG5ld1BhdHRlcm4uY29uY2F0KHJlbWFpbiksIGluZGV4LCBpbkdsb2JTdGFyKVxuICB9XG59XG5cblxuR2xvYlN5bmMucHJvdG90eXBlLl9lbWl0TWF0Y2ggPSBmdW5jdGlvbiAoaW5kZXgsIGUpIHtcbiAgaWYgKGlzSWdub3JlZCh0aGlzLCBlKSlcbiAgICByZXR1cm5cblxuICB2YXIgYWJzID0gdGhpcy5fbWFrZUFicyhlKVxuXG4gIGlmICh0aGlzLm1hcmspXG4gICAgZSA9IHRoaXMuX21hcmsoZSlcblxuICBpZiAodGhpcy5hYnNvbHV0ZSkge1xuICAgIGUgPSBhYnNcbiAgfVxuXG4gIGlmICh0aGlzLm1hdGNoZXNbaW5kZXhdW2VdKVxuICAgIHJldHVyblxuXG4gIGlmICh0aGlzLm5vZGlyKSB7XG4gICAgdmFyIGMgPSB0aGlzLmNhY2hlW2Fic11cbiAgICBpZiAoYyA9PT0gJ0RJUicgfHwgQXJyYXkuaXNBcnJheShjKSlcbiAgICAgIHJldHVyblxuICB9XG5cbiAgdGhpcy5tYXRjaGVzW2luZGV4XVtlXSA9IHRydWVcblxuICBpZiAodGhpcy5zdGF0KVxuICAgIHRoaXMuX3N0YXQoZSlcbn1cblxuXG5HbG9iU3luYy5wcm90b3R5cGUuX3JlYWRkaXJJbkdsb2JTdGFyID0gZnVuY3Rpb24gKGFicykge1xuICAvLyBmb2xsb3cgYWxsIHN5bWxpbmtlZCBkaXJlY3RvcmllcyBmb3JldmVyXG4gIC8vIGp1c3QgcHJvY2VlZCBhcyBpZiB0aGlzIGlzIGEgbm9uLWdsb2JzdGFyIHNpdHVhdGlvblxuICBpZiAodGhpcy5mb2xsb3cpXG4gICAgcmV0dXJuIHRoaXMuX3JlYWRkaXIoYWJzLCBmYWxzZSlcblxuICB2YXIgZW50cmllc1xuICB2YXIgbHN0YXRcbiAgdmFyIHN0YXRcbiAgdHJ5IHtcbiAgICBsc3RhdCA9IGZzLmxzdGF0U3luYyhhYnMpXG4gIH0gY2F0Y2ggKGVyKSB7XG4gICAgaWYgKGVyLmNvZGUgPT09ICdFTk9FTlQnKSB7XG4gICAgICAvLyBsc3RhdCBmYWlsZWQsIGRvZXNuJ3QgZXhpc3RcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuICB9XG5cbiAgdmFyIGlzU3ltID0gbHN0YXQgJiYgbHN0YXQuaXNTeW1ib2xpY0xpbmsoKVxuICB0aGlzLnN5bWxpbmtzW2Fic10gPSBpc1N5bVxuXG4gIC8vIElmIGl0J3Mgbm90IGEgc3ltbGluayBvciBhIGRpciwgdGhlbiBpdCdzIGRlZmluaXRlbHkgYSByZWd1bGFyIGZpbGUuXG4gIC8vIGRvbid0IGJvdGhlciBkb2luZyBhIHJlYWRkaXIgaW4gdGhhdCBjYXNlLlxuICBpZiAoIWlzU3ltICYmIGxzdGF0ICYmICFsc3RhdC5pc0RpcmVjdG9yeSgpKVxuICAgIHRoaXMuY2FjaGVbYWJzXSA9ICdGSUxFJ1xuICBlbHNlXG4gICAgZW50cmllcyA9IHRoaXMuX3JlYWRkaXIoYWJzLCBmYWxzZSlcblxuICByZXR1cm4gZW50cmllc1xufVxuXG5HbG9iU3luYy5wcm90b3R5cGUuX3JlYWRkaXIgPSBmdW5jdGlvbiAoYWJzLCBpbkdsb2JTdGFyKSB7XG4gIHZhciBlbnRyaWVzXG5cbiAgaWYgKGluR2xvYlN0YXIgJiYgIW93blByb3AodGhpcy5zeW1saW5rcywgYWJzKSlcbiAgICByZXR1cm4gdGhpcy5fcmVhZGRpckluR2xvYlN0YXIoYWJzKVxuXG4gIGlmIChvd25Qcm9wKHRoaXMuY2FjaGUsIGFicykpIHtcbiAgICB2YXIgYyA9IHRoaXMuY2FjaGVbYWJzXVxuICAgIGlmICghYyB8fCBjID09PSAnRklMRScpXG4gICAgICByZXR1cm4gbnVsbFxuXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoYykpXG4gICAgICByZXR1cm4gY1xuICB9XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gdGhpcy5fcmVhZGRpckVudHJpZXMoYWJzLCBmcy5yZWFkZGlyU3luYyhhYnMpKVxuICB9IGNhdGNoIChlcikge1xuICAgIHRoaXMuX3JlYWRkaXJFcnJvcihhYnMsIGVyKVxuICAgIHJldHVybiBudWxsXG4gIH1cbn1cblxuR2xvYlN5bmMucHJvdG90eXBlLl9yZWFkZGlyRW50cmllcyA9IGZ1bmN0aW9uIChhYnMsIGVudHJpZXMpIHtcbiAgLy8gaWYgd2UgaGF2ZW4ndCBhc2tlZCB0byBzdGF0IGV2ZXJ5dGhpbmcsIHRoZW4ganVzdFxuICAvLyBhc3N1bWUgdGhhdCBldmVyeXRoaW5nIGluIHRoZXJlIGV4aXN0cywgc28gd2UgY2FuIGF2b2lkXG4gIC8vIGhhdmluZyB0byBzdGF0IGl0IGEgc2Vjb25kIHRpbWUuXG4gIGlmICghdGhpcy5tYXJrICYmICF0aGlzLnN0YXQpIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGVudHJpZXMubGVuZ3RoOyBpICsrKSB7XG4gICAgICB2YXIgZSA9IGVudHJpZXNbaV1cbiAgICAgIGlmIChhYnMgPT09ICcvJylcbiAgICAgICAgZSA9IGFicyArIGVcbiAgICAgIGVsc2VcbiAgICAgICAgZSA9IGFicyArICcvJyArIGVcbiAgICAgIHRoaXMuY2FjaGVbZV0gPSB0cnVlXG4gICAgfVxuICB9XG5cbiAgdGhpcy5jYWNoZVthYnNdID0gZW50cmllc1xuXG4gIC8vIG1hcmsgYW5kIGNhY2hlIGRpci1uZXNzXG4gIHJldHVybiBlbnRyaWVzXG59XG5cbkdsb2JTeW5jLnByb3RvdHlwZS5fcmVhZGRpckVycm9yID0gZnVuY3Rpb24gKGYsIGVyKSB7XG4gIC8vIGhhbmRsZSBlcnJvcnMsIGFuZCBjYWNoZSB0aGUgaW5mb3JtYXRpb25cbiAgc3dpdGNoIChlci5jb2RlKSB7XG4gICAgY2FzZSAnRU5PVFNVUCc6IC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9pc2FhY3Mvbm9kZS1nbG9iL2lzc3Vlcy8yMDVcbiAgICBjYXNlICdFTk9URElSJzogLy8gdG90YWxseSBub3JtYWwuIG1lYW5zIGl0ICpkb2VzKiBleGlzdC5cbiAgICAgIHZhciBhYnMgPSB0aGlzLl9tYWtlQWJzKGYpXG4gICAgICB0aGlzLmNhY2hlW2Fic10gPSAnRklMRSdcbiAgICAgIGlmIChhYnMgPT09IHRoaXMuY3dkQWJzKSB7XG4gICAgICAgIHZhciBlcnJvciA9IG5ldyBFcnJvcihlci5jb2RlICsgJyBpbnZhbGlkIGN3ZCAnICsgdGhpcy5jd2QpXG4gICAgICAgIGVycm9yLnBhdGggPSB0aGlzLmN3ZFxuICAgICAgICBlcnJvci5jb2RlID0gZXIuY29kZVxuICAgICAgICB0aHJvdyBlcnJvclxuICAgICAgfVxuICAgICAgYnJlYWtcblxuICAgIGNhc2UgJ0VOT0VOVCc6IC8vIG5vdCB0ZXJyaWJseSB1bnVzdWFsXG4gICAgY2FzZSAnRUxPT1AnOlxuICAgIGNhc2UgJ0VOQU1FVE9PTE9ORyc6XG4gICAgY2FzZSAnVU5LTk9XTic6XG4gICAgICB0aGlzLmNhY2hlW3RoaXMuX21ha2VBYnMoZildID0gZmFsc2VcbiAgICAgIGJyZWFrXG5cbiAgICBkZWZhdWx0OiAvLyBzb21lIHVudXN1YWwgZXJyb3IuICBUcmVhdCBhcyBmYWlsdXJlLlxuICAgICAgdGhpcy5jYWNoZVt0aGlzLl9tYWtlQWJzKGYpXSA9IGZhbHNlXG4gICAgICBpZiAodGhpcy5zdHJpY3QpXG4gICAgICAgIHRocm93IGVyXG4gICAgICBpZiAoIXRoaXMuc2lsZW50KVxuICAgICAgICBjb25zb2xlLmVycm9yKCdnbG9iIGVycm9yJywgZXIpXG4gICAgICBicmVha1xuICB9XG59XG5cbkdsb2JTeW5jLnByb3RvdHlwZS5fcHJvY2Vzc0dsb2JTdGFyID0gZnVuY3Rpb24gKHByZWZpeCwgcmVhZCwgYWJzLCByZW1haW4sIGluZGV4LCBpbkdsb2JTdGFyKSB7XG5cbiAgdmFyIGVudHJpZXMgPSB0aGlzLl9yZWFkZGlyKGFicywgaW5HbG9iU3RhcilcblxuICAvLyBubyBlbnRyaWVzIG1lYW5zIG5vdCBhIGRpciwgc28gaXQgY2FuIG5ldmVyIGhhdmUgbWF0Y2hlc1xuICAvLyBmb28udHh0LyoqIGRvZXNuJ3QgbWF0Y2ggZm9vLnR4dFxuICBpZiAoIWVudHJpZXMpXG4gICAgcmV0dXJuXG5cbiAgLy8gdGVzdCB3aXRob3V0IHRoZSBnbG9ic3RhciwgYW5kIHdpdGggZXZlcnkgY2hpbGQgYm90aCBiZWxvd1xuICAvLyBhbmQgcmVwbGFjaW5nIHRoZSBnbG9ic3Rhci5cbiAgdmFyIHJlbWFpbldpdGhvdXRHbG9iU3RhciA9IHJlbWFpbi5zbGljZSgxKVxuICB2YXIgZ3NwcmVmID0gcHJlZml4ID8gWyBwcmVmaXggXSA6IFtdXG4gIHZhciBub0dsb2JTdGFyID0gZ3NwcmVmLmNvbmNhdChyZW1haW5XaXRob3V0R2xvYlN0YXIpXG5cbiAgLy8gdGhlIG5vR2xvYlN0YXIgcGF0dGVybiBleGl0cyB0aGUgaW5HbG9iU3RhciBzdGF0ZVxuICB0aGlzLl9wcm9jZXNzKG5vR2xvYlN0YXIsIGluZGV4LCBmYWxzZSlcblxuICB2YXIgbGVuID0gZW50cmllcy5sZW5ndGhcbiAgdmFyIGlzU3ltID0gdGhpcy5zeW1saW5rc1thYnNdXG5cbiAgLy8gSWYgaXQncyBhIHN5bWxpbmssIGFuZCB3ZSdyZSBpbiBhIGdsb2JzdGFyLCB0aGVuIHN0b3BcbiAgaWYgKGlzU3ltICYmIGluR2xvYlN0YXIpXG4gICAgcmV0dXJuXG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIHZhciBlID0gZW50cmllc1tpXVxuICAgIGlmIChlLmNoYXJBdCgwKSA9PT0gJy4nICYmICF0aGlzLmRvdClcbiAgICAgIGNvbnRpbnVlXG5cbiAgICAvLyB0aGVzZSB0d28gY2FzZXMgZW50ZXIgdGhlIGluR2xvYlN0YXIgc3RhdGVcbiAgICB2YXIgaW5zdGVhZCA9IGdzcHJlZi5jb25jYXQoZW50cmllc1tpXSwgcmVtYWluV2l0aG91dEdsb2JTdGFyKVxuICAgIHRoaXMuX3Byb2Nlc3MoaW5zdGVhZCwgaW5kZXgsIHRydWUpXG5cbiAgICB2YXIgYmVsb3cgPSBnc3ByZWYuY29uY2F0KGVudHJpZXNbaV0sIHJlbWFpbilcbiAgICB0aGlzLl9wcm9jZXNzKGJlbG93LCBpbmRleCwgdHJ1ZSlcbiAgfVxufVxuXG5HbG9iU3luYy5wcm90b3R5cGUuX3Byb2Nlc3NTaW1wbGUgPSBmdW5jdGlvbiAocHJlZml4LCBpbmRleCkge1xuICAvLyBYWFggcmV2aWV3IHRoaXMuICBTaG91bGRuJ3QgaXQgYmUgZG9pbmcgdGhlIG1vdW50aW5nIGV0Y1xuICAvLyBiZWZvcmUgZG9pbmcgc3RhdD8gIGtpbmRhIHdlaXJkP1xuICB2YXIgZXhpc3RzID0gdGhpcy5fc3RhdChwcmVmaXgpXG5cbiAgaWYgKCF0aGlzLm1hdGNoZXNbaW5kZXhdKVxuICAgIHRoaXMubWF0Y2hlc1tpbmRleF0gPSBPYmplY3QuY3JlYXRlKG51bGwpXG5cbiAgLy8gSWYgaXQgZG9lc24ndCBleGlzdCwgdGhlbiBqdXN0IG1hcmsgdGhlIGxhY2sgb2YgcmVzdWx0c1xuICBpZiAoIWV4aXN0cylcbiAgICByZXR1cm5cblxuICBpZiAocHJlZml4ICYmIGlzQWJzb2x1dGUocHJlZml4KSAmJiAhdGhpcy5ub21vdW50KSB7XG4gICAgdmFyIHRyYWlsID0gL1tcXC9cXFxcXSQvLnRlc3QocHJlZml4KVxuICAgIGlmIChwcmVmaXguY2hhckF0KDApID09PSAnLycpIHtcbiAgICAgIHByZWZpeCA9IHBhdGguam9pbih0aGlzLnJvb3QsIHByZWZpeClcbiAgICB9IGVsc2Uge1xuICAgICAgcHJlZml4ID0gcGF0aC5yZXNvbHZlKHRoaXMucm9vdCwgcHJlZml4KVxuICAgICAgaWYgKHRyYWlsKVxuICAgICAgICBwcmVmaXggKz0gJy8nXG4gICAgfVxuICB9XG5cbiAgaWYgKHByb2Nlc3MucGxhdGZvcm0gPT09ICd3aW4zMicpXG4gICAgcHJlZml4ID0gcHJlZml4LnJlcGxhY2UoL1xcXFwvZywgJy8nKVxuXG4gIC8vIE1hcmsgdGhpcyBhcyBhIG1hdGNoXG4gIHRoaXMuX2VtaXRNYXRjaChpbmRleCwgcHJlZml4KVxufVxuXG4vLyBSZXR1cm5zIGVpdGhlciAnRElSJywgJ0ZJTEUnLCBvciBmYWxzZVxuR2xvYlN5bmMucHJvdG90eXBlLl9zdGF0ID0gZnVuY3Rpb24gKGYpIHtcbiAgdmFyIGFicyA9IHRoaXMuX21ha2VBYnMoZilcbiAgdmFyIG5lZWREaXIgPSBmLnNsaWNlKC0xKSA9PT0gJy8nXG5cbiAgaWYgKGYubGVuZ3RoID4gdGhpcy5tYXhMZW5ndGgpXG4gICAgcmV0dXJuIGZhbHNlXG5cbiAgaWYgKCF0aGlzLnN0YXQgJiYgb3duUHJvcCh0aGlzLmNhY2hlLCBhYnMpKSB7XG4gICAgdmFyIGMgPSB0aGlzLmNhY2hlW2Fic11cblxuICAgIGlmIChBcnJheS5pc0FycmF5KGMpKVxuICAgICAgYyA9ICdESVInXG5cbiAgICAvLyBJdCBleGlzdHMsIGJ1dCBtYXliZSBub3QgaG93IHdlIG5lZWQgaXRcbiAgICBpZiAoIW5lZWREaXIgfHwgYyA9PT0gJ0RJUicpXG4gICAgICByZXR1cm4gY1xuXG4gICAgaWYgKG5lZWREaXIgJiYgYyA9PT0gJ0ZJTEUnKVxuICAgICAgcmV0dXJuIGZhbHNlXG5cbiAgICAvLyBvdGhlcndpc2Ugd2UgaGF2ZSB0byBzdGF0LCBiZWNhdXNlIG1heWJlIGM9dHJ1ZVxuICAgIC8vIGlmIHdlIGtub3cgaXQgZXhpc3RzLCBidXQgbm90IHdoYXQgaXQgaXMuXG4gIH1cblxuICB2YXIgZXhpc3RzXG4gIHZhciBzdGF0ID0gdGhpcy5zdGF0Q2FjaGVbYWJzXVxuICBpZiAoIXN0YXQpIHtcbiAgICB2YXIgbHN0YXRcbiAgICB0cnkge1xuICAgICAgbHN0YXQgPSBmcy5sc3RhdFN5bmMoYWJzKVxuICAgIH0gY2F0Y2ggKGVyKSB7XG4gICAgICBpZiAoZXIgJiYgKGVyLmNvZGUgPT09ICdFTk9FTlQnIHx8IGVyLmNvZGUgPT09ICdFTk9URElSJykpIHtcbiAgICAgICAgdGhpcy5zdGF0Q2FjaGVbYWJzXSA9IGZhbHNlXG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChsc3RhdCAmJiBsc3RhdC5pc1N5bWJvbGljTGluaygpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBzdGF0ID0gZnMuc3RhdFN5bmMoYWJzKVxuICAgICAgfSBjYXRjaCAoZXIpIHtcbiAgICAgICAgc3RhdCA9IGxzdGF0XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXQgPSBsc3RhdFxuICAgIH1cbiAgfVxuXG4gIHRoaXMuc3RhdENhY2hlW2Fic10gPSBzdGF0XG5cbiAgdmFyIGMgPSB0cnVlXG4gIGlmIChzdGF0KVxuICAgIGMgPSBzdGF0LmlzRGlyZWN0b3J5KCkgPyAnRElSJyA6ICdGSUxFJ1xuXG4gIHRoaXMuY2FjaGVbYWJzXSA9IHRoaXMuY2FjaGVbYWJzXSB8fCBjXG5cbiAgaWYgKG5lZWREaXIgJiYgYyA9PT0gJ0ZJTEUnKVxuICAgIHJldHVybiBmYWxzZVxuXG4gIHJldHVybiBjXG59XG5cbkdsb2JTeW5jLnByb3RvdHlwZS5fbWFyayA9IGZ1bmN0aW9uIChwKSB7XG4gIHJldHVybiBjb21tb24ubWFyayh0aGlzLCBwKVxufVxuXG5HbG9iU3luYy5wcm90b3R5cGUuX21ha2VBYnMgPSBmdW5jdGlvbiAoZikge1xuICByZXR1cm4gY29tbW9uLm1ha2VBYnModGhpcywgZilcbn1cbiIsInZhciB3cmFwcHkgPSByZXF1aXJlKCd3cmFwcHknKVxudmFyIHJlcXMgPSBPYmplY3QuY3JlYXRlKG51bGwpXG52YXIgb25jZSA9IHJlcXVpcmUoJ29uY2UnKVxuXG5tb2R1bGUuZXhwb3J0cyA9IHdyYXBweShpbmZsaWdodClcblxuZnVuY3Rpb24gaW5mbGlnaHQgKGtleSwgY2IpIHtcbiAgaWYgKHJlcXNba2V5XSkge1xuICAgIHJlcXNba2V5XS5wdXNoKGNiKVxuICAgIHJldHVybiBudWxsXG4gIH0gZWxzZSB7XG4gICAgcmVxc1trZXldID0gW2NiXVxuICAgIHJldHVybiBtYWtlcmVzKGtleSlcbiAgfVxufVxuXG5mdW5jdGlvbiBtYWtlcmVzIChrZXkpIHtcbiAgcmV0dXJuIG9uY2UoZnVuY3Rpb24gUkVTICgpIHtcbiAgICB2YXIgY2JzID0gcmVxc1trZXldXG4gICAgdmFyIGxlbiA9IGNicy5sZW5ndGhcbiAgICB2YXIgYXJncyA9IHNsaWNlKGFyZ3VtZW50cylcblxuICAgIC8vIFhYWCBJdCdzIHNvbWV3aGF0IGFtYmlndW91cyB3aGV0aGVyIGEgbmV3IGNhbGxiYWNrIGFkZGVkIGluIHRoaXNcbiAgICAvLyBwYXNzIHNob3VsZCBiZSBxdWV1ZWQgZm9yIGxhdGVyIGV4ZWN1dGlvbiBpZiBzb21ldGhpbmcgaW4gdGhlXG4gICAgLy8gbGlzdCBvZiBjYWxsYmFja3MgdGhyb3dzLCBvciBpZiBpdCBzaG91bGQganVzdCBiZSBkaXNjYXJkZWQuXG4gICAgLy8gSG93ZXZlciwgaXQncyBzdWNoIGFuIGVkZ2UgY2FzZSB0aGF0IGl0IGhhcmRseSBtYXR0ZXJzLCBhbmQgZWl0aGVyXG4gICAgLy8gY2hvaWNlIGlzIGxpa2VseSBhcyBzdXJwcmlzaW5nIGFzIHRoZSBvdGhlci5cbiAgICAvLyBBcyBpdCBoYXBwZW5zLCB3ZSBkbyBnbyBhaGVhZCBhbmQgc2NoZWR1bGUgaXQgZm9yIGxhdGVyIGV4ZWN1dGlvbi5cbiAgICB0cnkge1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBjYnNbaV0uYXBwbHkobnVsbCwgYXJncylcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKGNicy5sZW5ndGggPiBsZW4pIHtcbiAgICAgICAgLy8gYWRkZWQgbW9yZSBpbiB0aGUgaW50ZXJpbS5cbiAgICAgICAgLy8gZGUtemFsZ28sIGp1c3QgaW4gY2FzZSwgYnV0IGRvbid0IGNhbGwgYWdhaW4uXG4gICAgICAgIGNicy5zcGxpY2UoMCwgbGVuKVxuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBSRVMuYXBwbHkobnVsbCwgYXJncylcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRlbGV0ZSByZXFzW2tleV1cbiAgICAgIH1cbiAgICB9XG4gIH0pXG59XG5cbmZ1bmN0aW9uIHNsaWNlIChhcmdzKSB7XG4gIHZhciBsZW5ndGggPSBhcmdzLmxlbmd0aFxuICB2YXIgYXJyYXkgPSBbXVxuXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIGFycmF5W2ldID0gYXJnc1tpXVxuICByZXR1cm4gYXJyYXlcbn1cbiIsInRyeSB7XG4gIHZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpO1xuICBpZiAodHlwZW9mIHV0aWwuaW5oZXJpdHMgIT09ICdmdW5jdGlvbicpIHRocm93ICcnO1xuICBtb2R1bGUuZXhwb3J0cyA9IHV0aWwuaW5oZXJpdHM7XG59IGNhdGNoIChlKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9pbmhlcml0c19icm93c2VyLmpzJyk7XG59XG4iLCJpZiAodHlwZW9mIE9iamVjdC5jcmVhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgLy8gaW1wbGVtZW50YXRpb24gZnJvbSBzdGFuZGFyZCBub2RlLmpzICd1dGlsJyBtb2R1bGVcbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpbmhlcml0cyhjdG9yLCBzdXBlckN0b3IpIHtcbiAgICBjdG9yLnN1cGVyXyA9IHN1cGVyQ3RvclxuICAgIGN0b3IucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShzdXBlckN0b3IucHJvdG90eXBlLCB7XG4gICAgICBjb25zdHJ1Y3Rvcjoge1xuICAgICAgICB2YWx1ZTogY3RvcixcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcbn0gZWxzZSB7XG4gIC8vIG9sZCBzY2hvb2wgc2hpbSBmb3Igb2xkIGJyb3dzZXJzXG4gIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaW5oZXJpdHMoY3Rvciwgc3VwZXJDdG9yKSB7XG4gICAgY3Rvci5zdXBlcl8gPSBzdXBlckN0b3JcbiAgICB2YXIgVGVtcEN0b3IgPSBmdW5jdGlvbiAoKSB7fVxuICAgIFRlbXBDdG9yLnByb3RvdHlwZSA9IHN1cGVyQ3Rvci5wcm90b3R5cGVcbiAgICBjdG9yLnByb3RvdHlwZSA9IG5ldyBUZW1wQ3RvcigpXG4gICAgY3Rvci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBjdG9yXG4gIH1cbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gbWluaW1hdGNoXG5taW5pbWF0Y2guTWluaW1hdGNoID0gTWluaW1hdGNoXG5cbnZhciBwYXRoID0geyBzZXA6ICcvJyB9XG50cnkge1xuICBwYXRoID0gcmVxdWlyZSgncGF0aCcpXG59IGNhdGNoIChlcikge31cblxudmFyIEdMT0JTVEFSID0gbWluaW1hdGNoLkdMT0JTVEFSID0gTWluaW1hdGNoLkdMT0JTVEFSID0ge31cbnZhciBleHBhbmQgPSByZXF1aXJlKCdicmFjZS1leHBhbnNpb24nKVxuXG52YXIgcGxUeXBlcyA9IHtcbiAgJyEnOiB7IG9wZW46ICcoPzooPyEoPzonLCBjbG9zZTogJykpW14vXSo/KSd9LFxuICAnPyc6IHsgb3BlbjogJyg/OicsIGNsb3NlOiAnKT8nIH0sXG4gICcrJzogeyBvcGVuOiAnKD86JywgY2xvc2U6ICcpKycgfSxcbiAgJyonOiB7IG9wZW46ICcoPzonLCBjbG9zZTogJykqJyB9LFxuICAnQCc6IHsgb3BlbjogJyg/OicsIGNsb3NlOiAnKScgfVxufVxuXG4vLyBhbnkgc2luZ2xlIHRoaW5nIG90aGVyIHRoYW4gL1xuLy8gZG9uJ3QgbmVlZCB0byBlc2NhcGUgLyB3aGVuIHVzaW5nIG5ldyBSZWdFeHAoKVxudmFyIHFtYXJrID0gJ1teL10nXG5cbi8vICogPT4gYW55IG51bWJlciBvZiBjaGFyYWN0ZXJzXG52YXIgc3RhciA9IHFtYXJrICsgJyo/J1xuXG4vLyAqKiB3aGVuIGRvdHMgYXJlIGFsbG93ZWQuICBBbnl0aGluZyBnb2VzLCBleGNlcHQgLi4gYW5kIC5cbi8vIG5vdCAoXiBvciAvIGZvbGxvd2VkIGJ5IG9uZSBvciB0d28gZG90cyBmb2xsb3dlZCBieSAkIG9yIC8pLFxuLy8gZm9sbG93ZWQgYnkgYW55dGhpbmcsIGFueSBudW1iZXIgb2YgdGltZXMuXG52YXIgdHdvU3RhckRvdCA9ICcoPzooPyEoPzpcXFxcXFwvfF4pKD86XFxcXC57MSwyfSkoJHxcXFxcXFwvKSkuKSo/J1xuXG4vLyBub3QgYSBeIG9yIC8gZm9sbG93ZWQgYnkgYSBkb3QsXG4vLyBmb2xsb3dlZCBieSBhbnl0aGluZywgYW55IG51bWJlciBvZiB0aW1lcy5cbnZhciB0d29TdGFyTm9Eb3QgPSAnKD86KD8hKD86XFxcXFxcL3xeKVxcXFwuKS4pKj8nXG5cbi8vIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVzY2FwZWQgaW4gUmVnRXhwLlxudmFyIHJlU3BlY2lhbHMgPSBjaGFyU2V0KCcoKS4qe30rP1tdXiRcXFxcIScpXG5cbi8vIFwiYWJjXCIgLT4geyBhOnRydWUsIGI6dHJ1ZSwgYzp0cnVlIH1cbmZ1bmN0aW9uIGNoYXJTZXQgKHMpIHtcbiAgcmV0dXJuIHMuc3BsaXQoJycpLnJlZHVjZShmdW5jdGlvbiAoc2V0LCBjKSB7XG4gICAgc2V0W2NdID0gdHJ1ZVxuICAgIHJldHVybiBzZXRcbiAgfSwge30pXG59XG5cbi8vIG5vcm1hbGl6ZXMgc2xhc2hlcy5cbnZhciBzbGFzaFNwbGl0ID0gL1xcLysvXG5cbm1pbmltYXRjaC5maWx0ZXIgPSBmaWx0ZXJcbmZ1bmN0aW9uIGZpbHRlciAocGF0dGVybiwgb3B0aW9ucykge1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fVxuICByZXR1cm4gZnVuY3Rpb24gKHAsIGksIGxpc3QpIHtcbiAgICByZXR1cm4gbWluaW1hdGNoKHAsIHBhdHRlcm4sIG9wdGlvbnMpXG4gIH1cbn1cblxuZnVuY3Rpb24gZXh0IChhLCBiKSB7XG4gIGEgPSBhIHx8IHt9XG4gIGIgPSBiIHx8IHt9XG4gIHZhciB0ID0ge31cbiAgT2JqZWN0LmtleXMoYikuZm9yRWFjaChmdW5jdGlvbiAoaykge1xuICAgIHRba10gPSBiW2tdXG4gIH0pXG4gIE9iamVjdC5rZXlzKGEpLmZvckVhY2goZnVuY3Rpb24gKGspIHtcbiAgICB0W2tdID0gYVtrXVxuICB9KVxuICByZXR1cm4gdFxufVxuXG5taW5pbWF0Y2guZGVmYXVsdHMgPSBmdW5jdGlvbiAoZGVmKSB7XG4gIGlmICghZGVmIHx8ICFPYmplY3Qua2V5cyhkZWYpLmxlbmd0aCkgcmV0dXJuIG1pbmltYXRjaFxuXG4gIHZhciBvcmlnID0gbWluaW1hdGNoXG5cbiAgdmFyIG0gPSBmdW5jdGlvbiBtaW5pbWF0Y2ggKHAsIHBhdHRlcm4sIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gb3JpZy5taW5pbWF0Y2gocCwgcGF0dGVybiwgZXh0KGRlZiwgb3B0aW9ucykpXG4gIH1cblxuICBtLk1pbmltYXRjaCA9IGZ1bmN0aW9uIE1pbmltYXRjaCAocGF0dGVybiwgb3B0aW9ucykge1xuICAgIHJldHVybiBuZXcgb3JpZy5NaW5pbWF0Y2gocGF0dGVybiwgZXh0KGRlZiwgb3B0aW9ucykpXG4gIH1cblxuICByZXR1cm4gbVxufVxuXG5NaW5pbWF0Y2guZGVmYXVsdHMgPSBmdW5jdGlvbiAoZGVmKSB7XG4gIGlmICghZGVmIHx8ICFPYmplY3Qua2V5cyhkZWYpLmxlbmd0aCkgcmV0dXJuIE1pbmltYXRjaFxuICByZXR1cm4gbWluaW1hdGNoLmRlZmF1bHRzKGRlZikuTWluaW1hdGNoXG59XG5cbmZ1bmN0aW9uIG1pbmltYXRjaCAocCwgcGF0dGVybiwgb3B0aW9ucykge1xuICBpZiAodHlwZW9mIHBhdHRlcm4gIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignZ2xvYiBwYXR0ZXJuIHN0cmluZyByZXF1aXJlZCcpXG4gIH1cblxuICBpZiAoIW9wdGlvbnMpIG9wdGlvbnMgPSB7fVxuXG4gIC8vIHNob3J0Y3V0OiBjb21tZW50cyBtYXRjaCBub3RoaW5nLlxuICBpZiAoIW9wdGlvbnMubm9jb21tZW50ICYmIHBhdHRlcm4uY2hhckF0KDApID09PSAnIycpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIC8vIFwiXCIgb25seSBtYXRjaGVzIFwiXCJcbiAgaWYgKHBhdHRlcm4udHJpbSgpID09PSAnJykgcmV0dXJuIHAgPT09ICcnXG5cbiAgcmV0dXJuIG5ldyBNaW5pbWF0Y2gocGF0dGVybiwgb3B0aW9ucykubWF0Y2gocClcbn1cblxuZnVuY3Rpb24gTWluaW1hdGNoIChwYXR0ZXJuLCBvcHRpb25zKSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBNaW5pbWF0Y2gpKSB7XG4gICAgcmV0dXJuIG5ldyBNaW5pbWF0Y2gocGF0dGVybiwgb3B0aW9ucylcbiAgfVxuXG4gIGlmICh0eXBlb2YgcGF0dGVybiAhPT0gJ3N0cmluZycpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdnbG9iIHBhdHRlcm4gc3RyaW5nIHJlcXVpcmVkJylcbiAgfVxuXG4gIGlmICghb3B0aW9ucykgb3B0aW9ucyA9IHt9XG4gIHBhdHRlcm4gPSBwYXR0ZXJuLnRyaW0oKVxuXG4gIC8vIHdpbmRvd3Mgc3VwcG9ydDogbmVlZCB0byB1c2UgLywgbm90IFxcXG4gIGlmIChwYXRoLnNlcCAhPT0gJy8nKSB7XG4gICAgcGF0dGVybiA9IHBhdHRlcm4uc3BsaXQocGF0aC5zZXApLmpvaW4oJy8nKVxuICB9XG5cbiAgdGhpcy5vcHRpb25zID0gb3B0aW9uc1xuICB0aGlzLnNldCA9IFtdXG4gIHRoaXMucGF0dGVybiA9IHBhdHRlcm5cbiAgdGhpcy5yZWdleHAgPSBudWxsXG4gIHRoaXMubmVnYXRlID0gZmFsc2VcbiAgdGhpcy5jb21tZW50ID0gZmFsc2VcbiAgdGhpcy5lbXB0eSA9IGZhbHNlXG5cbiAgLy8gbWFrZSB0aGUgc2V0IG9mIHJlZ2V4cHMgZXRjLlxuICB0aGlzLm1ha2UoKVxufVxuXG5NaW5pbWF0Y2gucHJvdG90eXBlLmRlYnVnID0gZnVuY3Rpb24gKCkge31cblxuTWluaW1hdGNoLnByb3RvdHlwZS5tYWtlID0gbWFrZVxuZnVuY3Rpb24gbWFrZSAoKSB7XG4gIC8vIGRvbid0IGRvIGl0IG1vcmUgdGhhbiBvbmNlLlxuICBpZiAodGhpcy5fbWFkZSkgcmV0dXJuXG5cbiAgdmFyIHBhdHRlcm4gPSB0aGlzLnBhdHRlcm5cbiAgdmFyIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnNcblxuICAvLyBlbXB0eSBwYXR0ZXJucyBhbmQgY29tbWVudHMgbWF0Y2ggbm90aGluZy5cbiAgaWYgKCFvcHRpb25zLm5vY29tbWVudCAmJiBwYXR0ZXJuLmNoYXJBdCgwKSA9PT0gJyMnKSB7XG4gICAgdGhpcy5jb21tZW50ID0gdHJ1ZVxuICAgIHJldHVyblxuICB9XG4gIGlmICghcGF0dGVybikge1xuICAgIHRoaXMuZW1wdHkgPSB0cnVlXG4gICAgcmV0dXJuXG4gIH1cblxuICAvLyBzdGVwIDE6IGZpZ3VyZSBvdXQgbmVnYXRpb24sIGV0Yy5cbiAgdGhpcy5wYXJzZU5lZ2F0ZSgpXG5cbiAgLy8gc3RlcCAyOiBleHBhbmQgYnJhY2VzXG4gIHZhciBzZXQgPSB0aGlzLmdsb2JTZXQgPSB0aGlzLmJyYWNlRXhwYW5kKClcblxuICBpZiAob3B0aW9ucy5kZWJ1ZykgdGhpcy5kZWJ1ZyA9IGNvbnNvbGUuZXJyb3JcblxuICB0aGlzLmRlYnVnKHRoaXMucGF0dGVybiwgc2V0KVxuXG4gIC8vIHN0ZXAgMzogbm93IHdlIGhhdmUgYSBzZXQsIHNvIHR1cm4gZWFjaCBvbmUgaW50byBhIHNlcmllcyBvZiBwYXRoLXBvcnRpb25cbiAgLy8gbWF0Y2hpbmcgcGF0dGVybnMuXG4gIC8vIFRoZXNlIHdpbGwgYmUgcmVnZXhwcywgZXhjZXB0IGluIHRoZSBjYXNlIG9mIFwiKipcIiwgd2hpY2ggaXNcbiAgLy8gc2V0IHRvIHRoZSBHTE9CU1RBUiBvYmplY3QgZm9yIGdsb2JzdGFyIGJlaGF2aW9yLFxuICAvLyBhbmQgd2lsbCBub3QgY29udGFpbiBhbnkgLyBjaGFyYWN0ZXJzXG4gIHNldCA9IHRoaXMuZ2xvYlBhcnRzID0gc2V0Lm1hcChmdW5jdGlvbiAocykge1xuICAgIHJldHVybiBzLnNwbGl0KHNsYXNoU3BsaXQpXG4gIH0pXG5cbiAgdGhpcy5kZWJ1Zyh0aGlzLnBhdHRlcm4sIHNldClcblxuICAvLyBnbG9iIC0tPiByZWdleHBzXG4gIHNldCA9IHNldC5tYXAoZnVuY3Rpb24gKHMsIHNpLCBzZXQpIHtcbiAgICByZXR1cm4gcy5tYXAodGhpcy5wYXJzZSwgdGhpcylcbiAgfSwgdGhpcylcblxuICB0aGlzLmRlYnVnKHRoaXMucGF0dGVybiwgc2V0KVxuXG4gIC8vIGZpbHRlciBvdXQgZXZlcnl0aGluZyB0aGF0IGRpZG4ndCBjb21waWxlIHByb3Blcmx5LlxuICBzZXQgPSBzZXQuZmlsdGVyKGZ1bmN0aW9uIChzKSB7XG4gICAgcmV0dXJuIHMuaW5kZXhPZihmYWxzZSkgPT09IC0xXG4gIH0pXG5cbiAgdGhpcy5kZWJ1Zyh0aGlzLnBhdHRlcm4sIHNldClcblxuICB0aGlzLnNldCA9IHNldFxufVxuXG5NaW5pbWF0Y2gucHJvdG90eXBlLnBhcnNlTmVnYXRlID0gcGFyc2VOZWdhdGVcbmZ1bmN0aW9uIHBhcnNlTmVnYXRlICgpIHtcbiAgdmFyIHBhdHRlcm4gPSB0aGlzLnBhdHRlcm5cbiAgdmFyIG5lZ2F0ZSA9IGZhbHNlXG4gIHZhciBvcHRpb25zID0gdGhpcy5vcHRpb25zXG4gIHZhciBuZWdhdGVPZmZzZXQgPSAwXG5cbiAgaWYgKG9wdGlvbnMubm9uZWdhdGUpIHJldHVyblxuXG4gIGZvciAodmFyIGkgPSAwLCBsID0gcGF0dGVybi5sZW5ndGhcbiAgICA7IGkgPCBsICYmIHBhdHRlcm4uY2hhckF0KGkpID09PSAnISdcbiAgICA7IGkrKykge1xuICAgIG5lZ2F0ZSA9ICFuZWdhdGVcbiAgICBuZWdhdGVPZmZzZXQrK1xuICB9XG5cbiAgaWYgKG5lZ2F0ZU9mZnNldCkgdGhpcy5wYXR0ZXJuID0gcGF0dGVybi5zdWJzdHIobmVnYXRlT2Zmc2V0KVxuICB0aGlzLm5lZ2F0ZSA9IG5lZ2F0ZVxufVxuXG4vLyBCcmFjZSBleHBhbnNpb246XG4vLyBhe2IsY31kIC0+IGFiZCBhY2Rcbi8vIGF7Yix9YyAtPiBhYmMgYWNcbi8vIGF7MC4uM31kIC0+IGEwZCBhMWQgYTJkIGEzZFxuLy8gYXtiLGN7ZCxlfWZ9ZyAtPiBhYmcgYWNkZmcgYWNlZmdcbi8vIGF7YixjfWR7ZSxmfWcgLT4gYWJkZWcgYWNkZWcgYWJkZWcgYWJkZmdcbi8vXG4vLyBJbnZhbGlkIHNldHMgYXJlIG5vdCBleHBhbmRlZC5cbi8vIGF7Mi4ufWIgLT4gYXsyLi59YlxuLy8gYXtifWMgLT4gYXtifWNcbm1pbmltYXRjaC5icmFjZUV4cGFuZCA9IGZ1bmN0aW9uIChwYXR0ZXJuLCBvcHRpb25zKSB7XG4gIHJldHVybiBicmFjZUV4cGFuZChwYXR0ZXJuLCBvcHRpb25zKVxufVxuXG5NaW5pbWF0Y2gucHJvdG90eXBlLmJyYWNlRXhwYW5kID0gYnJhY2VFeHBhbmRcblxuZnVuY3Rpb24gYnJhY2VFeHBhbmQgKHBhdHRlcm4sIG9wdGlvbnMpIHtcbiAgaWYgKCFvcHRpb25zKSB7XG4gICAgaWYgKHRoaXMgaW5zdGFuY2VvZiBNaW5pbWF0Y2gpIHtcbiAgICAgIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnNcbiAgICB9IGVsc2Uge1xuICAgICAgb3B0aW9ucyA9IHt9XG4gICAgfVxuICB9XG5cbiAgcGF0dGVybiA9IHR5cGVvZiBwYXR0ZXJuID09PSAndW5kZWZpbmVkJ1xuICAgID8gdGhpcy5wYXR0ZXJuIDogcGF0dGVyblxuXG4gIGlmICh0eXBlb2YgcGF0dGVybiA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd1bmRlZmluZWQgcGF0dGVybicpXG4gIH1cblxuICBpZiAob3B0aW9ucy5ub2JyYWNlIHx8XG4gICAgIXBhdHRlcm4ubWF0Y2goL1xcey4qXFx9LykpIHtcbiAgICAvLyBzaG9ydGN1dC4gbm8gbmVlZCB0byBleHBhbmQuXG4gICAgcmV0dXJuIFtwYXR0ZXJuXVxuICB9XG5cbiAgcmV0dXJuIGV4cGFuZChwYXR0ZXJuKVxufVxuXG4vLyBwYXJzZSBhIGNvbXBvbmVudCBvZiB0aGUgZXhwYW5kZWQgc2V0LlxuLy8gQXQgdGhpcyBwb2ludCwgbm8gcGF0dGVybiBtYXkgY29udGFpbiBcIi9cIiBpbiBpdFxuLy8gc28gd2UncmUgZ29pbmcgdG8gcmV0dXJuIGEgMmQgYXJyYXksIHdoZXJlIGVhY2ggZW50cnkgaXMgdGhlIGZ1bGxcbi8vIHBhdHRlcm4sIHNwbGl0IG9uICcvJywgYW5kIHRoZW4gdHVybmVkIGludG8gYSByZWd1bGFyIGV4cHJlc3Npb24uXG4vLyBBIHJlZ2V4cCBpcyBtYWRlIGF0IHRoZSBlbmQgd2hpY2ggam9pbnMgZWFjaCBhcnJheSB3aXRoIGFuXG4vLyBlc2NhcGVkIC8sIGFuZCBhbm90aGVyIGZ1bGwgb25lIHdoaWNoIGpvaW5zIGVhY2ggcmVnZXhwIHdpdGggfC5cbi8vXG4vLyBGb2xsb3dpbmcgdGhlIGxlYWQgb2YgQmFzaCA0LjEsIG5vdGUgdGhhdCBcIioqXCIgb25seSBoYXMgc3BlY2lhbCBtZWFuaW5nXG4vLyB3aGVuIGl0IGlzIHRoZSAqb25seSogdGhpbmcgaW4gYSBwYXRoIHBvcnRpb24uICBPdGhlcndpc2UsIGFueSBzZXJpZXNcbi8vIG9mICogaXMgZXF1aXZhbGVudCB0byBhIHNpbmdsZSAqLiAgR2xvYnN0YXIgYmVoYXZpb3IgaXMgZW5hYmxlZCBieVxuLy8gZGVmYXVsdCwgYW5kIGNhbiBiZSBkaXNhYmxlZCBieSBzZXR0aW5nIG9wdGlvbnMubm9nbG9ic3Rhci5cbk1pbmltYXRjaC5wcm90b3R5cGUucGFyc2UgPSBwYXJzZVxudmFyIFNVQlBBUlNFID0ge31cbmZ1bmN0aW9uIHBhcnNlIChwYXR0ZXJuLCBpc1N1Yikge1xuICBpZiAocGF0dGVybi5sZW5ndGggPiAxMDI0ICogNjQpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdwYXR0ZXJuIGlzIHRvbyBsb25nJylcbiAgfVxuXG4gIHZhciBvcHRpb25zID0gdGhpcy5vcHRpb25zXG5cbiAgLy8gc2hvcnRjdXRzXG4gIGlmICghb3B0aW9ucy5ub2dsb2JzdGFyICYmIHBhdHRlcm4gPT09ICcqKicpIHJldHVybiBHTE9CU1RBUlxuICBpZiAocGF0dGVybiA9PT0gJycpIHJldHVybiAnJ1xuXG4gIHZhciByZSA9ICcnXG4gIHZhciBoYXNNYWdpYyA9ICEhb3B0aW9ucy5ub2Nhc2VcbiAgdmFyIGVzY2FwaW5nID0gZmFsc2VcbiAgLy8gPyA9PiBvbmUgc2luZ2xlIGNoYXJhY3RlclxuICB2YXIgcGF0dGVybkxpc3RTdGFjayA9IFtdXG4gIHZhciBuZWdhdGl2ZUxpc3RzID0gW11cbiAgdmFyIHN0YXRlQ2hhclxuICB2YXIgaW5DbGFzcyA9IGZhbHNlXG4gIHZhciByZUNsYXNzU3RhcnQgPSAtMVxuICB2YXIgY2xhc3NTdGFydCA9IC0xXG4gIC8vIC4gYW5kIC4uIG5ldmVyIG1hdGNoIGFueXRoaW5nIHRoYXQgZG9lc24ndCBzdGFydCB3aXRoIC4sXG4gIC8vIGV2ZW4gd2hlbiBvcHRpb25zLmRvdCBpcyBzZXQuXG4gIHZhciBwYXR0ZXJuU3RhcnQgPSBwYXR0ZXJuLmNoYXJBdCgwKSA9PT0gJy4nID8gJycgLy8gYW55dGhpbmdcbiAgLy8gbm90IChzdGFydCBvciAvIGZvbGxvd2VkIGJ5IC4gb3IgLi4gZm9sbG93ZWQgYnkgLyBvciBlbmQpXG4gIDogb3B0aW9ucy5kb3QgPyAnKD8hKD86XnxcXFxcXFwvKVxcXFwuezEsMn0oPzokfFxcXFxcXC8pKSdcbiAgOiAnKD8hXFxcXC4pJ1xuICB2YXIgc2VsZiA9IHRoaXNcblxuICBmdW5jdGlvbiBjbGVhclN0YXRlQ2hhciAoKSB7XG4gICAgaWYgKHN0YXRlQ2hhcikge1xuICAgICAgLy8gd2UgaGFkIHNvbWUgc3RhdGUtdHJhY2tpbmcgY2hhcmFjdGVyXG4gICAgICAvLyB0aGF0IHdhc24ndCBjb25zdW1lZCBieSB0aGlzIHBhc3MuXG4gICAgICBzd2l0Y2ggKHN0YXRlQ2hhcikge1xuICAgICAgICBjYXNlICcqJzpcbiAgICAgICAgICByZSArPSBzdGFyXG4gICAgICAgICAgaGFzTWFnaWMgPSB0cnVlXG4gICAgICAgIGJyZWFrXG4gICAgICAgIGNhc2UgJz8nOlxuICAgICAgICAgIHJlICs9IHFtYXJrXG4gICAgICAgICAgaGFzTWFnaWMgPSB0cnVlXG4gICAgICAgIGJyZWFrXG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmUgKz0gJ1xcXFwnICsgc3RhdGVDaGFyXG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgICBzZWxmLmRlYnVnKCdjbGVhclN0YXRlQ2hhciAlaiAlaicsIHN0YXRlQ2hhciwgcmUpXG4gICAgICBzdGF0ZUNoYXIgPSBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIGZvciAodmFyIGkgPSAwLCBsZW4gPSBwYXR0ZXJuLmxlbmd0aCwgY1xuICAgIDsgKGkgPCBsZW4pICYmIChjID0gcGF0dGVybi5jaGFyQXQoaSkpXG4gICAgOyBpKyspIHtcbiAgICB0aGlzLmRlYnVnKCclc1xcdCVzICVzICVqJywgcGF0dGVybiwgaSwgcmUsIGMpXG5cbiAgICAvLyBza2lwIG92ZXIgYW55IHRoYXQgYXJlIGVzY2FwZWQuXG4gICAgaWYgKGVzY2FwaW5nICYmIHJlU3BlY2lhbHNbY10pIHtcbiAgICAgIHJlICs9ICdcXFxcJyArIGNcbiAgICAgIGVzY2FwaW5nID0gZmFsc2VcbiAgICAgIGNvbnRpbnVlXG4gICAgfVxuXG4gICAgc3dpdGNoIChjKSB7XG4gICAgICBjYXNlICcvJzpcbiAgICAgICAgLy8gY29tcGxldGVseSBub3QgYWxsb3dlZCwgZXZlbiBlc2NhcGVkLlxuICAgICAgICAvLyBTaG91bGQgYWxyZWFkeSBiZSBwYXRoLXNwbGl0IGJ5IG5vdy5cbiAgICAgICAgcmV0dXJuIGZhbHNlXG5cbiAgICAgIGNhc2UgJ1xcXFwnOlxuICAgICAgICBjbGVhclN0YXRlQ2hhcigpXG4gICAgICAgIGVzY2FwaW5nID0gdHJ1ZVxuICAgICAgY29udGludWVcblxuICAgICAgLy8gdGhlIHZhcmlvdXMgc3RhdGVDaGFyIHZhbHVlc1xuICAgICAgLy8gZm9yIHRoZSBcImV4dGdsb2JcIiBzdHVmZi5cbiAgICAgIGNhc2UgJz8nOlxuICAgICAgY2FzZSAnKic6XG4gICAgICBjYXNlICcrJzpcbiAgICAgIGNhc2UgJ0AnOlxuICAgICAgY2FzZSAnISc6XG4gICAgICAgIHRoaXMuZGVidWcoJyVzXFx0JXMgJXMgJWogPC0tIHN0YXRlQ2hhcicsIHBhdHRlcm4sIGksIHJlLCBjKVxuXG4gICAgICAgIC8vIGFsbCBvZiB0aG9zZSBhcmUgbGl0ZXJhbHMgaW5zaWRlIGEgY2xhc3MsIGV4Y2VwdCB0aGF0XG4gICAgICAgIC8vIHRoZSBnbG9iIFshYV0gbWVhbnMgW15hXSBpbiByZWdleHBcbiAgICAgICAgaWYgKGluQ2xhc3MpIHtcbiAgICAgICAgICB0aGlzLmRlYnVnKCcgIGluIGNsYXNzJylcbiAgICAgICAgICBpZiAoYyA9PT0gJyEnICYmIGkgPT09IGNsYXNzU3RhcnQgKyAxKSBjID0gJ14nXG4gICAgICAgICAgcmUgKz0gY1xuICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgIH1cblxuICAgICAgICAvLyBpZiB3ZSBhbHJlYWR5IGhhdmUgYSBzdGF0ZUNoYXIsIHRoZW4gaXQgbWVhbnNcbiAgICAgICAgLy8gdGhhdCB0aGVyZSB3YXMgc29tZXRoaW5nIGxpa2UgKiogb3IgKz8gaW4gdGhlcmUuXG4gICAgICAgIC8vIEhhbmRsZSB0aGUgc3RhdGVDaGFyLCB0aGVuIHByb2NlZWQgd2l0aCB0aGlzIG9uZS5cbiAgICAgICAgc2VsZi5kZWJ1ZygnY2FsbCBjbGVhclN0YXRlQ2hhciAlaicsIHN0YXRlQ2hhcilcbiAgICAgICAgY2xlYXJTdGF0ZUNoYXIoKVxuICAgICAgICBzdGF0ZUNoYXIgPSBjXG4gICAgICAgIC8vIGlmIGV4dGdsb2IgaXMgZGlzYWJsZWQsIHRoZW4gKyhhc2RmfGZvbykgaXNuJ3QgYSB0aGluZy5cbiAgICAgICAgLy8ganVzdCBjbGVhciB0aGUgc3RhdGVjaGFyICpub3cqLCByYXRoZXIgdGhhbiBldmVuIGRpdmluZyBpbnRvXG4gICAgICAgIC8vIHRoZSBwYXR0ZXJuTGlzdCBzdHVmZi5cbiAgICAgICAgaWYgKG9wdGlvbnMubm9leHQpIGNsZWFyU3RhdGVDaGFyKClcbiAgICAgIGNvbnRpbnVlXG5cbiAgICAgIGNhc2UgJygnOlxuICAgICAgICBpZiAoaW5DbGFzcykge1xuICAgICAgICAgIHJlICs9ICcoJ1xuICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXN0YXRlQ2hhcikge1xuICAgICAgICAgIHJlICs9ICdcXFxcKCdcbiAgICAgICAgICBjb250aW51ZVxuICAgICAgICB9XG5cbiAgICAgICAgcGF0dGVybkxpc3RTdGFjay5wdXNoKHtcbiAgICAgICAgICB0eXBlOiBzdGF0ZUNoYXIsXG4gICAgICAgICAgc3RhcnQ6IGkgLSAxLFxuICAgICAgICAgIHJlU3RhcnQ6IHJlLmxlbmd0aCxcbiAgICAgICAgICBvcGVuOiBwbFR5cGVzW3N0YXRlQ2hhcl0ub3BlbixcbiAgICAgICAgICBjbG9zZTogcGxUeXBlc1tzdGF0ZUNoYXJdLmNsb3NlXG4gICAgICAgIH0pXG4gICAgICAgIC8vIG5lZ2F0aW9uIGlzICg/Oig/IWpzKVteL10qKVxuICAgICAgICByZSArPSBzdGF0ZUNoYXIgPT09ICchJyA/ICcoPzooPyEoPzonIDogJyg/OidcbiAgICAgICAgdGhpcy5kZWJ1ZygncGxUeXBlICVqICVqJywgc3RhdGVDaGFyLCByZSlcbiAgICAgICAgc3RhdGVDaGFyID0gZmFsc2VcbiAgICAgIGNvbnRpbnVlXG5cbiAgICAgIGNhc2UgJyknOlxuICAgICAgICBpZiAoaW5DbGFzcyB8fCAhcGF0dGVybkxpc3RTdGFjay5sZW5ndGgpIHtcbiAgICAgICAgICByZSArPSAnXFxcXCknXG4gICAgICAgICAgY29udGludWVcbiAgICAgICAgfVxuXG4gICAgICAgIGNsZWFyU3RhdGVDaGFyKClcbiAgICAgICAgaGFzTWFnaWMgPSB0cnVlXG4gICAgICAgIHZhciBwbCA9IHBhdHRlcm5MaXN0U3RhY2sucG9wKClcbiAgICAgICAgLy8gbmVnYXRpb24gaXMgKD86KD8hanMpW14vXSopXG4gICAgICAgIC8vIFRoZSBvdGhlcnMgYXJlICg/OjxwYXR0ZXJuPik8dHlwZT5cbiAgICAgICAgcmUgKz0gcGwuY2xvc2VcbiAgICAgICAgaWYgKHBsLnR5cGUgPT09ICchJykge1xuICAgICAgICAgIG5lZ2F0aXZlTGlzdHMucHVzaChwbClcbiAgICAgICAgfVxuICAgICAgICBwbC5yZUVuZCA9IHJlLmxlbmd0aFxuICAgICAgY29udGludWVcblxuICAgICAgY2FzZSAnfCc6XG4gICAgICAgIGlmIChpbkNsYXNzIHx8ICFwYXR0ZXJuTGlzdFN0YWNrLmxlbmd0aCB8fCBlc2NhcGluZykge1xuICAgICAgICAgIHJlICs9ICdcXFxcfCdcbiAgICAgICAgICBlc2NhcGluZyA9IGZhbHNlXG4gICAgICAgICAgY29udGludWVcbiAgICAgICAgfVxuXG4gICAgICAgIGNsZWFyU3RhdGVDaGFyKClcbiAgICAgICAgcmUgKz0gJ3wnXG4gICAgICBjb250aW51ZVxuXG4gICAgICAvLyB0aGVzZSBhcmUgbW9zdGx5IHRoZSBzYW1lIGluIHJlZ2V4cCBhbmQgZ2xvYlxuICAgICAgY2FzZSAnWyc6XG4gICAgICAgIC8vIHN3YWxsb3cgYW55IHN0YXRlLXRyYWNraW5nIGNoYXIgYmVmb3JlIHRoZSBbXG4gICAgICAgIGNsZWFyU3RhdGVDaGFyKClcblxuICAgICAgICBpZiAoaW5DbGFzcykge1xuICAgICAgICAgIHJlICs9ICdcXFxcJyArIGNcbiAgICAgICAgICBjb250aW51ZVxuICAgICAgICB9XG5cbiAgICAgICAgaW5DbGFzcyA9IHRydWVcbiAgICAgICAgY2xhc3NTdGFydCA9IGlcbiAgICAgICAgcmVDbGFzc1N0YXJ0ID0gcmUubGVuZ3RoXG4gICAgICAgIHJlICs9IGNcbiAgICAgIGNvbnRpbnVlXG5cbiAgICAgIGNhc2UgJ10nOlxuICAgICAgICAvLyAgYSByaWdodCBicmFja2V0IHNoYWxsIGxvc2UgaXRzIHNwZWNpYWxcbiAgICAgICAgLy8gIG1lYW5pbmcgYW5kIHJlcHJlc2VudCBpdHNlbGYgaW5cbiAgICAgICAgLy8gIGEgYnJhY2tldCBleHByZXNzaW9uIGlmIGl0IG9jY3Vyc1xuICAgICAgICAvLyAgZmlyc3QgaW4gdGhlIGxpc3QuICAtLSBQT1NJWC4yIDIuOC4zLjJcbiAgICAgICAgaWYgKGkgPT09IGNsYXNzU3RhcnQgKyAxIHx8ICFpbkNsYXNzKSB7XG4gICAgICAgICAgcmUgKz0gJ1xcXFwnICsgY1xuICAgICAgICAgIGVzY2FwaW5nID0gZmFsc2VcbiAgICAgICAgICBjb250aW51ZVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gaGFuZGxlIHRoZSBjYXNlIHdoZXJlIHdlIGxlZnQgYSBjbGFzcyBvcGVuLlxuICAgICAgICAvLyBcIlt6LWFdXCIgaXMgdmFsaWQsIGVxdWl2YWxlbnQgdG8gXCJcXFt6LWFcXF1cIlxuICAgICAgICBpZiAoaW5DbGFzcykge1xuICAgICAgICAgIC8vIHNwbGl0IHdoZXJlIHRoZSBsYXN0IFsgd2FzLCBtYWtlIHN1cmUgd2UgZG9uJ3QgaGF2ZVxuICAgICAgICAgIC8vIGFuIGludmFsaWQgcmUuIGlmIHNvLCByZS13YWxrIHRoZSBjb250ZW50cyBvZiB0aGVcbiAgICAgICAgICAvLyB3b3VsZC1iZSBjbGFzcyB0byByZS10cmFuc2xhdGUgYW55IGNoYXJhY3RlcnMgdGhhdFxuICAgICAgICAgIC8vIHdlcmUgcGFzc2VkIHRocm91Z2ggYXMtaXNcbiAgICAgICAgICAvLyBUT0RPOiBJdCB3b3VsZCBwcm9iYWJseSBiZSBmYXN0ZXIgdG8gZGV0ZXJtaW5lIHRoaXNcbiAgICAgICAgICAvLyB3aXRob3V0IGEgdHJ5L2NhdGNoIGFuZCBhIG5ldyBSZWdFeHAsIGJ1dCBpdCdzIHRyaWNreVxuICAgICAgICAgIC8vIHRvIGRvIHNhZmVseS4gIEZvciBub3csIHRoaXMgaXMgc2FmZSBhbmQgd29ya3MuXG4gICAgICAgICAgdmFyIGNzID0gcGF0dGVybi5zdWJzdHJpbmcoY2xhc3NTdGFydCArIDEsIGkpXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJlZ0V4cCgnWycgKyBjcyArICddJylcbiAgICAgICAgICB9IGNhdGNoIChlcikge1xuICAgICAgICAgICAgLy8gbm90IGEgdmFsaWQgY2xhc3MhXG4gICAgICAgICAgICB2YXIgc3AgPSB0aGlzLnBhcnNlKGNzLCBTVUJQQVJTRSlcbiAgICAgICAgICAgIHJlID0gcmUuc3Vic3RyKDAsIHJlQ2xhc3NTdGFydCkgKyAnXFxcXFsnICsgc3BbMF0gKyAnXFxcXF0nXG4gICAgICAgICAgICBoYXNNYWdpYyA9IGhhc01hZ2ljIHx8IHNwWzFdXG4gICAgICAgICAgICBpbkNsYXNzID0gZmFsc2VcbiAgICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gZmluaXNoIHVwIHRoZSBjbGFzcy5cbiAgICAgICAgaGFzTWFnaWMgPSB0cnVlXG4gICAgICAgIGluQ2xhc3MgPSBmYWxzZVxuICAgICAgICByZSArPSBjXG4gICAgICBjb250aW51ZVxuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICAvLyBzd2FsbG93IGFueSBzdGF0ZSBjaGFyIHRoYXQgd2Fzbid0IGNvbnN1bWVkXG4gICAgICAgIGNsZWFyU3RhdGVDaGFyKClcblxuICAgICAgICBpZiAoZXNjYXBpbmcpIHtcbiAgICAgICAgICAvLyBubyBuZWVkXG4gICAgICAgICAgZXNjYXBpbmcgPSBmYWxzZVxuICAgICAgICB9IGVsc2UgaWYgKHJlU3BlY2lhbHNbY11cbiAgICAgICAgICAmJiAhKGMgPT09ICdeJyAmJiBpbkNsYXNzKSkge1xuICAgICAgICAgIHJlICs9ICdcXFxcJ1xuICAgICAgICB9XG5cbiAgICAgICAgcmUgKz0gY1xuXG4gICAgfSAvLyBzd2l0Y2hcbiAgfSAvLyBmb3JcblxuICAvLyBoYW5kbGUgdGhlIGNhc2Ugd2hlcmUgd2UgbGVmdCBhIGNsYXNzIG9wZW4uXG4gIC8vIFwiW2FiY1wiIGlzIHZhbGlkLCBlcXVpdmFsZW50IHRvIFwiXFxbYWJjXCJcbiAgaWYgKGluQ2xhc3MpIHtcbiAgICAvLyBzcGxpdCB3aGVyZSB0aGUgbGFzdCBbIHdhcywgYW5kIGVzY2FwZSBpdFxuICAgIC8vIHRoaXMgaXMgYSBodWdlIHBpdGEuICBXZSBub3cgaGF2ZSB0byByZS13YWxrXG4gICAgLy8gdGhlIGNvbnRlbnRzIG9mIHRoZSB3b3VsZC1iZSBjbGFzcyB0byByZS10cmFuc2xhdGVcbiAgICAvLyBhbnkgY2hhcmFjdGVycyB0aGF0IHdlcmUgcGFzc2VkIHRocm91Z2ggYXMtaXNcbiAgICBjcyA9IHBhdHRlcm4uc3Vic3RyKGNsYXNzU3RhcnQgKyAxKVxuICAgIHNwID0gdGhpcy5wYXJzZShjcywgU1VCUEFSU0UpXG4gICAgcmUgPSByZS5zdWJzdHIoMCwgcmVDbGFzc1N0YXJ0KSArICdcXFxcWycgKyBzcFswXVxuICAgIGhhc01hZ2ljID0gaGFzTWFnaWMgfHwgc3BbMV1cbiAgfVxuXG4gIC8vIGhhbmRsZSB0aGUgY2FzZSB3aGVyZSB3ZSBoYWQgYSArKCB0aGluZyBhdCB0aGUgKmVuZCpcbiAgLy8gb2YgdGhlIHBhdHRlcm4uXG4gIC8vIGVhY2ggcGF0dGVybiBsaXN0IHN0YWNrIGFkZHMgMyBjaGFycywgYW5kIHdlIG5lZWQgdG8gZ28gdGhyb3VnaFxuICAvLyBhbmQgZXNjYXBlIGFueSB8IGNoYXJzIHRoYXQgd2VyZSBwYXNzZWQgdGhyb3VnaCBhcy1pcyBmb3IgdGhlIHJlZ2V4cC5cbiAgLy8gR28gdGhyb3VnaCBhbmQgZXNjYXBlIHRoZW0sIHRha2luZyBjYXJlIG5vdCB0byBkb3VibGUtZXNjYXBlIGFueVxuICAvLyB8IGNoYXJzIHRoYXQgd2VyZSBhbHJlYWR5IGVzY2FwZWQuXG4gIGZvciAocGwgPSBwYXR0ZXJuTGlzdFN0YWNrLnBvcCgpOyBwbDsgcGwgPSBwYXR0ZXJuTGlzdFN0YWNrLnBvcCgpKSB7XG4gICAgdmFyIHRhaWwgPSByZS5zbGljZShwbC5yZVN0YXJ0ICsgcGwub3Blbi5sZW5ndGgpXG4gICAgdGhpcy5kZWJ1Zygnc2V0dGluZyB0YWlsJywgcmUsIHBsKVxuICAgIC8vIG1heWJlIHNvbWUgZXZlbiBudW1iZXIgb2YgXFwsIHRoZW4gbWF5YmUgMSBcXCwgZm9sbG93ZWQgYnkgYSB8XG4gICAgdGFpbCA9IHRhaWwucmVwbGFjZSgvKCg/OlxcXFx7Mn0pezAsNjR9KShcXFxcPylcXHwvZywgZnVuY3Rpb24gKF8sICQxLCAkMikge1xuICAgICAgaWYgKCEkMikge1xuICAgICAgICAvLyB0aGUgfCBpc24ndCBhbHJlYWR5IGVzY2FwZWQsIHNvIGVzY2FwZSBpdC5cbiAgICAgICAgJDIgPSAnXFxcXCdcbiAgICAgIH1cblxuICAgICAgLy8gbmVlZCB0byBlc2NhcGUgYWxsIHRob3NlIHNsYXNoZXMgKmFnYWluKiwgd2l0aG91dCBlc2NhcGluZyB0aGVcbiAgICAgIC8vIG9uZSB0aGF0IHdlIG5lZWQgZm9yIGVzY2FwaW5nIHRoZSB8IGNoYXJhY3Rlci4gIEFzIGl0IHdvcmtzIG91dCxcbiAgICAgIC8vIGVzY2FwaW5nIGFuIGV2ZW4gbnVtYmVyIG9mIHNsYXNoZXMgY2FuIGJlIGRvbmUgYnkgc2ltcGx5IHJlcGVhdGluZ1xuICAgICAgLy8gaXQgZXhhY3RseSBhZnRlciBpdHNlbGYuICBUaGF0J3Mgd2h5IHRoaXMgdHJpY2sgd29ya3MuXG4gICAgICAvL1xuICAgICAgLy8gSSBhbSBzb3JyeSB0aGF0IHlvdSBoYXZlIHRvIHNlZSB0aGlzLlxuICAgICAgcmV0dXJuICQxICsgJDEgKyAkMiArICd8J1xuICAgIH0pXG5cbiAgICB0aGlzLmRlYnVnKCd0YWlsPSVqXFxuICAgJXMnLCB0YWlsLCB0YWlsLCBwbCwgcmUpXG4gICAgdmFyIHQgPSBwbC50eXBlID09PSAnKicgPyBzdGFyXG4gICAgICA6IHBsLnR5cGUgPT09ICc/JyA/IHFtYXJrXG4gICAgICA6ICdcXFxcJyArIHBsLnR5cGVcblxuICAgIGhhc01hZ2ljID0gdHJ1ZVxuICAgIHJlID0gcmUuc2xpY2UoMCwgcGwucmVTdGFydCkgKyB0ICsgJ1xcXFwoJyArIHRhaWxcbiAgfVxuXG4gIC8vIGhhbmRsZSB0cmFpbGluZyB0aGluZ3MgdGhhdCBvbmx5IG1hdHRlciBhdCB0aGUgdmVyeSBlbmQuXG4gIGNsZWFyU3RhdGVDaGFyKClcbiAgaWYgKGVzY2FwaW5nKSB7XG4gICAgLy8gdHJhaWxpbmcgXFxcXFxuICAgIHJlICs9ICdcXFxcXFxcXCdcbiAgfVxuXG4gIC8vIG9ubHkgbmVlZCB0byBhcHBseSB0aGUgbm9kb3Qgc3RhcnQgaWYgdGhlIHJlIHN0YXJ0cyB3aXRoXG4gIC8vIHNvbWV0aGluZyB0aGF0IGNvdWxkIGNvbmNlaXZhYmx5IGNhcHR1cmUgYSBkb3RcbiAgdmFyIGFkZFBhdHRlcm5TdGFydCA9IGZhbHNlXG4gIHN3aXRjaCAocmUuY2hhckF0KDApKSB7XG4gICAgY2FzZSAnLic6XG4gICAgY2FzZSAnWyc6XG4gICAgY2FzZSAnKCc6IGFkZFBhdHRlcm5TdGFydCA9IHRydWVcbiAgfVxuXG4gIC8vIEhhY2sgdG8gd29yayBhcm91bmQgbGFjayBvZiBuZWdhdGl2ZSBsb29rYmVoaW5kIGluIEpTXG4gIC8vIEEgcGF0dGVybiBsaWtlOiAqLiEoeCkuISh5fHopIG5lZWRzIHRvIGVuc3VyZSB0aGF0IGEgbmFtZVxuICAvLyBsaWtlICdhLnh5ei55eicgZG9lc24ndCBtYXRjaC4gIFNvLCB0aGUgZmlyc3QgbmVnYXRpdmVcbiAgLy8gbG9va2FoZWFkLCBoYXMgdG8gbG9vayBBTEwgdGhlIHdheSBhaGVhZCwgdG8gdGhlIGVuZCBvZlxuICAvLyB0aGUgcGF0dGVybi5cbiAgZm9yICh2YXIgbiA9IG5lZ2F0aXZlTGlzdHMubGVuZ3RoIC0gMTsgbiA+IC0xOyBuLS0pIHtcbiAgICB2YXIgbmwgPSBuZWdhdGl2ZUxpc3RzW25dXG5cbiAgICB2YXIgbmxCZWZvcmUgPSByZS5zbGljZSgwLCBubC5yZVN0YXJ0KVxuICAgIHZhciBubEZpcnN0ID0gcmUuc2xpY2UobmwucmVTdGFydCwgbmwucmVFbmQgLSA4KVxuICAgIHZhciBubExhc3QgPSByZS5zbGljZShubC5yZUVuZCAtIDgsIG5sLnJlRW5kKVxuICAgIHZhciBubEFmdGVyID0gcmUuc2xpY2UobmwucmVFbmQpXG5cbiAgICBubExhc3QgKz0gbmxBZnRlclxuXG4gICAgLy8gSGFuZGxlIG5lc3RlZCBzdHVmZiBsaWtlICooKi5qc3whKCouanNvbikpLCB3aGVyZSBvcGVuIHBhcmVuc1xuICAgIC8vIG1lYW4gdGhhdCB3ZSBzaG91bGQgKm5vdCogaW5jbHVkZSB0aGUgKSBpbiB0aGUgYml0IHRoYXQgaXMgY29uc2lkZXJlZFxuICAgIC8vIFwiYWZ0ZXJcIiB0aGUgbmVnYXRlZCBzZWN0aW9uLlxuICAgIHZhciBvcGVuUGFyZW5zQmVmb3JlID0gbmxCZWZvcmUuc3BsaXQoJygnKS5sZW5ndGggLSAxXG4gICAgdmFyIGNsZWFuQWZ0ZXIgPSBubEFmdGVyXG4gICAgZm9yIChpID0gMDsgaSA8IG9wZW5QYXJlbnNCZWZvcmU7IGkrKykge1xuICAgICAgY2xlYW5BZnRlciA9IGNsZWFuQWZ0ZXIucmVwbGFjZSgvXFwpWysqP10/LywgJycpXG4gICAgfVxuICAgIG5sQWZ0ZXIgPSBjbGVhbkFmdGVyXG5cbiAgICB2YXIgZG9sbGFyID0gJydcbiAgICBpZiAobmxBZnRlciA9PT0gJycgJiYgaXNTdWIgIT09IFNVQlBBUlNFKSB7XG4gICAgICBkb2xsYXIgPSAnJCdcbiAgICB9XG4gICAgdmFyIG5ld1JlID0gbmxCZWZvcmUgKyBubEZpcnN0ICsgbmxBZnRlciArIGRvbGxhciArIG5sTGFzdFxuICAgIHJlID0gbmV3UmVcbiAgfVxuXG4gIC8vIGlmIHRoZSByZSBpcyBub3QgXCJcIiBhdCB0aGlzIHBvaW50LCB0aGVuIHdlIG5lZWQgdG8gbWFrZSBzdXJlXG4gIC8vIGl0IGRvZXNuJ3QgbWF0Y2ggYWdhaW5zdCBhbiBlbXB0eSBwYXRoIHBhcnQuXG4gIC8vIE90aGVyd2lzZSBhLyogd2lsbCBtYXRjaCBhLywgd2hpY2ggaXQgc2hvdWxkIG5vdC5cbiAgaWYgKHJlICE9PSAnJyAmJiBoYXNNYWdpYykge1xuICAgIHJlID0gJyg/PS4pJyArIHJlXG4gIH1cblxuICBpZiAoYWRkUGF0dGVyblN0YXJ0KSB7XG4gICAgcmUgPSBwYXR0ZXJuU3RhcnQgKyByZVxuICB9XG5cbiAgLy8gcGFyc2luZyBqdXN0IGEgcGllY2Ugb2YgYSBsYXJnZXIgcGF0dGVybi5cbiAgaWYgKGlzU3ViID09PSBTVUJQQVJTRSkge1xuICAgIHJldHVybiBbcmUsIGhhc01hZ2ljXVxuICB9XG5cbiAgLy8gc2tpcCB0aGUgcmVnZXhwIGZvciBub24tbWFnaWNhbCBwYXR0ZXJuc1xuICAvLyB1bmVzY2FwZSBhbnl0aGluZyBpbiBpdCwgdGhvdWdoLCBzbyB0aGF0IGl0J2xsIGJlXG4gIC8vIGFuIGV4YWN0IG1hdGNoIGFnYWluc3QgYSBmaWxlIGV0Yy5cbiAgaWYgKCFoYXNNYWdpYykge1xuICAgIHJldHVybiBnbG9iVW5lc2NhcGUocGF0dGVybilcbiAgfVxuXG4gIHZhciBmbGFncyA9IG9wdGlvbnMubm9jYXNlID8gJ2knIDogJydcbiAgdHJ5IHtcbiAgICB2YXIgcmVnRXhwID0gbmV3IFJlZ0V4cCgnXicgKyByZSArICckJywgZmxhZ3MpXG4gIH0gY2F0Y2ggKGVyKSB7XG4gICAgLy8gSWYgaXQgd2FzIGFuIGludmFsaWQgcmVndWxhciBleHByZXNzaW9uLCB0aGVuIGl0IGNhbid0IG1hdGNoXG4gICAgLy8gYW55dGhpbmcuICBUaGlzIHRyaWNrIGxvb2tzIGZvciBhIGNoYXJhY3RlciBhZnRlciB0aGUgZW5kIG9mXG4gICAgLy8gdGhlIHN0cmluZywgd2hpY2ggaXMgb2YgY291cnNlIGltcG9zc2libGUsIGV4Y2VwdCBpbiBtdWx0aS1saW5lXG4gICAgLy8gbW9kZSwgYnV0IGl0J3Mgbm90IGEgL20gcmVnZXguXG4gICAgcmV0dXJuIG5ldyBSZWdFeHAoJyQuJylcbiAgfVxuXG4gIHJlZ0V4cC5fZ2xvYiA9IHBhdHRlcm5cbiAgcmVnRXhwLl9zcmMgPSByZVxuXG4gIHJldHVybiByZWdFeHBcbn1cblxubWluaW1hdGNoLm1ha2VSZSA9IGZ1bmN0aW9uIChwYXR0ZXJuLCBvcHRpb25zKSB7XG4gIHJldHVybiBuZXcgTWluaW1hdGNoKHBhdHRlcm4sIG9wdGlvbnMgfHwge30pLm1ha2VSZSgpXG59XG5cbk1pbmltYXRjaC5wcm90b3R5cGUubWFrZVJlID0gbWFrZVJlXG5mdW5jdGlvbiBtYWtlUmUgKCkge1xuICBpZiAodGhpcy5yZWdleHAgfHwgdGhpcy5yZWdleHAgPT09IGZhbHNlKSByZXR1cm4gdGhpcy5yZWdleHBcblxuICAvLyBhdCB0aGlzIHBvaW50LCB0aGlzLnNldCBpcyBhIDJkIGFycmF5IG9mIHBhcnRpYWxcbiAgLy8gcGF0dGVybiBzdHJpbmdzLCBvciBcIioqXCIuXG4gIC8vXG4gIC8vIEl0J3MgYmV0dGVyIHRvIHVzZSAubWF0Y2goKS4gIFRoaXMgZnVuY3Rpb24gc2hvdWxkbid0XG4gIC8vIGJlIHVzZWQsIHJlYWxseSwgYnV0IGl0J3MgcHJldHR5IGNvbnZlbmllbnQgc29tZXRpbWVzLFxuICAvLyB3aGVuIHlvdSBqdXN0IHdhbnQgdG8gd29yayB3aXRoIGEgcmVnZXguXG4gIHZhciBzZXQgPSB0aGlzLnNldFxuXG4gIGlmICghc2V0Lmxlbmd0aCkge1xuICAgIHRoaXMucmVnZXhwID0gZmFsc2VcbiAgICByZXR1cm4gdGhpcy5yZWdleHBcbiAgfVxuICB2YXIgb3B0aW9ucyA9IHRoaXMub3B0aW9uc1xuXG4gIHZhciB0d29TdGFyID0gb3B0aW9ucy5ub2dsb2JzdGFyID8gc3RhclxuICAgIDogb3B0aW9ucy5kb3QgPyB0d29TdGFyRG90XG4gICAgOiB0d29TdGFyTm9Eb3RcbiAgdmFyIGZsYWdzID0gb3B0aW9ucy5ub2Nhc2UgPyAnaScgOiAnJ1xuXG4gIHZhciByZSA9IHNldC5tYXAoZnVuY3Rpb24gKHBhdHRlcm4pIHtcbiAgICByZXR1cm4gcGF0dGVybi5tYXAoZnVuY3Rpb24gKHApIHtcbiAgICAgIHJldHVybiAocCA9PT0gR0xPQlNUQVIpID8gdHdvU3RhclxuICAgICAgOiAodHlwZW9mIHAgPT09ICdzdHJpbmcnKSA/IHJlZ0V4cEVzY2FwZShwKVxuICAgICAgOiBwLl9zcmNcbiAgICB9KS5qb2luKCdcXFxcXFwvJylcbiAgfSkuam9pbignfCcpXG5cbiAgLy8gbXVzdCBtYXRjaCBlbnRpcmUgcGF0dGVyblxuICAvLyBlbmRpbmcgaW4gYSAqIG9yICoqIHdpbGwgbWFrZSBpdCBsZXNzIHN0cmljdC5cbiAgcmUgPSAnXig/OicgKyByZSArICcpJCdcblxuICAvLyBjYW4gbWF0Y2ggYW55dGhpbmcsIGFzIGxvbmcgYXMgaXQncyBub3QgdGhpcy5cbiAgaWYgKHRoaXMubmVnYXRlKSByZSA9ICdeKD8hJyArIHJlICsgJykuKiQnXG5cbiAgdHJ5IHtcbiAgICB0aGlzLnJlZ2V4cCA9IG5ldyBSZWdFeHAocmUsIGZsYWdzKVxuICB9IGNhdGNoIChleCkge1xuICAgIHRoaXMucmVnZXhwID0gZmFsc2VcbiAgfVxuICByZXR1cm4gdGhpcy5yZWdleHBcbn1cblxubWluaW1hdGNoLm1hdGNoID0gZnVuY3Rpb24gKGxpc3QsIHBhdHRlcm4sIG9wdGlvbnMpIHtcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge31cbiAgdmFyIG1tID0gbmV3IE1pbmltYXRjaChwYXR0ZXJuLCBvcHRpb25zKVxuICBsaXN0ID0gbGlzdC5maWx0ZXIoZnVuY3Rpb24gKGYpIHtcbiAgICByZXR1cm4gbW0ubWF0Y2goZilcbiAgfSlcbiAgaWYgKG1tLm9wdGlvbnMubm9udWxsICYmICFsaXN0Lmxlbmd0aCkge1xuICAgIGxpc3QucHVzaChwYXR0ZXJuKVxuICB9XG4gIHJldHVybiBsaXN0XG59XG5cbk1pbmltYXRjaC5wcm90b3R5cGUubWF0Y2ggPSBtYXRjaFxuZnVuY3Rpb24gbWF0Y2ggKGYsIHBhcnRpYWwpIHtcbiAgdGhpcy5kZWJ1ZygnbWF0Y2gnLCBmLCB0aGlzLnBhdHRlcm4pXG4gIC8vIHNob3J0LWNpcmN1aXQgaW4gdGhlIGNhc2Ugb2YgYnVzdGVkIHRoaW5ncy5cbiAgLy8gY29tbWVudHMsIGV0Yy5cbiAgaWYgKHRoaXMuY29tbWVudCkgcmV0dXJuIGZhbHNlXG4gIGlmICh0aGlzLmVtcHR5KSByZXR1cm4gZiA9PT0gJydcblxuICBpZiAoZiA9PT0gJy8nICYmIHBhcnRpYWwpIHJldHVybiB0cnVlXG5cbiAgdmFyIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnNcblxuICAvLyB3aW5kb3dzOiBuZWVkIHRvIHVzZSAvLCBub3QgXFxcbiAgaWYgKHBhdGguc2VwICE9PSAnLycpIHtcbiAgICBmID0gZi5zcGxpdChwYXRoLnNlcCkuam9pbignLycpXG4gIH1cblxuICAvLyB0cmVhdCB0aGUgdGVzdCBwYXRoIGFzIGEgc2V0IG9mIHBhdGhwYXJ0cy5cbiAgZiA9IGYuc3BsaXQoc2xhc2hTcGxpdClcbiAgdGhpcy5kZWJ1Zyh0aGlzLnBhdHRlcm4sICdzcGxpdCcsIGYpXG5cbiAgLy8ganVzdCBPTkUgb2YgdGhlIHBhdHRlcm4gc2V0cyBpbiB0aGlzLnNldCBuZWVkcyB0byBtYXRjaFxuICAvLyBpbiBvcmRlciBmb3IgaXQgdG8gYmUgdmFsaWQuICBJZiBuZWdhdGluZywgdGhlbiBqdXN0IG9uZVxuICAvLyBtYXRjaCBtZWFucyB0aGF0IHdlIGhhdmUgZmFpbGVkLlxuICAvLyBFaXRoZXIgd2F5LCByZXR1cm4gb24gdGhlIGZpcnN0IGhpdC5cblxuICB2YXIgc2V0ID0gdGhpcy5zZXRcbiAgdGhpcy5kZWJ1Zyh0aGlzLnBhdHRlcm4sICdzZXQnLCBzZXQpXG5cbiAgLy8gRmluZCB0aGUgYmFzZW5hbWUgb2YgdGhlIHBhdGggYnkgbG9va2luZyBmb3IgdGhlIGxhc3Qgbm9uLWVtcHR5IHNlZ21lbnRcbiAgdmFyIGZpbGVuYW1lXG4gIHZhciBpXG4gIGZvciAoaSA9IGYubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICBmaWxlbmFtZSA9IGZbaV1cbiAgICBpZiAoZmlsZW5hbWUpIGJyZWFrXG4gIH1cblxuICBmb3IgKGkgPSAwOyBpIDwgc2V0Lmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIHBhdHRlcm4gPSBzZXRbaV1cbiAgICB2YXIgZmlsZSA9IGZcbiAgICBpZiAob3B0aW9ucy5tYXRjaEJhc2UgJiYgcGF0dGVybi5sZW5ndGggPT09IDEpIHtcbiAgICAgIGZpbGUgPSBbZmlsZW5hbWVdXG4gICAgfVxuICAgIHZhciBoaXQgPSB0aGlzLm1hdGNoT25lKGZpbGUsIHBhdHRlcm4sIHBhcnRpYWwpXG4gICAgaWYgKGhpdCkge1xuICAgICAgaWYgKG9wdGlvbnMuZmxpcE5lZ2F0ZSkgcmV0dXJuIHRydWVcbiAgICAgIHJldHVybiAhdGhpcy5uZWdhdGVcbiAgICB9XG4gIH1cblxuICAvLyBkaWRuJ3QgZ2V0IGFueSBoaXRzLiAgdGhpcyBpcyBzdWNjZXNzIGlmIGl0J3MgYSBuZWdhdGl2ZVxuICAvLyBwYXR0ZXJuLCBmYWlsdXJlIG90aGVyd2lzZS5cbiAgaWYgKG9wdGlvbnMuZmxpcE5lZ2F0ZSkgcmV0dXJuIGZhbHNlXG4gIHJldHVybiB0aGlzLm5lZ2F0ZVxufVxuXG4vLyBzZXQgcGFydGlhbCB0byB0cnVlIHRvIHRlc3QgaWYsIGZvciBleGFtcGxlLFxuLy8gXCIvYS9iXCIgbWF0Y2hlcyB0aGUgc3RhcnQgb2YgXCIvKi9iLyovZFwiXG4vLyBQYXJ0aWFsIG1lYW5zLCBpZiB5b3UgcnVuIG91dCBvZiBmaWxlIGJlZm9yZSB5b3UgcnVuXG4vLyBvdXQgb2YgcGF0dGVybiwgdGhlbiB0aGF0J3MgZmluZSwgYXMgbG9uZyBhcyBhbGxcbi8vIHRoZSBwYXJ0cyBtYXRjaC5cbk1pbmltYXRjaC5wcm90b3R5cGUubWF0Y2hPbmUgPSBmdW5jdGlvbiAoZmlsZSwgcGF0dGVybiwgcGFydGlhbCkge1xuICB2YXIgb3B0aW9ucyA9IHRoaXMub3B0aW9uc1xuXG4gIHRoaXMuZGVidWcoJ21hdGNoT25lJyxcbiAgICB7ICd0aGlzJzogdGhpcywgZmlsZTogZmlsZSwgcGF0dGVybjogcGF0dGVybiB9KVxuXG4gIHRoaXMuZGVidWcoJ21hdGNoT25lJywgZmlsZS5sZW5ndGgsIHBhdHRlcm4ubGVuZ3RoKVxuXG4gIGZvciAodmFyIGZpID0gMCxcbiAgICAgIHBpID0gMCxcbiAgICAgIGZsID0gZmlsZS5sZW5ndGgsXG4gICAgICBwbCA9IHBhdHRlcm4ubGVuZ3RoXG4gICAgICA7IChmaSA8IGZsKSAmJiAocGkgPCBwbClcbiAgICAgIDsgZmkrKywgcGkrKykge1xuICAgIHRoaXMuZGVidWcoJ21hdGNoT25lIGxvb3AnKVxuICAgIHZhciBwID0gcGF0dGVybltwaV1cbiAgICB2YXIgZiA9IGZpbGVbZmldXG5cbiAgICB0aGlzLmRlYnVnKHBhdHRlcm4sIHAsIGYpXG5cbiAgICAvLyBzaG91bGQgYmUgaW1wb3NzaWJsZS5cbiAgICAvLyBzb21lIGludmFsaWQgcmVnZXhwIHN0dWZmIGluIHRoZSBzZXQuXG4gICAgaWYgKHAgPT09IGZhbHNlKSByZXR1cm4gZmFsc2VcblxuICAgIGlmIChwID09PSBHTE9CU1RBUikge1xuICAgICAgdGhpcy5kZWJ1ZygnR0xPQlNUQVInLCBbcGF0dGVybiwgcCwgZl0pXG5cbiAgICAgIC8vIFwiKipcIlxuICAgICAgLy8gYS8qKi9iLyoqL2Mgd291bGQgbWF0Y2ggdGhlIGZvbGxvd2luZzpcbiAgICAgIC8vIGEvYi94L3kvei9jXG4gICAgICAvLyBhL3gveS96L2IvY1xuICAgICAgLy8gYS9iL3gvYi94L2NcbiAgICAgIC8vIGEvYi9jXG4gICAgICAvLyBUbyBkbyB0aGlzLCB0YWtlIHRoZSByZXN0IG9mIHRoZSBwYXR0ZXJuIGFmdGVyXG4gICAgICAvLyB0aGUgKiosIGFuZCBzZWUgaWYgaXQgd291bGQgbWF0Y2ggdGhlIGZpbGUgcmVtYWluZGVyLlxuICAgICAgLy8gSWYgc28sIHJldHVybiBzdWNjZXNzLlxuICAgICAgLy8gSWYgbm90LCB0aGUgKiogXCJzd2FsbG93c1wiIGEgc2VnbWVudCwgYW5kIHRyeSBhZ2Fpbi5cbiAgICAgIC8vIFRoaXMgaXMgcmVjdXJzaXZlbHkgYXdmdWwuXG4gICAgICAvL1xuICAgICAgLy8gYS8qKi9iLyoqL2MgbWF0Y2hpbmcgYS9iL3gveS96L2NcbiAgICAgIC8vIC0gYSBtYXRjaGVzIGFcbiAgICAgIC8vIC0gZG91Ymxlc3RhclxuICAgICAgLy8gICAtIG1hdGNoT25lKGIveC95L3ovYywgYi8qKi9jKVxuICAgICAgLy8gICAgIC0gYiBtYXRjaGVzIGJcbiAgICAgIC8vICAgICAtIGRvdWJsZXN0YXJcbiAgICAgIC8vICAgICAgIC0gbWF0Y2hPbmUoeC95L3ovYywgYykgLT4gbm9cbiAgICAgIC8vICAgICAgIC0gbWF0Y2hPbmUoeS96L2MsIGMpIC0+IG5vXG4gICAgICAvLyAgICAgICAtIG1hdGNoT25lKHovYywgYykgLT4gbm9cbiAgICAgIC8vICAgICAgIC0gbWF0Y2hPbmUoYywgYykgeWVzLCBoaXRcbiAgICAgIHZhciBmciA9IGZpXG4gICAgICB2YXIgcHIgPSBwaSArIDFcbiAgICAgIGlmIChwciA9PT0gcGwpIHtcbiAgICAgICAgdGhpcy5kZWJ1ZygnKiogYXQgdGhlIGVuZCcpXG4gICAgICAgIC8vIGEgKiogYXQgdGhlIGVuZCB3aWxsIGp1c3Qgc3dhbGxvdyB0aGUgcmVzdC5cbiAgICAgICAgLy8gV2UgaGF2ZSBmb3VuZCBhIG1hdGNoLlxuICAgICAgICAvLyBob3dldmVyLCBpdCB3aWxsIG5vdCBzd2FsbG93IC8ueCwgdW5sZXNzXG4gICAgICAgIC8vIG9wdGlvbnMuZG90IGlzIHNldC5cbiAgICAgICAgLy8gLiBhbmQgLi4gYXJlICpuZXZlciogbWF0Y2hlZCBieSAqKiwgZm9yIGV4cGxvc2l2ZWx5XG4gICAgICAgIC8vIGV4cG9uZW50aWFsIHJlYXNvbnMuXG4gICAgICAgIGZvciAoOyBmaSA8IGZsOyBmaSsrKSB7XG4gICAgICAgICAgaWYgKGZpbGVbZmldID09PSAnLicgfHwgZmlsZVtmaV0gPT09ICcuLicgfHxcbiAgICAgICAgICAgICghb3B0aW9ucy5kb3QgJiYgZmlsZVtmaV0uY2hhckF0KDApID09PSAnLicpKSByZXR1cm4gZmFsc2VcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgfVxuXG4gICAgICAvLyBvaywgbGV0J3Mgc2VlIGlmIHdlIGNhbiBzd2FsbG93IHdoYXRldmVyIHdlIGNhbi5cbiAgICAgIHdoaWxlIChmciA8IGZsKSB7XG4gICAgICAgIHZhciBzd2FsbG93ZWUgPSBmaWxlW2ZyXVxuXG4gICAgICAgIHRoaXMuZGVidWcoJ1xcbmdsb2JzdGFyIHdoaWxlJywgZmlsZSwgZnIsIHBhdHRlcm4sIHByLCBzd2FsbG93ZWUpXG5cbiAgICAgICAgLy8gWFhYIHJlbW92ZSB0aGlzIHNsaWNlLiAgSnVzdCBwYXNzIHRoZSBzdGFydCBpbmRleC5cbiAgICAgICAgaWYgKHRoaXMubWF0Y2hPbmUoZmlsZS5zbGljZShmciksIHBhdHRlcm4uc2xpY2UocHIpLCBwYXJ0aWFsKSkge1xuICAgICAgICAgIHRoaXMuZGVidWcoJ2dsb2JzdGFyIGZvdW5kIG1hdGNoIScsIGZyLCBmbCwgc3dhbGxvd2VlKVxuICAgICAgICAgIC8vIGZvdW5kIGEgbWF0Y2guXG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBjYW4ndCBzd2FsbG93IFwiLlwiIG9yIFwiLi5cIiBldmVyLlxuICAgICAgICAgIC8vIGNhbiBvbmx5IHN3YWxsb3cgXCIuZm9vXCIgd2hlbiBleHBsaWNpdGx5IGFza2VkLlxuICAgICAgICAgIGlmIChzd2FsbG93ZWUgPT09ICcuJyB8fCBzd2FsbG93ZWUgPT09ICcuLicgfHxcbiAgICAgICAgICAgICghb3B0aW9ucy5kb3QgJiYgc3dhbGxvd2VlLmNoYXJBdCgwKSA9PT0gJy4nKSkge1xuICAgICAgICAgICAgdGhpcy5kZWJ1ZygnZG90IGRldGVjdGVkIScsIGZpbGUsIGZyLCBwYXR0ZXJuLCBwcilcbiAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gKiogc3dhbGxvd3MgYSBzZWdtZW50LCBhbmQgY29udGludWUuXG4gICAgICAgICAgdGhpcy5kZWJ1ZygnZ2xvYnN0YXIgc3dhbGxvdyBhIHNlZ21lbnQsIGFuZCBjb250aW51ZScpXG4gICAgICAgICAgZnIrK1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIG5vIG1hdGNoIHdhcyBmb3VuZC5cbiAgICAgIC8vIEhvd2V2ZXIsIGluIHBhcnRpYWwgbW9kZSwgd2UgY2FuJ3Qgc2F5IHRoaXMgaXMgbmVjZXNzYXJpbHkgb3Zlci5cbiAgICAgIC8vIElmIHRoZXJlJ3MgbW9yZSAqcGF0dGVybiogbGVmdCwgdGhlblxuICAgICAgaWYgKHBhcnRpYWwpIHtcbiAgICAgICAgLy8gcmFuIG91dCBvZiBmaWxlXG4gICAgICAgIHRoaXMuZGVidWcoJ1xcbj4+PiBubyBtYXRjaCwgcGFydGlhbD8nLCBmaWxlLCBmciwgcGF0dGVybiwgcHIpXG4gICAgICAgIGlmIChmciA9PT0gZmwpIHJldHVybiB0cnVlXG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG5cbiAgICAvLyBzb21ldGhpbmcgb3RoZXIgdGhhbiAqKlxuICAgIC8vIG5vbi1tYWdpYyBwYXR0ZXJucyBqdXN0IGhhdmUgdG8gbWF0Y2ggZXhhY3RseVxuICAgIC8vIHBhdHRlcm5zIHdpdGggbWFnaWMgaGF2ZSBiZWVuIHR1cm5lZCBpbnRvIHJlZ2V4cHMuXG4gICAgdmFyIGhpdFxuICAgIGlmICh0eXBlb2YgcCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGlmIChvcHRpb25zLm5vY2FzZSkge1xuICAgICAgICBoaXQgPSBmLnRvTG93ZXJDYXNlKCkgPT09IHAudG9Mb3dlckNhc2UoKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaGl0ID0gZiA9PT0gcFxuICAgICAgfVxuICAgICAgdGhpcy5kZWJ1Zygnc3RyaW5nIG1hdGNoJywgcCwgZiwgaGl0KVxuICAgIH0gZWxzZSB7XG4gICAgICBoaXQgPSBmLm1hdGNoKHApXG4gICAgICB0aGlzLmRlYnVnKCdwYXR0ZXJuIG1hdGNoJywgcCwgZiwgaGl0KVxuICAgIH1cblxuICAgIGlmICghaGl0KSByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIC8vIE5vdGU6IGVuZGluZyBpbiAvIG1lYW5zIHRoYXQgd2UnbGwgZ2V0IGEgZmluYWwgXCJcIlxuICAvLyBhdCB0aGUgZW5kIG9mIHRoZSBwYXR0ZXJuLiAgVGhpcyBjYW4gb25seSBtYXRjaCBhXG4gIC8vIGNvcnJlc3BvbmRpbmcgXCJcIiBhdCB0aGUgZW5kIG9mIHRoZSBmaWxlLlxuICAvLyBJZiB0aGUgZmlsZSBlbmRzIGluIC8sIHRoZW4gaXQgY2FuIG9ubHkgbWF0Y2ggYVxuICAvLyBhIHBhdHRlcm4gdGhhdCBlbmRzIGluIC8sIHVubGVzcyB0aGUgcGF0dGVybiBqdXN0XG4gIC8vIGRvZXNuJ3QgaGF2ZSBhbnkgbW9yZSBmb3IgaXQuIEJ1dCwgYS9iLyBzaG91bGQgKm5vdCpcbiAgLy8gbWF0Y2ggXCJhL2IvKlwiLCBldmVuIHRob3VnaCBcIlwiIG1hdGNoZXMgYWdhaW5zdCB0aGVcbiAgLy8gW14vXSo/IHBhdHRlcm4sIGV4Y2VwdCBpbiBwYXJ0aWFsIG1vZGUsIHdoZXJlIGl0IG1pZ2h0XG4gIC8vIHNpbXBseSBub3QgYmUgcmVhY2hlZCB5ZXQuXG4gIC8vIEhvd2V2ZXIsIGEvYi8gc2hvdWxkIHN0aWxsIHNhdGlzZnkgYS8qXG5cbiAgLy8gbm93IGVpdGhlciB3ZSBmZWxsIG9mZiB0aGUgZW5kIG9mIHRoZSBwYXR0ZXJuLCBvciB3ZSdyZSBkb25lLlxuICBpZiAoZmkgPT09IGZsICYmIHBpID09PSBwbCkge1xuICAgIC8vIHJhbiBvdXQgb2YgcGF0dGVybiBhbmQgZmlsZW5hbWUgYXQgdGhlIHNhbWUgdGltZS5cbiAgICAvLyBhbiBleGFjdCBoaXQhXG4gICAgcmV0dXJuIHRydWVcbiAgfSBlbHNlIGlmIChmaSA9PT0gZmwpIHtcbiAgICAvLyByYW4gb3V0IG9mIGZpbGUsIGJ1dCBzdGlsbCBoYWQgcGF0dGVybiBsZWZ0LlxuICAgIC8vIHRoaXMgaXMgb2sgaWYgd2UncmUgZG9pbmcgdGhlIG1hdGNoIGFzIHBhcnQgb2ZcbiAgICAvLyBhIGdsb2IgZnMgdHJhdmVyc2FsLlxuICAgIHJldHVybiBwYXJ0aWFsXG4gIH0gZWxzZSBpZiAocGkgPT09IHBsKSB7XG4gICAgLy8gcmFuIG91dCBvZiBwYXR0ZXJuLCBzdGlsbCBoYXZlIGZpbGUgbGVmdC5cbiAgICAvLyB0aGlzIGlzIG9ubHkgYWNjZXB0YWJsZSBpZiB3ZSdyZSBvbiB0aGUgdmVyeSBsYXN0XG4gICAgLy8gZW1wdHkgc2VnbWVudCBvZiBhIGZpbGUgd2l0aCBhIHRyYWlsaW5nIHNsYXNoLlxuICAgIC8vIGEvKiBzaG91bGQgbWF0Y2ggYS9iL1xuICAgIHZhciBlbXB0eUZpbGVFbmQgPSAoZmkgPT09IGZsIC0gMSkgJiYgKGZpbGVbZmldID09PSAnJylcbiAgICByZXR1cm4gZW1wdHlGaWxlRW5kXG4gIH1cblxuICAvLyBzaG91bGQgYmUgdW5yZWFjaGFibGUuXG4gIHRocm93IG5ldyBFcnJvcignd3RmPycpXG59XG5cbi8vIHJlcGxhY2Ugc3R1ZmYgbGlrZSBcXCogd2l0aCAqXG5mdW5jdGlvbiBnbG9iVW5lc2NhcGUgKHMpIHtcbiAgcmV0dXJuIHMucmVwbGFjZSgvXFxcXCguKS9nLCAnJDEnKVxufVxuXG5mdW5jdGlvbiByZWdFeHBFc2NhcGUgKHMpIHtcbiAgcmV0dXJuIHMucmVwbGFjZSgvWy1bXFxde30oKSorPy4sXFxcXF4kfCNcXHNdL2csICdcXFxcJCYnKVxufVxuIiwidmFyIHdyYXBweSA9IHJlcXVpcmUoJ3dyYXBweScpXG5tb2R1bGUuZXhwb3J0cyA9IHdyYXBweShvbmNlKVxubW9kdWxlLmV4cG9ydHMuc3RyaWN0ID0gd3JhcHB5KG9uY2VTdHJpY3QpXG5cbm9uY2UucHJvdG8gPSBvbmNlKGZ1bmN0aW9uICgpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KEZ1bmN0aW9uLnByb3RvdHlwZSwgJ29uY2UnLCB7XG4gICAgdmFsdWU6IGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBvbmNlKHRoaXMpXG4gICAgfSxcbiAgICBjb25maWd1cmFibGU6IHRydWVcbiAgfSlcblxuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoRnVuY3Rpb24ucHJvdG90eXBlLCAnb25jZVN0cmljdCcsIHtcbiAgICB2YWx1ZTogZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIG9uY2VTdHJpY3QodGhpcylcbiAgICB9LFxuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICB9KVxufSlcblxuZnVuY3Rpb24gb25jZSAoZm4pIHtcbiAgdmFyIGYgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKGYuY2FsbGVkKSByZXR1cm4gZi52YWx1ZVxuICAgIGYuY2FsbGVkID0gdHJ1ZVxuICAgIHJldHVybiBmLnZhbHVlID0gZm4uYXBwbHkodGhpcywgYXJndW1lbnRzKVxuICB9XG4gIGYuY2FsbGVkID0gZmFsc2VcbiAgcmV0dXJuIGZcbn1cblxuZnVuY3Rpb24gb25jZVN0cmljdCAoZm4pIHtcbiAgdmFyIGYgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKGYuY2FsbGVkKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKGYub25jZUVycm9yKVxuICAgIGYuY2FsbGVkID0gdHJ1ZVxuICAgIHJldHVybiBmLnZhbHVlID0gZm4uYXBwbHkodGhpcywgYXJndW1lbnRzKVxuICB9XG4gIHZhciBuYW1lID0gZm4ubmFtZSB8fCAnRnVuY3Rpb24gd3JhcHBlZCB3aXRoIGBvbmNlYCdcbiAgZi5vbmNlRXJyb3IgPSBuYW1lICsgXCIgc2hvdWxkbid0IGJlIGNhbGxlZCBtb3JlIHRoYW4gb25jZVwiXG4gIGYuY2FsbGVkID0gZmFsc2VcbiAgcmV0dXJuIGZcbn1cbiIsInZhciBhc3NlcnQgPSByZXF1aXJlKCdhc3NlcnQnKVxuXG52YXIgUmVhZGVyID0gbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbihvcHRpb25zKSB7XG4gIC8vVE9ETyAtIHJlbW92ZSBmb3IgdmVyc2lvbiAxLjBcbiAgaWYodHlwZW9mIG9wdGlvbnMgPT0gJ251bWJlcicpIHtcbiAgICBvcHRpb25zID0geyBoZWFkZXJTaXplOiBvcHRpb25zIH1cbiAgfVxuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fVxuICB0aGlzLm9mZnNldCA9IDBcbiAgdGhpcy5sYXN0Q2h1bmsgPSBmYWxzZVxuICB0aGlzLmNodW5rID0gbnVsbFxuICB0aGlzLmNodW5rTGVuZ3RoID0gMFxuICB0aGlzLmhlYWRlclNpemUgPSBvcHRpb25zLmhlYWRlclNpemUgfHwgMFxuICB0aGlzLmxlbmd0aFBhZGRpbmcgPSBvcHRpb25zLmxlbmd0aFBhZGRpbmcgfHwgMFxuICB0aGlzLmhlYWRlciA9IG51bGxcbiAgYXNzZXJ0KHRoaXMuaGVhZGVyU2l6ZSA8IDIsICdwcmUtbGVuZ3RoIGhlYWRlciBvZiBtb3JlIHRoYW4gMSBieXRlIGxlbmd0aCBub3QgY3VycmVudGx5IHN1cHBvcnRlZCcpXG59XG5cblJlYWRlci5wcm90b3R5cGUuYWRkQ2h1bmsgPSBmdW5jdGlvbihjaHVuaykge1xuICBpZiAoIXRoaXMuY2h1bmsgfHwgdGhpcy5vZmZzZXQgPT09IHRoaXMuY2h1bmtMZW5ndGgpIHtcbiAgICB0aGlzLmNodW5rID0gY2h1bmtcbiAgICB0aGlzLmNodW5rTGVuZ3RoID0gY2h1bmsubGVuZ3RoXG4gICAgdGhpcy5vZmZzZXQgPSAwXG4gICAgcmV0dXJuXG4gIH1cblxuICB2YXIgbmV3Q2h1bmtMZW5ndGggPSBjaHVuay5sZW5ndGhcbiAgdmFyIG5ld0xlbmd0aCA9IHRoaXMuY2h1bmtMZW5ndGggKyBuZXdDaHVua0xlbmd0aFxuXG4gIGlmIChuZXdMZW5ndGggPiB0aGlzLmNodW5rLmxlbmd0aCkge1xuICAgIHZhciBuZXdCdWZmZXJMZW5ndGggPSB0aGlzLmNodW5rLmxlbmd0aCAqIDJcbiAgICB3aGlsZSAobmV3TGVuZ3RoID49IG5ld0J1ZmZlckxlbmd0aCkge1xuICAgICAgbmV3QnVmZmVyTGVuZ3RoICo9IDJcbiAgICB9XG4gICAgdmFyIG5ld0J1ZmZlciA9IG5ldyBCdWZmZXIobmV3QnVmZmVyTGVuZ3RoKVxuICAgIHRoaXMuY2h1bmsuY29weShuZXdCdWZmZXIpXG4gICAgdGhpcy5jaHVuayA9IG5ld0J1ZmZlclxuICB9XG4gIGNodW5rLmNvcHkodGhpcy5jaHVuaywgdGhpcy5jaHVua0xlbmd0aClcbiAgdGhpcy5jaHVua0xlbmd0aCA9IG5ld0xlbmd0aFxufVxuXG5SZWFkZXIucHJvdG90eXBlLnJlYWQgPSBmdW5jdGlvbigpIHtcbiAgaWYodGhpcy5jaHVua0xlbmd0aCA8ICh0aGlzLmhlYWRlclNpemUgKyA0ICsgdGhpcy5vZmZzZXQpKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBpZih0aGlzLmhlYWRlclNpemUpIHtcbiAgICB0aGlzLmhlYWRlciA9IHRoaXMuY2h1bmtbdGhpcy5vZmZzZXRdXG4gIH1cblxuICAvL3JlYWQgbGVuZ3RoIG9mIG5leHQgaXRlbVxuICB2YXIgbGVuZ3RoID0gdGhpcy5jaHVuay5yZWFkVUludDMyQkUodGhpcy5vZmZzZXQgKyB0aGlzLmhlYWRlclNpemUpICsgdGhpcy5sZW5ndGhQYWRkaW5nXG5cbiAgLy9uZXh0IGl0ZW0gc3BhbnMgbW9yZSBjaHVua3MgdGhhbiB3ZSBoYXZlXG4gIHZhciByZW1haW5pbmcgPSB0aGlzLmNodW5rTGVuZ3RoIC0gKHRoaXMub2Zmc2V0ICsgNCArIHRoaXMuaGVhZGVyU2l6ZSlcbiAgaWYobGVuZ3RoID4gcmVtYWluaW5nKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICB0aGlzLm9mZnNldCArPSAodGhpcy5oZWFkZXJTaXplICsgNClcbiAgdmFyIHJlc3VsdCA9IHRoaXMuY2h1bmsuc2xpY2UodGhpcy5vZmZzZXQsIHRoaXMub2Zmc2V0ICsgbGVuZ3RoKVxuICB0aGlzLm9mZnNldCArPSBsZW5ndGhcbiAgcmV0dXJuIHJlc3VsdFxufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5mdW5jdGlvbiBwb3NpeChwYXRoKSB7XG5cdHJldHVybiBwYXRoLmNoYXJBdCgwKSA9PT0gJy8nO1xufVxuXG5mdW5jdGlvbiB3aW4zMihwYXRoKSB7XG5cdC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9ub2RlanMvbm9kZS9ibG9iL2IzZmNjMjQ1ZmIyNTUzOTkwOWVmMWQ1ZWFhMDFkYmY5MmUxNjg2MzMvbGliL3BhdGguanMjTDU2XG5cdHZhciBzcGxpdERldmljZVJlID0gL14oW2EtekEtWl06fFtcXFxcXFwvXXsyfVteXFxcXFxcL10rW1xcXFxcXC9dK1teXFxcXFxcL10rKT8oW1xcXFxcXC9dKT8oW1xcc1xcU10qPykkLztcblx0dmFyIHJlc3VsdCA9IHNwbGl0RGV2aWNlUmUuZXhlYyhwYXRoKTtcblx0dmFyIGRldmljZSA9IHJlc3VsdFsxXSB8fCAnJztcblx0dmFyIGlzVW5jID0gQm9vbGVhbihkZXZpY2UgJiYgZGV2aWNlLmNoYXJBdCgxKSAhPT0gJzonKTtcblxuXHQvLyBVTkMgcGF0aHMgYXJlIGFsd2F5cyBhYnNvbHV0ZVxuXHRyZXR1cm4gQm9vbGVhbihyZXN1bHRbMl0gfHwgaXNVbmMpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHByb2Nlc3MucGxhdGZvcm0gPT09ICd3aW4zMicgPyB3aW4zMiA6IHBvc2l4O1xubW9kdWxlLmV4cG9ydHMucG9zaXggPSBwb3NpeDtcbm1vZHVsZS5leHBvcnRzLndpbjMyID0gd2luMzI7XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciB1cmwgPSByZXF1aXJlKCd1cmwnKTtcblxuLy9QYXJzZSBtZXRob2QgY29waWVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2JyaWFuYy9ub2RlLXBvc3RncmVzXG4vL0NvcHlyaWdodCAoYykgMjAxMC0yMDE0IEJyaWFuIENhcmxzb24gKGJyaWFuLm0uY2FybHNvbkBnbWFpbC5jb20pXG4vL01JVCBMaWNlbnNlXG5cbi8vcGFyc2VzIGEgY29ubmVjdGlvbiBzdHJpbmdcbmZ1bmN0aW9uIHBhcnNlKHN0cikge1xuICB2YXIgY29uZmlnO1xuICAvL3VuaXggc29ja2V0XG4gIGlmKHN0ci5jaGFyQXQoMCkgPT09ICcvJykge1xuICAgIGNvbmZpZyA9IHN0ci5zcGxpdCgnICcpO1xuICAgIHJldHVybiB7IGhvc3Q6IGNvbmZpZ1swXSwgZGF0YWJhc2U6IGNvbmZpZ1sxXSB9O1xuICB9XG4gIC8vIHVybCBwYXJzZSBleHBlY3RzIHNwYWNlcyBlbmNvZGVkIGFzICUyMFxuICBpZigvIHwlW15hLWYwLTldfCVbYS1mMC05XVteYS1mMC05XS9pLnRlc3Qoc3RyKSkge1xuICAgIHN0ciA9IGVuY29kZVVSSShzdHIpLnJlcGxhY2UoL1xcJTI1KFxcZFxcZCkvZywgXCIlJDFcIik7XG4gIH1cbiAgdmFyIHJlc3VsdCA9IHVybC5wYXJzZShzdHIsIHRydWUpO1xuICBjb25maWcgPSB7fTtcblxuICBpZiAocmVzdWx0LnF1ZXJ5LmFwcGxpY2F0aW9uX25hbWUpIHtcbiAgICBjb25maWcuYXBwbGljYXRpb25fbmFtZSA9IHJlc3VsdC5xdWVyeS5hcHBsaWNhdGlvbl9uYW1lO1xuICB9XG4gIGlmIChyZXN1bHQucXVlcnkuZmFsbGJhY2tfYXBwbGljYXRpb25fbmFtZSkge1xuICAgIGNvbmZpZy5mYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lID0gcmVzdWx0LnF1ZXJ5LmZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWU7XG4gIH1cblxuICBjb25maWcucG9ydCA9IHJlc3VsdC5wb3J0O1xuICBpZihyZXN1bHQucHJvdG9jb2wgPT0gJ3NvY2tldDonKSB7XG4gICAgY29uZmlnLmhvc3QgPSBkZWNvZGVVUkkocmVzdWx0LnBhdGhuYW1lKTtcbiAgICBjb25maWcuZGF0YWJhc2UgPSByZXN1bHQucXVlcnkuZGI7XG4gICAgY29uZmlnLmNsaWVudF9lbmNvZGluZyA9IHJlc3VsdC5xdWVyeS5lbmNvZGluZztcbiAgICByZXR1cm4gY29uZmlnO1xuICB9XG4gIGNvbmZpZy5ob3N0ID0gcmVzdWx0Lmhvc3RuYW1lO1xuXG4gIC8vIHJlc3VsdC5wYXRobmFtZSBpcyBub3QgYWx3YXlzIGd1YXJhbnRlZWQgdG8gaGF2ZSBhICcvJyBwcmVmaXggKGUuZy4gcmVsYXRpdmUgdXJscylcbiAgLy8gb25seSBzdHJpcCB0aGUgc2xhc2ggaWYgaXQgaXMgcHJlc2VudC5cbiAgdmFyIHBhdGhuYW1lID0gcmVzdWx0LnBhdGhuYW1lO1xuICBpZiAocGF0aG5hbWUgJiYgcGF0aG5hbWUuY2hhckF0KDApID09PSAnLycpIHtcbiAgICBwYXRobmFtZSA9IHJlc3VsdC5wYXRobmFtZS5zbGljZSgxKSB8fCBudWxsO1xuICB9XG4gIGNvbmZpZy5kYXRhYmFzZSA9IHBhdGhuYW1lICYmIGRlY29kZVVSSShwYXRobmFtZSk7XG5cbiAgdmFyIGF1dGggPSAocmVzdWx0LmF1dGggfHwgJzonKS5zcGxpdCgnOicpO1xuICBjb25maWcudXNlciA9IGF1dGhbMF07XG4gIGNvbmZpZy5wYXNzd29yZCA9IGF1dGguc3BsaWNlKDEpLmpvaW4oJzonKTtcblxuICB2YXIgc3NsID0gcmVzdWx0LnF1ZXJ5LnNzbDtcbiAgaWYgKHNzbCA9PT0gJ3RydWUnIHx8IHNzbCA9PT0gJzEnKSB7XG4gICAgY29uZmlnLnNzbCA9IHRydWU7XG4gIH1cblxuICByZXR1cm4gY29uZmlnO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgcGFyc2U6IHBhcnNlXG59O1xuIiwiJ3VzZSBzdHJpY3QnXG5jb25zdCBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcblxuY29uc3QgTk9PUCA9IGZ1bmN0aW9uICgpIHsgfVxuXG5jb25zdCByZW1vdmVXaGVyZSA9IChsaXN0LCBwcmVkaWNhdGUpID0+IHtcbiAgY29uc3QgaSA9IGxpc3QuZmluZEluZGV4KHByZWRpY2F0ZSlcblxuICByZXR1cm4gaSA9PT0gLTFcbiAgICA/IHVuZGVmaW5lZFxuICAgIDogbGlzdC5zcGxpY2UoaSwgMSlbMF1cbn1cblxuY2xhc3MgSWRsZUl0ZW0ge1xuICBjb25zdHJ1Y3RvciAoY2xpZW50LCB0aW1lb3V0SWQpIHtcbiAgICB0aGlzLmNsaWVudCA9IGNsaWVudFxuICAgIHRoaXMudGltZW91dElkID0gdGltZW91dElkXG4gIH1cbn1cblxuZnVuY3Rpb24gdGhyb3dPblJlbGVhc2UgKCkge1xuICB0aHJvdyBuZXcgRXJyb3IoJ1JlbGVhc2UgY2FsbGVkIG9uIGNsaWVudCB3aGljaCBoYXMgYWxyZWFkeSBiZWVuIHJlbGVhc2VkIHRvIHRoZSBwb29sLicpXG59XG5cbmZ1bmN0aW9uIHJlbGVhc2UgKGNsaWVudCwgZXJyKSB7XG4gIGNsaWVudC5yZWxlYXNlID0gdGhyb3dPblJlbGVhc2VcbiAgaWYgKGVyciB8fCB0aGlzLmVuZGluZykge1xuICAgIHRoaXMuX3JlbW92ZShjbGllbnQpXG4gICAgdGhpcy5fcHVsc2VRdWV1ZSgpXG4gICAgcmV0dXJuXG4gIH1cblxuICAvLyBpZGxlIHRpbWVvdXRcbiAgbGV0IHRpZFxuICBpZiAodGhpcy5vcHRpb25zLmlkbGVUaW1lb3V0TWlsbGlzKSB7XG4gICAgdGlkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLmxvZygncmVtb3ZlIGlkbGUgY2xpZW50JylcbiAgICAgIHRoaXMuX3JlbW92ZShjbGllbnQpXG4gICAgfSwgdGhpcy5vcHRpb25zLmlkbGVUaW1lb3V0TWlsbGlzKVxuICB9XG5cbiAgdGhpcy5faWRsZS5wdXNoKG5ldyBJZGxlSXRlbShjbGllbnQsIHRpZCkpXG4gIHRoaXMuX3B1bHNlUXVldWUoKVxufVxuXG5mdW5jdGlvbiBwcm9taXNpZnkgKFByb21pc2UsIGNhbGxiYWNrKSB7XG4gIGlmIChjYWxsYmFjaykge1xuICAgIHJldHVybiB7IGNhbGxiYWNrOiBjYWxsYmFjaywgcmVzdWx0OiB1bmRlZmluZWQgfVxuICB9XG4gIGxldCByZWpcbiAgbGV0IHJlc1xuICBjb25zdCBjYiA9IGZ1bmN0aW9uIChlcnIsIGNsaWVudCkge1xuICAgIGVyciA/IHJlaihlcnIpIDogcmVzKGNsaWVudClcbiAgfVxuICBjb25zdCByZXN1bHQgPSBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgcmVzID0gcmVzb2x2ZVxuICAgIHJlaiA9IHJlamVjdFxuICB9KVxuICByZXR1cm4geyBjYWxsYmFjazogY2IsIHJlc3VsdDogcmVzdWx0IH1cbn1cblxuY2xhc3MgUG9vbCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yIChvcHRpb25zLCBDbGllbnQpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy5vcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucylcbiAgICB0aGlzLm9wdGlvbnMubWF4ID0gdGhpcy5vcHRpb25zLm1heCB8fCB0aGlzLm9wdGlvbnMucG9vbFNpemUgfHwgMTBcbiAgICB0aGlzLmxvZyA9IHRoaXMub3B0aW9ucy5sb2cgfHwgZnVuY3Rpb24gKCkgeyB9XG4gICAgdGhpcy5DbGllbnQgPSB0aGlzLm9wdGlvbnMuQ2xpZW50IHx8IENsaWVudCB8fCByZXF1aXJlKCdwZycpLkNsaWVudFxuICAgIHRoaXMuUHJvbWlzZSA9IHRoaXMub3B0aW9ucy5Qcm9taXNlIHx8IGdsb2JhbC5Qcm9taXNlXG5cbiAgICBpZiAodHlwZW9mIHRoaXMub3B0aW9ucy5pZGxlVGltZW91dE1pbGxpcyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHRoaXMub3B0aW9ucy5pZGxlVGltZW91dE1pbGxpcyA9IDEwMDAwXG4gICAgfVxuXG4gICAgdGhpcy5fY2xpZW50cyA9IFtdXG4gICAgdGhpcy5faWRsZSA9IFtdXG4gICAgdGhpcy5fcGVuZGluZ1F1ZXVlID0gW11cbiAgICB0aGlzLl9lbmRDYWxsYmFjayA9IHVuZGVmaW5lZFxuICAgIHRoaXMuZW5kaW5nID0gZmFsc2VcbiAgfVxuXG4gIF9pc0Z1bGwgKCkge1xuICAgIHJldHVybiB0aGlzLl9jbGllbnRzLmxlbmd0aCA+PSB0aGlzLm9wdGlvbnMubWF4XG4gIH1cblxuICBfcHVsc2VRdWV1ZSAoKSB7XG4gICAgdGhpcy5sb2coJ3B1bHNlIHF1ZXVlJylcbiAgICBpZiAodGhpcy5lbmRpbmcpIHtcbiAgICAgIHRoaXMubG9nKCdwdWxzZSBxdWV1ZSBvbiBlbmRpbmcnKVxuICAgICAgaWYgKHRoaXMuX2lkbGUubGVuZ3RoKSB7XG4gICAgICAgIHRoaXMuX2lkbGUuc2xpY2UoKS5tYXAoaXRlbSA9PiB7XG4gICAgICAgICAgdGhpcy5fcmVtb3ZlKGl0ZW0uY2xpZW50KVxuICAgICAgICB9KVxuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLl9jbGllbnRzLmxlbmd0aCkge1xuICAgICAgICB0aGlzLl9lbmRDYWxsYmFjaygpXG4gICAgICB9XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgLy8gaWYgd2UgZG9uJ3QgaGF2ZSBhbnkgd2FpdGluZywgZG8gbm90aGluZ1xuICAgIGlmICghdGhpcy5fcGVuZGluZ1F1ZXVlLmxlbmd0aCkge1xuICAgICAgdGhpcy5sb2coJ25vIHF1ZXVlZCByZXF1ZXN0cycpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgLy8gaWYgd2UgZG9uJ3QgaGF2ZSBhbnkgaWRsZSBjbGllbnRzIGFuZCB3ZSBoYXZlIG5vIG1vcmUgcm9vbSBkbyBub3RoaW5nXG4gICAgaWYgKCF0aGlzLl9pZGxlLmxlbmd0aCAmJiB0aGlzLl9pc0Z1bGwoKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGNvbnN0IHdhaXRlciA9IHRoaXMuX3BlbmRpbmdRdWV1ZS5zaGlmdCgpXG4gICAgaWYgKHRoaXMuX2lkbGUubGVuZ3RoKSB7XG4gICAgICBjb25zdCBpZGxlSXRlbSA9IHRoaXMuX2lkbGUucG9wKClcbiAgICAgIGNsZWFyVGltZW91dChpZGxlSXRlbS50aW1lb3V0SWQpXG4gICAgICBjb25zdCBjbGllbnQgPSBpZGxlSXRlbS5jbGllbnRcbiAgICAgIGNsaWVudC5yZWxlYXNlID0gcmVsZWFzZS5iaW5kKHRoaXMsIGNsaWVudClcbiAgICAgIHRoaXMuZW1pdCgnYWNxdWlyZScsIGNsaWVudClcbiAgICAgIHJldHVybiB3YWl0ZXIodW5kZWZpbmVkLCBjbGllbnQsIGNsaWVudC5yZWxlYXNlKVxuICAgIH1cbiAgICBpZiAoIXRoaXMuX2lzRnVsbCgpKSB7XG4gICAgICByZXR1cm4gdGhpcy5jb25uZWN0KHdhaXRlcilcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKCd1bmV4cGVjdGVkIGNvbmRpdGlvbicpXG4gIH1cblxuICBfcmVtb3ZlIChjbGllbnQpIHtcbiAgICBjb25zdCByZW1vdmVkID0gcmVtb3ZlV2hlcmUoXG4gICAgICB0aGlzLl9pZGxlLFxuICAgICAgaXRlbSA9PiBpdGVtLmNsaWVudCA9PT0gY2xpZW50XG4gICAgKVxuXG4gICAgaWYgKHJlbW92ZWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgY2xlYXJUaW1lb3V0KHJlbW92ZWQudGltZW91dElkKVxuICAgIH1cblxuICAgIHRoaXMuX2NsaWVudHMgPSB0aGlzLl9jbGllbnRzLmZpbHRlcihjID0+IGMgIT09IGNsaWVudClcbiAgICBjbGllbnQuZW5kKClcbiAgICB0aGlzLmVtaXQoJ3JlbW92ZScsIGNsaWVudClcbiAgfVxuXG4gIGNvbm5lY3QgKGNiKSB7XG4gICAgaWYgKHRoaXMuZW5kaW5nKSB7XG4gICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoJ0Nhbm5vdCB1c2UgYSBwb29sIGFmdGVyIGNhbGxpbmcgZW5kIG9uIHRoZSBwb29sJylcbiAgICAgIHJldHVybiBjYiA/IGNiKGVycikgOiB0aGlzLlByb21pc2UucmVqZWN0KGVycilcbiAgICB9XG5cbiAgICAvLyBpZiB3ZSBkb24ndCBoYXZlIHRvIGNvbm5lY3QgYSBuZXcgY2xpZW50LCBkb24ndCBkbyBzb1xuICAgIGlmICh0aGlzLl9jbGllbnRzLmxlbmd0aCA+PSB0aGlzLm9wdGlvbnMubWF4IHx8IHRoaXMuX2lkbGUubGVuZ3RoKSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IHByb21pc2lmeSh0aGlzLlByb21pc2UsIGNiKVxuICAgICAgY29uc3QgcmVzdWx0ID0gcmVzcG9uc2UucmVzdWx0XG5cbiAgICAgIC8vIGlmIHdlIGhhdmUgaWRsZSBjbGllbnRzIHNjaGVkdWxlIGEgcHVsc2UgaW1tZWRpYXRlbHlcbiAgICAgIGlmICh0aGlzLl9pZGxlLmxlbmd0aCkge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHRoaXMuX3B1bHNlUXVldWUoKSlcbiAgICAgIH1cblxuICAgICAgaWYgKCF0aGlzLm9wdGlvbnMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpIHtcbiAgICAgICAgdGhpcy5fcGVuZGluZ1F1ZXVlLnB1c2gocmVzcG9uc2UuY2FsbGJhY2spXG4gICAgICAgIHJldHVybiByZXN1bHRcbiAgICAgIH1cblxuICAgICAgLy8gc2V0IGNvbm5lY3Rpb24gdGltZW91dCBvbiBjaGVja2luZyBvdXQgYW4gZXhpc3RpbmcgY2xpZW50XG4gICAgICBjb25zdCB0aWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgLy8gcmVtb3ZlIHRoZSBjYWxsYmFjayBmcm9tIHBlbmRpbmcgd2FpdGVycyBiZWNhdXNlXG4gICAgICAgIC8vIHdlJ3JlIGdvaW5nIHRvIGNhbGwgaXQgd2l0aCBhIHRpbWVvdXQgZXJyb3JcbiAgICAgICAgdGhpcy5fcGVuZGluZ1F1ZXVlID0gdGhpcy5fcGVuZGluZ1F1ZXVlLmZpbHRlcihjYiA9PiBjYiA9PT0gcmVzcG9uc2UuY2FsbGJhY2spXG4gICAgICAgIHJlc3BvbnNlLmNhbGxiYWNrKG5ldyBFcnJvcigndGltZW91dCBleGNlZWRlZCB3aGVuIHRyeWluZyB0byBjb25uZWN0JykpXG4gICAgICB9LCB0aGlzLm9wdGlvbnMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpXG5cbiAgICAgIHRoaXMuX3BlbmRpbmdRdWV1ZS5wdXNoKGZ1bmN0aW9uIChlcnIsIHJlcywgZG9uZSkge1xuICAgICAgICBjbGVhclRpbWVvdXQodGlkKVxuICAgICAgICByZXNwb25zZS5jYWxsYmFjayhlcnIsIHJlcywgZG9uZSlcbiAgICAgIH0pXG4gICAgICByZXR1cm4gcmVzdWx0XG4gICAgfVxuXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IHRoaXMuQ2xpZW50KHRoaXMub3B0aW9ucylcbiAgICB0aGlzLl9jbGllbnRzLnB1c2goY2xpZW50KVxuICAgIGNvbnN0IGlkbGVMaXN0ZW5lciA9IChlcnIpID0+IHtcbiAgICAgIGVyci5jbGllbnQgPSBjbGllbnRcbiAgICAgIGNsaWVudC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBpZGxlTGlzdGVuZXIpXG4gICAgICBjbGllbnQub24oJ2Vycm9yJywgKCkgPT4ge1xuICAgICAgICB0aGlzLmxvZygnYWRkaXRpb25hbCBjbGllbnQgZXJyb3IgYWZ0ZXIgZGlzY29ubmVjdGlvbiBkdWUgdG8gZXJyb3InLCBlcnIpXG4gICAgICB9KVxuICAgICAgdGhpcy5fcmVtb3ZlKGNsaWVudClcbiAgICAgIC8vIFRPRE8gLSBkb2N1bWVudCB0aGF0IG9uY2UgdGhlIHBvb2wgZW1pdHMgYW4gZXJyb3JcbiAgICAgIC8vIHRoZSBjbGllbnQgaGFzIGFscmVhZHkgYmVlbiBjbG9zZWQgJiBwdXJnZWQgYW5kIGlzIHVudXNhYmxlXG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyLCBjbGllbnQpXG4gICAgfVxuXG4gICAgdGhpcy5sb2coJ2Nvbm5lY3RpbmcgbmV3IGNsaWVudCcpXG5cbiAgICAvLyBjb25uZWN0aW9uIHRpbWVvdXQgbG9naWNcbiAgICBsZXQgdGlkXG4gICAgbGV0IHRpbWVvdXRIaXQgPSBmYWxzZVxuICAgIGlmICh0aGlzLm9wdGlvbnMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpIHtcbiAgICAgIHRpZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLmxvZygnZW5kaW5nIGNsaWVudCBkdWUgdG8gdGltZW91dCcpXG4gICAgICAgIHRpbWVvdXRIaXQgPSB0cnVlXG4gICAgICAgIC8vIGZvcmNlIGtpbGwgdGhlIG5vZGUgZHJpdmVyLCBhbmQgbGV0IGxpYnBxIGRvIGl0cyB0ZWFyZG93blxuICAgICAgICBjbGllbnQuY29ubmVjdGlvbiA/IGNsaWVudC5jb25uZWN0aW9uLnN0cmVhbS5kZXN0cm95KCkgOiBjbGllbnQuZW5kKClcbiAgICAgIH0sIHRoaXMub3B0aW9ucy5jb25uZWN0aW9uVGltZW91dE1pbGxpcylcbiAgICB9XG5cbiAgICBjb25zdCByZXNwb25zZSA9IHByb21pc2lmeSh0aGlzLlByb21pc2UsIGNiKVxuICAgIGNiID0gcmVzcG9uc2UuY2FsbGJhY2tcblxuICAgIHRoaXMubG9nKCdjb25uZWN0aW5nIG5ldyBjbGllbnQnKVxuICAgIGNsaWVudC5jb25uZWN0KChlcnIpID0+IHtcbiAgICAgIHRoaXMubG9nKCduZXcgY2xpZW50IGNvbm5lY3RlZCcpXG4gICAgICBpZiAodGlkKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aWQpXG4gICAgICB9XG4gICAgICBjbGllbnQub24oJ2Vycm9yJywgaWRsZUxpc3RlbmVyKVxuICAgICAgaWYgKGVycikge1xuICAgICAgICAvLyByZW1vdmUgdGhlIGRlYWQgY2xpZW50IGZyb20gb3VyIGxpc3Qgb2YgY2xpZW50c1xuICAgICAgICB0aGlzLl9jbGllbnRzID0gdGhpcy5fY2xpZW50cy5maWx0ZXIoYyA9PiBjICE9PSBjbGllbnQpXG4gICAgICAgIGlmICh0aW1lb3V0SGl0KSB7XG4gICAgICAgICAgZXJyLm1lc3NhZ2UgPSAnQ29ubmVjdGlvbiB0ZXJtaW5pYXRlZCBkdWUgdG8gY29ubmVjdGlvbiB0aW1lb3V0J1xuICAgICAgICB9XG4gICAgICAgIGNiKGVyciwgdW5kZWZpbmVkLCBOT09QKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2xpZW50LnJlbGVhc2UgPSByZWxlYXNlLmJpbmQodGhpcywgY2xpZW50KVxuICAgICAgICB0aGlzLmVtaXQoJ2Nvbm5lY3QnLCBjbGllbnQpXG4gICAgICAgIHRoaXMuZW1pdCgnYWNxdWlyZScsIGNsaWVudClcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy52ZXJpZnkpIHtcbiAgICAgICAgICB0aGlzLm9wdGlvbnMudmVyaWZ5KGNsaWVudCwgY2IpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2IodW5kZWZpbmVkLCBjbGllbnQsIGNsaWVudC5yZWxlYXNlKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcbiAgICByZXR1cm4gcmVzcG9uc2UucmVzdWx0XG4gIH1cblxuICBxdWVyeSAodGV4dCwgdmFsdWVzLCBjYikge1xuICAgIC8vIGd1YXJkIGNsYXVzZSBhZ2FpbnN0IHBhc3NpbmcgYSBmdW5jdGlvbiBhcyB0aGUgZmlyc3QgcGFyYW1ldGVyXG4gICAgaWYgKHR5cGVvZiB0ZXh0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IHByb21pc2lmeSh0aGlzLlByb21pc2UsIHRleHQpXG4gICAgICBzZXRJbW1lZGlhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY2FsbGJhY2sobmV3IEVycm9yKCdQYXNzaW5nIGEgZnVuY3Rpb24gYXMgdGhlIGZpcnN0IHBhcmFtZXRlciB0byBwb29sLnF1ZXJ5IGlzIG5vdCBzdXBwb3J0ZWQnKSlcbiAgICAgIH0pXG4gICAgICByZXR1cm4gcmVzcG9uc2UucmVzdWx0XG4gICAgfVxuXG4gICAgLy8gYWxsb3cgcGxhaW4gdGV4dCBxdWVyeSB3aXRob3V0IHZhbHVlc1xuICAgIGlmICh0eXBlb2YgdmFsdWVzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjYiA9IHZhbHVlc1xuICAgICAgdmFsdWVzID0gdW5kZWZpbmVkXG4gICAgfVxuICAgIGNvbnN0IHJlc3BvbnNlID0gcHJvbWlzaWZ5KHRoaXMuUHJvbWlzZSwgY2IpXG4gICAgY2IgPSByZXNwb25zZS5jYWxsYmFja1xuICAgIHRoaXMuY29ubmVjdCgoZXJyLCBjbGllbnQpID0+IHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgcmV0dXJuIGNiKGVycilcbiAgICAgIH1cbiAgICAgIHRoaXMubG9nKCdkaXNwYXRjaGluZyBxdWVyeScpXG4gICAgICBjbGllbnQucXVlcnkodGV4dCwgdmFsdWVzLCAoZXJyLCByZXMpID0+IHtcbiAgICAgICAgdGhpcy5sb2coJ3F1ZXJ5IGRpc3BhdGNoZWQnKVxuICAgICAgICBjbGllbnQucmVsZWFzZShlcnIpXG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICByZXR1cm4gY2IoZXJyKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBjYih1bmRlZmluZWQsIHJlcylcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9KVxuICAgIHJldHVybiByZXNwb25zZS5yZXN1bHRcbiAgfVxuXG4gIGVuZCAoY2IpIHtcbiAgICB0aGlzLmxvZygnZW5kaW5nJylcbiAgICBpZiAodGhpcy5lbmRpbmcpIHtcbiAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcignQ2FsbGVkIGVuZCBvbiBwb29sIG1vcmUgdGhhbiBvbmNlJylcbiAgICAgIHJldHVybiBjYiA/IGNiKGVycikgOiB0aGlzLlByb21pc2UucmVqZWN0KGVycilcbiAgICB9XG4gICAgdGhpcy5lbmRpbmcgPSB0cnVlXG4gICAgY29uc3QgcHJvbWlzZWQgPSBwcm9taXNpZnkodGhpcy5Qcm9taXNlLCBjYilcbiAgICB0aGlzLl9lbmRDYWxsYmFjayA9IHByb21pc2VkLmNhbGxiYWNrXG4gICAgdGhpcy5fcHVsc2VRdWV1ZSgpXG4gICAgcmV0dXJuIHByb21pc2VkLnJlc3VsdFxuICB9XG5cbiAgZ2V0IHdhaXRpbmdDb3VudCAoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BlbmRpbmdRdWV1ZS5sZW5ndGhcbiAgfVxuXG4gIGdldCBpZGxlQ291bnQgKCkge1xuICAgIHJldHVybiB0aGlzLl9pZGxlLmxlbmd0aFxuICB9XG5cbiAgZ2V0IHRvdGFsQ291bnQgKCkge1xuICAgIHJldHVybiB0aGlzLl9jbGllbnRzLmxlbmd0aFxuICB9XG59XG5tb2R1bGUuZXhwb3J0cyA9IFBvb2xcbiIsInZhciB0ZXh0UGFyc2VycyA9IHJlcXVpcmUoJy4vbGliL3RleHRQYXJzZXJzJyk7XG52YXIgYmluYXJ5UGFyc2VycyA9IHJlcXVpcmUoJy4vbGliL2JpbmFyeVBhcnNlcnMnKTtcbnZhciBhcnJheVBhcnNlciA9IHJlcXVpcmUoJy4vbGliL2FycmF5UGFyc2VyJyk7XG5cbmV4cG9ydHMuZ2V0VHlwZVBhcnNlciA9IGdldFR5cGVQYXJzZXI7XG5leHBvcnRzLnNldFR5cGVQYXJzZXIgPSBzZXRUeXBlUGFyc2VyO1xuZXhwb3J0cy5hcnJheVBhcnNlciA9IGFycmF5UGFyc2VyO1xuXG52YXIgdHlwZVBhcnNlcnMgPSB7XG4gIHRleHQ6IHt9LFxuICBiaW5hcnk6IHt9XG59O1xuXG4vL3RoZSBlbXB0eSBwYXJzZSBmdW5jdGlvblxuZnVuY3Rpb24gbm9QYXJzZSAodmFsKSB7XG4gIHJldHVybiBTdHJpbmcodmFsKTtcbn07XG5cbi8vcmV0dXJucyBhIGZ1bmN0aW9uIHVzZWQgdG8gY29udmVydCBhIHNwZWNpZmljIHR5cGUgKHNwZWNpZmllZCBieVxuLy9vaWQpIGludG8gYSByZXN1bHQgamF2YXNjcmlwdCB0eXBlXG4vL25vdGU6IHRoZSBvaWQgY2FuIGJlIG9idGFpbmVkIHZpYSB0aGUgZm9sbG93aW5nIHNxbCBxdWVyeTpcbi8vU0VMRUNUIG9pZCBGUk9NIHBnX3R5cGUgV0hFUkUgdHlwbmFtZSA9ICdUWVBFX05BTUVfSEVSRSc7XG5mdW5jdGlvbiBnZXRUeXBlUGFyc2VyIChvaWQsIGZvcm1hdCkge1xuICBmb3JtYXQgPSBmb3JtYXQgfHwgJ3RleHQnO1xuICBpZiAoIXR5cGVQYXJzZXJzW2Zvcm1hdF0pIHtcbiAgICByZXR1cm4gbm9QYXJzZTtcbiAgfVxuICByZXR1cm4gdHlwZVBhcnNlcnNbZm9ybWF0XVtvaWRdIHx8IG5vUGFyc2U7XG59O1xuXG5mdW5jdGlvbiBzZXRUeXBlUGFyc2VyIChvaWQsIGZvcm1hdCwgcGFyc2VGbikge1xuICBpZih0eXBlb2YgZm9ybWF0ID09ICdmdW5jdGlvbicpIHtcbiAgICBwYXJzZUZuID0gZm9ybWF0O1xuICAgIGZvcm1hdCA9ICd0ZXh0JztcbiAgfVxuICB0eXBlUGFyc2Vyc1tmb3JtYXRdW29pZF0gPSBwYXJzZUZuO1xufTtcblxudGV4dFBhcnNlcnMuaW5pdChmdW5jdGlvbihvaWQsIGNvbnZlcnRlcikge1xuICB0eXBlUGFyc2Vycy50ZXh0W29pZF0gPSBjb252ZXJ0ZXI7XG59KTtcblxuYmluYXJ5UGFyc2Vycy5pbml0KGZ1bmN0aW9uKG9pZCwgY29udmVydGVyKSB7XG4gIHR5cGVQYXJzZXJzLmJpbmFyeVtvaWRdID0gY29udmVydGVyO1xufSk7XG4iLCJ2YXIgYXJyYXkgPSByZXF1aXJlKCdwb3N0Z3Jlcy1hcnJheScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgY3JlYXRlOiBmdW5jdGlvbiAoc291cmNlLCB0cmFuc2Zvcm0pIHtcbiAgICByZXR1cm4ge1xuICAgICAgcGFyc2U6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gYXJyYXkucGFyc2Uoc291cmNlLCB0cmFuc2Zvcm0pO1xuICAgICAgfVxuICAgIH07XG4gIH1cbn07XG4iLCJ2YXIgcGFyc2VCaXRzID0gZnVuY3Rpb24oZGF0YSwgYml0cywgb2Zmc2V0LCBpbnZlcnQsIGNhbGxiYWNrKSB7XG4gIG9mZnNldCA9IG9mZnNldCB8fCAwO1xuICBpbnZlcnQgPSBpbnZlcnQgfHwgZmFsc2U7XG4gIGNhbGxiYWNrID0gY2FsbGJhY2sgfHwgZnVuY3Rpb24obGFzdFZhbHVlLCBuZXdWYWx1ZSwgYml0cykgeyByZXR1cm4gKGxhc3RWYWx1ZSAqIE1hdGgucG93KDIsIGJpdHMpKSArIG5ld1ZhbHVlOyB9O1xuICB2YXIgb2Zmc2V0Qnl0ZXMgPSBvZmZzZXQgPj4gMztcblxuICB2YXIgaW52ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgICBpZiAoaW52ZXJ0KSB7XG4gICAgICByZXR1cm4gfnZhbHVlICYgMHhmZjtcbiAgICB9XG5cbiAgICByZXR1cm4gdmFsdWU7XG4gIH07XG5cbiAgLy8gcmVhZCBmaXJzdCAobWF5YmUgcGFydGlhbCkgYnl0ZVxuICB2YXIgbWFzayA9IDB4ZmY7XG4gIHZhciBmaXJzdEJpdHMgPSA4IC0gKG9mZnNldCAlIDgpO1xuICBpZiAoYml0cyA8IGZpcnN0Qml0cykge1xuICAgIG1hc2sgPSAoMHhmZiA8PCAoOCAtIGJpdHMpKSAmIDB4ZmY7XG4gICAgZmlyc3RCaXRzID0gYml0cztcbiAgfVxuXG4gIGlmIChvZmZzZXQpIHtcbiAgICBtYXNrID0gbWFzayA+PiAob2Zmc2V0ICUgOCk7XG4gIH1cblxuICB2YXIgcmVzdWx0ID0gMDtcbiAgaWYgKChvZmZzZXQgJSA4KSArIGJpdHMgPj0gOCkge1xuICAgIHJlc3VsdCA9IGNhbGxiYWNrKDAsIGludihkYXRhW29mZnNldEJ5dGVzXSkgJiBtYXNrLCBmaXJzdEJpdHMpO1xuICB9XG5cbiAgLy8gcmVhZCBieXRlc1xuICB2YXIgYnl0ZXMgPSAoYml0cyArIG9mZnNldCkgPj4gMztcbiAgZm9yICh2YXIgaSA9IG9mZnNldEJ5dGVzICsgMTsgaSA8IGJ5dGVzOyBpKyspIHtcbiAgICByZXN1bHQgPSBjYWxsYmFjayhyZXN1bHQsIGludihkYXRhW2ldKSwgOCk7XG4gIH1cblxuICAvLyBiaXRzIHRvIHJlYWQsIHRoYXQgYXJlIG5vdCBhIGNvbXBsZXRlIGJ5dGVcbiAgdmFyIGxhc3RCaXRzID0gKGJpdHMgKyBvZmZzZXQpICUgODtcbiAgaWYgKGxhc3RCaXRzID4gMCkge1xuICAgIHJlc3VsdCA9IGNhbGxiYWNrKHJlc3VsdCwgaW52KGRhdGFbYnl0ZXNdKSA+PiAoOCAtIGxhc3RCaXRzKSwgbGFzdEJpdHMpO1xuICB9XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbnZhciBwYXJzZUZsb2F0RnJvbUJpdHMgPSBmdW5jdGlvbihkYXRhLCBwcmVjaXNpb25CaXRzLCBleHBvbmVudEJpdHMpIHtcbiAgdmFyIGJpYXMgPSBNYXRoLnBvdygyLCBleHBvbmVudEJpdHMgLSAxKSAtIDE7XG4gIHZhciBzaWduID0gcGFyc2VCaXRzKGRhdGEsIDEpO1xuICB2YXIgZXhwb25lbnQgPSBwYXJzZUJpdHMoZGF0YSwgZXhwb25lbnRCaXRzLCAxKTtcblxuICBpZiAoZXhwb25lbnQgPT09IDApIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuXG4gIC8vIHBhcnNlIG1hbnRpc3NhXG4gIHZhciBwcmVjaXNpb25CaXRzQ291bnRlciA9IDE7XG4gIHZhciBwYXJzZVByZWNpc2lvbkJpdHMgPSBmdW5jdGlvbihsYXN0VmFsdWUsIG5ld1ZhbHVlLCBiaXRzKSB7XG4gICAgaWYgKGxhc3RWYWx1ZSA9PT0gMCkge1xuICAgICAgbGFzdFZhbHVlID0gMTtcbiAgICB9XG5cbiAgICBmb3IgKHZhciBpID0gMTsgaSA8PSBiaXRzOyBpKyspIHtcbiAgICAgIHByZWNpc2lvbkJpdHNDb3VudGVyIC89IDI7XG4gICAgICBpZiAoKG5ld1ZhbHVlICYgKDB4MSA8PCAoYml0cyAtIGkpKSkgPiAwKSB7XG4gICAgICAgIGxhc3RWYWx1ZSArPSBwcmVjaXNpb25CaXRzQ291bnRlcjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbGFzdFZhbHVlO1xuICB9O1xuXG4gIHZhciBtYW50aXNzYSA9IHBhcnNlQml0cyhkYXRhLCBwcmVjaXNpb25CaXRzLCBleHBvbmVudEJpdHMgKyAxLCBmYWxzZSwgcGFyc2VQcmVjaXNpb25CaXRzKTtcblxuICAvLyBzcGVjaWFsIGNhc2VzXG4gIGlmIChleHBvbmVudCA9PSAoTWF0aC5wb3coMiwgZXhwb25lbnRCaXRzICsgMSkgLSAxKSkge1xuICAgIGlmIChtYW50aXNzYSA9PT0gMCkge1xuICAgICAgcmV0dXJuIChzaWduID09PSAwKSA/IEluZmluaXR5IDogLUluZmluaXR5O1xuICAgIH1cblxuICAgIHJldHVybiBOYU47XG4gIH1cblxuICAvLyBub3JtYWxlIG51bWJlclxuICByZXR1cm4gKChzaWduID09PSAwKSA/IDEgOiAtMSkgKiBNYXRoLnBvdygyLCBleHBvbmVudCAtIGJpYXMpICogbWFudGlzc2E7XG59O1xuXG52YXIgcGFyc2VJbnQxNiA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmIChwYXJzZUJpdHModmFsdWUsIDEpID09IDEpIHtcbiAgICByZXR1cm4gLTEgKiAocGFyc2VCaXRzKHZhbHVlLCAxNSwgMSwgdHJ1ZSkgKyAxKTtcbiAgfVxuXG4gIHJldHVybiBwYXJzZUJpdHModmFsdWUsIDE1LCAxKTtcbn07XG5cbnZhciBwYXJzZUludDMyID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKHBhcnNlQml0cyh2YWx1ZSwgMSkgPT0gMSkge1xuICAgIHJldHVybiAtMSAqIChwYXJzZUJpdHModmFsdWUsIDMxLCAxLCB0cnVlKSArIDEpO1xuICB9XG5cbiAgcmV0dXJuIHBhcnNlQml0cyh2YWx1ZSwgMzEsIDEpO1xufTtcblxudmFyIHBhcnNlRmxvYXQzMiA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHJldHVybiBwYXJzZUZsb2F0RnJvbUJpdHModmFsdWUsIDIzLCA4KTtcbn07XG5cbnZhciBwYXJzZUZsb2F0NjQgPSBmdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gcGFyc2VGbG9hdEZyb21CaXRzKHZhbHVlLCA1MiwgMTEpO1xufTtcblxudmFyIHBhcnNlTnVtZXJpYyA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHZhciBzaWduID0gcGFyc2VCaXRzKHZhbHVlLCAxNiwgMzIpO1xuICBpZiAoc2lnbiA9PSAweGMwMDApIHtcbiAgICByZXR1cm4gTmFOO1xuICB9XG5cbiAgdmFyIHdlaWdodCA9IE1hdGgucG93KDEwMDAwLCBwYXJzZUJpdHModmFsdWUsIDE2LCAxNikpO1xuICB2YXIgcmVzdWx0ID0gMDtcblxuICB2YXIgZGlnaXRzID0gW107XG4gIHZhciBuZGlnaXRzID0gcGFyc2VCaXRzKHZhbHVlLCAxNik7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbmRpZ2l0czsgaSsrKSB7XG4gICAgcmVzdWx0ICs9IHBhcnNlQml0cyh2YWx1ZSwgMTYsIDY0ICsgKDE2ICogaSkpICogd2VpZ2h0O1xuICAgIHdlaWdodCAvPSAxMDAwMDtcbiAgfVxuXG4gIHZhciBzY2FsZSA9IE1hdGgucG93KDEwLCBwYXJzZUJpdHModmFsdWUsIDE2LCA0OCkpO1xuICByZXR1cm4gKChzaWduID09PSAwKSA/IDEgOiAtMSkgKiBNYXRoLnJvdW5kKHJlc3VsdCAqIHNjYWxlKSAvIHNjYWxlO1xufTtcblxudmFyIHBhcnNlRGF0ZSA9IGZ1bmN0aW9uKGlzVVRDLCB2YWx1ZSkge1xuICB2YXIgc2lnbiA9IHBhcnNlQml0cyh2YWx1ZSwgMSk7XG4gIHZhciByYXdWYWx1ZSA9IHBhcnNlQml0cyh2YWx1ZSwgNjMsIDEpO1xuXG4gIC8vIGRpc2NhcmQgdXNlY3MgYW5kIHNoaWZ0IGZyb20gMjAwMCB0byAxOTcwXG4gIHZhciByZXN1bHQgPSBuZXcgRGF0ZSgoKChzaWduID09PSAwKSA/IDEgOiAtMSkgKiByYXdWYWx1ZSAvIDEwMDApICsgOTQ2Njg0ODAwMDAwKTtcblxuICBpZiAoIWlzVVRDKSB7XG4gICAgcmVzdWx0LnNldFRpbWUocmVzdWx0LmdldFRpbWUoKSArIHJlc3VsdC5nZXRUaW1lem9uZU9mZnNldCgpICogNjAwMDApO1xuICB9XG5cbiAgLy8gYWRkIG1pY3Jvc2Vjb25kcyB0byB0aGUgZGF0ZVxuICByZXN1bHQudXNlYyA9IHJhd1ZhbHVlICUgMTAwMDtcbiAgcmVzdWx0LmdldE1pY3JvU2Vjb25kcyA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnVzZWM7XG4gIH07XG4gIHJlc3VsdC5zZXRNaWNyb1NlY29uZHMgPSBmdW5jdGlvbih2YWx1ZSkge1xuICAgIHRoaXMudXNlYyA9IHZhbHVlO1xuICB9O1xuICByZXN1bHQuZ2V0VVRDTWljcm9TZWNvbmRzID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMudXNlYztcbiAgfTtcblxuICByZXR1cm4gcmVzdWx0O1xufTtcblxudmFyIHBhcnNlQXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICB2YXIgZGltID0gcGFyc2VCaXRzKHZhbHVlLCAzMik7XG5cbiAgdmFyIGZsYWdzID0gcGFyc2VCaXRzKHZhbHVlLCAzMiwgMzIpO1xuICB2YXIgZWxlbWVudFR5cGUgPSBwYXJzZUJpdHModmFsdWUsIDMyLCA2NCk7XG5cbiAgdmFyIG9mZnNldCA9IDk2O1xuICB2YXIgZGltcyA9IFtdO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGRpbTsgaSsrKSB7XG4gICAgLy8gcGFyc2UgZGltZW5zaW9uXG4gICAgZGltc1tpXSA9IHBhcnNlQml0cyh2YWx1ZSwgMzIsIG9mZnNldCk7XG4gICAgb2Zmc2V0ICs9IDMyO1xuXG4gICAgLy8gaWdub3JlIGxvd2VyIGJvdW5kc1xuICAgIG9mZnNldCArPSAzMjtcbiAgfVxuXG4gIHZhciBwYXJzZUVsZW1lbnQgPSBmdW5jdGlvbihlbGVtZW50VHlwZSkge1xuICAgIC8vIHBhcnNlIGNvbnRlbnQgbGVuZ3RoXG4gICAgdmFyIGxlbmd0aCA9IHBhcnNlQml0cyh2YWx1ZSwgMzIsIG9mZnNldCk7XG4gICAgb2Zmc2V0ICs9IDMyO1xuXG4gICAgLy8gcGFyc2UgbnVsbCB2YWx1ZXNcbiAgICBpZiAobGVuZ3RoID09IDB4ZmZmZmZmZmYpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHZhciByZXN1bHQ7XG4gICAgaWYgKChlbGVtZW50VHlwZSA9PSAweDE3KSB8fCAoZWxlbWVudFR5cGUgPT0gMHgxNCkpIHtcbiAgICAgIC8vIGludC9iaWdpbnRcbiAgICAgIHJlc3VsdCA9IHBhcnNlQml0cyh2YWx1ZSwgbGVuZ3RoICogOCwgb2Zmc2V0KTtcbiAgICAgIG9mZnNldCArPSBsZW5ndGggKiA4O1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgZWxzZSBpZiAoZWxlbWVudFR5cGUgPT0gMHgxOSkge1xuICAgICAgLy8gc3RyaW5nXG4gICAgICByZXN1bHQgPSB2YWx1ZS50b1N0cmluZyh0aGlzLmVuY29kaW5nLCBvZmZzZXQgPj4gMywgKG9mZnNldCArPSAobGVuZ3RoIDw8IDMpKSA+PiAzKTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgY29uc29sZS5sb2coXCJFUlJPUjogRWxlbWVudFR5cGUgbm90IGltcGxlbWVudGVkOiBcIiArIGVsZW1lbnRUeXBlKTtcbiAgICB9XG4gIH07XG5cbiAgdmFyIHBhcnNlID0gZnVuY3Rpb24oZGltZW5zaW9uLCBlbGVtZW50VHlwZSkge1xuICAgIHZhciBhcnJheSA9IFtdO1xuICAgIHZhciBpO1xuXG4gICAgaWYgKGRpbWVuc2lvbi5sZW5ndGggPiAxKSB7XG4gICAgICB2YXIgY291bnQgPSBkaW1lbnNpb24uc2hpZnQoKTtcbiAgICAgIGZvciAoaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgICAgIGFycmF5W2ldID0gcGFyc2UoZGltZW5zaW9uLCBlbGVtZW50VHlwZSk7XG4gICAgICB9XG4gICAgICBkaW1lbnNpb24udW5zaGlmdChjb3VudCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZm9yIChpID0gMDsgaSA8IGRpbWVuc2lvblswXTsgaSsrKSB7XG4gICAgICAgIGFycmF5W2ldID0gcGFyc2VFbGVtZW50KGVsZW1lbnRUeXBlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gYXJyYXk7XG4gIH07XG5cbiAgcmV0dXJuIHBhcnNlKGRpbXMsIGVsZW1lbnRUeXBlKTtcbn07XG5cbnZhciBwYXJzZVRleHQgPSBmdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUudG9TdHJpbmcoJ3V0ZjgnKTtcbn07XG5cbnZhciBwYXJzZUJvb2wgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZih2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiAocGFyc2VCaXRzKHZhbHVlLCA4KSA+IDApO1xufTtcblxudmFyIGluaXQgPSBmdW5jdGlvbihyZWdpc3Rlcikge1xuICByZWdpc3RlcigyMSwgcGFyc2VJbnQxNik7XG4gIHJlZ2lzdGVyKDIzLCBwYXJzZUludDMyKTtcbiAgcmVnaXN0ZXIoMjYsIHBhcnNlSW50MzIpO1xuICByZWdpc3RlcigxNzAwLCBwYXJzZU51bWVyaWMpO1xuICByZWdpc3Rlcig3MDAsIHBhcnNlRmxvYXQzMik7XG4gIHJlZ2lzdGVyKDcwMSwgcGFyc2VGbG9hdDY0KTtcbiAgcmVnaXN0ZXIoMTYsIHBhcnNlQm9vbCk7XG4gIHJlZ2lzdGVyKDExMTQsIHBhcnNlRGF0ZS5iaW5kKG51bGwsIGZhbHNlKSk7XG4gIHJlZ2lzdGVyKDExODQsIHBhcnNlRGF0ZS5iaW5kKG51bGwsIHRydWUpKTtcbiAgcmVnaXN0ZXIoMTAwMCwgcGFyc2VBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDcsIHBhcnNlQXJyYXkpO1xuICByZWdpc3RlcigxMDE2LCBwYXJzZUFycmF5KTtcbiAgcmVnaXN0ZXIoMTAwOCwgcGFyc2VBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDksIHBhcnNlQXJyYXkpO1xuICByZWdpc3RlcigyNSwgcGFyc2VUZXh0KTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBpbml0OiBpbml0XG59O1xuIiwidmFyIGFycmF5ID0gcmVxdWlyZSgncG9zdGdyZXMtYXJyYXknKVxudmFyIGFycmF5UGFyc2VyID0gcmVxdWlyZSgnLi9hcnJheVBhcnNlcicpO1xudmFyIHBhcnNlRGF0ZSA9IHJlcXVpcmUoJ3Bvc3RncmVzLWRhdGUnKTtcbnZhciBwYXJzZUludGVydmFsID0gcmVxdWlyZSgncG9zdGdyZXMtaW50ZXJ2YWwnKTtcbnZhciBwYXJzZUJ5dGVBID0gcmVxdWlyZSgncG9zdGdyZXMtYnl0ZWEnKTtcblxuZnVuY3Rpb24gYWxsb3dOdWxsIChmbikge1xuICByZXR1cm4gZnVuY3Rpb24gbnVsbEFsbG93ZWQgKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gdmFsdWVcbiAgICByZXR1cm4gZm4odmFsdWUpXG4gIH1cbn1cblxuZnVuY3Rpb24gcGFyc2VCb29sICh2YWx1ZSkge1xuICBpZiAodmFsdWUgPT09IG51bGwpIHJldHVybiB2YWx1ZVxuICByZXR1cm4gdmFsdWUgPT09ICdUUlVFJyB8fFxuICAgIHZhbHVlID09PSAndCcgfHxcbiAgICB2YWx1ZSA9PT0gJ3RydWUnIHx8XG4gICAgdmFsdWUgPT09ICd5JyB8fFxuICAgIHZhbHVlID09PSAneWVzJyB8fFxuICAgIHZhbHVlID09PSAnb24nIHx8XG4gICAgdmFsdWUgPT09ICcxJztcbn1cblxuZnVuY3Rpb24gcGFyc2VCb29sQXJyYXkgKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgcGFyc2VCb29sKVxufVxuXG5mdW5jdGlvbiBwYXJzZUJhc2VUZW5JbnQgKHN0cmluZykge1xuICByZXR1cm4gcGFyc2VJbnQoc3RyaW5nLCAxMClcbn1cblxuZnVuY3Rpb24gcGFyc2VJbnRlZ2VyQXJyYXkgKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgYWxsb3dOdWxsKHBhcnNlQmFzZVRlbkludCkpXG59XG5cbmZ1bmN0aW9uIHBhcnNlQmlnSW50ZWdlckFycmF5ICh2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSByZXR1cm4gbnVsbFxuICByZXR1cm4gYXJyYXkucGFyc2UodmFsdWUsIGFsbG93TnVsbChmdW5jdGlvbiAoZW50cnkpIHtcbiAgICByZXR1cm4gcGFyc2VCaWdJbnRlZ2VyKGVudHJ5KS50cmltKClcbiAgfSkpXG59XG5cbnZhciBwYXJzZVBvaW50QXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZighdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUsIGZ1bmN0aW9uKGVudHJ5KSB7XG4gICAgaWYoZW50cnkgIT09IG51bGwpIHtcbiAgICAgIGVudHJ5ID0gcGFyc2VQb2ludChlbnRyeSk7XG4gICAgfVxuICAgIHJldHVybiBlbnRyeTtcbiAgfSk7XG5cbiAgcmV0dXJuIHAucGFyc2UoKTtcbn07XG5cbnZhciBwYXJzZUZsb2F0QXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZighdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUsIGZ1bmN0aW9uKGVudHJ5KSB7XG4gICAgaWYoZW50cnkgIT09IG51bGwpIHtcbiAgICAgIGVudHJ5ID0gcGFyc2VGbG9hdChlbnRyeSk7XG4gICAgfVxuICAgIHJldHVybiBlbnRyeTtcbiAgfSk7XG5cbiAgcmV0dXJuIHAucGFyc2UoKTtcbn07XG5cbnZhciBwYXJzZVN0cmluZ0FycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG5cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUpO1xuICByZXR1cm4gcC5wYXJzZSgpO1xufTtcblxudmFyIHBhcnNlRGF0ZUFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHZhciBwID0gYXJyYXlQYXJzZXIuY3JlYXRlKHZhbHVlLCBmdW5jdGlvbihlbnRyeSkge1xuICAgIGlmIChlbnRyeSAhPT0gbnVsbCkge1xuICAgICAgZW50cnkgPSBwYXJzZURhdGUoZW50cnkpO1xuICAgIH1cbiAgICByZXR1cm4gZW50cnk7XG4gIH0pO1xuXG4gIHJldHVybiBwLnBhcnNlKCk7XG59O1xuXG52YXIgcGFyc2VCeXRlQUFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgYWxsb3dOdWxsKHBhcnNlQnl0ZUEpKTtcbn07XG5cbnZhciBwYXJzZUludGVnZXIgPSBmdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gcGFyc2VJbnQodmFsdWUsIDEwKTtcbn07XG5cbnZhciBwYXJzZUJpZ0ludGVnZXIgPSBmdW5jdGlvbih2YWx1ZSkge1xuICB2YXIgdmFsU3RyID0gU3RyaW5nKHZhbHVlKTtcbiAgaWYgKC9eXFxkKyQvLnRlc3QodmFsU3RyKSkgeyByZXR1cm4gdmFsU3RyOyB9XG4gIHJldHVybiB2YWx1ZTtcbn07XG5cbnZhciBwYXJzZUpzb25BcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHZhciBhcnIgPSBwYXJzZVN0cmluZ0FycmF5KHZhbHVlKTtcblxuICBpZiAoIWFycikge1xuICAgIHJldHVybiBhcnI7XG4gIH1cblxuICByZXR1cm4gYXJyLm1hcChmdW5jdGlvbihlbCkgeyByZXR1cm4gSlNPTi5wYXJzZShlbCk7IH0pO1xufTtcblxudmFyIHBhcnNlUG9pbnQgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAodmFsdWVbMF0gIT09ICcoJykgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHZhbHVlID0gdmFsdWUuc3Vic3RyaW5nKCAxLCB2YWx1ZS5sZW5ndGggLSAxICkuc3BsaXQoJywnKTtcblxuICByZXR1cm4ge1xuICAgIHg6IHBhcnNlRmxvYXQodmFsdWVbMF0pXG4gICwgeTogcGFyc2VGbG9hdCh2YWx1ZVsxXSlcbiAgfTtcbn07XG5cbnZhciBwYXJzZUNpcmNsZSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmICh2YWx1ZVswXSAhPT0gJzwnICYmIHZhbHVlWzFdICE9PSAnKCcpIHsgcmV0dXJuIG51bGw7IH1cblxuICB2YXIgcG9pbnQgPSAnKCc7XG4gIHZhciByYWRpdXMgPSAnJztcbiAgdmFyIHBvaW50UGFyc2VkID0gZmFsc2U7XG4gIGZvciAodmFyIGkgPSAyOyBpIDwgdmFsdWUubGVuZ3RoIC0gMTsgaSsrKXtcbiAgICBpZiAoIXBvaW50UGFyc2VkKSB7XG4gICAgICBwb2ludCArPSB2YWx1ZVtpXTtcbiAgICB9XG5cbiAgICBpZiAodmFsdWVbaV0gPT09ICcpJykge1xuICAgICAgcG9pbnRQYXJzZWQgPSB0cnVlO1xuICAgICAgY29udGludWU7XG4gICAgfSBlbHNlIGlmICghcG9pbnRQYXJzZWQpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmICh2YWx1ZVtpXSA9PT0gJywnKXtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIHJhZGl1cyArPSB2YWx1ZVtpXTtcbiAgfVxuICB2YXIgcmVzdWx0ID0gcGFyc2VQb2ludChwb2ludCk7XG4gIHJlc3VsdC5yYWRpdXMgPSBwYXJzZUZsb2F0KHJhZGl1cyk7XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbnZhciBpbml0ID0gZnVuY3Rpb24ocmVnaXN0ZXIpIHtcbiAgcmVnaXN0ZXIoMjAsIHBhcnNlQmlnSW50ZWdlcik7IC8vIGludDhcbiAgcmVnaXN0ZXIoMjEsIHBhcnNlSW50ZWdlcik7IC8vIGludDJcbiAgcmVnaXN0ZXIoMjMsIHBhcnNlSW50ZWdlcik7IC8vIGludDRcbiAgcmVnaXN0ZXIoMjYsIHBhcnNlSW50ZWdlcik7IC8vIG9pZFxuICByZWdpc3Rlcig3MDAsIHBhcnNlRmxvYXQpOyAvLyBmbG9hdDQvcmVhbFxuICByZWdpc3Rlcig3MDEsIHBhcnNlRmxvYXQpOyAvLyBmbG9hdDgvZG91YmxlXG4gIHJlZ2lzdGVyKDE2LCBwYXJzZUJvb2wpO1xuICByZWdpc3RlcigxMDgyLCBwYXJzZURhdGUpOyAvLyBkYXRlXG4gIHJlZ2lzdGVyKDExMTQsIHBhcnNlRGF0ZSk7IC8vIHRpbWVzdGFtcCB3aXRob3V0IHRpbWV6b25lXG4gIHJlZ2lzdGVyKDExODQsIHBhcnNlRGF0ZSk7IC8vIHRpbWVzdGFtcFxuICByZWdpc3Rlcig2MDAsIHBhcnNlUG9pbnQpOyAvLyBwb2ludFxuICByZWdpc3Rlcig2NTEsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyBjaWRyW11cbiAgcmVnaXN0ZXIoNzE4LCBwYXJzZUNpcmNsZSk7IC8vIGNpcmNsZVxuICByZWdpc3RlcigxMDAwLCBwYXJzZUJvb2xBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDEsIHBhcnNlQnl0ZUFBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDUsIHBhcnNlSW50ZWdlckFycmF5KTsgLy8gX2ludDJcbiAgcmVnaXN0ZXIoMTAwNywgcGFyc2VJbnRlZ2VyQXJyYXkpOyAvLyBfaW50NFxuICByZWdpc3RlcigxMDI4LCBwYXJzZUludGVnZXJBcnJheSk7IC8vIG9pZFtdXG4gIHJlZ2lzdGVyKDEwMTYsIHBhcnNlQmlnSW50ZWdlckFycmF5KTsgLy8gX2ludDhcbiAgcmVnaXN0ZXIoMTAxNywgcGFyc2VQb2ludEFycmF5KTsgLy8gcG9pbnRbXVxuICByZWdpc3RlcigxMDIxLCBwYXJzZUZsb2F0QXJyYXkpOyAvLyBfZmxvYXQ0XG4gIHJlZ2lzdGVyKDEwMjIsIHBhcnNlRmxvYXRBcnJheSk7IC8vIF9mbG9hdDhcbiAgcmVnaXN0ZXIoMTIzMSwgcGFyc2VGbG9hdEFycmF5KTsgLy8gX251bWVyaWNcbiAgcmVnaXN0ZXIoMTAxNCwgcGFyc2VTdHJpbmdBcnJheSk7IC8vY2hhclxuICByZWdpc3RlcigxMDE1LCBwYXJzZVN0cmluZ0FycmF5KTsgLy92YXJjaGFyXG4gIHJlZ2lzdGVyKDEwMDgsIHBhcnNlU3RyaW5nQXJyYXkpO1xuICByZWdpc3RlcigxMDA5LCBwYXJzZVN0cmluZ0FycmF5KTtcbiAgcmVnaXN0ZXIoMTA0MCwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIG1hY2FkZHJbXVxuICByZWdpc3RlcigxMDQxLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gaW5ldFtdXG4gIHJlZ2lzdGVyKDExMTUsIHBhcnNlRGF0ZUFycmF5KTsgLy8gdGltZXN0YW1wIHdpdGhvdXQgdGltZSB6b25lW11cbiAgcmVnaXN0ZXIoMTE4MiwgcGFyc2VEYXRlQXJyYXkpOyAvLyBfZGF0ZVxuICByZWdpc3RlcigxMTg1LCBwYXJzZURhdGVBcnJheSk7IC8vIHRpbWVzdGFtcCB3aXRoIHRpbWUgem9uZVtdXG4gIHJlZ2lzdGVyKDExODYsIHBhcnNlSW50ZXJ2YWwpO1xuICByZWdpc3RlcigxNywgcGFyc2VCeXRlQSk7XG4gIHJlZ2lzdGVyKDExNCwgSlNPTi5wYXJzZS5iaW5kKEpTT04pKTsgLy8ganNvblxuICByZWdpc3RlcigzODAyLCBKU09OLnBhcnNlLmJpbmQoSlNPTikpOyAvLyBqc29uYlxuICByZWdpc3RlcigxOTksIHBhcnNlSnNvbkFycmF5KTsgLy8ganNvbltdXG4gIHJlZ2lzdGVyKDM4MDcsIHBhcnNlSnNvbkFycmF5KTsgLy8ganNvbmJbXVxuICByZWdpc3RlcigzOTA3LCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gbnVtcmFuZ2VbXVxuICByZWdpc3RlcigyOTUxLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gdXVpZFtdXG4gIHJlZ2lzdGVyKDc5MSwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIG1vbmV5W11cbiAgcmVnaXN0ZXIoMTE4MywgcGFyc2VTdHJpbmdBcnJheSk7IC8vIHRpbWVbXVxuICByZWdpc3RlcigxMjcwLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gdGltZXR6W11cbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBpbml0OiBpbml0XG59O1xuIiwiJ3VzZSBzdHJpY3QnXG4vKipcbiAqIENvcHlyaWdodCAoYykgMjAxMC0yMDE3IEJyaWFuIENhcmxzb24gKGJyaWFuLm0uY2FybHNvbkBnbWFpbC5jb20pXG4gKiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogUkVBRE1FLm1kIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxudmFyIEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlclxudmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbnZhciB1dGlscyA9IHJlcXVpcmUoJy4vdXRpbHMnKVxudmFyIHBnUGFzcyA9IHJlcXVpcmUoJ3BncGFzcycpXG52YXIgVHlwZU92ZXJyaWRlcyA9IHJlcXVpcmUoJy4vdHlwZS1vdmVycmlkZXMnKVxuXG52YXIgQ29ubmVjdGlvblBhcmFtZXRlcnMgPSByZXF1aXJlKCcuL2Nvbm5lY3Rpb24tcGFyYW1ldGVycycpXG52YXIgUXVlcnkgPSByZXF1aXJlKCcuL3F1ZXJ5JylcbnZhciBkZWZhdWx0cyA9IHJlcXVpcmUoJy4vZGVmYXVsdHMnKVxudmFyIENvbm5lY3Rpb24gPSByZXF1aXJlKCcuL2Nvbm5lY3Rpb24nKVxuXG52YXIgQ2xpZW50ID0gZnVuY3Rpb24gKGNvbmZpZykge1xuICBFdmVudEVtaXR0ZXIuY2FsbCh0aGlzKVxuXG4gIHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMgPSBuZXcgQ29ubmVjdGlvblBhcmFtZXRlcnMoY29uZmlnKVxuICB0aGlzLnVzZXIgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnVzZXJcbiAgdGhpcy5kYXRhYmFzZSA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuZGF0YWJhc2VcbiAgdGhpcy5wb3J0ID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5wb3J0XG4gIHRoaXMuaG9zdCA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuaG9zdFxuICB0aGlzLnBhc3N3b3JkID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5wYXNzd29yZFxuICB0aGlzLnJlcGxpY2F0aW9uID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5yZXBsaWNhdGlvblxuXG4gIHZhciBjID0gY29uZmlnIHx8IHt9XG5cbiAgdGhpcy5fdHlwZXMgPSBuZXcgVHlwZU92ZXJyaWRlcyhjLnR5cGVzKVxuICB0aGlzLl9lbmRpbmcgPSBmYWxzZVxuICB0aGlzLl9jb25uZWN0aW5nID0gZmFsc2VcbiAgdGhpcy5fY29ubmVjdGVkID0gZmFsc2VcbiAgdGhpcy5fY29ubmVjdGlvbkVycm9yID0gZmFsc2VcblxuICB0aGlzLmNvbm5lY3Rpb24gPSBjLmNvbm5lY3Rpb24gfHwgbmV3IENvbm5lY3Rpb24oe1xuICAgIHN0cmVhbTogYy5zdHJlYW0sXG4gICAgc3NsOiB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnNzbCxcbiAgICBrZWVwQWxpdmU6IGMua2VlcEFsaXZlIHx8IGZhbHNlLFxuICAgIGVuY29kaW5nOiB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLmNsaWVudF9lbmNvZGluZyB8fCAndXRmOCdcbiAgfSlcbiAgdGhpcy5xdWVyeVF1ZXVlID0gW11cbiAgdGhpcy5iaW5hcnkgPSBjLmJpbmFyeSB8fCBkZWZhdWx0cy5iaW5hcnlcbiAgdGhpcy5wcm9jZXNzSUQgPSBudWxsXG4gIHRoaXMuc2VjcmV0S2V5ID0gbnVsbFxuICB0aGlzLnNzbCA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuc3NsIHx8IGZhbHNlXG59XG5cbnV0aWwuaW5oZXJpdHMoQ2xpZW50LCBFdmVudEVtaXR0ZXIpXG5cbkNsaWVudC5wcm90b3R5cGUuY29ubmVjdCA9IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICB2YXIgc2VsZiA9IHRoaXNcbiAgdmFyIGNvbiA9IHRoaXMuY29ubmVjdGlvblxuICBpZiAodGhpcy5fY29ubmVjdGluZyB8fCB0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoJ0NsaWVudCBoYXMgYWxyZWFkeSBiZWVuIGNvbm5lY3RlZC4gWW91IGNhbm5vdCByZXVzZSBhIGNsaWVudC4nKVxuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgY2FsbGJhY2soZXJyKVxuICAgICAgcmV0dXJuIHVuZGVmaW5lZFxuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyKVxuICB9XG4gIHRoaXMuX2Nvbm5lY3RpbmcgPSB0cnVlXG5cbiAgaWYgKHRoaXMuaG9zdCAmJiB0aGlzLmhvc3QuaW5kZXhPZignLycpID09PSAwKSB7XG4gICAgY29uLmNvbm5lY3QodGhpcy5ob3N0ICsgJy8ucy5QR1NRTC4nICsgdGhpcy5wb3J0KVxuICB9IGVsc2Uge1xuICAgIGNvbi5jb25uZWN0KHRoaXMucG9ydCwgdGhpcy5ob3N0KVxuICB9XG5cbiAgLy8gb25jZSBjb25uZWN0aW9uIGlzIGVzdGFibGlzaGVkIHNlbmQgc3RhcnR1cCBtZXNzYWdlXG4gIGNvbi5vbignY29ubmVjdCcsIGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoc2VsZi5zc2wpIHtcbiAgICAgIGNvbi5yZXF1ZXN0U3NsKClcbiAgICB9IGVsc2Uge1xuICAgICAgY29uLnN0YXJ0dXAoc2VsZi5nZXRTdGFydHVwQ29uZigpKVxuICAgIH1cbiAgfSlcblxuICBjb24ub24oJ3NzbGNvbm5lY3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgY29uLnN0YXJ0dXAoc2VsZi5nZXRTdGFydHVwQ29uZigpKVxuICB9KVxuXG4gIGZ1bmN0aW9uIGNoZWNrUGdQYXNzIChjYikge1xuICAgIHJldHVybiBmdW5jdGlvbiAobXNnKSB7XG4gICAgICBpZiAoc2VsZi5wYXNzd29yZCAhPT0gbnVsbCkge1xuICAgICAgICBjYihtc2cpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwZ1Bhc3Moc2VsZi5jb25uZWN0aW9uUGFyYW1ldGVycywgZnVuY3Rpb24gKHBhc3MpIHtcbiAgICAgICAgICBpZiAodW5kZWZpbmVkICE9PSBwYXNzKSB7XG4gICAgICAgICAgICBzZWxmLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnBhc3N3b3JkID0gc2VsZi5wYXNzd29yZCA9IHBhc3NcbiAgICAgICAgICB9XG4gICAgICAgICAgY2IobXNnKVxuICAgICAgICB9KVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vIHBhc3N3b3JkIHJlcXVlc3QgaGFuZGxpbmdcbiAgY29uLm9uKCdhdXRoZW50aWNhdGlvbkNsZWFydGV4dFBhc3N3b3JkJywgY2hlY2tQZ1Bhc3MoZnVuY3Rpb24gKCkge1xuICAgIGNvbi5wYXNzd29yZChzZWxmLnBhc3N3b3JkKVxuICB9KSlcblxuICAvLyBwYXNzd29yZCByZXF1ZXN0IGhhbmRsaW5nXG4gIGNvbi5vbignYXV0aGVudGljYXRpb25NRDVQYXNzd29yZCcsIGNoZWNrUGdQYXNzKGZ1bmN0aW9uIChtc2cpIHtcbiAgICBjb24ucGFzc3dvcmQodXRpbHMucG9zdGdyZXNNZDVQYXNzd29yZEhhc2goc2VsZi51c2VyLCBzZWxmLnBhc3N3b3JkLCBtc2cuc2FsdCkpXG4gIH0pKVxuXG4gIGNvbi5vbmNlKCdiYWNrZW5kS2V5RGF0YScsIGZ1bmN0aW9uIChtc2cpIHtcbiAgICBzZWxmLnByb2Nlc3NJRCA9IG1zZy5wcm9jZXNzSURcbiAgICBzZWxmLnNlY3JldEtleSA9IG1zZy5zZWNyZXRLZXlcbiAgfSlcblxuICBjb25zdCBjb25uZWN0aW5nRXJyb3JIYW5kbGVyID0gKGVycikgPT4ge1xuICAgIGlmICh0aGlzLl9jb25uZWN0aW9uRXJyb3IpIHtcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICB0aGlzLl9jb25uZWN0aW9uRXJyb3IgPSB0cnVlXG4gICAgaWYgKGNhbGxiYWNrKSB7XG4gICAgICByZXR1cm4gY2FsbGJhY2soZXJyKVxuICAgIH1cbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxuICB9XG5cbiAgY29uc3QgY29ubmVjdGVkRXJyb3JIYW5kbGVyID0gKGVycikgPT4ge1xuICAgIGlmICh0aGlzLmFjdGl2ZVF1ZXJ5KSB7XG4gICAgICB2YXIgYWN0aXZlUXVlcnkgPSBzZWxmLmFjdGl2ZVF1ZXJ5XG4gICAgICB0aGlzLmFjdGl2ZVF1ZXJ5ID0gbnVsbFxuICAgICAgcmV0dXJuIGFjdGl2ZVF1ZXJ5LmhhbmRsZUVycm9yKGVyciwgY29uKVxuICAgIH1cbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxuICB9XG5cbiAgY29uLm9uKCdlcnJvcicsIGNvbm5lY3RpbmdFcnJvckhhbmRsZXIpXG5cbiAgLy8gaG9vayB1cCBxdWVyeSBoYW5kbGluZyBldmVudHMgdG8gY29ubmVjdGlvblxuICAvLyBhZnRlciB0aGUgY29ubmVjdGlvbiBpbml0aWFsbHkgYmVjb21lcyByZWFkeSBmb3IgcXVlcmllc1xuICBjb24ub25jZSgncmVhZHlGb3JRdWVyeScsIGZ1bmN0aW9uICgpIHtcbiAgICBzZWxmLl9jb25uZWN0aW5nID0gZmFsc2VcbiAgICBzZWxmLl9jb25uZWN0ZWQgPSB0cnVlXG4gICAgc2VsZi5fYXR0YWNoTGlzdGVuZXJzKGNvbilcbiAgICBjb24ucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgY29ubmVjdGluZ0Vycm9ySGFuZGxlcilcbiAgICBjb24ub24oJ2Vycm9yJywgY29ubmVjdGVkRXJyb3JIYW5kbGVyKVxuXG4gICAgLy8gcHJvY2VzcyBwb3NzaWJsZSBjYWxsYmFjayBhcmd1bWVudCB0byBDbGllbnQjY29ubmVjdFxuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgY2FsbGJhY2sobnVsbCwgc2VsZilcbiAgICAgIC8vIHJlbW92ZSBjYWxsYmFjayBmb3IgcHJvcGVyIGVycm9yIGhhbmRsaW5nXG4gICAgICAvLyBhZnRlciB0aGUgY29ubmVjdCBldmVudFxuICAgICAgY2FsbGJhY2sgPSBudWxsXG4gICAgfVxuICAgIHNlbGYuZW1pdCgnY29ubmVjdCcpXG4gIH0pXG5cbiAgY29uLm9uKCdyZWFkeUZvclF1ZXJ5JywgZnVuY3Rpb24gKCkge1xuICAgIHZhciBhY3RpdmVRdWVyeSA9IHNlbGYuYWN0aXZlUXVlcnlcbiAgICBzZWxmLmFjdGl2ZVF1ZXJ5ID0gbnVsbFxuICAgIHNlbGYucmVhZHlGb3JRdWVyeSA9IHRydWVcbiAgICBpZiAoYWN0aXZlUXVlcnkpIHtcbiAgICAgIGFjdGl2ZVF1ZXJ5LmhhbmRsZVJlYWR5Rm9yUXVlcnkoY29uKVxuICAgIH1cbiAgICBzZWxmLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICB9KVxuXG4gIGNvbi5vbmNlKCdlbmQnLCAoKSA9PiB7XG4gICAgaWYgKHRoaXMuYWN0aXZlUXVlcnkpIHtcbiAgICAgIHZhciBkaXNjb25uZWN0RXJyb3IgPSBuZXcgRXJyb3IoJ0Nvbm5lY3Rpb24gdGVybWluYXRlZCcpXG4gICAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZUVycm9yKGRpc2Nvbm5lY3RFcnJvciwgY29uKVxuICAgICAgdGhpcy5hY3RpdmVRdWVyeSA9IG51bGxcbiAgICB9XG4gICAgaWYgKCF0aGlzLl9lbmRpbmcpIHtcbiAgICAgIC8vIGlmIHRoZSBjb25uZWN0aW9uIGlzIGVuZGVkIHdpdGhvdXQgdXMgY2FsbGluZyAuZW5kKClcbiAgICAgIC8vIG9uIHRoaXMgY2xpZW50IHRoZW4gd2UgaGF2ZSBhbiB1bmV4cGVjdGVkIGRpc2Nvbm5lY3Rpb25cbiAgICAgIC8vIHRyZWF0IHRoaXMgYXMgYW4gZXJyb3IgdW5sZXNzIHdlJ3ZlIGFscmVhZHkgZW1pdHRlZCBhbiBlcnJvclxuICAgICAgLy8gZHVyaW5nIGNvbm5lY3Rpb24uXG4gICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignQ29ubmVjdGlvbiB0ZXJtaW5hdGVkIHVuZXhwZWN0ZWRseScpXG4gICAgICBpZiAodGhpcy5fY29ubmVjdGluZyAmJiAhdGhpcy5fY29ubmVjdGlvbkVycm9yKSB7XG4gICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgIGNhbGxiYWNrKGVycm9yKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnJvcilcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICghdGhpcy5fY29ubmVjdGlvbkVycm9yKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnJvcilcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5lbWl0KCdlbmQnKVxuICB9KVxuXG4gIGNvbi5vbignbm90aWNlJywgZnVuY3Rpb24gKG1zZykge1xuICAgIHNlbGYuZW1pdCgnbm90aWNlJywgbXNnKVxuICB9KVxuXG4gIGlmICghY2FsbGJhY2spIHtcbiAgICByZXR1cm4gbmV3IGdsb2JhbC5Qcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMub25jZSgnZXJyb3InLCByZWplY3QpXG4gICAgICB0aGlzLm9uY2UoJ2Nvbm5lY3QnLCAoKSA9PiB7XG4gICAgICAgIHRoaXMucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgcmVqZWN0KVxuICAgICAgICByZXNvbHZlKClcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxufVxuXG5DbGllbnQucHJvdG90eXBlLl9hdHRhY2hMaXN0ZW5lcnMgPSBmdW5jdGlvbiAoY29uKSB7XG4gIGNvbnN0IHNlbGYgPSB0aGlzXG4gIC8vIGRlbGVnYXRlIHJvd0Rlc2NyaXB0aW9uIHRvIGFjdGl2ZSBxdWVyeVxuICBjb24ub24oJ3Jvd0Rlc2NyaXB0aW9uJywgZnVuY3Rpb24gKG1zZykge1xuICAgIHNlbGYuYWN0aXZlUXVlcnkuaGFuZGxlUm93RGVzY3JpcHRpb24obXNnKVxuICB9KVxuXG4gIC8vIGRlbGVnYXRlIGRhdGFSb3cgdG8gYWN0aXZlIHF1ZXJ5XG4gIGNvbi5vbignZGF0YVJvdycsIGZ1bmN0aW9uIChtc2cpIHtcbiAgICBzZWxmLmFjdGl2ZVF1ZXJ5LmhhbmRsZURhdGFSb3cobXNnKVxuICB9KVxuXG4gIC8vIGRlbGVnYXRlIHBvcnRhbFN1c3BlbmRlZCB0byBhY3RpdmUgcXVlcnlcbiAgY29uLm9uKCdwb3J0YWxTdXNwZW5kZWQnLCBmdW5jdGlvbiAobXNnKSB7XG4gICAgc2VsZi5hY3RpdmVRdWVyeS5oYW5kbGVQb3J0YWxTdXNwZW5kZWQoY29uKVxuICB9KVxuXG4gIC8vIGRlbGV0YWdhdGUgZW1wdHlRdWVyeSB0byBhY3RpdmUgcXVlcnlcbiAgY29uLm9uKCdlbXB0eVF1ZXJ5JywgZnVuY3Rpb24gKG1zZykge1xuICAgIHNlbGYuYWN0aXZlUXVlcnkuaGFuZGxlRW1wdHlRdWVyeShjb24pXG4gIH0pXG5cbiAgLy8gZGVsZWdhdGUgY29tbWFuZENvbXBsZXRlIHRvIGFjdGl2ZSBxdWVyeVxuICBjb24ub24oJ2NvbW1hbmRDb21wbGV0ZScsIGZ1bmN0aW9uIChtc2cpIHtcbiAgICBzZWxmLmFjdGl2ZVF1ZXJ5LmhhbmRsZUNvbW1hbmRDb21wbGV0ZShtc2csIGNvbilcbiAgfSlcblxuICAvLyBpZiBhIHByZXBhcmVkIHN0YXRlbWVudCBoYXMgYSBuYW1lIGFuZCBwcm9wZXJseSBwYXJzZXNcbiAgLy8gd2UgdHJhY2sgdGhhdCBpdHMgYWxyZWFkeSBiZWVuIGV4ZWN1dGVkIHNvIHdlIGRvbid0IHBhcnNlXG4gIC8vIGl0IGFnYWluIG9uIHRoZSBzYW1lIGNsaWVudFxuICBjb24ub24oJ3BhcnNlQ29tcGxldGUnLCBmdW5jdGlvbiAobXNnKSB7XG4gICAgaWYgKHNlbGYuYWN0aXZlUXVlcnkubmFtZSkge1xuICAgICAgY29uLnBhcnNlZFN0YXRlbWVudHNbc2VsZi5hY3RpdmVRdWVyeS5uYW1lXSA9IHRydWVcbiAgICB9XG4gIH0pXG5cbiAgY29uLm9uKCdjb3B5SW5SZXNwb25zZScsIGZ1bmN0aW9uIChtc2cpIHtcbiAgICBzZWxmLmFjdGl2ZVF1ZXJ5LmhhbmRsZUNvcHlJblJlc3BvbnNlKHNlbGYuY29ubmVjdGlvbilcbiAgfSlcblxuICBjb24ub24oJ2NvcHlEYXRhJywgZnVuY3Rpb24gKG1zZykge1xuICAgIHNlbGYuYWN0aXZlUXVlcnkuaGFuZGxlQ29weURhdGEobXNnLCBzZWxmLmNvbm5lY3Rpb24pXG4gIH0pXG5cbiAgY29uLm9uKCdub3RpZmljYXRpb24nLCBmdW5jdGlvbiAobXNnKSB7XG4gICAgc2VsZi5lbWl0KCdub3RpZmljYXRpb24nLCBtc2cpXG4gIH0pXG59XG5cbkNsaWVudC5wcm90b3R5cGUuZ2V0U3RhcnR1cENvbmYgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBwYXJhbXMgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzXG5cbiAgdmFyIGRhdGEgPSB7XG4gICAgdXNlcjogcGFyYW1zLnVzZXIsXG4gICAgZGF0YWJhc2U6IHBhcmFtcy5kYXRhYmFzZVxuICB9XG5cbiAgdmFyIGFwcE5hbWUgPSBwYXJhbXMuYXBwbGljYXRpb25fbmFtZSB8fCBwYXJhbXMuZmFsbGJhY2tfYXBwbGljYXRpb25fbmFtZVxuICBpZiAoYXBwTmFtZSkge1xuICAgIGRhdGEuYXBwbGljYXRpb25fbmFtZSA9IGFwcE5hbWVcbiAgfVxuICBpZiAocGFyYW1zLnJlcGxpY2F0aW9uKSB7XG4gICAgZGF0YS5yZXBsaWNhdGlvbiA9ICcnICsgcGFyYW1zLnJlcGxpY2F0aW9uXG4gIH1cbiAgaWYgKHBhcmFtcy5zdGF0ZW1lbnRfdGltZW91dCkge1xuICAgIGRhdGEuc3RhdGVtZW50X3RpbWVvdXQgPSBTdHJpbmcocGFyc2VJbnQocGFyYW1zLnN0YXRlbWVudF90aW1lb3V0LCAxMCkpXG4gIH1cblxuICByZXR1cm4gZGF0YVxufVxuXG5DbGllbnQucHJvdG90eXBlLmNhbmNlbCA9IGZ1bmN0aW9uIChjbGllbnQsIHF1ZXJ5KSB7XG4gIGlmIChjbGllbnQuYWN0aXZlUXVlcnkgPT09IHF1ZXJ5KSB7XG4gICAgdmFyIGNvbiA9IHRoaXMuY29ubmVjdGlvblxuXG4gICAgaWYgKHRoaXMuaG9zdCAmJiB0aGlzLmhvc3QuaW5kZXhPZignLycpID09PSAwKSB7XG4gICAgICBjb24uY29ubmVjdCh0aGlzLmhvc3QgKyAnLy5zLlBHU1FMLicgKyB0aGlzLnBvcnQpXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbi5jb25uZWN0KHRoaXMucG9ydCwgdGhpcy5ob3N0KVxuICAgIH1cblxuICAgIC8vIG9uY2UgY29ubmVjdGlvbiBpcyBlc3RhYmxpc2hlZCBzZW5kIGNhbmNlbCBtZXNzYWdlXG4gICAgY29uLm9uKCdjb25uZWN0JywgZnVuY3Rpb24gKCkge1xuICAgICAgY29uLmNhbmNlbChjbGllbnQucHJvY2Vzc0lELCBjbGllbnQuc2VjcmV0S2V5KVxuICAgIH0pXG4gIH0gZWxzZSBpZiAoY2xpZW50LnF1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSkgIT09IC0xKSB7XG4gICAgY2xpZW50LnF1ZXJ5UXVldWUuc3BsaWNlKGNsaWVudC5xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpLCAxKVxuICB9XG59XG5cbkNsaWVudC5wcm90b3R5cGUuc2V0VHlwZVBhcnNlciA9IGZ1bmN0aW9uIChvaWQsIGZvcm1hdCwgcGFyc2VGbikge1xuICByZXR1cm4gdGhpcy5fdHlwZXMuc2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdCwgcGFyc2VGbilcbn1cblxuQ2xpZW50LnByb3RvdHlwZS5nZXRUeXBlUGFyc2VyID0gZnVuY3Rpb24gKG9pZCwgZm9ybWF0KSB7XG4gIHJldHVybiB0aGlzLl90eXBlcy5nZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0KVxufVxuXG4vLyBQb3J0ZWQgZnJvbSBQb3N0Z3JlU1FMIDkuMi40IHNvdXJjZSBjb2RlIGluIHNyYy9pbnRlcmZhY2VzL2xpYnBxL2ZlLWV4ZWMuY1xuQ2xpZW50LnByb3RvdHlwZS5lc2NhcGVJZGVudGlmaWVyID0gZnVuY3Rpb24gKHN0cikge1xuICB2YXIgZXNjYXBlZCA9ICdcIidcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgIHZhciBjID0gc3RyW2ldXG4gICAgaWYgKGMgPT09ICdcIicpIHtcbiAgICAgIGVzY2FwZWQgKz0gYyArIGNcbiAgICB9IGVsc2Uge1xuICAgICAgZXNjYXBlZCArPSBjXG4gICAgfVxuICB9XG5cbiAgZXNjYXBlZCArPSAnXCInXG5cbiAgcmV0dXJuIGVzY2FwZWRcbn1cblxuLy8gUG9ydGVkIGZyb20gUG9zdGdyZVNRTCA5LjIuNCBzb3VyY2UgY29kZSBpbiBzcmMvaW50ZXJmYWNlcy9saWJwcS9mZS1leGVjLmNcbkNsaWVudC5wcm90b3R5cGUuZXNjYXBlTGl0ZXJhbCA9IGZ1bmN0aW9uIChzdHIpIHtcbiAgdmFyIGhhc0JhY2tzbGFzaCA9IGZhbHNlXG4gIHZhciBlc2NhcGVkID0gJ1xcJydcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgIHZhciBjID0gc3RyW2ldXG4gICAgaWYgKGMgPT09ICdcXCcnKSB7XG4gICAgICBlc2NhcGVkICs9IGMgKyBjXG4gICAgfSBlbHNlIGlmIChjID09PSAnXFxcXCcpIHtcbiAgICAgIGVzY2FwZWQgKz0gYyArIGNcbiAgICAgIGhhc0JhY2tzbGFzaCA9IHRydWVcbiAgICB9IGVsc2Uge1xuICAgICAgZXNjYXBlZCArPSBjXG4gICAgfVxuICB9XG5cbiAgZXNjYXBlZCArPSAnXFwnJ1xuXG4gIGlmIChoYXNCYWNrc2xhc2ggPT09IHRydWUpIHtcbiAgICBlc2NhcGVkID0gJyBFJyArIGVzY2FwZWRcbiAgfVxuXG4gIHJldHVybiBlc2NhcGVkXG59XG5cbkNsaWVudC5wcm90b3R5cGUuX3B1bHNlUXVlcnlRdWV1ZSA9IGZ1bmN0aW9uICgpIHtcbiAgaWYgKHRoaXMucmVhZHlGb3JRdWVyeSA9PT0gdHJ1ZSkge1xuICAgIHRoaXMuYWN0aXZlUXVlcnkgPSB0aGlzLnF1ZXJ5UXVldWUuc2hpZnQoKVxuICAgIGlmICh0aGlzLmFjdGl2ZVF1ZXJ5KSB7XG4gICAgICB0aGlzLnJlYWR5Rm9yUXVlcnkgPSBmYWxzZVxuICAgICAgdGhpcy5oYXNFeGVjdXRlZCA9IHRydWVcbiAgICAgIHRoaXMuYWN0aXZlUXVlcnkuc3VibWl0KHRoaXMuY29ubmVjdGlvbilcbiAgICB9IGVsc2UgaWYgKHRoaXMuaGFzRXhlY3V0ZWQpIHtcbiAgICAgIHRoaXMuYWN0aXZlUXVlcnkgPSBudWxsXG4gICAgICB0aGlzLmVtaXQoJ2RyYWluJylcbiAgICB9XG4gIH1cbn1cblxuQ2xpZW50LnByb3RvdHlwZS5xdWVyeSA9IGZ1bmN0aW9uIChjb25maWcsIHZhbHVlcywgY2FsbGJhY2spIHtcbiAgLy8gY2FuIHRha2UgaW4gc3RyaW5ncywgY29uZmlnIG9iamVjdCBvciBxdWVyeSBvYmplY3RcbiAgdmFyIHF1ZXJ5XG4gIHZhciByZXN1bHRcbiAgaWYgKHR5cGVvZiBjb25maWcuc3VibWl0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmVzdWx0ID0gcXVlcnkgPSBjb25maWdcbiAgICBpZiAodHlwZW9mIHZhbHVlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgcXVlcnkuY2FsbGJhY2sgPSBxdWVyeS5jYWxsYmFjayB8fCB2YWx1ZXNcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcXVlcnkgPSBuZXcgUXVlcnkoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKVxuICAgIGlmICghcXVlcnkuY2FsbGJhY2spIHtcbiAgICAgIGxldCByZXNvbHZlT3V0LCByZWplY3RPdXRcbiAgICAgIHJlc3VsdCA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgcmVzb2x2ZU91dCA9IHJlc29sdmVcbiAgICAgICAgcmVqZWN0T3V0ID0gcmVqZWN0XG4gICAgICB9KVxuICAgICAgcXVlcnkuY2FsbGJhY2sgPSAoZXJyLCByZXMpID0+IGVyciA/IHJlamVjdE91dChlcnIpIDogcmVzb2x2ZU91dChyZXMpXG4gICAgfVxuICB9XG5cbiAgaWYgKHRoaXMuYmluYXJ5ICYmICFxdWVyeS5iaW5hcnkpIHtcbiAgICBxdWVyeS5iaW5hcnkgPSB0cnVlXG4gIH1cbiAgaWYgKHF1ZXJ5Ll9yZXN1bHQpIHtcbiAgICBxdWVyeS5fcmVzdWx0Ll9nZXRUeXBlUGFyc2VyID0gdGhpcy5fdHlwZXMuZ2V0VHlwZVBhcnNlci5iaW5kKHRoaXMuX3R5cGVzKVxuICB9XG5cbiAgdGhpcy5xdWVyeVF1ZXVlLnB1c2gocXVlcnkpXG4gIHRoaXMuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gIHJldHVybiByZXN1bHRcbn1cblxuQ2xpZW50LnByb3RvdHlwZS5lbmQgPSBmdW5jdGlvbiAoY2IpIHtcbiAgdGhpcy5fZW5kaW5nID0gdHJ1ZVxuICBpZiAodGhpcy5hY3RpdmVRdWVyeSkge1xuICAgIC8vIGlmIHdlIGhhdmUgYW4gYWN0aXZlIHF1ZXJ5IHdlIG5lZWQgdG8gZm9yY2UgYSBkaXNjb25uZWN0XG4gICAgLy8gb24gdGhlIHNvY2tldCAtIG90aGVyd2lzZSBhIGh1bmcgcXVlcnkgY291bGQgYmxvY2sgZW5kIGZvcmV2ZXJcbiAgICB0aGlzLmNvbm5lY3Rpb24uc3RyZWFtLmRlc3Ryb3kobmV3IEVycm9yKCdDb25uZWN0aW9uIHRlcm1pbmF0ZWQgYnkgdXNlcicpKVxuICAgIHJldHVybiBjYiA/IGNiKCkgOiBQcm9taXNlLnJlc29sdmUoKVxuICB9XG4gIGlmIChjYikge1xuICAgIHRoaXMuY29ubmVjdGlvbi5lbmQoKVxuICAgIHRoaXMuY29ubmVjdGlvbi5vbmNlKCdlbmQnLCBjYilcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gbmV3IGdsb2JhbC5Qcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5lbmQoKVxuICAgICAgdGhpcy5jb25uZWN0aW9uLm9uY2UoJ2VuZCcsIHJlc29sdmUpXG4gICAgfSlcbiAgfVxufVxuXG4vLyBleHBvc2UgYSBRdWVyeSBjb25zdHJ1Y3RvclxuQ2xpZW50LlF1ZXJ5ID0gUXVlcnlcblxubW9kdWxlLmV4cG9ydHMgPSBDbGllbnRcbiIsIid1c2Ugc3RyaWN0J1xuLyoqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTAtMjAxNyBCcmlhbiBDYXJsc29uIChicmlhbi5tLmNhcmxzb25AZ21haWwuY29tKVxuICogQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIFJFQURNRS5tZCBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbnZhciBkbnMgPSByZXF1aXJlKCdkbnMnKVxuXG52YXIgZGVmYXVsdHMgPSByZXF1aXJlKCcuL2RlZmF1bHRzJylcblxudmFyIHBhcnNlID0gcmVxdWlyZSgncGctY29ubmVjdGlvbi1zdHJpbmcnKS5wYXJzZSAvLyBwYXJzZXMgYSBjb25uZWN0aW9uIHN0cmluZ1xuXG52YXIgdmFsID0gZnVuY3Rpb24gKGtleSwgY29uZmlnLCBlbnZWYXIpIHtcbiAgaWYgKGVudlZhciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgZW52VmFyID0gcHJvY2Vzcy5lbnZbICdQRycgKyBrZXkudG9VcHBlckNhc2UoKSBdXG4gIH0gZWxzZSBpZiAoZW52VmFyID09PSBmYWxzZSkge1xuICAgIC8vIGRvIG5vdGhpbmcgLi4uIHVzZSBmYWxzZVxuICB9IGVsc2Uge1xuICAgIGVudlZhciA9IHByb2Nlc3MuZW52WyBlbnZWYXIgXVxuICB9XG5cbiAgcmV0dXJuIGNvbmZpZ1trZXldIHx8XG4gICAgZW52VmFyIHx8XG4gICAgZGVmYXVsdHNba2V5XVxufVxuXG52YXIgdXNlU3NsID0gZnVuY3Rpb24gKCkge1xuICBzd2l0Y2ggKHByb2Nlc3MuZW52LlBHU1NMTU9ERSkge1xuICAgIGNhc2UgJ2Rpc2FibGUnOlxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgY2FzZSAncHJlZmVyJzpcbiAgICBjYXNlICdyZXF1aXJlJzpcbiAgICBjYXNlICd2ZXJpZnktY2EnOlxuICAgIGNhc2UgJ3ZlcmlmeS1mdWxsJzpcbiAgICAgIHJldHVybiB0cnVlXG4gIH1cbiAgcmV0dXJuIGRlZmF1bHRzLnNzbFxufVxuXG52YXIgQ29ubmVjdGlvblBhcmFtZXRlcnMgPSBmdW5jdGlvbiAoY29uZmlnKSB7XG4gIC8vIGlmIGEgc3RyaW5nIGlzIHBhc3NlZCwgaXQgaXMgYSByYXcgY29ubmVjdGlvbiBzdHJpbmcgc28gd2UgcGFyc2UgaXQgaW50byBhIGNvbmZpZ1xuICBjb25maWcgPSB0eXBlb2YgY29uZmlnID09PSAnc3RyaW5nJyA/IHBhcnNlKGNvbmZpZykgOiBjb25maWcgfHwge31cblxuICAvLyBpZiB0aGUgY29uZmlnIGhhcyBhIGNvbm5lY3Rpb25TdHJpbmcgZGVmaW5lZCwgcGFyc2UgSVQgaW50byB0aGUgY29uZmlnIHdlIHVzZVxuICAvLyB0aGlzIHdpbGwgb3ZlcnJpZGUgb3RoZXIgZGVmYXVsdCB2YWx1ZXMgd2l0aCB3aGF0IGlzIHN0b3JlZCBpbiBjb25uZWN0aW9uU3RyaW5nXG4gIGlmIChjb25maWcuY29ubmVjdGlvblN0cmluZykge1xuICAgIGNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIGNvbmZpZywgcGFyc2UoY29uZmlnLmNvbm5lY3Rpb25TdHJpbmcpKVxuICB9XG5cbiAgdGhpcy51c2VyID0gdmFsKCd1c2VyJywgY29uZmlnKVxuICB0aGlzLmRhdGFiYXNlID0gdmFsKCdkYXRhYmFzZScsIGNvbmZpZylcbiAgdGhpcy5wb3J0ID0gcGFyc2VJbnQodmFsKCdwb3J0JywgY29uZmlnKSwgMTApXG4gIHRoaXMuaG9zdCA9IHZhbCgnaG9zdCcsIGNvbmZpZylcbiAgdGhpcy5wYXNzd29yZCA9IHZhbCgncGFzc3dvcmQnLCBjb25maWcpXG4gIHRoaXMuYmluYXJ5ID0gdmFsKCdiaW5hcnknLCBjb25maWcpXG4gIHRoaXMuc3NsID0gdHlwZW9mIGNvbmZpZy5zc2wgPT09ICd1bmRlZmluZWQnID8gdXNlU3NsKCkgOiBjb25maWcuc3NsXG4gIHRoaXMuY2xpZW50X2VuY29kaW5nID0gdmFsKCdjbGllbnRfZW5jb2RpbmcnLCBjb25maWcpXG4gIHRoaXMucmVwbGljYXRpb24gPSB2YWwoJ3JlcGxpY2F0aW9uJywgY29uZmlnKVxuICAvLyBhIGRvbWFpbiBzb2NrZXQgYmVnaW5zIHdpdGggJy8nXG4gIHRoaXMuaXNEb21haW5Tb2NrZXQgPSAoISh0aGlzLmhvc3QgfHwgJycpLmluZGV4T2YoJy8nKSlcblxuICB0aGlzLmFwcGxpY2F0aW9uX25hbWUgPSB2YWwoJ2FwcGxpY2F0aW9uX25hbWUnLCBjb25maWcsICdQR0FQUE5BTUUnKVxuICB0aGlzLmZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWUgPSB2YWwoJ2ZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWUnLCBjb25maWcsIGZhbHNlKVxuICB0aGlzLnN0YXRlbWVudF90aW1lb3V0ID0gdmFsKCdzdGF0ZW1lbnRfdGltZW91dCcsIGNvbmZpZywgZmFsc2UpXG59XG5cbi8vIENvbnZlcnQgYXJnIHRvIGEgc3RyaW5nLCBzdXJyb3VuZCBpbiBzaW5nbGUgcXVvdGVzLCBhbmQgZXNjYXBlIHNpbmdsZSBxdW90ZXMgYW5kIGJhY2tzbGFzaGVzXG52YXIgcXVvdGVQYXJhbVZhbHVlID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHJldHVybiBcIidcIiArICgnJyArIHZhbHVlKS5yZXBsYWNlKC9cXFxcL2csICdcXFxcXFxcXCcpLnJlcGxhY2UoLycvZywgXCJcXFxcJ1wiKSArIFwiJ1wiXG59XG5cbnZhciBhZGQgPSBmdW5jdGlvbiAocGFyYW1zLCBjb25maWcsIHBhcmFtTmFtZSkge1xuICB2YXIgdmFsdWUgPSBjb25maWdbcGFyYW1OYW1lXVxuICBpZiAodmFsdWUpIHtcbiAgICBwYXJhbXMucHVzaChwYXJhbU5hbWUgKyAnPScgKyBxdW90ZVBhcmFtVmFsdWUodmFsdWUpKVxuICB9XG59XG5cbkNvbm5lY3Rpb25QYXJhbWV0ZXJzLnByb3RvdHlwZS5nZXRMaWJwcUNvbm5lY3Rpb25TdHJpbmcgPSBmdW5jdGlvbiAoY2IpIHtcbiAgdmFyIHBhcmFtcyA9IFtdXG4gIGFkZChwYXJhbXMsIHRoaXMsICd1c2VyJylcbiAgYWRkKHBhcmFtcywgdGhpcywgJ3Bhc3N3b3JkJylcbiAgYWRkKHBhcmFtcywgdGhpcywgJ3BvcnQnKVxuICBhZGQocGFyYW1zLCB0aGlzLCAnYXBwbGljYXRpb25fbmFtZScpXG4gIGFkZChwYXJhbXMsIHRoaXMsICdmYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lJylcblxuICB2YXIgc3NsID0gdHlwZW9mIHRoaXMuc3NsID09PSAnb2JqZWN0JyA/IHRoaXMuc3NsIDoge3NzbG1vZGU6IHRoaXMuc3NsfVxuICBhZGQocGFyYW1zLCBzc2wsICdzc2xtb2RlJylcbiAgYWRkKHBhcmFtcywgc3NsLCAnc3NsY2EnKVxuICBhZGQocGFyYW1zLCBzc2wsICdzc2xrZXknKVxuICBhZGQocGFyYW1zLCBzc2wsICdzc2xjZXJ0JylcbiAgYWRkKHBhcmFtcywgc3NsLCAnc3Nscm9vdGNlcnQnKVxuXG4gIGlmICh0aGlzLmRhdGFiYXNlKSB7XG4gICAgcGFyYW1zLnB1c2goJ2RibmFtZT0nICsgcXVvdGVQYXJhbVZhbHVlKHRoaXMuZGF0YWJhc2UpKVxuICB9XG4gIGlmICh0aGlzLnJlcGxpY2F0aW9uKSB7XG4gICAgcGFyYW1zLnB1c2goJ3JlcGxpY2F0aW9uPScgKyBxdW90ZVBhcmFtVmFsdWUodGhpcy5yZXBsaWNhdGlvbikpXG4gIH1cbiAgaWYgKHRoaXMuaG9zdCkge1xuICAgIHBhcmFtcy5wdXNoKCdob3N0PScgKyBxdW90ZVBhcmFtVmFsdWUodGhpcy5ob3N0KSlcbiAgfVxuICBpZiAodGhpcy5pc0RvbWFpblNvY2tldCkge1xuICAgIHJldHVybiBjYihudWxsLCBwYXJhbXMuam9pbignICcpKVxuICB9XG4gIGlmICh0aGlzLmNsaWVudF9lbmNvZGluZykge1xuICAgIHBhcmFtcy5wdXNoKCdjbGllbnRfZW5jb2Rpbmc9JyArIHF1b3RlUGFyYW1WYWx1ZSh0aGlzLmNsaWVudF9lbmNvZGluZykpXG4gIH1cbiAgZG5zLmxvb2t1cCh0aGlzLmhvc3QsIGZ1bmN0aW9uIChlcnIsIGFkZHJlc3MpIHtcbiAgICBpZiAoZXJyKSByZXR1cm4gY2IoZXJyLCBudWxsKVxuICAgIHBhcmFtcy5wdXNoKCdob3N0YWRkcj0nICsgcXVvdGVQYXJhbVZhbHVlKGFkZHJlc3MpKVxuICAgIHJldHVybiBjYihudWxsLCBwYXJhbXMuam9pbignICcpKVxuICB9KVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IENvbm5lY3Rpb25QYXJhbWV0ZXJzXG4iLCIndXNlIHN0cmljdCdcbi8qKlxuICogQ29weXJpZ2h0IChjKSAyMDEwLTIwMTcgQnJpYW4gQ2FybHNvbiAoYnJpYW4ubS5jYXJsc29uQGdtYWlsLmNvbSlcbiAqIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKlxuICogVGhpcyBzb3VyY2UgY29kZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UgZm91bmQgaW4gdGhlXG4gKiBSRUFETUUubWQgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG52YXIgbmV0ID0gcmVxdWlyZSgnbmV0JylcbnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpXG5cbnZhciBXcml0ZXIgPSByZXF1aXJlKCdidWZmZXItd3JpdGVyJylcbnZhciBSZWFkZXIgPSByZXF1aXJlKCdwYWNrZXQtcmVhZGVyJylcblxudmFyIFRFWFRfTU9ERSA9IDBcbnZhciBCSU5BUllfTU9ERSA9IDFcbnZhciBDb25uZWN0aW9uID0gZnVuY3Rpb24gKGNvbmZpZykge1xuICBFdmVudEVtaXR0ZXIuY2FsbCh0aGlzKVxuICBjb25maWcgPSBjb25maWcgfHwge31cbiAgdGhpcy5zdHJlYW0gPSBjb25maWcuc3RyZWFtIHx8IG5ldyBuZXQuU29ja2V0KClcbiAgdGhpcy5fa2VlcEFsaXZlID0gY29uZmlnLmtlZXBBbGl2ZVxuICB0aGlzLmxhc3RCdWZmZXIgPSBmYWxzZVxuICB0aGlzLmxhc3RPZmZzZXQgPSAwXG4gIHRoaXMuYnVmZmVyID0gbnVsbFxuICB0aGlzLm9mZnNldCA9IG51bGxcbiAgdGhpcy5lbmNvZGluZyA9IGNvbmZpZy5lbmNvZGluZyB8fCAndXRmOCdcbiAgdGhpcy5wYXJzZWRTdGF0ZW1lbnRzID0ge31cbiAgdGhpcy53cml0ZXIgPSBuZXcgV3JpdGVyKClcbiAgdGhpcy5zc2wgPSBjb25maWcuc3NsIHx8IGZhbHNlXG4gIHRoaXMuX2VuZGluZyA9IGZhbHNlXG4gIHRoaXMuX21vZGUgPSBURVhUX01PREVcbiAgdGhpcy5fZW1pdE1lc3NhZ2UgPSBmYWxzZVxuICB0aGlzLl9yZWFkZXIgPSBuZXcgUmVhZGVyKHtcbiAgICBoZWFkZXJTaXplOiAxLFxuICAgIGxlbmd0aFBhZGRpbmc6IC00XG4gIH0pXG4gIHZhciBzZWxmID0gdGhpc1xuICB0aGlzLm9uKCduZXdMaXN0ZW5lcicsIGZ1bmN0aW9uIChldmVudE5hbWUpIHtcbiAgICBpZiAoZXZlbnROYW1lID09PSAnbWVzc2FnZScpIHtcbiAgICAgIHNlbGYuX2VtaXRNZXNzYWdlID0gdHJ1ZVxuICAgIH1cbiAgfSlcbn1cblxudXRpbC5pbmhlcml0cyhDb25uZWN0aW9uLCBFdmVudEVtaXR0ZXIpXG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLmNvbm5lY3QgPSBmdW5jdGlvbiAocG9ydCwgaG9zdCkge1xuICBpZiAodGhpcy5zdHJlYW0ucmVhZHlTdGF0ZSA9PT0gJ2Nsb3NlZCcpIHtcbiAgICB0aGlzLnN0cmVhbS5jb25uZWN0KHBvcnQsIGhvc3QpXG4gIH0gZWxzZSBpZiAodGhpcy5zdHJlYW0ucmVhZHlTdGF0ZSA9PT0gJ29wZW4nKSB7XG4gICAgdGhpcy5lbWl0KCdjb25uZWN0JylcbiAgfVxuXG4gIHZhciBzZWxmID0gdGhpc1xuXG4gIHRoaXMuc3RyZWFtLm9uKCdjb25uZWN0JywgZnVuY3Rpb24gKCkge1xuICAgIGlmIChzZWxmLl9rZWVwQWxpdmUpIHtcbiAgICAgIHNlbGYuc3RyZWFtLnNldEtlZXBBbGl2ZSh0cnVlKVxuICAgIH1cbiAgICBzZWxmLmVtaXQoJ2Nvbm5lY3QnKVxuICB9KVxuXG4gIGNvbnN0IHJlcG9ydFN0cmVhbUVycm9yID0gZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgLy8gZG9uJ3QgcmFpc2UgRUNPTk5SRVNFVCBlcnJvcnMgLSB0aGV5IGNhbiAmIHNob3VsZCBiZSBpZ25vcmVkXG4gICAgLy8gZHVyaW5nIGRpc2Nvbm5lY3RcbiAgICBpZiAoc2VsZi5fZW5kaW5nICYmIGVycm9yLmNvZGUgPT09ICdFQ09OTlJFU0VUJykge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHNlbGYuZW1pdCgnZXJyb3InLCBlcnJvcilcbiAgfVxuICB0aGlzLnN0cmVhbS5vbignZXJyb3InLCByZXBvcnRTdHJlYW1FcnJvcilcblxuICB0aGlzLnN0cmVhbS5vbignY2xvc2UnLCBmdW5jdGlvbiAoKSB7XG4gICAgc2VsZi5lbWl0KCdlbmQnKVxuICB9KVxuXG4gIGlmICghdGhpcy5zc2wpIHtcbiAgICByZXR1cm4gdGhpcy5hdHRhY2hMaXN0ZW5lcnModGhpcy5zdHJlYW0pXG4gIH1cblxuICB0aGlzLnN0cmVhbS5vbmNlKCdkYXRhJywgZnVuY3Rpb24gKGJ1ZmZlcikge1xuICAgIHZhciByZXNwb25zZUNvZGUgPSBidWZmZXIudG9TdHJpbmcoJ3V0ZjgnKVxuICAgIHN3aXRjaCAocmVzcG9uc2VDb2RlKSB7XG4gICAgICBjYXNlICdOJzogLy8gU2VydmVyIGRvZXMgbm90IHN1cHBvcnQgU1NMIGNvbm5lY3Rpb25zXG4gICAgICAgIHJldHVybiBzZWxmLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKCdUaGUgc2VydmVyIGRvZXMgbm90IHN1cHBvcnQgU1NMIGNvbm5lY3Rpb25zJykpXG4gICAgICBjYXNlICdTJzogLy8gU2VydmVyIHN1cHBvcnRzIFNTTCBjb25uZWN0aW9ucywgY29udGludWUgd2l0aCBhIHNlY3VyZSBjb25uZWN0aW9uXG4gICAgICAgIGJyZWFrXG4gICAgICBkZWZhdWx0OiAvLyBBbnkgb3RoZXIgcmVzcG9uc2UgYnl0ZSwgaW5jbHVkaW5nICdFJyAoRXJyb3JSZXNwb25zZSkgaW5kaWNhdGluZyBhIHNlcnZlciBlcnJvclxuICAgICAgICByZXR1cm4gc2VsZi5lbWl0KCdlcnJvcicsIG5ldyBFcnJvcignVGhlcmUgd2FzIGFuIGVycm9yIGVzdGFibGlzaGluZyBhbiBTU0wgY29ubmVjdGlvbicpKVxuICAgIH1cbiAgICB2YXIgdGxzID0gcmVxdWlyZSgndGxzJylcbiAgICBzZWxmLnN0cmVhbSA9IHRscy5jb25uZWN0KHtcbiAgICAgIHNvY2tldDogc2VsZi5zdHJlYW0sXG4gICAgICBzZXJ2ZXJuYW1lOiBob3N0LFxuICAgICAgY2hlY2tTZXJ2ZXJJZGVudGl0eTogc2VsZi5zc2wuY2hlY2tTZXJ2ZXJJZGVudGl0eSB8fCB0bHMuY2hlY2tTZXJ2ZXJJZGVudGl0eSxcbiAgICAgIHJlamVjdFVuYXV0aG9yaXplZDogc2VsZi5zc2wucmVqZWN0VW5hdXRob3JpemVkLFxuICAgICAgY2E6IHNlbGYuc3NsLmNhLFxuICAgICAgcGZ4OiBzZWxmLnNzbC5wZngsXG4gICAgICBrZXk6IHNlbGYuc3NsLmtleSxcbiAgICAgIHBhc3NwaHJhc2U6IHNlbGYuc3NsLnBhc3NwaHJhc2UsXG4gICAgICBjZXJ0OiBzZWxmLnNzbC5jZXJ0LFxuICAgICAgTlBOUHJvdG9jb2xzOiBzZWxmLnNzbC5OUE5Qcm90b2NvbHNcbiAgICB9KVxuICAgIHNlbGYuYXR0YWNoTGlzdGVuZXJzKHNlbGYuc3RyZWFtKVxuICAgIHNlbGYuc3RyZWFtLm9uKCdlcnJvcicsIHJlcG9ydFN0cmVhbUVycm9yKVxuXG4gICAgc2VsZi5lbWl0KCdzc2xjb25uZWN0JylcbiAgfSlcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUuYXR0YWNoTGlzdGVuZXJzID0gZnVuY3Rpb24gKHN0cmVhbSkge1xuICB2YXIgc2VsZiA9IHRoaXNcbiAgc3RyZWFtLm9uKCdkYXRhJywgZnVuY3Rpb24gKGJ1ZmYpIHtcbiAgICBzZWxmLl9yZWFkZXIuYWRkQ2h1bmsoYnVmZilcbiAgICB2YXIgcGFja2V0ID0gc2VsZi5fcmVhZGVyLnJlYWQoKVxuICAgIHdoaWxlIChwYWNrZXQpIHtcbiAgICAgIHZhciBtc2cgPSBzZWxmLnBhcnNlTWVzc2FnZShwYWNrZXQpXG4gICAgICBpZiAoc2VsZi5fZW1pdE1lc3NhZ2UpIHtcbiAgICAgICAgc2VsZi5lbWl0KCdtZXNzYWdlJywgbXNnKVxuICAgICAgfVxuICAgICAgc2VsZi5lbWl0KG1zZy5uYW1lLCBtc2cpXG4gICAgICBwYWNrZXQgPSBzZWxmLl9yZWFkZXIucmVhZCgpXG4gICAgfVxuICB9KVxuICBzdHJlYW0ub24oJ2VuZCcsIGZ1bmN0aW9uICgpIHtcbiAgICBzZWxmLmVtaXQoJ2VuZCcpXG4gIH0pXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnJlcXVlc3RTc2wgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBib2R5QnVmZmVyID0gdGhpcy53cml0ZXJcbiAgICAuYWRkSW50MTYoMHgwNEQyKVxuICAgIC5hZGRJbnQxNigweDE2MkYpLmZsdXNoKClcblxuICB2YXIgbGVuZ3RoID0gYm9keUJ1ZmZlci5sZW5ndGggKyA0XG5cbiAgdmFyIGJ1ZmZlciA9IG5ldyBXcml0ZXIoKVxuICAgIC5hZGRJbnQzMihsZW5ndGgpXG4gICAgLmFkZChib2R5QnVmZmVyKVxuICAgIC5qb2luKClcbiAgdGhpcy5zdHJlYW0ud3JpdGUoYnVmZmVyKVxufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5zdGFydHVwID0gZnVuY3Rpb24gKGNvbmZpZykge1xuICB2YXIgd3JpdGVyID0gdGhpcy53cml0ZXJcbiAgICAuYWRkSW50MTYoMylcbiAgICAuYWRkSW50MTYoMClcblxuICBPYmplY3Qua2V5cyhjb25maWcpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgIHZhciB2YWwgPSBjb25maWdba2V5XVxuICAgIHdyaXRlci5hZGRDU3RyaW5nKGtleSkuYWRkQ1N0cmluZyh2YWwpXG4gIH0pXG5cbiAgd3JpdGVyLmFkZENTdHJpbmcoJ2NsaWVudF9lbmNvZGluZycpLmFkZENTdHJpbmcoXCIndXRmLTgnXCIpXG5cbiAgdmFyIGJvZHlCdWZmZXIgPSB3cml0ZXIuYWRkQ1N0cmluZygnJykuZmx1c2goKVxuICAvLyB0aGlzIG1lc3NhZ2UgaXMgc2VudCB3aXRob3V0IGEgY29kZVxuXG4gIHZhciBsZW5ndGggPSBib2R5QnVmZmVyLmxlbmd0aCArIDRcblxuICB2YXIgYnVmZmVyID0gbmV3IFdyaXRlcigpXG4gICAgLmFkZEludDMyKGxlbmd0aClcbiAgICAuYWRkKGJvZHlCdWZmZXIpXG4gICAgLmpvaW4oKVxuICB0aGlzLnN0cmVhbS53cml0ZShidWZmZXIpXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLmNhbmNlbCA9IGZ1bmN0aW9uIChwcm9jZXNzSUQsIHNlY3JldEtleSkge1xuICB2YXIgYm9keUJ1ZmZlciA9IHRoaXMud3JpdGVyXG4gICAgLmFkZEludDE2KDEyMzQpXG4gICAgLmFkZEludDE2KDU2NzgpXG4gICAgLmFkZEludDMyKHByb2Nlc3NJRClcbiAgICAuYWRkSW50MzIoc2VjcmV0S2V5KVxuICAgIC5mbHVzaCgpXG5cbiAgdmFyIGxlbmd0aCA9IGJvZHlCdWZmZXIubGVuZ3RoICsgNFxuXG4gIHZhciBidWZmZXIgPSBuZXcgV3JpdGVyKClcbiAgICAuYWRkSW50MzIobGVuZ3RoKVxuICAgIC5hZGQoYm9keUJ1ZmZlcilcbiAgICAuam9pbigpXG4gIHRoaXMuc3RyZWFtLndyaXRlKGJ1ZmZlcilcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUucGFzc3dvcmQgPSBmdW5jdGlvbiAocGFzc3dvcmQpIHtcbiAgLy8gMHg3MCA9ICdwJ1xuICB0aGlzLl9zZW5kKDB4NzAsIHRoaXMud3JpdGVyLmFkZENTdHJpbmcocGFzc3dvcmQpKVxufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5fc2VuZCA9IGZ1bmN0aW9uIChjb2RlLCBtb3JlKSB7XG4gIGlmICghdGhpcy5zdHJlYW0ud3JpdGFibGUpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuICBpZiAobW9yZSA9PT0gdHJ1ZSkge1xuICAgIHRoaXMud3JpdGVyLmFkZEhlYWRlcihjb2RlKVxuICB9IGVsc2Uge1xuICAgIHJldHVybiB0aGlzLnN0cmVhbS53cml0ZSh0aGlzLndyaXRlci5mbHVzaChjb2RlKSlcbiAgfVxufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5xdWVyeSA9IGZ1bmN0aW9uICh0ZXh0KSB7XG4gIC8vIDB4NTEgPSBRXG4gIHRoaXMuc3RyZWFtLndyaXRlKHRoaXMud3JpdGVyLmFkZENTdHJpbmcodGV4dCkuZmx1c2goMHg1MSkpXG59XG5cbi8vIHNlbmQgcGFyc2UgbWVzc2FnZVxuLy8gXCJtb3JlXCIgPT09IHRydWUgdG8gYnVmZmVyIHRoZSBtZXNzYWdlIHVudGlsIGZsdXNoKCkgaXMgY2FsbGVkXG5Db25uZWN0aW9uLnByb3RvdHlwZS5wYXJzZSA9IGZ1bmN0aW9uIChxdWVyeSwgbW9yZSkge1xuICAvLyBleHBlY3Qgc29tZXRoaW5nIGxpa2UgdGhpczpcbiAgLy8geyBuYW1lOiAncXVlcnlOYW1lJyxcbiAgLy8gICB0ZXh0OiAnc2VsZWN0ICogZnJvbSBibGFoJyxcbiAgLy8gICB0eXBlczogWydpbnQ4JywgJ2Jvb2wnXSB9XG5cbiAgLy8gbm9ybWFsaXplIG1pc3NpbmcgcXVlcnkgbmFtZXMgdG8gYWxsb3cgZm9yIG51bGxcbiAgcXVlcnkubmFtZSA9IHF1ZXJ5Lm5hbWUgfHwgJydcbiAgaWYgKHF1ZXJ5Lm5hbWUubGVuZ3RoID4gNjMpIHtcbiAgICBjb25zb2xlLmVycm9yKCdXYXJuaW5nISBQb3N0Z3JlcyBvbmx5IHN1cHBvcnRzIDYzIGNoYXJhY3RlcnMgZm9yIHF1ZXJ5IG5hbWVzLicpXG4gICAgY29uc29sZS5lcnJvcignWW91IHN1cHBsaWVkJywgcXVlcnkubmFtZSwgJygnLCBxdWVyeS5uYW1lLmxlbmd0aCwgJyknKVxuICAgIGNvbnNvbGUuZXJyb3IoJ1RoaXMgY2FuIGNhdXNlIGNvbmZsaWN0cyBhbmQgc2lsZW50IGVycm9ycyBleGVjdXRpbmcgcXVlcmllcycpXG4gIH1cbiAgLy8gbm9ybWFsaXplIG51bGwgdHlwZSBhcnJheVxuICBxdWVyeS50eXBlcyA9IHF1ZXJ5LnR5cGVzIHx8IFtdXG4gIHZhciBsZW4gPSBxdWVyeS50eXBlcy5sZW5ndGhcbiAgdmFyIGJ1ZmZlciA9IHRoaXMud3JpdGVyXG4gICAgLmFkZENTdHJpbmcocXVlcnkubmFtZSkgLy8gbmFtZSBvZiBxdWVyeVxuICAgIC5hZGRDU3RyaW5nKHF1ZXJ5LnRleHQpIC8vIGFjdHVhbCBxdWVyeSB0ZXh0XG4gICAgLmFkZEludDE2KGxlbilcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIGJ1ZmZlci5hZGRJbnQzMihxdWVyeS50eXBlc1tpXSlcbiAgfVxuXG4gIHZhciBjb2RlID0gMHg1MFxuICB0aGlzLl9zZW5kKGNvZGUsIG1vcmUpXG59XG5cbi8vIHNlbmQgYmluZCBtZXNzYWdlXG4vLyBcIm1vcmVcIiA9PT0gdHJ1ZSB0byBidWZmZXIgdGhlIG1lc3NhZ2UgdW50aWwgZmx1c2goKSBpcyBjYWxsZWRcbkNvbm5lY3Rpb24ucHJvdG90eXBlLmJpbmQgPSBmdW5jdGlvbiAoY29uZmlnLCBtb3JlKSB7XG4gIC8vIG5vcm1hbGl6ZSBjb25maWdcbiAgY29uZmlnID0gY29uZmlnIHx8IHt9XG4gIGNvbmZpZy5wb3J0YWwgPSBjb25maWcucG9ydGFsIHx8ICcnXG4gIGNvbmZpZy5zdGF0ZW1lbnQgPSBjb25maWcuc3RhdGVtZW50IHx8ICcnXG4gIGNvbmZpZy5iaW5hcnkgPSBjb25maWcuYmluYXJ5IHx8IGZhbHNlXG4gIHZhciB2YWx1ZXMgPSBjb25maWcudmFsdWVzIHx8IFtdXG4gIHZhciBsZW4gPSB2YWx1ZXMubGVuZ3RoXG4gIHZhciB1c2VCaW5hcnkgPSBmYWxzZVxuICBmb3IgKHZhciBqID0gMDsgaiA8IGxlbjsgaisrKSB7IHVzZUJpbmFyeSB8PSB2YWx1ZXNbal0gaW5zdGFuY2VvZiBCdWZmZXIgfVxuICB2YXIgYnVmZmVyID0gdGhpcy53cml0ZXJcbiAgICAuYWRkQ1N0cmluZyhjb25maWcucG9ydGFsKVxuICAgIC5hZGRDU3RyaW5nKGNvbmZpZy5zdGF0ZW1lbnQpXG4gIGlmICghdXNlQmluYXJ5KSB7IGJ1ZmZlci5hZGRJbnQxNigwKSB9IGVsc2Uge1xuICAgIGJ1ZmZlci5hZGRJbnQxNihsZW4pXG4gICAgZm9yIChqID0gMDsgaiA8IGxlbjsgaisrKSB7IGJ1ZmZlci5hZGRJbnQxNih2YWx1ZXNbal0gaW5zdGFuY2VvZiBCdWZmZXIpIH1cbiAgfVxuICBidWZmZXIuYWRkSW50MTYobGVuKVxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgdmFyIHZhbCA9IHZhbHVlc1tpXVxuICAgIGlmICh2YWwgPT09IG51bGwgfHwgdHlwZW9mIHZhbCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIGJ1ZmZlci5hZGRJbnQzMigtMSlcbiAgICB9IGVsc2UgaWYgKHZhbCBpbnN0YW5jZW9mIEJ1ZmZlcikge1xuICAgICAgYnVmZmVyLmFkZEludDMyKHZhbC5sZW5ndGgpXG4gICAgICBidWZmZXIuYWRkKHZhbClcbiAgICB9IGVsc2Uge1xuICAgICAgYnVmZmVyLmFkZEludDMyKEJ1ZmZlci5ieXRlTGVuZ3RoKHZhbCkpXG4gICAgICBidWZmZXIuYWRkU3RyaW5nKHZhbClcbiAgICB9XG4gIH1cblxuICBpZiAoY29uZmlnLmJpbmFyeSkge1xuICAgIGJ1ZmZlci5hZGRJbnQxNigxKSAvLyBmb3JtYXQgY29kZXMgdG8gdXNlIGJpbmFyeVxuICAgIGJ1ZmZlci5hZGRJbnQxNigxKVxuICB9IGVsc2Uge1xuICAgIGJ1ZmZlci5hZGRJbnQxNigwKSAvLyBmb3JtYXQgY29kZXMgdG8gdXNlIHRleHRcbiAgfVxuICAvLyAweDQyID0gJ0InXG4gIHRoaXMuX3NlbmQoMHg0MiwgbW9yZSlcbn1cblxuLy8gc2VuZCBleGVjdXRlIG1lc3NhZ2Vcbi8vIFwibW9yZVwiID09PSB0cnVlIHRvIGJ1ZmZlciB0aGUgbWVzc2FnZSB1bnRpbCBmbHVzaCgpIGlzIGNhbGxlZFxuQ29ubmVjdGlvbi5wcm90b3R5cGUuZXhlY3V0ZSA9IGZ1bmN0aW9uIChjb25maWcsIG1vcmUpIHtcbiAgY29uZmlnID0gY29uZmlnIHx8IHt9XG4gIGNvbmZpZy5wb3J0YWwgPSBjb25maWcucG9ydGFsIHx8ICcnXG4gIGNvbmZpZy5yb3dzID0gY29uZmlnLnJvd3MgfHwgJydcbiAgdGhpcy53cml0ZXJcbiAgICAuYWRkQ1N0cmluZyhjb25maWcucG9ydGFsKVxuICAgIC5hZGRJbnQzMihjb25maWcucm93cylcblxuICAvLyAweDQ1ID0gJ0UnXG4gIHRoaXMuX3NlbmQoMHg0NSwgbW9yZSlcbn1cblxudmFyIGVtcHR5QnVmZmVyID0gQnVmZmVyLmFsbG9jKDApXG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLmZsdXNoID0gZnVuY3Rpb24gKCkge1xuICAvLyAweDQ4ID0gJ0gnXG4gIHRoaXMud3JpdGVyLmFkZChlbXB0eUJ1ZmZlcilcbiAgdGhpcy5fc2VuZCgweDQ4KVxufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5zeW5jID0gZnVuY3Rpb24gKCkge1xuICAvLyBjbGVhciBvdXQgYW55IHBlbmRpbmcgZGF0YSBpbiB0aGUgd3JpdGVyXG4gIHRoaXMud3JpdGVyLmZsdXNoKDApXG5cbiAgdGhpcy53cml0ZXIuYWRkKGVtcHR5QnVmZmVyKVxuICB0aGlzLl9lbmRpbmcgPSB0cnVlXG4gIHRoaXMuX3NlbmQoMHg1Mylcbn1cblxuY29uc3QgRU5EX0JVRkZFUiA9IEJ1ZmZlci5mcm9tKFsweDU4LCAweDAwLCAweDAwLCAweDAwLCAweDA0XSlcblxuQ29ubmVjdGlvbi5wcm90b3R5cGUuZW5kID0gZnVuY3Rpb24gKCkge1xuICAvLyAweDU4ID0gJ1gnXG4gIHRoaXMud3JpdGVyLmFkZChlbXB0eUJ1ZmZlcilcbiAgdGhpcy5fZW5kaW5nID0gdHJ1ZVxuICByZXR1cm4gdGhpcy5zdHJlYW0ud3JpdGUoRU5EX0JVRkZFUiwgKCkgPT4ge1xuICAgIHRoaXMuc3RyZWFtLmVuZCgpXG4gIH0pXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLmNsb3NlID0gZnVuY3Rpb24gKG1zZywgbW9yZSkge1xuICB0aGlzLndyaXRlci5hZGRDU3RyaW5nKG1zZy50eXBlICsgKG1zZy5uYW1lIHx8ICcnKSlcbiAgdGhpcy5fc2VuZCgweDQzLCBtb3JlKVxufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5kZXNjcmliZSA9IGZ1bmN0aW9uIChtc2csIG1vcmUpIHtcbiAgdGhpcy53cml0ZXIuYWRkQ1N0cmluZyhtc2cudHlwZSArIChtc2cubmFtZSB8fCAnJykpXG4gIHRoaXMuX3NlbmQoMHg0NCwgbW9yZSlcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUuc2VuZENvcHlGcm9tQ2h1bmsgPSBmdW5jdGlvbiAoY2h1bmspIHtcbiAgdGhpcy5zdHJlYW0ud3JpdGUodGhpcy53cml0ZXIuYWRkKGNodW5rKS5mbHVzaCgweDY0KSlcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUuZW5kQ29weUZyb20gPSBmdW5jdGlvbiAoKSB7XG4gIHRoaXMuc3RyZWFtLndyaXRlKHRoaXMud3JpdGVyLmFkZChlbXB0eUJ1ZmZlcikuZmx1c2goMHg2MykpXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnNlbmRDb3B5RmFpbCA9IGZ1bmN0aW9uIChtc2cpIHtcbiAgLy8gdGhpcy5zdHJlYW0ud3JpdGUodGhpcy53cml0ZXIuYWRkKGVtcHR5QnVmZmVyKS5mbHVzaCgweDY2KSk7XG4gIHRoaXMud3JpdGVyLmFkZENTdHJpbmcobXNnKVxuICB0aGlzLl9zZW5kKDB4NjYpXG59XG5cbnZhciBNZXNzYWdlID0gZnVuY3Rpb24gKG5hbWUsIGxlbmd0aCkge1xuICB0aGlzLm5hbWUgPSBuYW1lXG4gIHRoaXMubGVuZ3RoID0gbGVuZ3RoXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlTWVzc2FnZSA9IGZ1bmN0aW9uIChidWZmZXIpIHtcbiAgdGhpcy5vZmZzZXQgPSAwXG4gIHZhciBsZW5ndGggPSBidWZmZXIubGVuZ3RoICsgNFxuICBzd2l0Y2ggKHRoaXMuX3JlYWRlci5oZWFkZXIpIHtcbiAgICBjYXNlIDB4NTI6IC8vIFJcbiAgICAgIHJldHVybiB0aGlzLnBhcnNlUihidWZmZXIsIGxlbmd0aClcblxuICAgIGNhc2UgMHg1MzogLy8gU1xuICAgICAgcmV0dXJuIHRoaXMucGFyc2VTKGJ1ZmZlciwgbGVuZ3RoKVxuXG4gICAgY2FzZSAweDRiOiAvLyBLXG4gICAgICByZXR1cm4gdGhpcy5wYXJzZUsoYnVmZmVyLCBsZW5ndGgpXG5cbiAgICBjYXNlIDB4NDM6IC8vIENcbiAgICAgIHJldHVybiB0aGlzLnBhcnNlQyhidWZmZXIsIGxlbmd0aClcblxuICAgIGNhc2UgMHg1YTogLy8gWlxuICAgICAgcmV0dXJuIHRoaXMucGFyc2VaKGJ1ZmZlciwgbGVuZ3RoKVxuXG4gICAgY2FzZSAweDU0OiAvLyBUXG4gICAgICByZXR1cm4gdGhpcy5wYXJzZVQoYnVmZmVyLCBsZW5ndGgpXG5cbiAgICBjYXNlIDB4NDQ6IC8vIERcbiAgICAgIHJldHVybiB0aGlzLnBhcnNlRChidWZmZXIsIGxlbmd0aClcblxuICAgIGNhc2UgMHg0NTogLy8gRVxuICAgICAgcmV0dXJuIHRoaXMucGFyc2VFKGJ1ZmZlciwgbGVuZ3RoKVxuXG4gICAgY2FzZSAweDRlOiAvLyBOXG4gICAgICByZXR1cm4gdGhpcy5wYXJzZU4oYnVmZmVyLCBsZW5ndGgpXG5cbiAgICBjYXNlIDB4MzE6IC8vIDFcbiAgICAgIHJldHVybiBuZXcgTWVzc2FnZSgncGFyc2VDb21wbGV0ZScsIGxlbmd0aClcblxuICAgIGNhc2UgMHgzMjogLy8gMlxuICAgICAgcmV0dXJuIG5ldyBNZXNzYWdlKCdiaW5kQ29tcGxldGUnLCBsZW5ndGgpXG5cbiAgICBjYXNlIDB4MzM6IC8vIDNcbiAgICAgIHJldHVybiBuZXcgTWVzc2FnZSgnY2xvc2VDb21wbGV0ZScsIGxlbmd0aClcblxuICAgIGNhc2UgMHg0MTogLy8gQVxuICAgICAgcmV0dXJuIHRoaXMucGFyc2VBKGJ1ZmZlciwgbGVuZ3RoKVxuXG4gICAgY2FzZSAweDZlOiAvLyBuXG4gICAgICByZXR1cm4gbmV3IE1lc3NhZ2UoJ25vRGF0YScsIGxlbmd0aClcblxuICAgIGNhc2UgMHg0OTogLy8gSVxuICAgICAgcmV0dXJuIG5ldyBNZXNzYWdlKCdlbXB0eVF1ZXJ5JywgbGVuZ3RoKVxuXG4gICAgY2FzZSAweDczOiAvLyBzXG4gICAgICByZXR1cm4gbmV3IE1lc3NhZ2UoJ3BvcnRhbFN1c3BlbmRlZCcsIGxlbmd0aClcblxuICAgIGNhc2UgMHg0NzogLy8gR1xuICAgICAgcmV0dXJuIHRoaXMucGFyc2VHKGJ1ZmZlciwgbGVuZ3RoKVxuXG4gICAgY2FzZSAweDQ4OiAvLyBIXG4gICAgICByZXR1cm4gdGhpcy5wYXJzZUgoYnVmZmVyLCBsZW5ndGgpXG5cbiAgICBjYXNlIDB4NTc6IC8vIFdcbiAgICAgIHJldHVybiBuZXcgTWVzc2FnZSgncmVwbGljYXRpb25TdGFydCcsIGxlbmd0aClcblxuICAgIGNhc2UgMHg2MzogLy8gY1xuICAgICAgcmV0dXJuIG5ldyBNZXNzYWdlKCdjb3B5RG9uZScsIGxlbmd0aClcblxuICAgIGNhc2UgMHg2NDogLy8gZFxuICAgICAgcmV0dXJuIHRoaXMucGFyc2VkKGJ1ZmZlciwgbGVuZ3RoKVxuICB9XG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlUiA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICB2YXIgY29kZSA9IDBcbiAgdmFyIG1zZyA9IG5ldyBNZXNzYWdlKCdhdXRoZW50aWNhdGlvbk9rJywgbGVuZ3RoKVxuICBpZiAobXNnLmxlbmd0aCA9PT0gOCkge1xuICAgIGNvZGUgPSB0aGlzLnBhcnNlSW50MzIoYnVmZmVyKVxuICAgIGlmIChjb2RlID09PSAzKSB7XG4gICAgICBtc2cubmFtZSA9ICdhdXRoZW50aWNhdGlvbkNsZWFydGV4dFBhc3N3b3JkJ1xuICAgIH1cbiAgICByZXR1cm4gbXNnXG4gIH1cbiAgaWYgKG1zZy5sZW5ndGggPT09IDEyKSB7XG4gICAgY29kZSA9IHRoaXMucGFyc2VJbnQzMihidWZmZXIpXG4gICAgaWYgKGNvZGUgPT09IDUpIHsgLy8gbWQ1IHJlcXVpcmVkXG4gICAgICBtc2cubmFtZSA9ICdhdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkJ1xuICAgICAgbXNnLnNhbHQgPSBCdWZmZXIuYWxsb2MoNClcbiAgICAgIGJ1ZmZlci5jb3B5KG1zZy5zYWx0LCAwLCB0aGlzLm9mZnNldCwgdGhpcy5vZmZzZXQgKyA0KVxuICAgICAgdGhpcy5vZmZzZXQgKz0gNFxuICAgICAgcmV0dXJuIG1zZ1xuICAgIH1cbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoJ1Vua25vd24gYXV0aGVudGljYXRpb25PayBtZXNzYWdlIHR5cGUnICsgdXRpbC5pbnNwZWN0KG1zZykpXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlUyA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICB2YXIgbXNnID0gbmV3IE1lc3NhZ2UoJ3BhcmFtZXRlclN0YXR1cycsIGxlbmd0aClcbiAgbXNnLnBhcmFtZXRlck5hbWUgPSB0aGlzLnBhcnNlQ1N0cmluZyhidWZmZXIpXG4gIG1zZy5wYXJhbWV0ZXJWYWx1ZSA9IHRoaXMucGFyc2VDU3RyaW5nKGJ1ZmZlcilcbiAgcmV0dXJuIG1zZ1xufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5wYXJzZUsgPSBmdW5jdGlvbiAoYnVmZmVyLCBsZW5ndGgpIHtcbiAgdmFyIG1zZyA9IG5ldyBNZXNzYWdlKCdiYWNrZW5kS2V5RGF0YScsIGxlbmd0aClcbiAgbXNnLnByb2Nlc3NJRCA9IHRoaXMucGFyc2VJbnQzMihidWZmZXIpXG4gIG1zZy5zZWNyZXRLZXkgPSB0aGlzLnBhcnNlSW50MzIoYnVmZmVyKVxuICByZXR1cm4gbXNnXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlQyA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICB2YXIgbXNnID0gbmV3IE1lc3NhZ2UoJ2NvbW1hbmRDb21wbGV0ZScsIGxlbmd0aClcbiAgbXNnLnRleHQgPSB0aGlzLnBhcnNlQ1N0cmluZyhidWZmZXIpXG4gIHJldHVybiBtc2dcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUucGFyc2VaID0gZnVuY3Rpb24gKGJ1ZmZlciwgbGVuZ3RoKSB7XG4gIHZhciBtc2cgPSBuZXcgTWVzc2FnZSgncmVhZHlGb3JRdWVyeScsIGxlbmd0aClcbiAgbXNnLm5hbWUgPSAncmVhZHlGb3JRdWVyeSdcbiAgbXNnLnN0YXR1cyA9IHRoaXMucmVhZFN0cmluZyhidWZmZXIsIDEpXG4gIHJldHVybiBtc2dcbn1cblxudmFyIFJPV19ERVNDUklQVElPTiA9ICdyb3dEZXNjcmlwdGlvbidcbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlVCA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICB2YXIgbXNnID0gbmV3IE1lc3NhZ2UoUk9XX0RFU0NSSVBUSU9OLCBsZW5ndGgpXG4gIG1zZy5maWVsZENvdW50ID0gdGhpcy5wYXJzZUludDE2KGJ1ZmZlcilcbiAgdmFyIGZpZWxkcyA9IFtdXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbXNnLmZpZWxkQ291bnQ7IGkrKykge1xuICAgIGZpZWxkcy5wdXNoKHRoaXMucGFyc2VGaWVsZChidWZmZXIpKVxuICB9XG4gIG1zZy5maWVsZHMgPSBmaWVsZHNcbiAgcmV0dXJuIG1zZ1xufVxuXG52YXIgRmllbGQgPSBmdW5jdGlvbiAoKSB7XG4gIHRoaXMubmFtZSA9IG51bGxcbiAgdGhpcy50YWJsZUlEID0gbnVsbFxuICB0aGlzLmNvbHVtbklEID0gbnVsbFxuICB0aGlzLmRhdGFUeXBlSUQgPSBudWxsXG4gIHRoaXMuZGF0YVR5cGVTaXplID0gbnVsbFxuICB0aGlzLmRhdGFUeXBlTW9kaWZpZXIgPSBudWxsXG4gIHRoaXMuZm9ybWF0ID0gbnVsbFxufVxuXG52YXIgRk9STUFUX1RFWFQgPSAndGV4dCdcbnZhciBGT1JNQVRfQklOQVJZID0gJ2JpbmFyeSdcbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlRmllbGQgPSBmdW5jdGlvbiAoYnVmZmVyKSB7XG4gIHZhciBmaWVsZCA9IG5ldyBGaWVsZCgpXG4gIGZpZWxkLm5hbWUgPSB0aGlzLnBhcnNlQ1N0cmluZyhidWZmZXIpXG4gIGZpZWxkLnRhYmxlSUQgPSB0aGlzLnBhcnNlSW50MzIoYnVmZmVyKVxuICBmaWVsZC5jb2x1bW5JRCA9IHRoaXMucGFyc2VJbnQxNihidWZmZXIpXG4gIGZpZWxkLmRhdGFUeXBlSUQgPSB0aGlzLnBhcnNlSW50MzIoYnVmZmVyKVxuICBmaWVsZC5kYXRhVHlwZVNpemUgPSB0aGlzLnBhcnNlSW50MTYoYnVmZmVyKVxuICBmaWVsZC5kYXRhVHlwZU1vZGlmaWVyID0gdGhpcy5wYXJzZUludDMyKGJ1ZmZlcilcbiAgaWYgKHRoaXMucGFyc2VJbnQxNihidWZmZXIpID09PSBURVhUX01PREUpIHtcbiAgICB0aGlzLl9tb2RlID0gVEVYVF9NT0RFXG4gICAgZmllbGQuZm9ybWF0ID0gRk9STUFUX1RFWFRcbiAgfSBlbHNlIHtcbiAgICB0aGlzLl9tb2RlID0gQklOQVJZX01PREVcbiAgICBmaWVsZC5mb3JtYXQgPSBGT1JNQVRfQklOQVJZXG4gIH1cbiAgcmV0dXJuIGZpZWxkXG59XG5cbnZhciBEQVRBX1JPVyA9ICdkYXRhUm93J1xudmFyIERhdGFSb3dNZXNzYWdlID0gZnVuY3Rpb24gKGxlbmd0aCwgZmllbGRDb3VudCkge1xuICB0aGlzLm5hbWUgPSBEQVRBX1JPV1xuICB0aGlzLmxlbmd0aCA9IGxlbmd0aFxuICB0aGlzLmZpZWxkQ291bnQgPSBmaWVsZENvdW50XG4gIHRoaXMuZmllbGRzID0gW11cbn1cblxuLy8gZXh0cmVtZWx5IGhvdC1wYXRoIGNvZGVcbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlRCA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICB2YXIgZmllbGRDb3VudCA9IHRoaXMucGFyc2VJbnQxNihidWZmZXIpXG4gIHZhciBtc2cgPSBuZXcgRGF0YVJvd01lc3NhZ2UobGVuZ3RoLCBmaWVsZENvdW50KVxuICBmb3IgKHZhciBpID0gMDsgaSA8IGZpZWxkQ291bnQ7IGkrKykge1xuICAgIG1zZy5maWVsZHMucHVzaCh0aGlzLl9yZWFkVmFsdWUoYnVmZmVyKSlcbiAgfVxuICByZXR1cm4gbXNnXG59XG5cbi8vIGV4dHJlbWVseSBob3QtcGF0aCBjb2RlXG5Db25uZWN0aW9uLnByb3RvdHlwZS5fcmVhZFZhbHVlID0gZnVuY3Rpb24gKGJ1ZmZlcikge1xuICB2YXIgbGVuZ3RoID0gdGhpcy5wYXJzZUludDMyKGJ1ZmZlcilcbiAgaWYgKGxlbmd0aCA9PT0gLTEpIHJldHVybiBudWxsXG4gIGlmICh0aGlzLl9tb2RlID09PSBURVhUX01PREUpIHtcbiAgICByZXR1cm4gdGhpcy5yZWFkU3RyaW5nKGJ1ZmZlciwgbGVuZ3RoKVxuICB9XG4gIHJldHVybiB0aGlzLnJlYWRCeXRlcyhidWZmZXIsIGxlbmd0aClcbn1cblxuLy8gcGFyc2VzIGVycm9yXG5Db25uZWN0aW9uLnByb3RvdHlwZS5wYXJzZUUgPSBmdW5jdGlvbiAoYnVmZmVyLCBsZW5ndGgpIHtcbiAgdmFyIGZpZWxkcyA9IHt9XG4gIHZhciBtc2csIGl0ZW1cbiAgdmFyIGlucHV0ID0gbmV3IE1lc3NhZ2UoJ2Vycm9yJywgbGVuZ3RoKVxuICB2YXIgZmllbGRUeXBlID0gdGhpcy5yZWFkU3RyaW5nKGJ1ZmZlciwgMSlcbiAgd2hpbGUgKGZpZWxkVHlwZSAhPT0gJ1xcMCcpIHtcbiAgICBmaWVsZHNbZmllbGRUeXBlXSA9IHRoaXMucGFyc2VDU3RyaW5nKGJ1ZmZlcilcbiAgICBmaWVsZFR5cGUgPSB0aGlzLnJlYWRTdHJpbmcoYnVmZmVyLCAxKVxuICB9XG4gIGlmIChpbnB1dC5uYW1lID09PSAnZXJyb3InKSB7XG4gICAgLy8gdGhlIG1zZyBpcyBhbiBFcnJvciBpbnN0YW5jZVxuICAgIG1zZyA9IG5ldyBFcnJvcihmaWVsZHMuTSlcbiAgICBmb3IgKGl0ZW0gaW4gaW5wdXQpIHtcbiAgICAgIC8vIGNvcHkgaW5wdXQgcHJvcGVydGllcyB0byB0aGUgZXJyb3JcbiAgICAgIGlmIChpbnB1dC5oYXNPd25Qcm9wZXJ0eShpdGVtKSkge1xuICAgICAgICBtc2dbaXRlbV0gPSBpbnB1dFtpdGVtXVxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICAvLyB0aGUgbXNnIGlzIGFuIG9iamVjdCBsaXRlcmFsXG4gICAgbXNnID0gaW5wdXRcbiAgICBtc2cubWVzc2FnZSA9IGZpZWxkcy5NXG4gIH1cbiAgbXNnLnNldmVyaXR5ID0gZmllbGRzLlNcbiAgbXNnLmNvZGUgPSBmaWVsZHMuQ1xuICBtc2cuZGV0YWlsID0gZmllbGRzLkRcbiAgbXNnLmhpbnQgPSBmaWVsZHMuSFxuICBtc2cucG9zaXRpb24gPSBmaWVsZHMuUFxuICBtc2cuaW50ZXJuYWxQb3NpdGlvbiA9IGZpZWxkcy5wXG4gIG1zZy5pbnRlcm5hbFF1ZXJ5ID0gZmllbGRzLnFcbiAgbXNnLndoZXJlID0gZmllbGRzLldcbiAgbXNnLnNjaGVtYSA9IGZpZWxkcy5zXG4gIG1zZy50YWJsZSA9IGZpZWxkcy50XG4gIG1zZy5jb2x1bW4gPSBmaWVsZHMuY1xuICBtc2cuZGF0YVR5cGUgPSBmaWVsZHMuZFxuICBtc2cuY29uc3RyYWludCA9IGZpZWxkcy5uXG4gIG1zZy5maWxlID0gZmllbGRzLkZcbiAgbXNnLmxpbmUgPSBmaWVsZHMuTFxuICBtc2cucm91dGluZSA9IGZpZWxkcy5SXG4gIHJldHVybiBtc2dcbn1cblxuLy8gc2FtZSB0aGluZywgZGlmZmVyZW50IG5hbWVcbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlTiA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICB2YXIgbXNnID0gdGhpcy5wYXJzZUUoYnVmZmVyLCBsZW5ndGgpXG4gIG1zZy5uYW1lID0gJ25vdGljZSdcbiAgcmV0dXJuIG1zZ1xufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5wYXJzZUEgPSBmdW5jdGlvbiAoYnVmZmVyLCBsZW5ndGgpIHtcbiAgdmFyIG1zZyA9IG5ldyBNZXNzYWdlKCdub3RpZmljYXRpb24nLCBsZW5ndGgpXG4gIG1zZy5wcm9jZXNzSWQgPSB0aGlzLnBhcnNlSW50MzIoYnVmZmVyKVxuICBtc2cuY2hhbm5lbCA9IHRoaXMucGFyc2VDU3RyaW5nKGJ1ZmZlcilcbiAgbXNnLnBheWxvYWQgPSB0aGlzLnBhcnNlQ1N0cmluZyhidWZmZXIpXG4gIHJldHVybiBtc2dcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUucGFyc2VHID0gZnVuY3Rpb24gKGJ1ZmZlciwgbGVuZ3RoKSB7XG4gIHZhciBtc2cgPSBuZXcgTWVzc2FnZSgnY29weUluUmVzcG9uc2UnLCBsZW5ndGgpXG4gIHJldHVybiB0aGlzLnBhcnNlR0goYnVmZmVyLCBtc2cpXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnBhcnNlSCA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICB2YXIgbXNnID0gbmV3IE1lc3NhZ2UoJ2NvcHlPdXRSZXNwb25zZScsIGxlbmd0aClcbiAgcmV0dXJuIHRoaXMucGFyc2VHSChidWZmZXIsIG1zZylcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUucGFyc2VHSCA9IGZ1bmN0aW9uIChidWZmZXIsIG1zZykge1xuICB2YXIgaXNCaW5hcnkgPSBidWZmZXJbdGhpcy5vZmZzZXRdICE9PSAwXG4gIHRoaXMub2Zmc2V0KytcbiAgbXNnLmJpbmFyeSA9IGlzQmluYXJ5XG4gIHZhciBjb2x1bW5Db3VudCA9IHRoaXMucGFyc2VJbnQxNihidWZmZXIpXG4gIG1zZy5jb2x1bW5UeXBlcyA9IFtdXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgY29sdW1uQ291bnQ7IGkrKykge1xuICAgIG1zZy5jb2x1bW5UeXBlcy5wdXNoKHRoaXMucGFyc2VJbnQxNihidWZmZXIpKVxuICB9XG4gIHJldHVybiBtc2dcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUucGFyc2VkID0gZnVuY3Rpb24gKGJ1ZmZlciwgbGVuZ3RoKSB7XG4gIHZhciBtc2cgPSBuZXcgTWVzc2FnZSgnY29weURhdGEnLCBsZW5ndGgpXG4gIG1zZy5jaHVuayA9IHRoaXMucmVhZEJ5dGVzKGJ1ZmZlciwgbXNnLmxlbmd0aCAtIDQpXG4gIHJldHVybiBtc2dcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUucGFyc2VJbnQzMiA9IGZ1bmN0aW9uIChidWZmZXIpIHtcbiAgdmFyIHZhbHVlID0gYnVmZmVyLnJlYWRJbnQzMkJFKHRoaXMub2Zmc2V0KVxuICB0aGlzLm9mZnNldCArPSA0XG4gIHJldHVybiB2YWx1ZVxufVxuXG5Db25uZWN0aW9uLnByb3RvdHlwZS5wYXJzZUludDE2ID0gZnVuY3Rpb24gKGJ1ZmZlcikge1xuICB2YXIgdmFsdWUgPSBidWZmZXIucmVhZEludDE2QkUodGhpcy5vZmZzZXQpXG4gIHRoaXMub2Zmc2V0ICs9IDJcbiAgcmV0dXJuIHZhbHVlXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnJlYWRTdHJpbmcgPSBmdW5jdGlvbiAoYnVmZmVyLCBsZW5ndGgpIHtcbiAgcmV0dXJuIGJ1ZmZlci50b1N0cmluZyh0aGlzLmVuY29kaW5nLCB0aGlzLm9mZnNldCwgKHRoaXMub2Zmc2V0ICs9IGxlbmd0aCkpXG59XG5cbkNvbm5lY3Rpb24ucHJvdG90eXBlLnJlYWRCeXRlcyA9IGZ1bmN0aW9uIChidWZmZXIsIGxlbmd0aCkge1xuICByZXR1cm4gYnVmZmVyLnNsaWNlKHRoaXMub2Zmc2V0LCAodGhpcy5vZmZzZXQgKz0gbGVuZ3RoKSlcbn1cblxuQ29ubmVjdGlvbi5wcm90b3R5cGUucGFyc2VDU3RyaW5nID0gZnVuY3Rpb24gKGJ1ZmZlcikge1xuICB2YXIgc3RhcnQgPSB0aGlzLm9mZnNldFxuICB2YXIgZW5kID0gYnVmZmVyLmluZGV4T2YoMCwgc3RhcnQpXG4gIHRoaXMub2Zmc2V0ID0gZW5kICsgMVxuICByZXR1cm4gYnVmZmVyLnRvU3RyaW5nKHRoaXMuZW5jb2RpbmcsIHN0YXJ0LCBlbmQpXG59XG4vLyBlbmQgcGFyc2luZyBtZXRob2RzXG5tb2R1bGUuZXhwb3J0cyA9IENvbm5lY3Rpb25cbiIsIid1c2Ugc3RyaWN0J1xuLyoqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTAtMjAxNyBCcmlhbiBDYXJsc29uIChicmlhbi5tLmNhcmxzb25AZ21haWwuY29tKVxuICogQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIFJFQURNRS5tZCBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAvLyBkYXRhYmFzZSBob3N0LiBkZWZhdWx0cyB0byBsb2NhbGhvc3RcbiAgaG9zdDogJ2xvY2FsaG9zdCcsXG5cbiAgLy8gZGF0YWJhc2UgdXNlcidzIG5hbWVcbiAgdXNlcjogcHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ3dpbjMyJyA/IHByb2Nlc3MuZW52LlVTRVJOQU1FIDogcHJvY2Vzcy5lbnYuVVNFUixcblxuICAvLyBuYW1lIG9mIGRhdGFiYXNlIHRvIGNvbm5lY3RcbiAgZGF0YWJhc2U6IHByb2Nlc3MucGxhdGZvcm0gPT09ICd3aW4zMicgPyBwcm9jZXNzLmVudi5VU0VSTkFNRSA6IHByb2Nlc3MuZW52LlVTRVIsXG5cbiAgLy8gZGF0YWJhc2UgdXNlcidzIHBhc3N3b3JkXG4gIHBhc3N3b3JkOiBudWxsLFxuXG4gIC8vIGEgUG9zdGdyZXMgY29ubmVjdGlvbiBzdHJpbmcgdG8gYmUgdXNlZCBpbnN0ZWFkIG9mIHNldHRpbmcgaW5kaXZpZHVhbCBjb25uZWN0aW9uIGl0ZW1zXG4gIC8vIE5PVEU6ICBTZXR0aW5nIHRoaXMgdmFsdWUgd2lsbCBjYXVzZSBpdCB0byBvdmVycmlkZSBhbnkgb3RoZXIgdmFsdWUgKHN1Y2ggYXMgZGF0YWJhc2Ugb3IgdXNlcikgZGVmaW5lZFxuICAvLyBpbiB0aGUgZGVmYXVsdHMgb2JqZWN0LlxuICBjb25uZWN0aW9uU3RyaW5nOiB1bmRlZmluZWQsXG5cbiAgLy8gZGF0YWJhc2UgcG9ydFxuICBwb3J0OiA1NDMyLFxuXG4gIC8vIG51bWJlciBvZiByb3dzIHRvIHJldHVybiBhdCBhIHRpbWUgZnJvbSBhIHByZXBhcmVkIHN0YXRlbWVudCdzXG4gIC8vIHBvcnRhbC4gMCB3aWxsIHJldHVybiBhbGwgcm93cyBhdCBvbmNlXG4gIHJvd3M6IDAsXG5cbiAgLy8gYmluYXJ5IHJlc3VsdCBtb2RlXG4gIGJpbmFyeTogZmFsc2UsXG5cbiAgLy8gQ29ubmVjdGlvbiBwb29sIG9wdGlvbnMgLSBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2JyaWFuYy9ub2RlLXBnLXBvb2xcblxuICAvLyBudW1iZXIgb2YgY29ubmVjdGlvbnMgdG8gdXNlIGluIGNvbm5lY3Rpb24gcG9vbFxuICAvLyAwIHdpbGwgZGlzYWJsZSBjb25uZWN0aW9uIHBvb2xpbmdcbiAgbWF4OiAxMCxcblxuICAvLyBtYXggbWlsbGlzZWNvbmRzIGEgY2xpZW50IGNhbiBnbyB1bnVzZWQgYmVmb3JlIGl0IGlzIHJlbW92ZWRcbiAgLy8gZnJvbSB0aGUgcG9vbCBhbmQgZGVzdHJveWVkXG4gIGlkbGVUaW1lb3V0TWlsbGlzOiAzMDAwMCxcblxuICBjbGllbnRfZW5jb2Rpbmc6ICcnLFxuXG4gIHNzbDogZmFsc2UsXG5cbiAgYXBwbGljYXRpb25fbmFtZTogdW5kZWZpbmVkLFxuICBmYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lOiB1bmRlZmluZWQsXG5cbiAgcGFyc2VJbnB1dERhdGVzQXNVVEM6IGZhbHNlLFxuXG4gIC8vIG1heCBtaWxsaXNlY29uZHMgYW55IHF1ZXJ5IHVzaW5nIHRoaXMgY29ubmVjdGlvbiB3aWxsIGV4ZWN1dGUgZm9yIGJlZm9yZSB0aW1pbmcgb3V0IGluIGVycm9yLiBmYWxzZT11bmxpbWl0ZWRcbiAgc3RhdGVtZW50X3RpbWVvdXQ6IGZhbHNlXG59XG5cbnZhciBwZ1R5cGVzID0gcmVxdWlyZSgncGctdHlwZXMnKVxuLy8gc2F2ZSBkZWZhdWx0IHBhcnNlcnNcbnZhciBwYXJzZUJpZ0ludGVnZXIgPSBwZ1R5cGVzLmdldFR5cGVQYXJzZXIoMjAsICd0ZXh0JylcbnZhciBwYXJzZUJpZ0ludGVnZXJBcnJheSA9IHBnVHlwZXMuZ2V0VHlwZVBhcnNlcigxMDE2LCAndGV4dCcpXG5cbi8vIHBhcnNlIGludDggc28geW91IGNhbiBnZXQgeW91ciBjb3VudCB2YWx1ZXMgYXMgYWN0dWFsIG51bWJlcnNcbm1vZHVsZS5leHBvcnRzLl9fZGVmaW5lU2V0dGVyX18oJ3BhcnNlSW50OCcsIGZ1bmN0aW9uICh2YWwpIHtcbiAgcGdUeXBlcy5zZXRUeXBlUGFyc2VyKDIwLCAndGV4dCcsIHZhbCA/IHBnVHlwZXMuZ2V0VHlwZVBhcnNlcigyMywgJ3RleHQnKSA6IHBhcnNlQmlnSW50ZWdlcilcbiAgcGdUeXBlcy5zZXRUeXBlUGFyc2VyKDEwMTYsICd0ZXh0JywgdmFsID8gcGdUeXBlcy5nZXRUeXBlUGFyc2VyKDEwMDcsICd0ZXh0JykgOiBwYXJzZUJpZ0ludGVnZXJBcnJheSlcbn0pXG4iLCIndXNlIHN0cmljdCdcbi8qKlxuICogQ29weXJpZ2h0IChjKSAyMDEwLTIwMTcgQnJpYW4gQ2FybHNvbiAoYnJpYW4ubS5jYXJsc29uQGdtYWlsLmNvbSlcbiAqIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKlxuICogVGhpcyBzb3VyY2UgY29kZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UgZm91bmQgaW4gdGhlXG4gKiBSRUFETUUubWQgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG52YXIgdXRpbCA9IHJlcXVpcmUoJ3V0aWwnKVxudmFyIENsaWVudCA9IHJlcXVpcmUoJy4vY2xpZW50JylcbnZhciBkZWZhdWx0cyA9IHJlcXVpcmUoJy4vZGVmYXVsdHMnKVxudmFyIENvbm5lY3Rpb24gPSByZXF1aXJlKCcuL2Nvbm5lY3Rpb24nKVxudmFyIFBvb2wgPSByZXF1aXJlKCdwZy1wb29sJylcblxuY29uc3QgcG9vbEZhY3RvcnkgPSAoQ2xpZW50KSA9PiB7XG4gIHZhciBCb3VuZFBvb2wgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICAgIHZhciBjb25maWcgPSBPYmplY3QuYXNzaWduKHsgQ2xpZW50OiBDbGllbnQgfSwgb3B0aW9ucylcbiAgICByZXR1cm4gbmV3IFBvb2woY29uZmlnKVxuICB9XG5cbiAgdXRpbC5pbmhlcml0cyhCb3VuZFBvb2wsIFBvb2wpXG5cbiAgcmV0dXJuIEJvdW5kUG9vbFxufVxuXG52YXIgUEcgPSBmdW5jdGlvbiAoY2xpZW50Q29uc3RydWN0b3IpIHtcbiAgdGhpcy5kZWZhdWx0cyA9IGRlZmF1bHRzXG4gIHRoaXMuQ2xpZW50ID0gY2xpZW50Q29uc3RydWN0b3JcbiAgdGhpcy5RdWVyeSA9IHRoaXMuQ2xpZW50LlF1ZXJ5XG4gIHRoaXMuUG9vbCA9IHBvb2xGYWN0b3J5KHRoaXMuQ2xpZW50KVxuICB0aGlzLl9wb29scyA9IFtdXG4gIHRoaXMuQ29ubmVjdGlvbiA9IENvbm5lY3Rpb25cbiAgdGhpcy50eXBlcyA9IHJlcXVpcmUoJ3BnLXR5cGVzJylcbn1cblxuaWYgKHR5cGVvZiBwcm9jZXNzLmVudi5OT0RFX1BHX0ZPUkNFX05BVElWRSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBuZXcgUEcocmVxdWlyZSgnLi9uYXRpdmUnKSlcbn0gZWxzZSB7XG4gIG1vZHVsZS5leHBvcnRzID0gbmV3IFBHKENsaWVudClcblxuICAvLyBsYXp5IHJlcXVpcmUgbmF0aXZlIG1vZHVsZS4uLnRoZSBuYXRpdmUgbW9kdWxlIG1heSBub3QgaGF2ZSBpbnN0YWxsZWRcbiAgbW9kdWxlLmV4cG9ydHMuX19kZWZpbmVHZXR0ZXJfXygnbmF0aXZlJywgZnVuY3Rpb24gKCkge1xuICAgIGRlbGV0ZSBtb2R1bGUuZXhwb3J0cy5uYXRpdmVcbiAgICB2YXIgbmF0aXZlID0gbnVsbFxuICAgIHRyeSB7XG4gICAgICBuYXRpdmUgPSBuZXcgUEcocmVxdWlyZSgnLi9uYXRpdmUnKSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIuY29kZSAhPT0gJ01PRFVMRV9OT1RfRk9VTkQnKSB7XG4gICAgICAgIHRocm93IGVyclxuICAgICAgfVxuICAgICAgY29uc29sZS5lcnJvcihlcnIubWVzc2FnZSlcbiAgICB9XG4gICAgbW9kdWxlLmV4cG9ydHMubmF0aXZlID0gbmF0aXZlXG4gICAgcmV0dXJuIG5hdGl2ZVxuICB9KVxufVxuIiwiJ3VzZSBzdHJpY3QnXG4vKipcbiAqIENvcHlyaWdodCAoYykgMjAxMC0yMDE3IEJyaWFuIENhcmxzb24gKGJyaWFuLm0uY2FybHNvbkBnbWFpbC5jb20pXG4gKiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogUkVBRE1FLm1kIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxudmFyIE5hdGl2ZSA9IHJlcXVpcmUoJ3BnLW5hdGl2ZScpXG52YXIgVHlwZU92ZXJyaWRlcyA9IHJlcXVpcmUoJy4uL3R5cGUtb3ZlcnJpZGVzJylcbnZhciBzZW12ZXIgPSByZXF1aXJlKCdzZW12ZXInKVxudmFyIHBrZyA9IHJlcXVpcmUoJy4uLy4uL3BhY2thZ2UuanNvbicpXG52YXIgYXNzZXJ0ID0gcmVxdWlyZSgnYXNzZXJ0JylcbnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpXG52YXIgQ29ubmVjdGlvblBhcmFtZXRlcnMgPSByZXF1aXJlKCcuLi9jb25uZWN0aW9uLXBhcmFtZXRlcnMnKVxuXG52YXIgbXNnID0gJ1ZlcnNpb24gPj0gJyArIHBrZy5taW5OYXRpdmVWZXJzaW9uICsgJyBvZiBwZy1uYXRpdmUgcmVxdWlyZWQuJ1xuYXNzZXJ0KHNlbXZlci5ndGUoTmF0aXZlLnZlcnNpb24sIHBrZy5taW5OYXRpdmVWZXJzaW9uKSwgbXNnKVxuXG52YXIgTmF0aXZlUXVlcnkgPSByZXF1aXJlKCcuL3F1ZXJ5JylcblxudmFyIENsaWVudCA9IG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGNvbmZpZykge1xuICBFdmVudEVtaXR0ZXIuY2FsbCh0aGlzKVxuICBjb25maWcgPSBjb25maWcgfHwge31cblxuICB0aGlzLl90eXBlcyA9IG5ldyBUeXBlT3ZlcnJpZGVzKGNvbmZpZy50eXBlcylcblxuICB0aGlzLm5hdGl2ZSA9IG5ldyBOYXRpdmUoe1xuICAgIHR5cGVzOiB0aGlzLl90eXBlc1xuICB9KVxuXG4gIHRoaXMuX3F1ZXJ5UXVldWUgPSBbXVxuICB0aGlzLl9jb25uZWN0ZWQgPSBmYWxzZVxuICB0aGlzLl9jb25uZWN0aW5nID0gZmFsc2VcblxuICAvLyBrZWVwIHRoZXNlIG9uIHRoZSBvYmplY3QgZm9yIGxlZ2FjeSByZWFzb25zXG4gIC8vIGZvciB0aGUgdGltZSBiZWluZy4gVE9ETzogZGVwcmVjYXRlIGFsbCB0aGlzIGphenpcbiAgdmFyIGNwID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycyA9IG5ldyBDb25uZWN0aW9uUGFyYW1ldGVycyhjb25maWcpXG4gIHRoaXMudXNlciA9IGNwLnVzZXJcbiAgdGhpcy5wYXNzd29yZCA9IGNwLnBhc3N3b3JkXG4gIHRoaXMuZGF0YWJhc2UgPSBjcC5kYXRhYmFzZVxuICB0aGlzLmhvc3QgPSBjcC5ob3N0XG4gIHRoaXMucG9ydCA9IGNwLnBvcnRcblxuICAvLyBhIGhhc2ggdG8gaG9sZCBuYW1lZCBxdWVyaWVzXG4gIHRoaXMubmFtZWRRdWVyaWVzID0ge31cbn1cblxuQ2xpZW50LlF1ZXJ5ID0gTmF0aXZlUXVlcnlcblxudXRpbC5pbmhlcml0cyhDbGllbnQsIEV2ZW50RW1pdHRlcilcblxuLy8gY29ubmVjdCB0byB0aGUgYmFja2VuZFxuLy8gcGFzcyBhbiBvcHRpb25hbCBjYWxsYmFjayB0byBiZSBjYWxsZWQgb25jZSBjb25uZWN0ZWRcbi8vIG9yIHdpdGggYW4gZXJyb3IgaWYgdGhlcmUgd2FzIGEgY29ubmVjdGlvbiBlcnJvclxuLy8gaWYgbm8gY2FsbGJhY2sgaXMgcGFzc2VkIGFuZCB0aGVyZSBpcyBhIGNvbm5lY3Rpb24gZXJyb3Jcbi8vIHRoZSBjbGllbnQgd2lsbCBlbWl0IGFuIGVycm9yIGV2ZW50LlxuQ2xpZW50LnByb3RvdHlwZS5jb25uZWN0ID0gZnVuY3Rpb24gKGNiKSB7XG4gIHZhciBzZWxmID0gdGhpc1xuXG4gIHZhciBvbkVycm9yID0gZnVuY3Rpb24gKGVycikge1xuICAgIGlmIChjYikgcmV0dXJuIGNiKGVycilcbiAgICByZXR1cm4gc2VsZi5lbWl0KCdlcnJvcicsIGVycilcbiAgfVxuXG4gIHZhciByZXN1bHRcbiAgaWYgKCFjYikge1xuICAgIHZhciByZXNvbHZlT3V0LCByZWplY3RPdXRcbiAgICBjYiA9IChlcnIpID0+IGVyciA/IHJlamVjdE91dChlcnIpIDogcmVzb2x2ZU91dCgpXG4gICAgcmVzdWx0ID0gbmV3IGdsb2JhbC5Qcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIHJlc29sdmVPdXQgPSByZXNvbHZlXG4gICAgICByZWplY3RPdXQgPSByZWplY3RcbiAgICB9KVxuICB9XG5cbiAgaWYgKHRoaXMuX2Nvbm5lY3RpbmcpIHtcbiAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IGNiKG5ldyBFcnJvcignQ2xpZW50IGhhcyBhbHJlYWR5IGJlZW4gY29ubmVjdGVkLiBZb3UgY2Fubm90IHJldXNlIGEgY2xpZW50LicpKSlcbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICB0aGlzLl9jb25uZWN0aW5nID0gdHJ1ZVxuXG4gIHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuZ2V0TGlicHFDb25uZWN0aW9uU3RyaW5nKGZ1bmN0aW9uIChlcnIsIGNvblN0cmluZykge1xuICAgIGlmIChlcnIpIHJldHVybiBvbkVycm9yKGVycilcbiAgICBzZWxmLm5hdGl2ZS5jb25uZWN0KGNvblN0cmluZywgZnVuY3Rpb24gKGVycikge1xuICAgICAgaWYgKGVycikgcmV0dXJuIG9uRXJyb3IoZXJyKVxuXG4gICAgICAvLyBzZXQgaW50ZXJuYWwgc3RhdGVzIHRvIGNvbm5lY3RlZFxuICAgICAgc2VsZi5fY29ubmVjdGVkID0gdHJ1ZVxuXG4gICAgICAvLyBoYW5kbGUgY29ubmVjdGlvbiBlcnJvcnMgZnJvbSB0aGUgbmF0aXZlIGxheWVyXG4gICAgICBzZWxmLm5hdGl2ZS5vbignZXJyb3InLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIC8vIGVycm9yIHdpbGwgYmUgaGFuZGxlZCBieSBhY3RpdmUgcXVlcnlcbiAgICAgICAgaWYgKHNlbGYuX2FjdGl2ZVF1ZXJ5ICYmIHNlbGYuX2FjdGl2ZVF1ZXJ5LnN0YXRlICE9PSAnZW5kJykge1xuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIHNlbGYuZW1pdCgnZXJyb3InLCBlcnIpXG4gICAgICB9KVxuXG4gICAgICBzZWxmLm5hdGl2ZS5vbignbm90aWZpY2F0aW9uJywgZnVuY3Rpb24gKG1zZykge1xuICAgICAgICBzZWxmLmVtaXQoJ25vdGlmaWNhdGlvbicsIHtcbiAgICAgICAgICBjaGFubmVsOiBtc2cucmVsbmFtZSxcbiAgICAgICAgICBwYXlsb2FkOiBtc2cuZXh0cmFcbiAgICAgICAgfSlcbiAgICAgIH0pXG5cbiAgICAgIC8vIHNpZ25hbCB3ZSBhcmUgY29ubmVjdGVkIG5vd1xuICAgICAgc2VsZi5lbWl0KCdjb25uZWN0JylcbiAgICAgIHNlbGYuX3B1bHNlUXVlcnlRdWV1ZSh0cnVlKVxuXG4gICAgICAvLyBwb3NzaWJseSBjYWxsIHRoZSBvcHRpb25hbCBjYWxsYmFja1xuICAgICAgaWYgKGNiKSBjYigpXG4gICAgfSlcbiAgfSlcblxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8vIHNlbmQgYSBxdWVyeSB0byB0aGUgc2VydmVyXG4vLyB0aGlzIG1ldGhvZCBpcyBoaWdobHkgb3ZlcmxvYWRlZCB0byB0YWtlXG4vLyAxKSBzdHJpbmcgcXVlcnksIG9wdGlvbmFsIGFycmF5IG9mIHBhcmFtZXRlcnMsIG9wdGlvbmFsIGZ1bmN0aW9uIGNhbGxiYWNrXG4vLyAyKSBvYmplY3QgcXVlcnkgd2l0aCB7XG4vLyAgICBzdHJpbmcgcXVlcnlcbi8vICAgIG9wdGlvbmFsIGFycmF5IHZhbHVlcyxcbi8vICAgIG9wdGlvbmFsIGZ1bmN0aW9uIGNhbGxiYWNrIGluc3RlYWQgb2YgYXMgYSBzZXBhcmF0ZSBwYXJhbWV0ZXJcbi8vICAgIG9wdGlvbmFsIHN0cmluZyBuYW1lIHRvIG5hbWUgJiBjYWNoZSB0aGUgcXVlcnkgcGxhblxuLy8gICAgb3B0aW9uYWwgc3RyaW5nIHJvd01vZGUgPSAnYXJyYXknIGZvciBhbiBhcnJheSBvZiByZXN1bHRzXG4vLyAgfVxuQ2xpZW50LnByb3RvdHlwZS5xdWVyeSA9IGZ1bmN0aW9uIChjb25maWcsIHZhbHVlcywgY2FsbGJhY2spIHtcbiAgaWYgKHR5cGVvZiBjb25maWcuc3VibWl0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgLy8gYWNjZXB0IHF1ZXJ5KG5ldyBRdWVyeSguLi4pLCAoZXJyLCByZXMpID0+IHsgfSkgc3R5bGVcbiAgICBpZiAodHlwZW9mIHZhbHVlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY29uZmlnLmNhbGxiYWNrID0gdmFsdWVzXG4gICAgfVxuICAgIHRoaXMuX3F1ZXJ5UXVldWUucHVzaChjb25maWcpXG4gICAgdGhpcy5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgICByZXR1cm4gY29uZmlnXG4gIH1cblxuICB2YXIgcXVlcnkgPSBuZXcgTmF0aXZlUXVlcnkoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKVxuICB2YXIgcmVzdWx0XG4gIGlmICghcXVlcnkuY2FsbGJhY2spIHtcbiAgICBsZXQgcmVzb2x2ZU91dCwgcmVqZWN0T3V0XG4gICAgcmVzdWx0ID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgcmVzb2x2ZU91dCA9IHJlc29sdmVcbiAgICAgIHJlamVjdE91dCA9IHJlamVjdFxuICAgIH0pXG4gICAgcXVlcnkuY2FsbGJhY2sgPSAoZXJyLCByZXMpID0+IGVyciA/IHJlamVjdE91dChlcnIpIDogcmVzb2x2ZU91dChyZXMpXG4gIH1cbiAgdGhpcy5fcXVlcnlRdWV1ZS5wdXNoKHF1ZXJ5KVxuICB0aGlzLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8vIGRpc2Nvbm5lY3QgZnJvbSB0aGUgYmFja2VuZCBzZXJ2ZXJcbkNsaWVudC5wcm90b3R5cGUuZW5kID0gZnVuY3Rpb24gKGNiKSB7XG4gIHZhciBzZWxmID0gdGhpc1xuICBpZiAoIXRoaXMuX2Nvbm5lY3RlZCkge1xuICAgIHRoaXMub25jZSgnY29ubmVjdCcsIHRoaXMuZW5kLmJpbmQodGhpcywgY2IpKVxuICB9XG4gIHZhciByZXN1bHRcbiAgaWYgKCFjYikge1xuICAgIHZhciByZXNvbHZlLCByZWplY3RcbiAgICBjYiA9IChlcnIpID0+IGVyciA/IHJlamVjdChlcnIpIDogcmVzb2x2ZSgpXG4gICAgcmVzdWx0ID0gbmV3IGdsb2JhbC5Qcm9taXNlKGZ1bmN0aW9uIChyZXMsIHJlaikge1xuICAgICAgcmVzb2x2ZSA9IHJlc1xuICAgICAgcmVqZWN0ID0gcmVqXG4gICAgfSlcbiAgfVxuICB0aGlzLm5hdGl2ZS5lbmQoZnVuY3Rpb24gKCkge1xuICAgIC8vIHNlbmQgYW4gZXJyb3IgdG8gdGhlIGFjdGl2ZSBxdWVyeVxuICAgIGlmIChzZWxmLl9oYXNBY3RpdmVRdWVyeSgpKSB7XG4gICAgICB2YXIgbXNnID0gJ0Nvbm5lY3Rpb24gdGVybWluYXRlZCdcbiAgICAgIHNlbGYuX3F1ZXJ5UXVldWUubGVuZ3RoID0gMFxuICAgICAgc2VsZi5fYWN0aXZlUXVlcnkuaGFuZGxlRXJyb3IobmV3IEVycm9yKG1zZykpXG4gICAgfVxuICAgIHNlbGYuZW1pdCgnZW5kJylcbiAgICBpZiAoY2IpIGNiKClcbiAgfSlcbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5DbGllbnQucHJvdG90eXBlLl9oYXNBY3RpdmVRdWVyeSA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHRoaXMuX2FjdGl2ZVF1ZXJ5ICYmIHRoaXMuX2FjdGl2ZVF1ZXJ5LnN0YXRlICE9PSAnZXJyb3InICYmIHRoaXMuX2FjdGl2ZVF1ZXJ5LnN0YXRlICE9PSAnZW5kJ1xufVxuXG5DbGllbnQucHJvdG90eXBlLl9wdWxzZVF1ZXJ5UXVldWUgPSBmdW5jdGlvbiAoaW5pdGlhbENvbm5lY3Rpb24pIHtcbiAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICByZXR1cm5cbiAgfVxuICBpZiAodGhpcy5faGFzQWN0aXZlUXVlcnkoKSkge1xuICAgIHJldHVyblxuICB9XG4gIHZhciBxdWVyeSA9IHRoaXMuX3F1ZXJ5UXVldWUuc2hpZnQoKVxuICBpZiAoIXF1ZXJ5KSB7XG4gICAgaWYgKCFpbml0aWFsQ29ubmVjdGlvbikge1xuICAgICAgdGhpcy5lbWl0KCdkcmFpbicpXG4gICAgfVxuICAgIHJldHVyblxuICB9XG4gIHRoaXMuX2FjdGl2ZVF1ZXJ5ID0gcXVlcnlcbiAgcXVlcnkuc3VibWl0KHRoaXMpXG4gIHZhciBzZWxmID0gdGhpc1xuICBxdWVyeS5vbmNlKCdfZG9uZScsIGZ1bmN0aW9uICgpIHtcbiAgICBzZWxmLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICB9KVxufVxuXG4vLyBhdHRlbXB0IHRvIGNhbmNlbCBhbiBpbi1wcm9ncmVzcyBxdWVyeVxuQ2xpZW50LnByb3RvdHlwZS5jYW5jZWwgPSBmdW5jdGlvbiAocXVlcnkpIHtcbiAgaWYgKHRoaXMuX2FjdGl2ZVF1ZXJ5ID09PSBxdWVyeSkge1xuICAgIHRoaXMubmF0aXZlLmNhbmNlbChmdW5jdGlvbiAoKSB7fSlcbiAgfSBlbHNlIGlmICh0aGlzLl9xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpICE9PSAtMSkge1xuICAgIHRoaXMuX3F1ZXJ5UXVldWUuc3BsaWNlKHRoaXMuX3F1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSksIDEpXG4gIH1cbn1cblxuQ2xpZW50LnByb3RvdHlwZS5zZXRUeXBlUGFyc2VyID0gZnVuY3Rpb24gKG9pZCwgZm9ybWF0LCBwYXJzZUZuKSB7XG4gIHJldHVybiB0aGlzLl90eXBlcy5zZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0LCBwYXJzZUZuKVxufVxuXG5DbGllbnQucHJvdG90eXBlLmdldFR5cGVQYXJzZXIgPSBmdW5jdGlvbiAob2lkLCBmb3JtYXQpIHtcbiAgcmV0dXJuIHRoaXMuX3R5cGVzLmdldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQpXG59XG4iLCIndXNlIHN0cmljdCdcbm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9jbGllbnQnKVxuIiwiJ3VzZSBzdHJpY3QnXG4vKipcbiAqIENvcHlyaWdodCAoYykgMjAxMC0yMDE3IEJyaWFuIENhcmxzb24gKGJyaWFuLm0uY2FybHNvbkBnbWFpbC5jb20pXG4gKiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogUkVBRE1FLm1kIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxudmFyIEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlclxudmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbnZhciB1dGlscyA9IHJlcXVpcmUoJy4uL3V0aWxzJylcblxudmFyIE5hdGl2ZVF1ZXJ5ID0gbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gIEV2ZW50RW1pdHRlci5jYWxsKHRoaXMpXG4gIGNvbmZpZyA9IHV0aWxzLm5vcm1hbGl6ZVF1ZXJ5Q29uZmlnKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaylcbiAgdGhpcy50ZXh0ID0gY29uZmlnLnRleHRcbiAgdGhpcy52YWx1ZXMgPSBjb25maWcudmFsdWVzXG4gIHRoaXMubmFtZSA9IGNvbmZpZy5uYW1lXG4gIHRoaXMuY2FsbGJhY2sgPSBjb25maWcuY2FsbGJhY2tcbiAgdGhpcy5zdGF0ZSA9ICduZXcnXG4gIHRoaXMuX2FycmF5TW9kZSA9IGNvbmZpZy5yb3dNb2RlID09PSAnYXJyYXknXG5cbiAgLy8gaWYgdGhlICdyb3cnIGV2ZW50IGlzIGxpc3RlbmVkIGZvclxuICAvLyB0aGVuIGVtaXQgdGhlbSBhcyB0aGV5IGNvbWUgaW5cbiAgLy8gd2l0aG91dCBzZXR0aW5nIHNpbmdsZVJvd01vZGUgdG8gdHJ1ZVxuICAvLyB0aGlzIGhhcyBhbG1vc3Qgbm8gbWVhbmluZyBiZWNhdXNlIGxpYnBxXG4gIC8vIHJlYWRzIGFsbCByb3dzIGludG8gbWVtb3J5IGJlZm9yIHJldHVybmluZyBhbnlcbiAgdGhpcy5fZW1pdFJvd0V2ZW50cyA9IGZhbHNlXG4gIHRoaXMub24oJ25ld0xpc3RlbmVyJywgZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgaWYgKGV2ZW50ID09PSAncm93JykgdGhpcy5fZW1pdFJvd0V2ZW50cyA9IHRydWVcbiAgfS5iaW5kKHRoaXMpKVxufVxuXG51dGlsLmluaGVyaXRzKE5hdGl2ZVF1ZXJ5LCBFdmVudEVtaXR0ZXIpXG5cbnZhciBlcnJvckZpZWxkTWFwID0ge1xuICAnc3FsU3RhdGUnOiAnY29kZScsXG4gICdzdGF0ZW1lbnRQb3NpdGlvbic6ICdwb3NpdGlvbicsXG4gICdtZXNzYWdlUHJpbWFyeSc6ICdtZXNzYWdlJyxcbiAgJ2NvbnRleHQnOiAnd2hlcmUnLFxuICAnc2NoZW1hTmFtZSc6ICdzY2hlbWEnLFxuICAndGFibGVOYW1lJzogJ3RhYmxlJyxcbiAgJ2NvbHVtbk5hbWUnOiAnY29sdW1uJyxcbiAgJ2RhdGFUeXBlTmFtZSc6ICdkYXRhVHlwZScsXG4gICdjb25zdHJhaW50TmFtZSc6ICdjb25zdHJhaW50JyxcbiAgJ3NvdXJjZUZpbGUnOiAnZmlsZScsXG4gICdzb3VyY2VMaW5lJzogJ2xpbmUnLFxuICAnc291cmNlRnVuY3Rpb24nOiAncm91dGluZSdcbn1cblxuTmF0aXZlUXVlcnkucHJvdG90eXBlLmhhbmRsZUVycm9yID0gZnVuY3Rpb24gKGVycikge1xuICAvLyBjb3B5IHBxIGVycm9yIGZpZWxkcyBpbnRvIHRoZSBlcnJvciBvYmplY3RcbiAgdmFyIGZpZWxkcyA9IHRoaXMubmF0aXZlLnBxLnJlc3VsdEVycm9yRmllbGRzKClcbiAgaWYgKGZpZWxkcykge1xuICAgIGZvciAodmFyIGtleSBpbiBmaWVsZHMpIHtcbiAgICAgIHZhciBub3JtYWxpemVkRmllbGROYW1lID0gZXJyb3JGaWVsZE1hcFtrZXldIHx8IGtleVxuICAgICAgZXJyW25vcm1hbGl6ZWRGaWVsZE5hbWVdID0gZmllbGRzW2tleV1cbiAgICB9XG4gIH1cbiAgaWYgKHRoaXMuY2FsbGJhY2spIHtcbiAgICB0aGlzLmNhbGxiYWNrKGVycilcbiAgfSBlbHNlIHtcbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxuICB9XG4gIHRoaXMuc3RhdGUgPSAnZXJyb3InXG59XG5cbk5hdGl2ZVF1ZXJ5LnByb3RvdHlwZS50aGVuID0gZnVuY3Rpb24gKG9uU3VjY2Vzcywgb25GYWlsdXJlKSB7XG4gIHJldHVybiB0aGlzLl9nZXRQcm9taXNlKCkudGhlbihvblN1Y2Nlc3MsIG9uRmFpbHVyZSlcbn1cblxuTmF0aXZlUXVlcnkucHJvdG90eXBlLmNhdGNoID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gIHJldHVybiB0aGlzLl9nZXRQcm9taXNlKCkuY2F0Y2goY2FsbGJhY2spXG59XG5cbk5hdGl2ZVF1ZXJ5LnByb3RvdHlwZS5fZ2V0UHJvbWlzZSA9IGZ1bmN0aW9uICgpIHtcbiAgaWYgKHRoaXMuX3Byb21pc2UpIHJldHVybiB0aGlzLl9wcm9taXNlXG4gIHRoaXMuX3Byb21pc2UgPSBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgdGhpcy5fb25jZSgnZW5kJywgcmVzb2x2ZSlcbiAgICB0aGlzLl9vbmNlKCdlcnJvcicsIHJlamVjdClcbiAgfS5iaW5kKHRoaXMpKVxuICByZXR1cm4gdGhpcy5fcHJvbWlzZVxufVxuXG5OYXRpdmVRdWVyeS5wcm90b3R5cGUuc3VibWl0ID0gZnVuY3Rpb24gKGNsaWVudCkge1xuICB0aGlzLnN0YXRlID0gJ3J1bm5pbmcnXG4gIHZhciBzZWxmID0gdGhpc1xuICB0aGlzLm5hdGl2ZSA9IGNsaWVudC5uYXRpdmVcbiAgY2xpZW50Lm5hdGl2ZS5hcnJheU1vZGUgPSB0aGlzLl9hcnJheU1vZGVcblxuICB2YXIgYWZ0ZXIgPSBmdW5jdGlvbiAoZXJyLCByb3dzLCByZXN1bHRzKSB7XG4gICAgY2xpZW50Lm5hdGl2ZS5hcnJheU1vZGUgPSBmYWxzZVxuICAgIHNldEltbWVkaWF0ZShmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLmVtaXQoJ19kb25lJylcbiAgICB9KVxuXG4gICAgLy8gaGFuZGxlIHBvc3NpYmxlIHF1ZXJ5IGVycm9yXG4gICAgaWYgKGVycikge1xuICAgICAgcmV0dXJuIHNlbGYuaGFuZGxlRXJyb3IoZXJyKVxuICAgIH1cblxuICAgIC8vIGVtaXQgcm93IGV2ZW50cyBmb3IgZWFjaCByb3cgaW4gdGhlIHJlc3VsdFxuICAgIGlmIChzZWxmLl9lbWl0Um93RXZlbnRzKSB7XG4gICAgICBpZiAocmVzdWx0cy5sZW5ndGggPiAxKSB7XG4gICAgICAgIHJvd3MuZm9yRWFjaCgocm93T2ZSb3dzLCBpKSA9PiB7XG4gICAgICAgICAgcm93T2ZSb3dzLmZvckVhY2gocm93ID0+IHtcbiAgICAgICAgICAgIHNlbGYuZW1pdCgncm93Jywgcm93LCByZXN1bHRzW2ldKVxuICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByb3dzLmZvckVhY2goZnVuY3Rpb24gKHJvdykge1xuICAgICAgICAgIHNlbGYuZW1pdCgncm93Jywgcm93LCByZXN1bHRzKVxuICAgICAgICB9KVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIGhhbmRsZSBzdWNjZXNzZnVsIHJlc3VsdFxuICAgIHNlbGYuc3RhdGUgPSAnZW5kJ1xuICAgIHNlbGYuZW1pdCgnZW5kJywgcmVzdWx0cylcbiAgICBpZiAoc2VsZi5jYWxsYmFjaykge1xuICAgICAgc2VsZi5jYWxsYmFjayhudWxsLCByZXN1bHRzKVxuICAgIH1cbiAgfVxuXG4gIGlmIChwcm9jZXNzLmRvbWFpbikge1xuICAgIGFmdGVyID0gcHJvY2Vzcy5kb21haW4uYmluZChhZnRlcilcbiAgfVxuXG4gIC8vIG5hbWVkIHF1ZXJ5XG4gIGlmICh0aGlzLm5hbWUpIHtcbiAgICBpZiAodGhpcy5uYW1lLmxlbmd0aCA+IDYzKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdXYXJuaW5nISBQb3N0Z3JlcyBvbmx5IHN1cHBvcnRzIDYzIGNoYXJhY3RlcnMgZm9yIHF1ZXJ5IG5hbWVzLicpXG4gICAgICBjb25zb2xlLmVycm9yKCdZb3Ugc3VwcGxpZWQnLCB0aGlzLm5hbWUsICcoJywgdGhpcy5uYW1lLmxlbmd0aCwgJyknKVxuICAgICAgY29uc29sZS5lcnJvcignVGhpcyBjYW4gY2F1c2UgY29uZmxpY3RzIGFuZCBzaWxlbnQgZXJyb3JzIGV4ZWN1dGluZyBxdWVyaWVzJylcbiAgICB9XG4gICAgdmFyIHZhbHVlcyA9ICh0aGlzLnZhbHVlcyB8fCBbXSkubWFwKHV0aWxzLnByZXBhcmVWYWx1ZSlcblxuICAgIC8vIGNoZWNrIGlmIHRoZSBjbGllbnQgaGFzIGFscmVhZHkgZXhlY3V0ZWQgdGhpcyBuYW1lZCBxdWVyeVxuICAgIC8vIGlmIHNvLi4uanVzdCBleGVjdXRlIGl0IGFnYWluIC0gc2tpcCB0aGUgcGxhbm5pbmcgcGhhc2VcbiAgICBpZiAoY2xpZW50Lm5hbWVkUXVlcmllc1t0aGlzLm5hbWVdKSB7XG4gICAgICByZXR1cm4gY2xpZW50Lm5hdGl2ZS5leGVjdXRlKHRoaXMubmFtZSwgdmFsdWVzLCBhZnRlcilcbiAgICB9XG4gICAgLy8gcGxhbiB0aGUgbmFtZWQgcXVlcnkgdGhlIGZpcnN0IHRpbWUsIHRoZW4gZXhlY3V0ZSBpdFxuICAgIHJldHVybiBjbGllbnQubmF0aXZlLnByZXBhcmUodGhpcy5uYW1lLCB0aGlzLnRleHQsIHZhbHVlcy5sZW5ndGgsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIGlmIChlcnIpIHJldHVybiBhZnRlcihlcnIpXG4gICAgICBjbGllbnQubmFtZWRRdWVyaWVzW3NlbGYubmFtZV0gPSB0cnVlXG4gICAgICByZXR1cm4gc2VsZi5uYXRpdmUuZXhlY3V0ZShzZWxmLm5hbWUsIHZhbHVlcywgYWZ0ZXIpXG4gICAgfSlcbiAgfSBlbHNlIGlmICh0aGlzLnZhbHVlcykge1xuICAgIGlmICghQXJyYXkuaXNBcnJheSh0aGlzLnZhbHVlcykpIHtcbiAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcignUXVlcnkgdmFsdWVzIG11c3QgYmUgYW4gYXJyYXknKVxuICAgICAgcmV0dXJuIGFmdGVyKGVycilcbiAgICB9XG4gICAgdmFyIHZhbHMgPSB0aGlzLnZhbHVlcy5tYXAodXRpbHMucHJlcGFyZVZhbHVlKVxuICAgIGNsaWVudC5uYXRpdmUucXVlcnkodGhpcy50ZXh0LCB2YWxzLCBhZnRlcilcbiAgfSBlbHNlIHtcbiAgICBjbGllbnQubmF0aXZlLnF1ZXJ5KHRoaXMudGV4dCwgYWZ0ZXIpXG4gIH1cbn1cbiIsIid1c2Ugc3RyaWN0J1xuLyoqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTAtMjAxNyBCcmlhbiBDYXJsc29uIChicmlhbi5tLmNhcmxzb25AZ21haWwuY29tKVxuICogQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIFJFQURNRS5tZCBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpXG5cbnZhciBSZXN1bHQgPSByZXF1aXJlKCcuL3Jlc3VsdCcpXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuL3V0aWxzJylcblxudmFyIFF1ZXJ5ID0gZnVuY3Rpb24gKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaykge1xuICAvLyB1c2Ugb2YgXCJuZXdcIiBvcHRpb25hbFxuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgUXVlcnkpKSB7IHJldHVybiBuZXcgUXVlcnkoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB9XG5cbiAgY29uZmlnID0gdXRpbHMubm9ybWFsaXplUXVlcnlDb25maWcoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKVxuXG4gIHRoaXMudGV4dCA9IGNvbmZpZy50ZXh0XG4gIHRoaXMudmFsdWVzID0gY29uZmlnLnZhbHVlc1xuICB0aGlzLnJvd3MgPSBjb25maWcucm93c1xuICB0aGlzLnR5cGVzID0gY29uZmlnLnR5cGVzXG4gIHRoaXMubmFtZSA9IGNvbmZpZy5uYW1lXG4gIHRoaXMuYmluYXJ5ID0gY29uZmlnLmJpbmFyeVxuICB0aGlzLnN0cmVhbSA9IGNvbmZpZy5zdHJlYW1cbiAgLy8gdXNlIHVuaXF1ZSBwb3J0YWwgbmFtZSBlYWNoIHRpbWVcbiAgdGhpcy5wb3J0YWwgPSBjb25maWcucG9ydGFsIHx8ICcnXG4gIHRoaXMuY2FsbGJhY2sgPSBjb25maWcuY2FsbGJhY2tcbiAgdGhpcy5fcm93TW9kZSA9IGNvbmZpZy5yb3dNb2RlXG4gIGlmIChwcm9jZXNzLmRvbWFpbiAmJiBjb25maWcuY2FsbGJhY2spIHtcbiAgICB0aGlzLmNhbGxiYWNrID0gcHJvY2Vzcy5kb21haW4uYmluZChjb25maWcuY2FsbGJhY2spXG4gIH1cbiAgdGhpcy5fcmVzdWx0ID0gbmV3IFJlc3VsdCh0aGlzLl9yb3dNb2RlLCB0aGlzLnR5cGVzKVxuXG4gIC8vIHBvdGVudGlhbCBmb3IgbXVsdGlwbGUgcmVzdWx0c1xuICB0aGlzLl9yZXN1bHRzID0gdGhpcy5fcmVzdWx0XG4gIHRoaXMuaXNQcmVwYXJlZFN0YXRlbWVudCA9IGZhbHNlXG4gIHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvciA9IGZhbHNlXG4gIHRoaXMuX3Byb21pc2UgPSBudWxsXG4gIEV2ZW50RW1pdHRlci5jYWxsKHRoaXMpXG59XG5cbnV0aWwuaW5oZXJpdHMoUXVlcnksIEV2ZW50RW1pdHRlcilcblxuUXVlcnkucHJvdG90eXBlLnJlcXVpcmVzUHJlcGFyYXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gIC8vIG5hbWVkIHF1ZXJpZXMgbXVzdCBhbHdheXMgYmUgcHJlcGFyZWRcbiAgaWYgKHRoaXMubmFtZSkgeyByZXR1cm4gdHJ1ZSB9XG4gIC8vIGFsd2F5cyBwcmVwYXJlIGlmIHRoZXJlIGFyZSBtYXggbnVtYmVyIG9mIHJvd3MgZXhwZWN0ZWQgcGVyXG4gIC8vIHBvcnRhbCBleGVjdXRpb25cbiAgaWYgKHRoaXMucm93cykgeyByZXR1cm4gdHJ1ZSB9XG4gIC8vIGRvbid0IHByZXBhcmUgZW1wdHkgdGV4dCBxdWVyaWVzXG4gIGlmICghdGhpcy50ZXh0KSB7IHJldHVybiBmYWxzZSB9XG4gIC8vIHByZXBhcmUgaWYgdGhlcmUgYXJlIHZhbHVlc1xuICBpZiAoIXRoaXMudmFsdWVzKSB7IHJldHVybiBmYWxzZSB9XG4gIHJldHVybiB0aGlzLnZhbHVlcy5sZW5ndGggPiAwXG59XG5cblF1ZXJ5LnByb3RvdHlwZS5fY2hlY2tGb3JNdWx0aXJvdyA9IGZ1bmN0aW9uICgpIHtcbiAgLy8gaWYgd2UgYWxyZWFkeSBoYXZlIGEgcmVzdWx0IHdpdGggYSBjb21tYW5kIHByb3BlcnR5XG4gIC8vIHRoZW4gd2UndmUgYWxyZWFkeSBleGVjdXRlZCBvbmUgcXVlcnkgaW4gYSBtdWx0aS1zdGF0ZW1lbnQgc2ltcGxlIHF1ZXJ5XG4gIC8vIHR1cm4gb3VyIHJlc3VsdHMgaW50byBhbiBhcnJheSBvZiByZXN1bHRzXG4gIGlmICh0aGlzLl9yZXN1bHQuY29tbWFuZCkge1xuICAgIGlmICghQXJyYXkuaXNBcnJheSh0aGlzLl9yZXN1bHRzKSkge1xuICAgICAgdGhpcy5fcmVzdWx0cyA9IFt0aGlzLl9yZXN1bHRdXG4gICAgfVxuICAgIHRoaXMuX3Jlc3VsdCA9IG5ldyBSZXN1bHQodGhpcy5fcm93TW9kZSwgdGhpcy50eXBlcylcbiAgICB0aGlzLl9yZXN1bHRzLnB1c2godGhpcy5fcmVzdWx0KVxuICB9XG59XG5cbi8vIGFzc29jaWF0ZXMgcm93IG1ldGFkYXRhIGZyb20gdGhlIHN1cHBsaWVkXG4vLyBtZXNzYWdlIHdpdGggdGhpcyBxdWVyeSBvYmplY3Rcbi8vIG1ldGFkYXRhIHVzZWQgd2hlbiBwYXJzaW5nIHJvdyByZXN1bHRzXG5RdWVyeS5wcm90b3R5cGUuaGFuZGxlUm93RGVzY3JpcHRpb24gPSBmdW5jdGlvbiAobXNnKSB7XG4gIHRoaXMuX2NoZWNrRm9yTXVsdGlyb3coKVxuICB0aGlzLl9yZXN1bHQuYWRkRmllbGRzKG1zZy5maWVsZHMpXG4gIHRoaXMuX2FjY3VtdWxhdGVSb3dzID0gdGhpcy5jYWxsYmFjayB8fCAhdGhpcy5saXN0ZW5lcnMoJ3JvdycpLmxlbmd0aFxufVxuXG5RdWVyeS5wcm90b3R5cGUuaGFuZGxlRGF0YVJvdyA9IGZ1bmN0aW9uIChtc2cpIHtcbiAgdmFyIHJvd1xuXG4gIGlmICh0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IpIHtcbiAgICByZXR1cm5cbiAgfVxuXG4gIHRyeSB7XG4gICAgcm93ID0gdGhpcy5fcmVzdWx0LnBhcnNlUm93KG1zZy5maWVsZHMpXG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvciA9IGVyclxuICAgIHJldHVyblxuICB9XG5cbiAgdGhpcy5lbWl0KCdyb3cnLCByb3csIHRoaXMuX3Jlc3VsdClcbiAgaWYgKHRoaXMuX2FjY3VtdWxhdGVSb3dzKSB7XG4gICAgdGhpcy5fcmVzdWx0LmFkZFJvdyhyb3cpXG4gIH1cbn1cblxuUXVlcnkucHJvdG90eXBlLmhhbmRsZUNvbW1hbmRDb21wbGV0ZSA9IGZ1bmN0aW9uIChtc2csIGNvbikge1xuICB0aGlzLl9jaGVja0Zvck11bHRpcm93KClcbiAgdGhpcy5fcmVzdWx0LmFkZENvbW1hbmRDb21wbGV0ZShtc2cpXG4gIC8vIG5lZWQgdG8gc3luYyBhZnRlciBlYWNoIGNvbW1hbmQgY29tcGxldGUgb2YgYSBwcmVwYXJlZCBzdGF0ZW1lbnRcbiAgaWYgKHRoaXMuaXNQcmVwYXJlZFN0YXRlbWVudCkge1xuICAgIGNvbi5zeW5jKClcbiAgfVxufVxuXG4vLyBpZiBhIG5hbWVkIHByZXBhcmVkIHN0YXRlbWVudCBpcyBjcmVhdGVkIHdpdGggZW1wdHkgcXVlcnkgdGV4dFxuLy8gdGhlIGJhY2tlbmQgd2lsbCBzZW5kIGFuIGVtcHR5UXVlcnkgbWVzc2FnZSBidXQgKm5vdCogYSBjb21tYW5kIGNvbXBsZXRlIG1lc3NhZ2Vcbi8vIGV4ZWN1dGlvbiBvbiB0aGUgY29ubmVjdGlvbiB3aWxsIGhhbmcgdW50aWwgdGhlIGJhY2tlbmQgcmVjZWl2ZXMgYSBzeW5jIG1lc3NhZ2VcblF1ZXJ5LnByb3RvdHlwZS5oYW5kbGVFbXB0eVF1ZXJ5ID0gZnVuY3Rpb24gKGNvbikge1xuICBpZiAodGhpcy5pc1ByZXBhcmVkU3RhdGVtZW50KSB7XG4gICAgY29uLnN5bmMoKVxuICB9XG59XG5cblF1ZXJ5LnByb3RvdHlwZS5oYW5kbGVSZWFkeUZvclF1ZXJ5ID0gZnVuY3Rpb24gKGNvbikge1xuICBpZiAodGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yKSB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlRXJyb3IodGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yLCBjb24pXG4gIH1cbiAgaWYgKHRoaXMuY2FsbGJhY2spIHtcbiAgICB0aGlzLmNhbGxiYWNrKG51bGwsIHRoaXMuX3Jlc3VsdHMpXG4gIH1cbiAgdGhpcy5lbWl0KCdlbmQnLCB0aGlzLl9yZXN1bHRzKVxufVxuXG5RdWVyeS5wcm90b3R5cGUuaGFuZGxlRXJyb3IgPSBmdW5jdGlvbiAoZXJyLCBjb25uZWN0aW9uKSB7XG4gIC8vIG5lZWQgdG8gc3luYyBhZnRlciBlcnJvciBkdXJpbmcgYSBwcmVwYXJlZCBzdGF0ZW1lbnRcbiAgaWYgKHRoaXMuaXNQcmVwYXJlZFN0YXRlbWVudCkge1xuICAgIGNvbm5lY3Rpb24uc3luYygpXG4gIH1cbiAgaWYgKHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvcikge1xuICAgIGVyciA9IHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvclxuICAgIHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvciA9IGZhbHNlXG4gIH1cbiAgLy8gaWYgY2FsbGJhY2sgc3VwcGxpZWQgZG8gbm90IGVtaXQgZXJyb3IgZXZlbnQgYXMgdW5jYXVnaHQgZXJyb3JcbiAgLy8gZXZlbnRzIHdpbGwgYnViYmxlIHVwIHRvIG5vZGUgcHJvY2Vzc1xuICBpZiAodGhpcy5jYWxsYmFjaykge1xuICAgIHJldHVybiB0aGlzLmNhbGxiYWNrKGVycilcbiAgfVxuICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxufVxuXG5RdWVyeS5wcm90b3R5cGUuc3VibWl0ID0gZnVuY3Rpb24gKGNvbm5lY3Rpb24pIHtcbiAgaWYgKHR5cGVvZiB0aGlzLnRleHQgIT09ICdzdHJpbmcnICYmIHR5cGVvZiB0aGlzLm5hbWUgIT09ICdzdHJpbmcnKSB7XG4gICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdBIHF1ZXJ5IG11c3QgaGF2ZSBlaXRoZXIgdGV4dCBvciBhIG5hbWUuIFN1cHBseWluZyBuZWl0aGVyIGlzIHVuc3VwcG9ydGVkLicpXG4gICAgY29ubmVjdGlvbi5lbWl0KCdlcnJvcicsIGVycilcbiAgICBjb25uZWN0aW9uLmVtaXQoJ3JlYWR5Rm9yUXVlcnknKVxuICAgIHJldHVyblxuICB9XG4gIGlmICh0aGlzLnZhbHVlcyAmJiAhQXJyYXkuaXNBcnJheSh0aGlzLnZhbHVlcykpIHtcbiAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoJ1F1ZXJ5IHZhbHVlcyBtdXN0IGJlIGFuIGFycmF5JylcbiAgICBjb25uZWN0aW9uLmVtaXQoJ2Vycm9yJywgZXJyKVxuICAgIGNvbm5lY3Rpb24uZW1pdCgncmVhZHlGb3JRdWVyeScpXG4gICAgcmV0dXJuXG4gIH1cbiAgaWYgKHRoaXMucmVxdWlyZXNQcmVwYXJhdGlvbigpKSB7XG4gICAgdGhpcy5wcmVwYXJlKGNvbm5lY3Rpb24pXG4gIH0gZWxzZSB7XG4gICAgY29ubmVjdGlvbi5xdWVyeSh0aGlzLnRleHQpXG4gIH1cbn1cblxuUXVlcnkucHJvdG90eXBlLmhhc0JlZW5QYXJzZWQgPSBmdW5jdGlvbiAoY29ubmVjdGlvbikge1xuICByZXR1cm4gdGhpcy5uYW1lICYmIGNvbm5lY3Rpb24ucGFyc2VkU3RhdGVtZW50c1t0aGlzLm5hbWVdXG59XG5cblF1ZXJ5LnByb3RvdHlwZS5oYW5kbGVQb3J0YWxTdXNwZW5kZWQgPSBmdW5jdGlvbiAoY29ubmVjdGlvbikge1xuICB0aGlzLl9nZXRSb3dzKGNvbm5lY3Rpb24sIHRoaXMucm93cylcbn1cblxuUXVlcnkucHJvdG90eXBlLl9nZXRSb3dzID0gZnVuY3Rpb24gKGNvbm5lY3Rpb24sIHJvd3MpIHtcbiAgY29ubmVjdGlvbi5leGVjdXRlKHtcbiAgICBwb3J0YWw6IHRoaXMucG9ydGFsLFxuICAgIHJvd3M6IHJvd3NcbiAgfSwgdHJ1ZSlcbiAgY29ubmVjdGlvbi5mbHVzaCgpXG59XG5cblF1ZXJ5LnByb3RvdHlwZS5wcmVwYXJlID0gZnVuY3Rpb24gKGNvbm5lY3Rpb24pIHtcbiAgdmFyIHNlbGYgPSB0aGlzXG4gIC8vIHByZXBhcmVkIHN0YXRlbWVudHMgbmVlZCBzeW5jIHRvIGJlIGNhbGxlZCBhZnRlciBlYWNoIGNvbW1hbmRcbiAgLy8gY29tcGxldGUgb3Igd2hlbiBhbiBlcnJvciBpcyBlbmNvdW50ZXJlZFxuICB0aGlzLmlzUHJlcGFyZWRTdGF0ZW1lbnQgPSB0cnVlXG4gIC8vIFRPRE8gcmVmYWN0b3IgdGhpcyBwb29yIGVuY2Fwc3VsYXRpb25cbiAgaWYgKCF0aGlzLmhhc0JlZW5QYXJzZWQoY29ubmVjdGlvbikpIHtcbiAgICBjb25uZWN0aW9uLnBhcnNlKHtcbiAgICAgIHRleHQ6IHNlbGYudGV4dCxcbiAgICAgIG5hbWU6IHNlbGYubmFtZSxcbiAgICAgIHR5cGVzOiBzZWxmLnR5cGVzXG4gICAgfSwgdHJ1ZSlcbiAgfVxuXG4gIGlmIChzZWxmLnZhbHVlcykge1xuICAgIHNlbGYudmFsdWVzID0gc2VsZi52YWx1ZXMubWFwKHV0aWxzLnByZXBhcmVWYWx1ZSlcbiAgfVxuXG4gIC8vIGh0dHA6Ly9kZXZlbG9wZXIucG9zdGdyZXNxbC5vcmcvcGdkb2NzL3Bvc3RncmVzL3Byb3RvY29sLWZsb3cuaHRtbCNQUk9UT0NPTC1GTE9XLUVYVC1RVUVSWVxuICBjb25uZWN0aW9uLmJpbmQoe1xuICAgIHBvcnRhbDogc2VsZi5wb3J0YWwsXG4gICAgc3RhdGVtZW50OiBzZWxmLm5hbWUsXG4gICAgdmFsdWVzOiBzZWxmLnZhbHVlcyxcbiAgICBiaW5hcnk6IHNlbGYuYmluYXJ5XG4gIH0sIHRydWUpXG5cbiAgY29ubmVjdGlvbi5kZXNjcmliZSh7XG4gICAgdHlwZTogJ1AnLFxuICAgIG5hbWU6IHNlbGYucG9ydGFsIHx8ICcnXG4gIH0sIHRydWUpXG5cbiAgdGhpcy5fZ2V0Um93cyhjb25uZWN0aW9uLCB0aGlzLnJvd3MpXG59XG5cblF1ZXJ5LnByb3RvdHlwZS5oYW5kbGVDb3B5SW5SZXNwb25zZSA9IGZ1bmN0aW9uIChjb25uZWN0aW9uKSB7XG4gIGlmICh0aGlzLnN0cmVhbSkgdGhpcy5zdHJlYW0uc3RhcnRTdHJlYW1pbmdUb0Nvbm5lY3Rpb24oY29ubmVjdGlvbilcbiAgZWxzZSBjb25uZWN0aW9uLnNlbmRDb3B5RmFpbCgnTm8gc291cmNlIHN0cmVhbSBkZWZpbmVkJylcbn1cblxuUXVlcnkucHJvdG90eXBlLmhhbmRsZUNvcHlEYXRhID0gZnVuY3Rpb24gKG1zZywgY29ubmVjdGlvbikge1xuICB2YXIgY2h1bmsgPSBtc2cuY2h1bmtcbiAgaWYgKHRoaXMuc3RyZWFtKSB7XG4gICAgdGhpcy5zdHJlYW0uaGFuZGxlQ2h1bmsoY2h1bmspXG4gIH1cbiAgLy8gaWYgdGhlcmUgYXJlIG5vIHN0cmVhbSAoZm9yIGV4YW1wbGUgd2hlbiBjb3B5IHRvIHF1ZXJ5IHdhcyBzZW50IGJ5XG4gIC8vIHF1ZXJ5IG1ldGhvZCBpbnN0ZWFkIG9mIGNvcHlUbykgZXJyb3Igd2lsbCBiZSBoYW5kbGVkXG4gIC8vIG9uIGNvcHlPdXRSZXNwb25zZSBldmVudCwgc28gc2lsZW50bHkgaWdub3JlIHRoaXMgZXJyb3IgaGVyZVxufVxubW9kdWxlLmV4cG9ydHMgPSBRdWVyeVxuIiwiJ3VzZSBzdHJpY3QnXG4vKipcbiAqIENvcHlyaWdodCAoYykgMjAxMC0yMDE3IEJyaWFuIENhcmxzb24gKGJyaWFuLm0uY2FybHNvbkBnbWFpbC5jb20pXG4gKiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogUkVBRE1FLm1kIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxudmFyIHR5cGVzID0gcmVxdWlyZSgncGctdHlwZXMnKVxuXG4vLyByZXN1bHQgb2JqZWN0IHJldHVybmVkIGZyb20gcXVlcnlcbi8vIGluIHRoZSAnZW5kJyBldmVudCBhbmQgYWxzb1xuLy8gcGFzc2VkIGFzIHNlY29uZCBhcmd1bWVudCB0byBwcm92aWRlZCBjYWxsYmFja1xudmFyIFJlc3VsdCA9IGZ1bmN0aW9uIChyb3dNb2RlKSB7XG4gIHRoaXMuY29tbWFuZCA9IG51bGxcbiAgdGhpcy5yb3dDb3VudCA9IG51bGxcbiAgdGhpcy5vaWQgPSBudWxsXG4gIHRoaXMucm93cyA9IFtdXG4gIHRoaXMuZmllbGRzID0gW11cbiAgdGhpcy5fcGFyc2VycyA9IFtdXG4gIHRoaXMuUm93Q3RvciA9IG51bGxcbiAgdGhpcy5yb3dBc0FycmF5ID0gcm93TW9kZSA9PT0gJ2FycmF5J1xuICBpZiAodGhpcy5yb3dBc0FycmF5KSB7XG4gICAgdGhpcy5wYXJzZVJvdyA9IHRoaXMuX3BhcnNlUm93QXNBcnJheVxuICB9XG59XG5cbnZhciBtYXRjaFJlZ2V4cCA9IC9eKFtBLVphLXpdKykoPzogKFxcZCspKT8oPzogKFxcZCspKT8vXG5cbi8vIGFkZHMgYSBjb21tYW5kIGNvbXBsZXRlIG1lc3NhZ2VcblJlc3VsdC5wcm90b3R5cGUuYWRkQ29tbWFuZENvbXBsZXRlID0gZnVuY3Rpb24gKG1zZykge1xuICB2YXIgbWF0Y2hcbiAgaWYgKG1zZy50ZXh0KSB7XG4gICAgLy8gcHVyZSBqYXZhc2NyaXB0XG4gICAgbWF0Y2ggPSBtYXRjaFJlZ2V4cC5leGVjKG1zZy50ZXh0KVxuICB9IGVsc2Uge1xuICAgIC8vIG5hdGl2ZSBiaW5kaW5nc1xuICAgIG1hdGNoID0gbWF0Y2hSZWdleHAuZXhlYyhtc2cuY29tbWFuZClcbiAgfVxuICBpZiAobWF0Y2gpIHtcbiAgICB0aGlzLmNvbW1hbmQgPSBtYXRjaFsxXVxuICAgIGlmIChtYXRjaFszXSkge1xuICAgICAgLy8gQ09NTU1BTkQgT0lEIFJPV1NcbiAgICAgIHRoaXMub2lkID0gcGFyc2VJbnQobWF0Y2hbMl0sIDEwKVxuICAgICAgdGhpcy5yb3dDb3VudCA9IHBhcnNlSW50KG1hdGNoWzNdLCAxMClcbiAgICB9IGVsc2UgaWYgKG1hdGNoWzJdKSB7XG4gICAgICAvLyBDT01NQU5EIFJPV1NcbiAgICAgIHRoaXMucm93Q291bnQgPSBwYXJzZUludChtYXRjaFsyXSwgMTApXG4gICAgfVxuICB9XG59XG5cblJlc3VsdC5wcm90b3R5cGUuX3BhcnNlUm93QXNBcnJheSA9IGZ1bmN0aW9uIChyb3dEYXRhKSB7XG4gIHZhciByb3cgPSBbXVxuICBmb3IgKHZhciBpID0gMCwgbGVuID0gcm93RGF0YS5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgIHZhciByYXdWYWx1ZSA9IHJvd0RhdGFbaV1cbiAgICBpZiAocmF3VmFsdWUgIT09IG51bGwpIHtcbiAgICAgIHJvdy5wdXNoKHRoaXMuX3BhcnNlcnNbaV0ocmF3VmFsdWUpKVxuICAgIH0gZWxzZSB7XG4gICAgICByb3cucHVzaChudWxsKVxuICAgIH1cbiAgfVxuICByZXR1cm4gcm93XG59XG5cblJlc3VsdC5wcm90b3R5cGUucGFyc2VSb3cgPSBmdW5jdGlvbiAocm93RGF0YSkge1xuICB2YXIgcm93ID0ge31cbiAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHJvd0RhdGEubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICB2YXIgcmF3VmFsdWUgPSByb3dEYXRhW2ldXG4gICAgdmFyIGZpZWxkID0gdGhpcy5maWVsZHNbaV0ubmFtZVxuICAgIGlmIChyYXdWYWx1ZSAhPT0gbnVsbCkge1xuICAgICAgcm93W2ZpZWxkXSA9IHRoaXMuX3BhcnNlcnNbaV0ocmF3VmFsdWUpXG4gICAgfSBlbHNlIHtcbiAgICAgIHJvd1tmaWVsZF0gPSBudWxsXG4gICAgfVxuICB9XG4gIHJldHVybiByb3dcbn1cblxuUmVzdWx0LnByb3RvdHlwZS5hZGRSb3cgPSBmdW5jdGlvbiAocm93KSB7XG4gIHRoaXMucm93cy5wdXNoKHJvdylcbn1cblxuUmVzdWx0LnByb3RvdHlwZS5hZGRGaWVsZHMgPSBmdW5jdGlvbiAoZmllbGREZXNjcmlwdGlvbnMpIHtcbiAgLy8gY2xlYXJzIGZpZWxkIGRlZmluaXRpb25zXG4gIC8vIG11bHRpcGxlIHF1ZXJ5IHN0YXRlbWVudHMgaW4gMSBhY3Rpb24gY2FuIHJlc3VsdCBpbiBtdWx0aXBsZSBzZXRzXG4gIC8vIG9mIHJvd0Rlc2NyaXB0aW9ucy4uLmVnOiAnc2VsZWN0IE5PVygpOyBzZWxlY3QgMTo6aW50OydcbiAgLy8geW91IG5lZWQgdG8gcmVzZXQgdGhlIGZpZWxkc1xuICBpZiAodGhpcy5maWVsZHMubGVuZ3RoKSB7XG4gICAgdGhpcy5maWVsZHMgPSBbXVxuICAgIHRoaXMuX3BhcnNlcnMgPSBbXVxuICB9XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgZmllbGREZXNjcmlwdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgZGVzYyA9IGZpZWxkRGVzY3JpcHRpb25zW2ldXG4gICAgdGhpcy5maWVsZHMucHVzaChkZXNjKVxuICAgIHZhciBwYXJzZXIgPSB0aGlzLl9nZXRUeXBlUGFyc2VyKGRlc2MuZGF0YVR5cGVJRCwgZGVzYy5mb3JtYXQgfHwgJ3RleHQnKVxuICAgIHRoaXMuX3BhcnNlcnMucHVzaChwYXJzZXIpXG4gIH1cbn1cblxuUmVzdWx0LnByb3RvdHlwZS5fZ2V0VHlwZVBhcnNlciA9IHR5cGVzLmdldFR5cGVQYXJzZXJcblxubW9kdWxlLmV4cG9ydHMgPSBSZXN1bHRcbiIsIid1c2Ugc3RyaWN0J1xuLyoqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTAtMjAxNyBCcmlhbiBDYXJsc29uIChicmlhbi5tLmNhcmxzb25AZ21haWwuY29tKVxuICogQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIFJFQURNRS5tZCBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbnZhciB0eXBlcyA9IHJlcXVpcmUoJ3BnLXR5cGVzJylcblxuZnVuY3Rpb24gVHlwZU92ZXJyaWRlcyAodXNlclR5cGVzKSB7XG4gIHRoaXMuX3R5cGVzID0gdXNlclR5cGVzIHx8IHR5cGVzXG4gIHRoaXMudGV4dCA9IHt9XG4gIHRoaXMuYmluYXJ5ID0ge31cbn1cblxuVHlwZU92ZXJyaWRlcy5wcm90b3R5cGUuZ2V0T3ZlcnJpZGVzID0gZnVuY3Rpb24gKGZvcm1hdCkge1xuICBzd2l0Y2ggKGZvcm1hdCkge1xuICAgIGNhc2UgJ3RleHQnOiByZXR1cm4gdGhpcy50ZXh0XG4gICAgY2FzZSAnYmluYXJ5JzogcmV0dXJuIHRoaXMuYmluYXJ5XG4gICAgZGVmYXVsdDogcmV0dXJuIHt9XG4gIH1cbn1cblxuVHlwZU92ZXJyaWRlcy5wcm90b3R5cGUuc2V0VHlwZVBhcnNlciA9IGZ1bmN0aW9uIChvaWQsIGZvcm1hdCwgcGFyc2VGbikge1xuICBpZiAodHlwZW9mIGZvcm1hdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHBhcnNlRm4gPSBmb3JtYXRcbiAgICBmb3JtYXQgPSAndGV4dCdcbiAgfVxuICB0aGlzLmdldE92ZXJyaWRlcyhmb3JtYXQpW29pZF0gPSBwYXJzZUZuXG59XG5cblR5cGVPdmVycmlkZXMucHJvdG90eXBlLmdldFR5cGVQYXJzZXIgPSBmdW5jdGlvbiAob2lkLCBmb3JtYXQpIHtcbiAgZm9ybWF0ID0gZm9ybWF0IHx8ICd0ZXh0J1xuICByZXR1cm4gdGhpcy5nZXRPdmVycmlkZXMoZm9ybWF0KVtvaWRdIHx8IHRoaXMuX3R5cGVzLmdldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQpXG59XG5cbm1vZHVsZS5leHBvcnRzID0gVHlwZU92ZXJyaWRlc1xuIiwiJ3VzZSBzdHJpY3QnXG4vKipcbiAqIENvcHlyaWdodCAoYykgMjAxMC0yMDE3IEJyaWFuIENhcmxzb24gKGJyaWFuLm0uY2FybHNvbkBnbWFpbC5jb20pXG4gKiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogUkVBRE1FLm1kIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxuY29uc3QgY3J5cHRvID0gcmVxdWlyZSgnY3J5cHRvJylcblxuY29uc3QgZGVmYXVsdHMgPSByZXF1aXJlKCcuL2RlZmF1bHRzJylcblxuZnVuY3Rpb24gZXNjYXBlRWxlbWVudCAoZWxlbWVudFJlcHJlc2VudGF0aW9uKSB7XG4gIHZhciBlc2NhcGVkID0gZWxlbWVudFJlcHJlc2VudGF0aW9uXG4gICAgLnJlcGxhY2UoL1xcXFwvZywgJ1xcXFxcXFxcJylcbiAgICAucmVwbGFjZSgvXCIvZywgJ1xcXFxcIicpXG5cbiAgcmV0dXJuICdcIicgKyBlc2NhcGVkICsgJ1wiJ1xufVxuXG4vLyBjb252ZXJ0IGEgSlMgYXJyYXkgdG8gYSBwb3N0Z3JlcyBhcnJheSBsaXRlcmFsXG4vLyB1c2VzIGNvbW1hIHNlcGFyYXRvciBzbyB3b24ndCB3b3JrIGZvciB0eXBlcyBsaWtlIGJveCB0aGF0IHVzZVxuLy8gYSBkaWZmZXJlbnQgYXJyYXkgc2VwYXJhdG9yLlxuZnVuY3Rpb24gYXJyYXlTdHJpbmcgKHZhbCkge1xuICB2YXIgcmVzdWx0ID0gJ3snXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGkgPiAwKSB7XG4gICAgICByZXN1bHQgPSByZXN1bHQgKyAnLCdcbiAgICB9XG4gICAgaWYgKHZhbFtpXSA9PT0gbnVsbCB8fCB0eXBlb2YgdmFsW2ldID09PSAndW5kZWZpbmVkJykge1xuICAgICAgcmVzdWx0ID0gcmVzdWx0ICsgJ05VTEwnXG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbFtpXSkpIHtcbiAgICAgIHJlc3VsdCA9IHJlc3VsdCArIGFycmF5U3RyaW5nKHZhbFtpXSlcbiAgICB9IGVsc2UgaWYgKHZhbFtpXSBpbnN0YW5jZW9mIEJ1ZmZlcikge1xuICAgICAgcmVzdWx0ICs9ICdcXFxcXFxcXHgnICsgdmFsW2ldLnRvU3RyaW5nKCdoZXgnKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHQgKz0gZXNjYXBlRWxlbWVudChwcmVwYXJlVmFsdWUodmFsW2ldKSlcbiAgICB9XG4gIH1cbiAgcmVzdWx0ID0gcmVzdWx0ICsgJ30nXG4gIHJldHVybiByZXN1bHRcbn1cblxuLy8gY29udmVydHMgdmFsdWVzIGZyb20gamF2YXNjcmlwdCB0eXBlc1xuLy8gdG8gdGhlaXIgJ3JhdycgY291bnRlcnBhcnRzIGZvciB1c2UgYXMgYSBwb3N0Z3JlcyBwYXJhbWV0ZXJcbi8vIG5vdGU6IHlvdSBjYW4gb3ZlcnJpZGUgdGhpcyBmdW5jdGlvbiB0byBwcm92aWRlIHlvdXIgb3duIGNvbnZlcnNpb24gbWVjaGFuaXNtXG4vLyBmb3IgY29tcGxleCB0eXBlcywgZXRjLi4uXG52YXIgcHJlcGFyZVZhbHVlID0gZnVuY3Rpb24gKHZhbCwgc2Vlbikge1xuICBpZiAodmFsIGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgcmV0dXJuIHZhbFxuICB9XG4gIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcodmFsKSkge1xuICAgIHZhciBidWYgPSBCdWZmZXIuZnJvbSh2YWwuYnVmZmVyLCB2YWwuYnl0ZU9mZnNldCwgdmFsLmJ5dGVMZW5ndGgpXG4gICAgaWYgKGJ1Zi5sZW5ndGggPT09IHZhbC5ieXRlTGVuZ3RoKSB7XG4gICAgICByZXR1cm4gYnVmXG4gICAgfVxuICAgIHJldHVybiBidWYuc2xpY2UodmFsLmJ5dGVPZmZzZXQsIHZhbC5ieXRlT2Zmc2V0ICsgdmFsLmJ5dGVMZW5ndGgpIC8vIE5vZGUuanMgdjQgZG9lcyBub3Qgc3VwcG9ydCB0aG9zZSBCdWZmZXIuZnJvbSBwYXJhbXNcbiAgfVxuICBpZiAodmFsIGluc3RhbmNlb2YgRGF0ZSkge1xuICAgIGlmIChkZWZhdWx0cy5wYXJzZUlucHV0RGF0ZXNBc1VUQykge1xuICAgICAgcmV0dXJuIGRhdGVUb1N0cmluZ1VUQyh2YWwpXG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBkYXRlVG9TdHJpbmcodmFsKVxuICAgIH1cbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWwpKSB7XG4gICAgcmV0dXJuIGFycmF5U3RyaW5nKHZhbClcbiAgfVxuICBpZiAodmFsID09PSBudWxsIHx8IHR5cGVvZiB2YWwgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuICBpZiAodHlwZW9mIHZhbCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gcHJlcGFyZU9iamVjdCh2YWwsIHNlZW4pXG4gIH1cbiAgcmV0dXJuIHZhbC50b1N0cmluZygpXG59XG5cbmZ1bmN0aW9uIHByZXBhcmVPYmplY3QgKHZhbCwgc2Vlbikge1xuICBpZiAodmFsICYmIHR5cGVvZiB2YWwudG9Qb3N0Z3JlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHNlZW4gPSBzZWVuIHx8IFtdXG4gICAgaWYgKHNlZW4uaW5kZXhPZih2YWwpICE9PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdjaXJjdWxhciByZWZlcmVuY2UgZGV0ZWN0ZWQgd2hpbGUgcHJlcGFyaW5nIFwiJyArIHZhbCArICdcIiBmb3IgcXVlcnknKVxuICAgIH1cbiAgICBzZWVuLnB1c2godmFsKVxuXG4gICAgcmV0dXJuIHByZXBhcmVWYWx1ZSh2YWwudG9Qb3N0Z3JlcyhwcmVwYXJlVmFsdWUpLCBzZWVuKVxuICB9XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWwpXG59XG5cbmZ1bmN0aW9uIHBhZCAobnVtYmVyLCBkaWdpdHMpIHtcbiAgbnVtYmVyID0gJycgKyBudW1iZXJcbiAgd2hpbGUgKG51bWJlci5sZW5ndGggPCBkaWdpdHMpIHsgbnVtYmVyID0gJzAnICsgbnVtYmVyIH1cbiAgcmV0dXJuIG51bWJlclxufVxuXG5mdW5jdGlvbiBkYXRlVG9TdHJpbmcgKGRhdGUpIHtcbiAgdmFyIG9mZnNldCA9IC1kYXRlLmdldFRpbWV6b25lT2Zmc2V0KClcbiAgdmFyIHJldCA9IHBhZChkYXRlLmdldEZ1bGxZZWFyKCksIDQpICsgJy0nICtcbiAgICBwYWQoZGF0ZS5nZXRNb250aCgpICsgMSwgMikgKyAnLScgK1xuICAgIHBhZChkYXRlLmdldERhdGUoKSwgMikgKyAnVCcgK1xuICAgIHBhZChkYXRlLmdldEhvdXJzKCksIDIpICsgJzonICtcbiAgICBwYWQoZGF0ZS5nZXRNaW51dGVzKCksIDIpICsgJzonICtcbiAgICBwYWQoZGF0ZS5nZXRTZWNvbmRzKCksIDIpICsgJy4nICtcbiAgICBwYWQoZGF0ZS5nZXRNaWxsaXNlY29uZHMoKSwgMylcblxuICBpZiAob2Zmc2V0IDwgMCkge1xuICAgIHJldCArPSAnLSdcbiAgICBvZmZzZXQgKj0gLTFcbiAgfSBlbHNlIHsgcmV0ICs9ICcrJyB9XG5cbiAgcmV0dXJuIHJldCArIHBhZChNYXRoLmZsb29yKG9mZnNldCAvIDYwKSwgMikgKyAnOicgKyBwYWQob2Zmc2V0ICUgNjAsIDIpXG59XG5cbmZ1bmN0aW9uIGRhdGVUb1N0cmluZ1VUQyAoZGF0ZSkge1xuICB2YXIgcmV0ID0gcGFkKGRhdGUuZ2V0VVRDRnVsbFllYXIoKSwgNCkgKyAnLScgK1xuICAgIHBhZChkYXRlLmdldFVUQ01vbnRoKCkgKyAxLCAyKSArICctJyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDRGF0ZSgpLCAyKSArICdUJyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDSG91cnMoKSwgMikgKyAnOicgK1xuICAgIHBhZChkYXRlLmdldFVUQ01pbnV0ZXMoKSwgMikgKyAnOicgK1xuICAgIHBhZChkYXRlLmdldFVUQ1NlY29uZHMoKSwgMikgKyAnLicgK1xuICAgIHBhZChkYXRlLmdldFVUQ01pbGxpc2Vjb25kcygpLCAzKVxuXG4gIHJldHVybiByZXQgKyAnKzAwOjAwJ1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVRdWVyeUNvbmZpZyAoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gIC8vIGNhbiB0YWtlIGluIHN0cmluZ3Mgb3IgY29uZmlnIG9iamVjdHNcbiAgY29uZmlnID0gKHR5cGVvZiAoY29uZmlnKSA9PT0gJ3N0cmluZycpID8geyB0ZXh0OiBjb25maWcgfSA6IGNvbmZpZ1xuICBpZiAodmFsdWVzKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZXMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNvbmZpZy5jYWxsYmFjayA9IHZhbHVlc1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25maWcudmFsdWVzID0gdmFsdWVzXG4gICAgfVxuICB9XG4gIGlmIChjYWxsYmFjaykge1xuICAgIGNvbmZpZy5jYWxsYmFjayA9IGNhbGxiYWNrXG4gIH1cbiAgcmV0dXJuIGNvbmZpZ1xufVxuXG5jb25zdCBtZDUgPSBmdW5jdGlvbiAoc3RyaW5nKSB7XG4gIHJldHVybiBjcnlwdG8uY3JlYXRlSGFzaCgnbWQ1JykudXBkYXRlKHN0cmluZywgJ3V0Zi04JykuZGlnZXN0KCdoZXgnKVxufVxuXG4vLyBTZWUgQXV0aGVudGljYXRpb25NRDVQYXNzd29yZCBhdCBodHRwczovL3d3dy5wb3N0Z3Jlc3FsLm9yZy9kb2NzL2N1cnJlbnQvc3RhdGljL3Byb3RvY29sLWZsb3cuaHRtbFxuY29uc3QgcG9zdGdyZXNNZDVQYXNzd29yZEhhc2ggPSBmdW5jdGlvbiAodXNlciwgcGFzc3dvcmQsIHNhbHQpIHtcbiAgdmFyIGlubmVyID0gbWQ1KHBhc3N3b3JkICsgdXNlcilcbiAgdmFyIG91dGVyID0gbWQ1KEJ1ZmZlci5jb25jYXQoW0J1ZmZlci5mcm9tKGlubmVyKSwgc2FsdF0pKVxuICByZXR1cm4gJ21kNScgKyBvdXRlclxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgcHJlcGFyZVZhbHVlOiBmdW5jdGlvbiBwcmVwYXJlVmFsdWVXcmFwcGVyICh2YWx1ZSkge1xuICAgIC8vIHRoaXMgZW5zdXJlcyB0aGF0IGV4dHJhIGFyZ3VtZW50cyBkbyBub3QgZ2V0IHBhc3NlZCBpbnRvIHByZXBhcmVWYWx1ZVxuICAgIC8vIGJ5IGFjY2lkZW50LCBlZzogZnJvbSBjYWxsaW5nIHZhbHVlcy5tYXAodXRpbHMucHJlcGFyZVZhbHVlKVxuICAgIHJldHVybiBwcmVwYXJlVmFsdWUodmFsdWUpXG4gIH0sXG4gIG5vcm1hbGl6ZVF1ZXJ5Q29uZmlnLFxuICBwb3N0Z3Jlc01kNVBhc3N3b3JkSGFzaCxcbiAgbWQ1XG59XG4iLCIvLyBleHBvcnQgdGhlIGNsYXNzIGlmIHdlIGFyZSBpbiBhIE5vZGUtbGlrZSBzeXN0ZW0uXG5pZiAodHlwZW9mIG1vZHVsZSA9PT0gJ29iamVjdCcgJiYgbW9kdWxlLmV4cG9ydHMgPT09IGV4cG9ydHMpXG4gIGV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IFNlbVZlcjtcblxuLy8gVGhlIGRlYnVnIGZ1bmN0aW9uIGlzIGV4Y2x1ZGVkIGVudGlyZWx5IGZyb20gdGhlIG1pbmlmaWVkIHZlcnNpb24uXG4vKiBub21pbiAqLyB2YXIgZGVidWc7XG4vKiBub21pbiAqLyBpZiAodHlwZW9mIHByb2Nlc3MgPT09ICdvYmplY3QnICYmXG4gICAgLyogbm9taW4gKi8gcHJvY2Vzcy5lbnYgJiZcbiAgICAvKiBub21pbiAqLyBwcm9jZXNzLmVudi5OT0RFX0RFQlVHICYmXG4gICAgLyogbm9taW4gKi8gL1xcYnNlbXZlclxcYi9pLnRlc3QocHJvY2Vzcy5lbnYuTk9ERV9ERUJVRykpXG4gIC8qIG5vbWluICovIGRlYnVnID0gZnVuY3Rpb24oKSB7XG4gICAgLyogbm9taW4gKi8gdmFyIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDApO1xuICAgIC8qIG5vbWluICovIGFyZ3MudW5zaGlmdCgnU0VNVkVSJyk7XG4gICAgLyogbm9taW4gKi8gY29uc29sZS5sb2cuYXBwbHkoY29uc29sZSwgYXJncyk7XG4gICAgLyogbm9taW4gKi8gfTtcbi8qIG5vbWluICovIGVsc2VcbiAgLyogbm9taW4gKi8gZGVidWcgPSBmdW5jdGlvbigpIHt9O1xuXG4vLyBOb3RlOiB0aGlzIGlzIHRoZSBzZW12ZXIub3JnIHZlcnNpb24gb2YgdGhlIHNwZWMgdGhhdCBpdCBpbXBsZW1lbnRzXG4vLyBOb3QgbmVjZXNzYXJpbHkgdGhlIHBhY2thZ2UgdmVyc2lvbiBvZiB0aGlzIGNvZGUuXG5leHBvcnRzLlNFTVZFUl9TUEVDX1ZFUlNJT04gPSAnMi4wLjAnO1xuXG52YXIgTUFYX0xFTkdUSCA9IDI1NjtcbnZhciBNQVhfU0FGRV9JTlRFR0VSID0gTnVtYmVyLk1BWF9TQUZFX0lOVEVHRVIgfHwgOTAwNzE5OTI1NDc0MDk5MTtcblxuLy8gVGhlIGFjdHVhbCByZWdleHBzIGdvIG9uIGV4cG9ydHMucmVcbnZhciByZSA9IGV4cG9ydHMucmUgPSBbXTtcbnZhciBzcmMgPSBleHBvcnRzLnNyYyA9IFtdO1xudmFyIFIgPSAwO1xuXG4vLyBUaGUgZm9sbG93aW5nIFJlZ3VsYXIgRXhwcmVzc2lvbnMgY2FuIGJlIHVzZWQgZm9yIHRva2VuaXppbmcsXG4vLyB2YWxpZGF0aW5nLCBhbmQgcGFyc2luZyBTZW1WZXIgdmVyc2lvbiBzdHJpbmdzLlxuXG4vLyAjIyBOdW1lcmljIElkZW50aWZpZXJcbi8vIEEgc2luZ2xlIGAwYCwgb3IgYSBub24temVybyBkaWdpdCBmb2xsb3dlZCBieSB6ZXJvIG9yIG1vcmUgZGlnaXRzLlxuXG52YXIgTlVNRVJJQ0lERU5USUZJRVIgPSBSKys7XG5zcmNbTlVNRVJJQ0lERU5USUZJRVJdID0gJzB8WzEtOV1cXFxcZConO1xudmFyIE5VTUVSSUNJREVOVElGSUVSTE9PU0UgPSBSKys7XG5zcmNbTlVNRVJJQ0lERU5USUZJRVJMT09TRV0gPSAnWzAtOV0rJztcblxuXG4vLyAjIyBOb24tbnVtZXJpYyBJZGVudGlmaWVyXG4vLyBaZXJvIG9yIG1vcmUgZGlnaXRzLCBmb2xsb3dlZCBieSBhIGxldHRlciBvciBoeXBoZW4sIGFuZCB0aGVuIHplcm8gb3Jcbi8vIG1vcmUgbGV0dGVycywgZGlnaXRzLCBvciBoeXBoZW5zLlxuXG52YXIgTk9OTlVNRVJJQ0lERU5USUZJRVIgPSBSKys7XG5zcmNbTk9OTlVNRVJJQ0lERU5USUZJRVJdID0gJ1xcXFxkKlthLXpBLVotXVthLXpBLVowLTktXSonO1xuXG5cbi8vICMjIE1haW4gVmVyc2lvblxuLy8gVGhyZWUgZG90LXNlcGFyYXRlZCBudW1lcmljIGlkZW50aWZpZXJzLlxuXG52YXIgTUFJTlZFUlNJT04gPSBSKys7XG5zcmNbTUFJTlZFUlNJT05dID0gJygnICsgc3JjW05VTUVSSUNJREVOVElGSUVSXSArICcpXFxcXC4nICtcbiAgICAgICAgICAgICAgICAgICAnKCcgKyBzcmNbTlVNRVJJQ0lERU5USUZJRVJdICsgJylcXFxcLicgK1xuICAgICAgICAgICAgICAgICAgICcoJyArIHNyY1tOVU1FUklDSURFTlRJRklFUl0gKyAnKSc7XG5cbnZhciBNQUlOVkVSU0lPTkxPT1NFID0gUisrO1xuc3JjW01BSU5WRVJTSU9OTE9PU0VdID0gJygnICsgc3JjW05VTUVSSUNJREVOVElGSUVSTE9PU0VdICsgJylcXFxcLicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgJygnICsgc3JjW05VTUVSSUNJREVOVElGSUVSTE9PU0VdICsgJylcXFxcLicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgJygnICsgc3JjW05VTUVSSUNJREVOVElGSUVSTE9PU0VdICsgJyknO1xuXG4vLyAjIyBQcmUtcmVsZWFzZSBWZXJzaW9uIElkZW50aWZpZXJcbi8vIEEgbnVtZXJpYyBpZGVudGlmaWVyLCBvciBhIG5vbi1udW1lcmljIGlkZW50aWZpZXIuXG5cbnZhciBQUkVSRUxFQVNFSURFTlRJRklFUiA9IFIrKztcbnNyY1tQUkVSRUxFQVNFSURFTlRJRklFUl0gPSAnKD86JyArIHNyY1tOVU1FUklDSURFTlRJRklFUl0gK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICd8JyArIHNyY1tOT05OVU1FUklDSURFTlRJRklFUl0gKyAnKSc7XG5cbnZhciBQUkVSRUxFQVNFSURFTlRJRklFUkxPT1NFID0gUisrO1xuc3JjW1BSRVJFTEVBU0VJREVOVElGSUVSTE9PU0VdID0gJyg/OicgKyBzcmNbTlVNRVJJQ0lERU5USUZJRVJMT09TRV0gK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3wnICsgc3JjW05PTk5VTUVSSUNJREVOVElGSUVSXSArICcpJztcblxuXG4vLyAjIyBQcmUtcmVsZWFzZSBWZXJzaW9uXG4vLyBIeXBoZW4sIGZvbGxvd2VkIGJ5IG9uZSBvciBtb3JlIGRvdC1zZXBhcmF0ZWQgcHJlLXJlbGVhc2UgdmVyc2lvblxuLy8gaWRlbnRpZmllcnMuXG5cbnZhciBQUkVSRUxFQVNFID0gUisrO1xuc3JjW1BSRVJFTEVBU0VdID0gJyg/Oi0oJyArIHNyY1tQUkVSRUxFQVNFSURFTlRJRklFUl0gK1xuICAgICAgICAgICAgICAgICAgJyg/OlxcXFwuJyArIHNyY1tQUkVSRUxFQVNFSURFTlRJRklFUl0gKyAnKSopKSc7XG5cbnZhciBQUkVSRUxFQVNFTE9PU0UgPSBSKys7XG5zcmNbUFJFUkVMRUFTRUxPT1NFXSA9ICcoPzotPygnICsgc3JjW1BSRVJFTEVBU0VJREVOVElGSUVSTE9PU0VdICtcbiAgICAgICAgICAgICAgICAgICAgICAgJyg/OlxcXFwuJyArIHNyY1tQUkVSRUxFQVNFSURFTlRJRklFUkxPT1NFXSArICcpKikpJztcblxuLy8gIyMgQnVpbGQgTWV0YWRhdGEgSWRlbnRpZmllclxuLy8gQW55IGNvbWJpbmF0aW9uIG9mIGRpZ2l0cywgbGV0dGVycywgb3IgaHlwaGVucy5cblxudmFyIEJVSUxESURFTlRJRklFUiA9IFIrKztcbnNyY1tCVUlMRElERU5USUZJRVJdID0gJ1swLTlBLVphLXotXSsnO1xuXG4vLyAjIyBCdWlsZCBNZXRhZGF0YVxuLy8gUGx1cyBzaWduLCBmb2xsb3dlZCBieSBvbmUgb3IgbW9yZSBwZXJpb2Qtc2VwYXJhdGVkIGJ1aWxkIG1ldGFkYXRhXG4vLyBpZGVudGlmaWVycy5cblxudmFyIEJVSUxEID0gUisrO1xuc3JjW0JVSUxEXSA9ICcoPzpcXFxcKygnICsgc3JjW0JVSUxESURFTlRJRklFUl0gK1xuICAgICAgICAgICAgICcoPzpcXFxcLicgKyBzcmNbQlVJTERJREVOVElGSUVSXSArICcpKikpJztcblxuXG4vLyAjIyBGdWxsIFZlcnNpb24gU3RyaW5nXG4vLyBBIG1haW4gdmVyc2lvbiwgZm9sbG93ZWQgb3B0aW9uYWxseSBieSBhIHByZS1yZWxlYXNlIHZlcnNpb24gYW5kXG4vLyBidWlsZCBtZXRhZGF0YS5cblxuLy8gTm90ZSB0aGF0IHRoZSBvbmx5IG1ham9yLCBtaW5vciwgcGF0Y2gsIGFuZCBwcmUtcmVsZWFzZSBzZWN0aW9ucyBvZlxuLy8gdGhlIHZlcnNpb24gc3RyaW5nIGFyZSBjYXB0dXJpbmcgZ3JvdXBzLiAgVGhlIGJ1aWxkIG1ldGFkYXRhIGlzIG5vdCBhXG4vLyBjYXB0dXJpbmcgZ3JvdXAsIGJlY2F1c2UgaXQgc2hvdWxkIG5vdCBldmVyIGJlIHVzZWQgaW4gdmVyc2lvblxuLy8gY29tcGFyaXNvbi5cblxudmFyIEZVTEwgPSBSKys7XG52YXIgRlVMTFBMQUlOID0gJ3Y/JyArIHNyY1tNQUlOVkVSU0lPTl0gK1xuICAgICAgICAgICAgICAgIHNyY1tQUkVSRUxFQVNFXSArICc/JyArXG4gICAgICAgICAgICAgICAgc3JjW0JVSUxEXSArICc/Jztcblxuc3JjW0ZVTExdID0gJ14nICsgRlVMTFBMQUlOICsgJyQnO1xuXG4vLyBsaWtlIGZ1bGwsIGJ1dCBhbGxvd3MgdjEuMi4zIGFuZCA9MS4yLjMsIHdoaWNoIHBlb3BsZSBkbyBzb21ldGltZXMuXG4vLyBhbHNvLCAxLjAuMGFscGhhMSAocHJlcmVsZWFzZSB3aXRob3V0IHRoZSBoeXBoZW4pIHdoaWNoIGlzIHByZXR0eVxuLy8gY29tbW9uIGluIHRoZSBucG0gcmVnaXN0cnkuXG52YXIgTE9PU0VQTEFJTiA9ICdbdj1cXFxcc10qJyArIHNyY1tNQUlOVkVSU0lPTkxPT1NFXSArXG4gICAgICAgICAgICAgICAgIHNyY1tQUkVSRUxFQVNFTE9PU0VdICsgJz8nICtcbiAgICAgICAgICAgICAgICAgc3JjW0JVSUxEXSArICc/JztcblxudmFyIExPT1NFID0gUisrO1xuc3JjW0xPT1NFXSA9ICdeJyArIExPT1NFUExBSU4gKyAnJCc7XG5cbnZhciBHVExUID0gUisrO1xuc3JjW0dUTFRdID0gJygoPzo8fD4pPz0/KSc7XG5cbi8vIFNvbWV0aGluZyBsaWtlIFwiMi4qXCIgb3IgXCIxLjIueFwiLlxuLy8gTm90ZSB0aGF0IFwieC54XCIgaXMgYSB2YWxpZCB4UmFuZ2UgaWRlbnRpZmVyLCBtZWFuaW5nIFwiYW55IHZlcnNpb25cIlxuLy8gT25seSB0aGUgZmlyc3QgaXRlbSBpcyBzdHJpY3RseSByZXF1aXJlZC5cbnZhciBYUkFOR0VJREVOVElGSUVSTE9PU0UgPSBSKys7XG5zcmNbWFJBTkdFSURFTlRJRklFUkxPT1NFXSA9IHNyY1tOVU1FUklDSURFTlRJRklFUkxPT1NFXSArICd8eHxYfFxcXFwqJztcbnZhciBYUkFOR0VJREVOVElGSUVSID0gUisrO1xuc3JjW1hSQU5HRUlERU5USUZJRVJdID0gc3JjW05VTUVSSUNJREVOVElGSUVSXSArICd8eHxYfFxcXFwqJztcblxudmFyIFhSQU5HRVBMQUlOID0gUisrO1xuc3JjW1hSQU5HRVBMQUlOXSA9ICdbdj1cXFxcc10qKCcgKyBzcmNbWFJBTkdFSURFTlRJRklFUl0gKyAnKScgK1xuICAgICAgICAgICAgICAgICAgICcoPzpcXFxcLignICsgc3JjW1hSQU5HRUlERU5USUZJRVJdICsgJyknICtcbiAgICAgICAgICAgICAgICAgICAnKD86XFxcXC4oJyArIHNyY1tYUkFOR0VJREVOVElGSUVSXSArICcpJyArXG4gICAgICAgICAgICAgICAgICAgJyg/OicgKyBzcmNbUFJFUkVMRUFTRV0gKyAnKT8nICtcbiAgICAgICAgICAgICAgICAgICBzcmNbQlVJTERdICsgJz8nICtcbiAgICAgICAgICAgICAgICAgICAnKT8pPyc7XG5cbnZhciBYUkFOR0VQTEFJTkxPT1NFID0gUisrO1xuc3JjW1hSQU5HRVBMQUlOTE9PU0VdID0gJ1t2PVxcXFxzXSooJyArIHNyY1tYUkFOR0VJREVOVElGSUVSTE9PU0VdICsgJyknICtcbiAgICAgICAgICAgICAgICAgICAgICAgICcoPzpcXFxcLignICsgc3JjW1hSQU5HRUlERU5USUZJRVJMT09TRV0gKyAnKScgK1xuICAgICAgICAgICAgICAgICAgICAgICAgJyg/OlxcXFwuKCcgKyBzcmNbWFJBTkdFSURFTlRJRklFUkxPT1NFXSArICcpJyArXG4gICAgICAgICAgICAgICAgICAgICAgICAnKD86JyArIHNyY1tQUkVSRUxFQVNFTE9PU0VdICsgJyk/JyArXG4gICAgICAgICAgICAgICAgICAgICAgICBzcmNbQlVJTERdICsgJz8nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICcpPyk/JztcblxudmFyIFhSQU5HRSA9IFIrKztcbnNyY1tYUkFOR0VdID0gJ14nICsgc3JjW0dUTFRdICsgJ1xcXFxzKicgKyBzcmNbWFJBTkdFUExBSU5dICsgJyQnO1xudmFyIFhSQU5HRUxPT1NFID0gUisrO1xuc3JjW1hSQU5HRUxPT1NFXSA9ICdeJyArIHNyY1tHVExUXSArICdcXFxccyonICsgc3JjW1hSQU5HRVBMQUlOTE9PU0VdICsgJyQnO1xuXG4vLyBUaWxkZSByYW5nZXMuXG4vLyBNZWFuaW5nIGlzIFwicmVhc29uYWJseSBhdCBvciBncmVhdGVyIHRoYW5cIlxudmFyIExPTkVUSUxERSA9IFIrKztcbnNyY1tMT05FVElMREVdID0gJyg/On4+PyknO1xuXG52YXIgVElMREVUUklNID0gUisrO1xuc3JjW1RJTERFVFJJTV0gPSAnKFxcXFxzKiknICsgc3JjW0xPTkVUSUxERV0gKyAnXFxcXHMrJztcbnJlW1RJTERFVFJJTV0gPSBuZXcgUmVnRXhwKHNyY1tUSUxERVRSSU1dLCAnZycpO1xudmFyIHRpbGRlVHJpbVJlcGxhY2UgPSAnJDF+JztcblxudmFyIFRJTERFID0gUisrO1xuc3JjW1RJTERFXSA9ICdeJyArIHNyY1tMT05FVElMREVdICsgc3JjW1hSQU5HRVBMQUlOXSArICckJztcbnZhciBUSUxERUxPT1NFID0gUisrO1xuc3JjW1RJTERFTE9PU0VdID0gJ14nICsgc3JjW0xPTkVUSUxERV0gKyBzcmNbWFJBTkdFUExBSU5MT09TRV0gKyAnJCc7XG5cbi8vIENhcmV0IHJhbmdlcy5cbi8vIE1lYW5pbmcgaXMgXCJhdCBsZWFzdCBhbmQgYmFja3dhcmRzIGNvbXBhdGlibGUgd2l0aFwiXG52YXIgTE9ORUNBUkVUID0gUisrO1xuc3JjW0xPTkVDQVJFVF0gPSAnKD86XFxcXF4pJztcblxudmFyIENBUkVUVFJJTSA9IFIrKztcbnNyY1tDQVJFVFRSSU1dID0gJyhcXFxccyopJyArIHNyY1tMT05FQ0FSRVRdICsgJ1xcXFxzKyc7XG5yZVtDQVJFVFRSSU1dID0gbmV3IFJlZ0V4cChzcmNbQ0FSRVRUUklNXSwgJ2cnKTtcbnZhciBjYXJldFRyaW1SZXBsYWNlID0gJyQxXic7XG5cbnZhciBDQVJFVCA9IFIrKztcbnNyY1tDQVJFVF0gPSAnXicgKyBzcmNbTE9ORUNBUkVUXSArIHNyY1tYUkFOR0VQTEFJTl0gKyAnJCc7XG52YXIgQ0FSRVRMT09TRSA9IFIrKztcbnNyY1tDQVJFVExPT1NFXSA9ICdeJyArIHNyY1tMT05FQ0FSRVRdICsgc3JjW1hSQU5HRVBMQUlOTE9PU0VdICsgJyQnO1xuXG4vLyBBIHNpbXBsZSBndC9sdC9lcSB0aGluZywgb3IganVzdCBcIlwiIHRvIGluZGljYXRlIFwiYW55IHZlcnNpb25cIlxudmFyIENPTVBBUkFUT1JMT09TRSA9IFIrKztcbnNyY1tDT01QQVJBVE9STE9PU0VdID0gJ14nICsgc3JjW0dUTFRdICsgJ1xcXFxzKignICsgTE9PU0VQTEFJTiArICcpJHxeJCc7XG52YXIgQ09NUEFSQVRPUiA9IFIrKztcbnNyY1tDT01QQVJBVE9SXSA9ICdeJyArIHNyY1tHVExUXSArICdcXFxccyooJyArIEZVTExQTEFJTiArICcpJHxeJCc7XG5cblxuLy8gQW4gZXhwcmVzc2lvbiB0byBzdHJpcCBhbnkgd2hpdGVzcGFjZSBiZXR3ZWVuIHRoZSBndGx0IGFuZCB0aGUgdGhpbmdcbi8vIGl0IG1vZGlmaWVzLCBzbyB0aGF0IGA+IDEuMi4zYCA9PT4gYD4xLjIuM2BcbnZhciBDT01QQVJBVE9SVFJJTSA9IFIrKztcbnNyY1tDT01QQVJBVE9SVFJJTV0gPSAnKFxcXFxzKiknICsgc3JjW0dUTFRdICtcbiAgICAgICAgICAgICAgICAgICAgICAnXFxcXHMqKCcgKyBMT09TRVBMQUlOICsgJ3wnICsgc3JjW1hSQU5HRVBMQUlOXSArICcpJztcblxuLy8gdGhpcyBvbmUgaGFzIHRvIHVzZSB0aGUgL2cgZmxhZ1xucmVbQ09NUEFSQVRPUlRSSU1dID0gbmV3IFJlZ0V4cChzcmNbQ09NUEFSQVRPUlRSSU1dLCAnZycpO1xudmFyIGNvbXBhcmF0b3JUcmltUmVwbGFjZSA9ICckMSQyJDMnO1xuXG5cbi8vIFNvbWV0aGluZyBsaWtlIGAxLjIuMyAtIDEuMi40YFxuLy8gTm90ZSB0aGF0IHRoZXNlIGFsbCB1c2UgdGhlIGxvb3NlIGZvcm0sIGJlY2F1c2UgdGhleSdsbCBiZVxuLy8gY2hlY2tlZCBhZ2FpbnN0IGVpdGhlciB0aGUgc3RyaWN0IG9yIGxvb3NlIGNvbXBhcmF0b3IgZm9ybVxuLy8gbGF0ZXIuXG52YXIgSFlQSEVOUkFOR0UgPSBSKys7XG5zcmNbSFlQSEVOUkFOR0VdID0gJ15cXFxccyooJyArIHNyY1tYUkFOR0VQTEFJTl0gKyAnKScgK1xuICAgICAgICAgICAgICAgICAgICdcXFxccystXFxcXHMrJyArXG4gICAgICAgICAgICAgICAgICAgJygnICsgc3JjW1hSQU5HRVBMQUlOXSArICcpJyArXG4gICAgICAgICAgICAgICAgICAgJ1xcXFxzKiQnO1xuXG52YXIgSFlQSEVOUkFOR0VMT09TRSA9IFIrKztcbnNyY1tIWVBIRU5SQU5HRUxPT1NFXSA9ICdeXFxcXHMqKCcgKyBzcmNbWFJBTkdFUExBSU5MT09TRV0gKyAnKScgK1xuICAgICAgICAgICAgICAgICAgICAgICAgJ1xcXFxzKy1cXFxccysnICtcbiAgICAgICAgICAgICAgICAgICAgICAgICcoJyArIHNyY1tYUkFOR0VQTEFJTkxPT1NFXSArICcpJyArXG4gICAgICAgICAgICAgICAgICAgICAgICAnXFxcXHMqJCc7XG5cbi8vIFN0YXIgcmFuZ2VzIGJhc2ljYWxseSBqdXN0IGFsbG93IGFueXRoaW5nIGF0IGFsbC5cbnZhciBTVEFSID0gUisrO1xuc3JjW1NUQVJdID0gJyg8fD4pPz0/XFxcXHMqXFxcXConO1xuXG4vLyBDb21waWxlIHRvIGFjdHVhbCByZWdleHAgb2JqZWN0cy5cbi8vIEFsbCBhcmUgZmxhZy1mcmVlLCB1bmxlc3MgdGhleSB3ZXJlIGNyZWF0ZWQgYWJvdmUgd2l0aCBhIGZsYWcuXG5mb3IgKHZhciBpID0gMDsgaSA8IFI7IGkrKykge1xuICBkZWJ1ZyhpLCBzcmNbaV0pO1xuICBpZiAoIXJlW2ldKVxuICAgIHJlW2ldID0gbmV3IFJlZ0V4cChzcmNbaV0pO1xufVxuXG5leHBvcnRzLnBhcnNlID0gcGFyc2U7XG5mdW5jdGlvbiBwYXJzZSh2ZXJzaW9uLCBsb29zZSkge1xuICBpZiAodmVyc2lvbi5sZW5ndGggPiBNQVhfTEVOR1RIKVxuICAgIHJldHVybiBudWxsO1xuXG4gIHZhciByID0gbG9vc2UgPyByZVtMT09TRV0gOiByZVtGVUxMXTtcbiAgaWYgKCFyLnRlc3QodmVyc2lvbikpXG4gICAgcmV0dXJuIG51bGw7XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gbmV3IFNlbVZlcih2ZXJzaW9uLCBsb29zZSk7XG4gIH0gY2F0Y2ggKGVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZXhwb3J0cy52YWxpZCA9IHZhbGlkO1xuZnVuY3Rpb24gdmFsaWQodmVyc2lvbiwgbG9vc2UpIHtcbiAgdmFyIHYgPSBwYXJzZSh2ZXJzaW9uLCBsb29zZSk7XG4gIHJldHVybiB2ID8gdi52ZXJzaW9uIDogbnVsbDtcbn1cblxuXG5leHBvcnRzLmNsZWFuID0gY2xlYW47XG5mdW5jdGlvbiBjbGVhbih2ZXJzaW9uLCBsb29zZSkge1xuICB2YXIgcyA9IHBhcnNlKHZlcnNpb24udHJpbSgpLnJlcGxhY2UoL15bPXZdKy8sICcnKSwgbG9vc2UpO1xuICByZXR1cm4gcyA/IHMudmVyc2lvbiA6IG51bGw7XG59XG5cbmV4cG9ydHMuU2VtVmVyID0gU2VtVmVyO1xuXG5mdW5jdGlvbiBTZW1WZXIodmVyc2lvbiwgbG9vc2UpIHtcbiAgaWYgKHZlcnNpb24gaW5zdGFuY2VvZiBTZW1WZXIpIHtcbiAgICBpZiAodmVyc2lvbi5sb29zZSA9PT0gbG9vc2UpXG4gICAgICByZXR1cm4gdmVyc2lvbjtcbiAgICBlbHNlXG4gICAgICB2ZXJzaW9uID0gdmVyc2lvbi52ZXJzaW9uO1xuICB9IGVsc2UgaWYgKHR5cGVvZiB2ZXJzaW9uICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0ludmFsaWQgVmVyc2lvbjogJyArIHZlcnNpb24pO1xuICB9XG5cbiAgaWYgKHZlcnNpb24ubGVuZ3RoID4gTUFYX0xFTkdUSClcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd2ZXJzaW9uIGlzIGxvbmdlciB0aGFuICcgKyBNQVhfTEVOR1RIICsgJyBjaGFyYWN0ZXJzJylcblxuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgU2VtVmVyKSlcbiAgICByZXR1cm4gbmV3IFNlbVZlcih2ZXJzaW9uLCBsb29zZSk7XG5cbiAgZGVidWcoJ1NlbVZlcicsIHZlcnNpb24sIGxvb3NlKTtcbiAgdGhpcy5sb29zZSA9IGxvb3NlO1xuICB2YXIgbSA9IHZlcnNpb24udHJpbSgpLm1hdGNoKGxvb3NlID8gcmVbTE9PU0VdIDogcmVbRlVMTF0pO1xuXG4gIGlmICghbSlcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbnZhbGlkIFZlcnNpb246ICcgKyB2ZXJzaW9uKTtcblxuICB0aGlzLnJhdyA9IHZlcnNpb247XG5cbiAgLy8gdGhlc2UgYXJlIGFjdHVhbGx5IG51bWJlcnNcbiAgdGhpcy5tYWpvciA9ICttWzFdO1xuICB0aGlzLm1pbm9yID0gK21bMl07XG4gIHRoaXMucGF0Y2ggPSArbVszXTtcblxuICBpZiAodGhpcy5tYWpvciA+IE1BWF9TQUZFX0lOVEVHRVIgfHwgdGhpcy5tYWpvciA8IDApXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCBtYWpvciB2ZXJzaW9uJylcblxuICBpZiAodGhpcy5taW5vciA+IE1BWF9TQUZFX0lOVEVHRVIgfHwgdGhpcy5taW5vciA8IDApXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCBtaW5vciB2ZXJzaW9uJylcblxuICBpZiAodGhpcy5wYXRjaCA+IE1BWF9TQUZFX0lOVEVHRVIgfHwgdGhpcy5wYXRjaCA8IDApXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCBwYXRjaCB2ZXJzaW9uJylcblxuICAvLyBudW1iZXJpZnkgYW55IHByZXJlbGVhc2UgbnVtZXJpYyBpZHNcbiAgaWYgKCFtWzRdKVxuICAgIHRoaXMucHJlcmVsZWFzZSA9IFtdO1xuICBlbHNlXG4gICAgdGhpcy5wcmVyZWxlYXNlID0gbVs0XS5zcGxpdCgnLicpLm1hcChmdW5jdGlvbihpZCkge1xuICAgICAgcmV0dXJuICgvXlswLTldKyQvLnRlc3QoaWQpKSA/ICtpZCA6IGlkO1xuICAgIH0pO1xuXG4gIHRoaXMuYnVpbGQgPSBtWzVdID8gbVs1XS5zcGxpdCgnLicpIDogW107XG4gIHRoaXMuZm9ybWF0KCk7XG59XG5cblNlbVZlci5wcm90b3R5cGUuZm9ybWF0ID0gZnVuY3Rpb24oKSB7XG4gIHRoaXMudmVyc2lvbiA9IHRoaXMubWFqb3IgKyAnLicgKyB0aGlzLm1pbm9yICsgJy4nICsgdGhpcy5wYXRjaDtcbiAgaWYgKHRoaXMucHJlcmVsZWFzZS5sZW5ndGgpXG4gICAgdGhpcy52ZXJzaW9uICs9ICctJyArIHRoaXMucHJlcmVsZWFzZS5qb2luKCcuJyk7XG4gIHJldHVybiB0aGlzLnZlcnNpb247XG59O1xuXG5TZW1WZXIucHJvdG90eXBlLmluc3BlY3QgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuICc8U2VtVmVyIFwiJyArIHRoaXMgKyAnXCI+Jztcbn07XG5cblNlbVZlci5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIHRoaXMudmVyc2lvbjtcbn07XG5cblNlbVZlci5wcm90b3R5cGUuY29tcGFyZSA9IGZ1bmN0aW9uKG90aGVyKSB7XG4gIGRlYnVnKCdTZW1WZXIuY29tcGFyZScsIHRoaXMudmVyc2lvbiwgdGhpcy5sb29zZSwgb3RoZXIpO1xuICBpZiAoIShvdGhlciBpbnN0YW5jZW9mIFNlbVZlcikpXG4gICAgb3RoZXIgPSBuZXcgU2VtVmVyKG90aGVyLCB0aGlzLmxvb3NlKTtcblxuICByZXR1cm4gdGhpcy5jb21wYXJlTWFpbihvdGhlcikgfHwgdGhpcy5jb21wYXJlUHJlKG90aGVyKTtcbn07XG5cblNlbVZlci5wcm90b3R5cGUuY29tcGFyZU1haW4gPSBmdW5jdGlvbihvdGhlcikge1xuICBpZiAoIShvdGhlciBpbnN0YW5jZW9mIFNlbVZlcikpXG4gICAgb3RoZXIgPSBuZXcgU2VtVmVyKG90aGVyLCB0aGlzLmxvb3NlKTtcblxuICByZXR1cm4gY29tcGFyZUlkZW50aWZpZXJzKHRoaXMubWFqb3IsIG90aGVyLm1ham9yKSB8fFxuICAgICAgICAgY29tcGFyZUlkZW50aWZpZXJzKHRoaXMubWlub3IsIG90aGVyLm1pbm9yKSB8fFxuICAgICAgICAgY29tcGFyZUlkZW50aWZpZXJzKHRoaXMucGF0Y2gsIG90aGVyLnBhdGNoKTtcbn07XG5cblNlbVZlci5wcm90b3R5cGUuY29tcGFyZVByZSA9IGZ1bmN0aW9uKG90aGVyKSB7XG4gIGlmICghKG90aGVyIGluc3RhbmNlb2YgU2VtVmVyKSlcbiAgICBvdGhlciA9IG5ldyBTZW1WZXIob3RoZXIsIHRoaXMubG9vc2UpO1xuXG4gIC8vIE5PVCBoYXZpbmcgYSBwcmVyZWxlYXNlIGlzID4gaGF2aW5nIG9uZVxuICBpZiAodGhpcy5wcmVyZWxlYXNlLmxlbmd0aCAmJiAhb3RoZXIucHJlcmVsZWFzZS5sZW5ndGgpXG4gICAgcmV0dXJuIC0xO1xuICBlbHNlIGlmICghdGhpcy5wcmVyZWxlYXNlLmxlbmd0aCAmJiBvdGhlci5wcmVyZWxlYXNlLmxlbmd0aClcbiAgICByZXR1cm4gMTtcbiAgZWxzZSBpZiAoIXRoaXMucHJlcmVsZWFzZS5sZW5ndGggJiYgIW90aGVyLnByZXJlbGVhc2UubGVuZ3RoKVxuICAgIHJldHVybiAwO1xuXG4gIHZhciBpID0gMDtcbiAgZG8ge1xuICAgIHZhciBhID0gdGhpcy5wcmVyZWxlYXNlW2ldO1xuICAgIHZhciBiID0gb3RoZXIucHJlcmVsZWFzZVtpXTtcbiAgICBkZWJ1ZygncHJlcmVsZWFzZSBjb21wYXJlJywgaSwgYSwgYik7XG4gICAgaWYgKGEgPT09IHVuZGVmaW5lZCAmJiBiID09PSB1bmRlZmluZWQpXG4gICAgICByZXR1cm4gMDtcbiAgICBlbHNlIGlmIChiID09PSB1bmRlZmluZWQpXG4gICAgICByZXR1cm4gMTtcbiAgICBlbHNlIGlmIChhID09PSB1bmRlZmluZWQpXG4gICAgICByZXR1cm4gLTE7XG4gICAgZWxzZSBpZiAoYSA9PT0gYilcbiAgICAgIGNvbnRpbnVlO1xuICAgIGVsc2VcbiAgICAgIHJldHVybiBjb21wYXJlSWRlbnRpZmllcnMoYSwgYik7XG4gIH0gd2hpbGUgKCsraSk7XG59O1xuXG4vLyBwcmVtaW5vciB3aWxsIGJ1bXAgdGhlIHZlcnNpb24gdXAgdG8gdGhlIG5leHQgbWlub3IgcmVsZWFzZSwgYW5kIGltbWVkaWF0ZWx5XG4vLyBkb3duIHRvIHByZS1yZWxlYXNlLiBwcmVtYWpvciBhbmQgcHJlcGF0Y2ggd29yayB0aGUgc2FtZSB3YXkuXG5TZW1WZXIucHJvdG90eXBlLmluYyA9IGZ1bmN0aW9uKHJlbGVhc2UsIGlkZW50aWZpZXIpIHtcbiAgc3dpdGNoIChyZWxlYXNlKSB7XG4gICAgY2FzZSAncHJlbWFqb3InOlxuICAgICAgdGhpcy5wcmVyZWxlYXNlLmxlbmd0aCA9IDA7XG4gICAgICB0aGlzLnBhdGNoID0gMDtcbiAgICAgIHRoaXMubWlub3IgPSAwO1xuICAgICAgdGhpcy5tYWpvcisrO1xuICAgICAgdGhpcy5pbmMoJ3ByZScsIGlkZW50aWZpZXIpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAncHJlbWlub3InOlxuICAgICAgdGhpcy5wcmVyZWxlYXNlLmxlbmd0aCA9IDA7XG4gICAgICB0aGlzLnBhdGNoID0gMDtcbiAgICAgIHRoaXMubWlub3IrKztcbiAgICAgIHRoaXMuaW5jKCdwcmUnLCBpZGVudGlmaWVyKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3ByZXBhdGNoJzpcbiAgICAgIC8vIElmIHRoaXMgaXMgYWxyZWFkeSBhIHByZXJlbGVhc2UsIGl0IHdpbGwgYnVtcCB0byB0aGUgbmV4dCB2ZXJzaW9uXG4gICAgICAvLyBkcm9wIGFueSBwcmVyZWxlYXNlcyB0aGF0IG1pZ2h0IGFscmVhZHkgZXhpc3QsIHNpbmNlIHRoZXkgYXJlIG5vdFxuICAgICAgLy8gcmVsZXZhbnQgYXQgdGhpcyBwb2ludC5cbiAgICAgIHRoaXMucHJlcmVsZWFzZS5sZW5ndGggPSAwO1xuICAgICAgdGhpcy5pbmMoJ3BhdGNoJywgaWRlbnRpZmllcik7XG4gICAgICB0aGlzLmluYygncHJlJywgaWRlbnRpZmllcik7XG4gICAgICBicmVhaztcbiAgICAvLyBJZiB0aGUgaW5wdXQgaXMgYSBub24tcHJlcmVsZWFzZSB2ZXJzaW9uLCB0aGlzIGFjdHMgdGhlIHNhbWUgYXNcbiAgICAvLyBwcmVwYXRjaC5cbiAgICBjYXNlICdwcmVyZWxlYXNlJzpcbiAgICAgIGlmICh0aGlzLnByZXJlbGVhc2UubGVuZ3RoID09PSAwKVxuICAgICAgICB0aGlzLmluYygncGF0Y2gnLCBpZGVudGlmaWVyKTtcbiAgICAgIHRoaXMuaW5jKCdwcmUnLCBpZGVudGlmaWVyKTtcbiAgICAgIGJyZWFrO1xuXG4gICAgY2FzZSAnbWFqb3InOlxuICAgICAgLy8gSWYgdGhpcyBpcyBhIHByZS1tYWpvciB2ZXJzaW9uLCBidW1wIHVwIHRvIHRoZSBzYW1lIG1ham9yIHZlcnNpb24uXG4gICAgICAvLyBPdGhlcndpc2UgaW5jcmVtZW50IG1ham9yLlxuICAgICAgLy8gMS4wLjAtNSBidW1wcyB0byAxLjAuMFxuICAgICAgLy8gMS4xLjAgYnVtcHMgdG8gMi4wLjBcbiAgICAgIGlmICh0aGlzLm1pbm9yICE9PSAwIHx8IHRoaXMucGF0Y2ggIT09IDAgfHwgdGhpcy5wcmVyZWxlYXNlLmxlbmd0aCA9PT0gMClcbiAgICAgICAgdGhpcy5tYWpvcisrO1xuICAgICAgdGhpcy5taW5vciA9IDA7XG4gICAgICB0aGlzLnBhdGNoID0gMDtcbiAgICAgIHRoaXMucHJlcmVsZWFzZSA9IFtdO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbWlub3InOlxuICAgICAgLy8gSWYgdGhpcyBpcyBhIHByZS1taW5vciB2ZXJzaW9uLCBidW1wIHVwIHRvIHRoZSBzYW1lIG1pbm9yIHZlcnNpb24uXG4gICAgICAvLyBPdGhlcndpc2UgaW5jcmVtZW50IG1pbm9yLlxuICAgICAgLy8gMS4yLjAtNSBidW1wcyB0byAxLjIuMFxuICAgICAgLy8gMS4yLjEgYnVtcHMgdG8gMS4zLjBcbiAgICAgIGlmICh0aGlzLnBhdGNoICE9PSAwIHx8IHRoaXMucHJlcmVsZWFzZS5sZW5ndGggPT09IDApXG4gICAgICAgIHRoaXMubWlub3IrKztcbiAgICAgIHRoaXMucGF0Y2ggPSAwO1xuICAgICAgdGhpcy5wcmVyZWxlYXNlID0gW107XG4gICAgICBicmVhaztcbiAgICBjYXNlICdwYXRjaCc6XG4gICAgICAvLyBJZiB0aGlzIGlzIG5vdCBhIHByZS1yZWxlYXNlIHZlcnNpb24sIGl0IHdpbGwgaW5jcmVtZW50IHRoZSBwYXRjaC5cbiAgICAgIC8vIElmIGl0IGlzIGEgcHJlLXJlbGVhc2UgaXQgd2lsbCBidW1wIHVwIHRvIHRoZSBzYW1lIHBhdGNoIHZlcnNpb24uXG4gICAgICAvLyAxLjIuMC01IHBhdGNoZXMgdG8gMS4yLjBcbiAgICAgIC8vIDEuMi4wIHBhdGNoZXMgdG8gMS4yLjFcbiAgICAgIGlmICh0aGlzLnByZXJlbGVhc2UubGVuZ3RoID09PSAwKVxuICAgICAgICB0aGlzLnBhdGNoKys7XG4gICAgICB0aGlzLnByZXJlbGVhc2UgPSBbXTtcbiAgICAgIGJyZWFrO1xuICAgIC8vIFRoaXMgcHJvYmFibHkgc2hvdWxkbid0IGJlIHVzZWQgcHVibGljbHkuXG4gICAgLy8gMS4wLjAgXCJwcmVcIiB3b3VsZCBiZWNvbWUgMS4wLjAtMCB3aGljaCBpcyB0aGUgd3JvbmcgZGlyZWN0aW9uLlxuICAgIGNhc2UgJ3ByZSc6XG4gICAgICBpZiAodGhpcy5wcmVyZWxlYXNlLmxlbmd0aCA9PT0gMClcbiAgICAgICAgdGhpcy5wcmVyZWxlYXNlID0gWzBdO1xuICAgICAgZWxzZSB7XG4gICAgICAgIHZhciBpID0gdGhpcy5wcmVyZWxlYXNlLmxlbmd0aDtcbiAgICAgICAgd2hpbGUgKC0taSA+PSAwKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnByZXJlbGVhc2VbaV0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICB0aGlzLnByZXJlbGVhc2VbaV0rKztcbiAgICAgICAgICAgIGkgPSAtMjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGkgPT09IC0xKSAvLyBkaWRuJ3QgaW5jcmVtZW50IGFueXRoaW5nXG4gICAgICAgICAgdGhpcy5wcmVyZWxlYXNlLnB1c2goMCk7XG4gICAgICB9XG4gICAgICBpZiAoaWRlbnRpZmllcikge1xuICAgICAgICAvLyAxLjIuMC1iZXRhLjEgYnVtcHMgdG8gMS4yLjAtYmV0YS4yLFxuICAgICAgICAvLyAxLjIuMC1iZXRhLmZvb2JseiBvciAxLjIuMC1iZXRhIGJ1bXBzIHRvIDEuMi4wLWJldGEuMFxuICAgICAgICBpZiAodGhpcy5wcmVyZWxlYXNlWzBdID09PSBpZGVudGlmaWVyKSB7XG4gICAgICAgICAgaWYgKGlzTmFOKHRoaXMucHJlcmVsZWFzZVsxXSkpXG4gICAgICAgICAgICB0aGlzLnByZXJlbGVhc2UgPSBbaWRlbnRpZmllciwgMF07XG4gICAgICAgIH0gZWxzZVxuICAgICAgICAgIHRoaXMucHJlcmVsZWFzZSA9IFtpZGVudGlmaWVyLCAwXTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuXG4gICAgZGVmYXVsdDpcbiAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBpbmNyZW1lbnQgYXJndW1lbnQ6ICcgKyByZWxlYXNlKTtcbiAgfVxuICB0aGlzLmZvcm1hdCgpO1xuICByZXR1cm4gdGhpcztcbn07XG5cbmV4cG9ydHMuaW5jID0gaW5jO1xuZnVuY3Rpb24gaW5jKHZlcnNpb24sIHJlbGVhc2UsIGxvb3NlLCBpZGVudGlmaWVyKSB7XG4gIGlmICh0eXBlb2YobG9vc2UpID09PSAnc3RyaW5nJykge1xuICAgIGlkZW50aWZpZXIgPSBsb29zZTtcbiAgICBsb29zZSA9IHVuZGVmaW5lZDtcbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIG5ldyBTZW1WZXIodmVyc2lvbiwgbG9vc2UpLmluYyhyZWxlYXNlLCBpZGVudGlmaWVyKS52ZXJzaW9uO1xuICB9IGNhdGNoIChlcikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmV4cG9ydHMuZGlmZiA9IGRpZmY7XG5mdW5jdGlvbiBkaWZmKHZlcnNpb24xLCB2ZXJzaW9uMikge1xuICBpZiAoZXEodmVyc2lvbjEsIHZlcnNpb24yKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9IGVsc2Uge1xuICAgIHZhciB2MSA9IHBhcnNlKHZlcnNpb24xKTtcbiAgICB2YXIgdjIgPSBwYXJzZSh2ZXJzaW9uMik7XG4gICAgaWYgKHYxLnByZXJlbGVhc2UubGVuZ3RoIHx8IHYyLnByZXJlbGVhc2UubGVuZ3RoKSB7XG4gICAgICBmb3IgKHZhciBrZXkgaW4gdjEpIHtcbiAgICAgICAgaWYgKGtleSA9PT0gJ21ham9yJyB8fCBrZXkgPT09ICdtaW5vcicgfHwga2V5ID09PSAncGF0Y2gnKSB7XG4gICAgICAgICAgaWYgKHYxW2tleV0gIT09IHYyW2tleV0pIHtcbiAgICAgICAgICAgIHJldHVybiAncHJlJytrZXk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gJ3ByZXJlbGVhc2UnO1xuICAgIH1cbiAgICBmb3IgKHZhciBrZXkgaW4gdjEpIHtcbiAgICAgIGlmIChrZXkgPT09ICdtYWpvcicgfHwga2V5ID09PSAnbWlub3InIHx8IGtleSA9PT0gJ3BhdGNoJykge1xuICAgICAgICBpZiAodjFba2V5XSAhPT0gdjJba2V5XSkge1xuICAgICAgICAgIHJldHVybiBrZXk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0cy5jb21wYXJlSWRlbnRpZmllcnMgPSBjb21wYXJlSWRlbnRpZmllcnM7XG5cbnZhciBudW1lcmljID0gL15bMC05XSskLztcbmZ1bmN0aW9uIGNvbXBhcmVJZGVudGlmaWVycyhhLCBiKSB7XG4gIHZhciBhbnVtID0gbnVtZXJpYy50ZXN0KGEpO1xuICB2YXIgYm51bSA9IG51bWVyaWMudGVzdChiKTtcblxuICBpZiAoYW51bSAmJiBibnVtKSB7XG4gICAgYSA9ICthO1xuICAgIGIgPSArYjtcbiAgfVxuXG4gIHJldHVybiAoYW51bSAmJiAhYm51bSkgPyAtMSA6XG4gICAgICAgICAoYm51bSAmJiAhYW51bSkgPyAxIDpcbiAgICAgICAgIGEgPCBiID8gLTEgOlxuICAgICAgICAgYSA+IGIgPyAxIDpcbiAgICAgICAgIDA7XG59XG5cbmV4cG9ydHMucmNvbXBhcmVJZGVudGlmaWVycyA9IHJjb21wYXJlSWRlbnRpZmllcnM7XG5mdW5jdGlvbiByY29tcGFyZUlkZW50aWZpZXJzKGEsIGIpIHtcbiAgcmV0dXJuIGNvbXBhcmVJZGVudGlmaWVycyhiLCBhKTtcbn1cblxuZXhwb3J0cy5tYWpvciA9IG1ham9yO1xuZnVuY3Rpb24gbWFqb3IoYSwgbG9vc2UpIHtcbiAgcmV0dXJuIG5ldyBTZW1WZXIoYSwgbG9vc2UpLm1ham9yO1xufVxuXG5leHBvcnRzLm1pbm9yID0gbWlub3I7XG5mdW5jdGlvbiBtaW5vcihhLCBsb29zZSkge1xuICByZXR1cm4gbmV3IFNlbVZlcihhLCBsb29zZSkubWlub3I7XG59XG5cbmV4cG9ydHMucGF0Y2ggPSBwYXRjaDtcbmZ1bmN0aW9uIHBhdGNoKGEsIGxvb3NlKSB7XG4gIHJldHVybiBuZXcgU2VtVmVyKGEsIGxvb3NlKS5wYXRjaDtcbn1cblxuZXhwb3J0cy5jb21wYXJlID0gY29tcGFyZTtcbmZ1bmN0aW9uIGNvbXBhcmUoYSwgYiwgbG9vc2UpIHtcbiAgcmV0dXJuIG5ldyBTZW1WZXIoYSwgbG9vc2UpLmNvbXBhcmUoYik7XG59XG5cbmV4cG9ydHMuY29tcGFyZUxvb3NlID0gY29tcGFyZUxvb3NlO1xuZnVuY3Rpb24gY29tcGFyZUxvb3NlKGEsIGIpIHtcbiAgcmV0dXJuIGNvbXBhcmUoYSwgYiwgdHJ1ZSk7XG59XG5cbmV4cG9ydHMucmNvbXBhcmUgPSByY29tcGFyZTtcbmZ1bmN0aW9uIHJjb21wYXJlKGEsIGIsIGxvb3NlKSB7XG4gIHJldHVybiBjb21wYXJlKGIsIGEsIGxvb3NlKTtcbn1cblxuZXhwb3J0cy5zb3J0ID0gc29ydDtcbmZ1bmN0aW9uIHNvcnQobGlzdCwgbG9vc2UpIHtcbiAgcmV0dXJuIGxpc3Quc29ydChmdW5jdGlvbihhLCBiKSB7XG4gICAgcmV0dXJuIGV4cG9ydHMuY29tcGFyZShhLCBiLCBsb29zZSk7XG4gIH0pO1xufVxuXG5leHBvcnRzLnJzb3J0ID0gcnNvcnQ7XG5mdW5jdGlvbiByc29ydChsaXN0LCBsb29zZSkge1xuICByZXR1cm4gbGlzdC5zb3J0KGZ1bmN0aW9uKGEsIGIpIHtcbiAgICByZXR1cm4gZXhwb3J0cy5yY29tcGFyZShhLCBiLCBsb29zZSk7XG4gIH0pO1xufVxuXG5leHBvcnRzLmd0ID0gZ3Q7XG5mdW5jdGlvbiBndChhLCBiLCBsb29zZSkge1xuICByZXR1cm4gY29tcGFyZShhLCBiLCBsb29zZSkgPiAwO1xufVxuXG5leHBvcnRzLmx0ID0gbHQ7XG5mdW5jdGlvbiBsdChhLCBiLCBsb29zZSkge1xuICByZXR1cm4gY29tcGFyZShhLCBiLCBsb29zZSkgPCAwO1xufVxuXG5leHBvcnRzLmVxID0gZXE7XG5mdW5jdGlvbiBlcShhLCBiLCBsb29zZSkge1xuICByZXR1cm4gY29tcGFyZShhLCBiLCBsb29zZSkgPT09IDA7XG59XG5cbmV4cG9ydHMubmVxID0gbmVxO1xuZnVuY3Rpb24gbmVxKGEsIGIsIGxvb3NlKSB7XG4gIHJldHVybiBjb21wYXJlKGEsIGIsIGxvb3NlKSAhPT0gMDtcbn1cblxuZXhwb3J0cy5ndGUgPSBndGU7XG5mdW5jdGlvbiBndGUoYSwgYiwgbG9vc2UpIHtcbiAgcmV0dXJuIGNvbXBhcmUoYSwgYiwgbG9vc2UpID49IDA7XG59XG5cbmV4cG9ydHMubHRlID0gbHRlO1xuZnVuY3Rpb24gbHRlKGEsIGIsIGxvb3NlKSB7XG4gIHJldHVybiBjb21wYXJlKGEsIGIsIGxvb3NlKSA8PSAwO1xufVxuXG5leHBvcnRzLmNtcCA9IGNtcDtcbmZ1bmN0aW9uIGNtcChhLCBvcCwgYiwgbG9vc2UpIHtcbiAgdmFyIHJldDtcbiAgc3dpdGNoIChvcCkge1xuICAgIGNhc2UgJz09PSc6XG4gICAgICBpZiAodHlwZW9mIGEgPT09ICdvYmplY3QnKSBhID0gYS52ZXJzaW9uO1xuICAgICAgaWYgKHR5cGVvZiBiID09PSAnb2JqZWN0JykgYiA9IGIudmVyc2lvbjtcbiAgICAgIHJldCA9IGEgPT09IGI7XG4gICAgICBicmVhaztcbiAgICBjYXNlICchPT0nOlxuICAgICAgaWYgKHR5cGVvZiBhID09PSAnb2JqZWN0JykgYSA9IGEudmVyc2lvbjtcbiAgICAgIGlmICh0eXBlb2YgYiA9PT0gJ29iamVjdCcpIGIgPSBiLnZlcnNpb247XG4gICAgICByZXQgPSBhICE9PSBiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnJzogY2FzZSAnPSc6IGNhc2UgJz09JzogcmV0ID0gZXEoYSwgYiwgbG9vc2UpOyBicmVhaztcbiAgICBjYXNlICchPSc6IHJldCA9IG5lcShhLCBiLCBsb29zZSk7IGJyZWFrO1xuICAgIGNhc2UgJz4nOiByZXQgPSBndChhLCBiLCBsb29zZSk7IGJyZWFrO1xuICAgIGNhc2UgJz49JzogcmV0ID0gZ3RlKGEsIGIsIGxvb3NlKTsgYnJlYWs7XG4gICAgY2FzZSAnPCc6IHJldCA9IGx0KGEsIGIsIGxvb3NlKTsgYnJlYWs7XG4gICAgY2FzZSAnPD0nOiByZXQgPSBsdGUoYSwgYiwgbG9vc2UpOyBicmVhaztcbiAgICBkZWZhdWx0OiB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbnZhbGlkIG9wZXJhdG9yOiAnICsgb3ApO1xuICB9XG4gIHJldHVybiByZXQ7XG59XG5cbmV4cG9ydHMuQ29tcGFyYXRvciA9IENvbXBhcmF0b3I7XG5mdW5jdGlvbiBDb21wYXJhdG9yKGNvbXAsIGxvb3NlKSB7XG4gIGlmIChjb21wIGluc3RhbmNlb2YgQ29tcGFyYXRvcikge1xuICAgIGlmIChjb21wLmxvb3NlID09PSBsb29zZSlcbiAgICAgIHJldHVybiBjb21wO1xuICAgIGVsc2VcbiAgICAgIGNvbXAgPSBjb21wLnZhbHVlO1xuICB9XG5cbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIENvbXBhcmF0b3IpKVxuICAgIHJldHVybiBuZXcgQ29tcGFyYXRvcihjb21wLCBsb29zZSk7XG5cbiAgZGVidWcoJ2NvbXBhcmF0b3InLCBjb21wLCBsb29zZSk7XG4gIHRoaXMubG9vc2UgPSBsb29zZTtcbiAgdGhpcy5wYXJzZShjb21wKTtcblxuICBpZiAodGhpcy5zZW12ZXIgPT09IEFOWSlcbiAgICB0aGlzLnZhbHVlID0gJyc7XG4gIGVsc2VcbiAgICB0aGlzLnZhbHVlID0gdGhpcy5vcGVyYXRvciArIHRoaXMuc2VtdmVyLnZlcnNpb247XG5cbiAgZGVidWcoJ2NvbXAnLCB0aGlzKTtcbn1cblxudmFyIEFOWSA9IHt9O1xuQ29tcGFyYXRvci5wcm90b3R5cGUucGFyc2UgPSBmdW5jdGlvbihjb21wKSB7XG4gIHZhciByID0gdGhpcy5sb29zZSA/IHJlW0NPTVBBUkFUT1JMT09TRV0gOiByZVtDT01QQVJBVE9SXTtcbiAgdmFyIG0gPSBjb21wLm1hdGNoKHIpO1xuXG4gIGlmICghbSlcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbnZhbGlkIGNvbXBhcmF0b3I6ICcgKyBjb21wKTtcblxuICB0aGlzLm9wZXJhdG9yID0gbVsxXTtcbiAgaWYgKHRoaXMub3BlcmF0b3IgPT09ICc9JylcbiAgICB0aGlzLm9wZXJhdG9yID0gJyc7XG5cbiAgLy8gaWYgaXQgbGl0ZXJhbGx5IGlzIGp1c3QgJz4nIG9yICcnIHRoZW4gYWxsb3cgYW55dGhpbmcuXG4gIGlmICghbVsyXSlcbiAgICB0aGlzLnNlbXZlciA9IEFOWTtcbiAgZWxzZVxuICAgIHRoaXMuc2VtdmVyID0gbmV3IFNlbVZlcihtWzJdLCB0aGlzLmxvb3NlKTtcbn07XG5cbkNvbXBhcmF0b3IucHJvdG90eXBlLmluc3BlY3QgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuICc8U2VtVmVyIENvbXBhcmF0b3IgXCInICsgdGhpcyArICdcIj4nO1xufTtcblxuQ29tcGFyYXRvci5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIHRoaXMudmFsdWU7XG59O1xuXG5Db21wYXJhdG9yLnByb3RvdHlwZS50ZXN0ID0gZnVuY3Rpb24odmVyc2lvbikge1xuICBkZWJ1ZygnQ29tcGFyYXRvci50ZXN0JywgdmVyc2lvbiwgdGhpcy5sb29zZSk7XG5cbiAgaWYgKHRoaXMuc2VtdmVyID09PSBBTlkpXG4gICAgcmV0dXJuIHRydWU7XG5cbiAgaWYgKHR5cGVvZiB2ZXJzaW9uID09PSAnc3RyaW5nJylcbiAgICB2ZXJzaW9uID0gbmV3IFNlbVZlcih2ZXJzaW9uLCB0aGlzLmxvb3NlKTtcblxuICByZXR1cm4gY21wKHZlcnNpb24sIHRoaXMub3BlcmF0b3IsIHRoaXMuc2VtdmVyLCB0aGlzLmxvb3NlKTtcbn07XG5cblxuZXhwb3J0cy5SYW5nZSA9IFJhbmdlO1xuZnVuY3Rpb24gUmFuZ2UocmFuZ2UsIGxvb3NlKSB7XG4gIGlmICgocmFuZ2UgaW5zdGFuY2VvZiBSYW5nZSkgJiYgcmFuZ2UubG9vc2UgPT09IGxvb3NlKVxuICAgIHJldHVybiByYW5nZTtcblxuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgUmFuZ2UpKVxuICAgIHJldHVybiBuZXcgUmFuZ2UocmFuZ2UsIGxvb3NlKTtcblxuICB0aGlzLmxvb3NlID0gbG9vc2U7XG5cbiAgLy8gRmlyc3QsIHNwbGl0IGJhc2VkIG9uIGJvb2xlYW4gb3IgfHxcbiAgdGhpcy5yYXcgPSByYW5nZTtcbiAgdGhpcy5zZXQgPSByYW5nZS5zcGxpdCgvXFxzKlxcfFxcfFxccyovKS5tYXAoZnVuY3Rpb24ocmFuZ2UpIHtcbiAgICByZXR1cm4gdGhpcy5wYXJzZVJhbmdlKHJhbmdlLnRyaW0oKSk7XG4gIH0sIHRoaXMpLmZpbHRlcihmdW5jdGlvbihjKSB7XG4gICAgLy8gdGhyb3cgb3V0IGFueSB0aGF0IGFyZSBub3QgcmVsZXZhbnQgZm9yIHdoYXRldmVyIHJlYXNvblxuICAgIHJldHVybiBjLmxlbmd0aDtcbiAgfSk7XG5cbiAgaWYgKCF0aGlzLnNldC5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbnZhbGlkIFNlbVZlciBSYW5nZTogJyArIHJhbmdlKTtcbiAgfVxuXG4gIHRoaXMuZm9ybWF0KCk7XG59XG5cblJhbmdlLnByb3RvdHlwZS5pbnNwZWN0ID0gZnVuY3Rpb24oKSB7XG4gIHJldHVybiAnPFNlbVZlciBSYW5nZSBcIicgKyB0aGlzLnJhbmdlICsgJ1wiPic7XG59O1xuXG5SYW5nZS5wcm90b3R5cGUuZm9ybWF0ID0gZnVuY3Rpb24oKSB7XG4gIHRoaXMucmFuZ2UgPSB0aGlzLnNldC5tYXAoZnVuY3Rpb24oY29tcHMpIHtcbiAgICByZXR1cm4gY29tcHMuam9pbignICcpLnRyaW0oKTtcbiAgfSkuam9pbignfHwnKS50cmltKCk7XG4gIHJldHVybiB0aGlzLnJhbmdlO1xufTtcblxuUmFuZ2UucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XG4gIHJldHVybiB0aGlzLnJhbmdlO1xufTtcblxuUmFuZ2UucHJvdG90eXBlLnBhcnNlUmFuZ2UgPSBmdW5jdGlvbihyYW5nZSkge1xuICB2YXIgbG9vc2UgPSB0aGlzLmxvb3NlO1xuICByYW5nZSA9IHJhbmdlLnRyaW0oKTtcbiAgZGVidWcoJ3JhbmdlJywgcmFuZ2UsIGxvb3NlKTtcbiAgLy8gYDEuMi4zIC0gMS4yLjRgID0+IGA+PTEuMi4zIDw9MS4yLjRgXG4gIHZhciBociA9IGxvb3NlID8gcmVbSFlQSEVOUkFOR0VMT09TRV0gOiByZVtIWVBIRU5SQU5HRV07XG4gIHJhbmdlID0gcmFuZ2UucmVwbGFjZShociwgaHlwaGVuUmVwbGFjZSk7XG4gIGRlYnVnKCdoeXBoZW4gcmVwbGFjZScsIHJhbmdlKTtcbiAgLy8gYD4gMS4yLjMgPCAxLjIuNWAgPT4gYD4xLjIuMyA8MS4yLjVgXG4gIHJhbmdlID0gcmFuZ2UucmVwbGFjZShyZVtDT01QQVJBVE9SVFJJTV0sIGNvbXBhcmF0b3JUcmltUmVwbGFjZSk7XG4gIGRlYnVnKCdjb21wYXJhdG9yIHRyaW0nLCByYW5nZSwgcmVbQ09NUEFSQVRPUlRSSU1dKTtcblxuICAvLyBgfiAxLjIuM2AgPT4gYH4xLjIuM2BcbiAgcmFuZ2UgPSByYW5nZS5yZXBsYWNlKHJlW1RJTERFVFJJTV0sIHRpbGRlVHJpbVJlcGxhY2UpO1xuXG4gIC8vIGBeIDEuMi4zYCA9PiBgXjEuMi4zYFxuICByYW5nZSA9IHJhbmdlLnJlcGxhY2UocmVbQ0FSRVRUUklNXSwgY2FyZXRUcmltUmVwbGFjZSk7XG5cbiAgLy8gbm9ybWFsaXplIHNwYWNlc1xuICByYW5nZSA9IHJhbmdlLnNwbGl0KC9cXHMrLykuam9pbignICcpO1xuXG4gIC8vIEF0IHRoaXMgcG9pbnQsIHRoZSByYW5nZSBpcyBjb21wbGV0ZWx5IHRyaW1tZWQgYW5kXG4gIC8vIHJlYWR5IHRvIGJlIHNwbGl0IGludG8gY29tcGFyYXRvcnMuXG5cbiAgdmFyIGNvbXBSZSA9IGxvb3NlID8gcmVbQ09NUEFSQVRPUkxPT1NFXSA6IHJlW0NPTVBBUkFUT1JdO1xuICB2YXIgc2V0ID0gcmFuZ2Uuc3BsaXQoJyAnKS5tYXAoZnVuY3Rpb24oY29tcCkge1xuICAgIHJldHVybiBwYXJzZUNvbXBhcmF0b3IoY29tcCwgbG9vc2UpO1xuICB9KS5qb2luKCcgJykuc3BsaXQoL1xccysvKTtcbiAgaWYgKHRoaXMubG9vc2UpIHtcbiAgICAvLyBpbiBsb29zZSBtb2RlLCB0aHJvdyBvdXQgYW55IHRoYXQgYXJlIG5vdCB2YWxpZCBjb21wYXJhdG9yc1xuICAgIHNldCA9IHNldC5maWx0ZXIoZnVuY3Rpb24oY29tcCkge1xuICAgICAgcmV0dXJuICEhY29tcC5tYXRjaChjb21wUmUpO1xuICAgIH0pO1xuICB9XG4gIHNldCA9IHNldC5tYXAoZnVuY3Rpb24oY29tcCkge1xuICAgIHJldHVybiBuZXcgQ29tcGFyYXRvcihjb21wLCBsb29zZSk7XG4gIH0pO1xuXG4gIHJldHVybiBzZXQ7XG59O1xuXG4vLyBNb3N0bHkganVzdCBmb3IgdGVzdGluZyBhbmQgbGVnYWN5IEFQSSByZWFzb25zXG5leHBvcnRzLnRvQ29tcGFyYXRvcnMgPSB0b0NvbXBhcmF0b3JzO1xuZnVuY3Rpb24gdG9Db21wYXJhdG9ycyhyYW5nZSwgbG9vc2UpIHtcbiAgcmV0dXJuIG5ldyBSYW5nZShyYW5nZSwgbG9vc2UpLnNldC5tYXAoZnVuY3Rpb24oY29tcCkge1xuICAgIHJldHVybiBjb21wLm1hcChmdW5jdGlvbihjKSB7XG4gICAgICByZXR1cm4gYy52YWx1ZTtcbiAgICB9KS5qb2luKCcgJykudHJpbSgpLnNwbGl0KCcgJyk7XG4gIH0pO1xufVxuXG4vLyBjb21wcmlzZWQgb2YgeHJhbmdlcywgdGlsZGVzLCBzdGFycywgYW5kIGd0bHQncyBhdCB0aGlzIHBvaW50LlxuLy8gYWxyZWFkeSByZXBsYWNlZCB0aGUgaHlwaGVuIHJhbmdlc1xuLy8gdHVybiBpbnRvIGEgc2V0IG9mIEpVU1QgY29tcGFyYXRvcnMuXG5mdW5jdGlvbiBwYXJzZUNvbXBhcmF0b3IoY29tcCwgbG9vc2UpIHtcbiAgZGVidWcoJ2NvbXAnLCBjb21wKTtcbiAgY29tcCA9IHJlcGxhY2VDYXJldHMoY29tcCwgbG9vc2UpO1xuICBkZWJ1ZygnY2FyZXQnLCBjb21wKTtcbiAgY29tcCA9IHJlcGxhY2VUaWxkZXMoY29tcCwgbG9vc2UpO1xuICBkZWJ1ZygndGlsZGVzJywgY29tcCk7XG4gIGNvbXAgPSByZXBsYWNlWFJhbmdlcyhjb21wLCBsb29zZSk7XG4gIGRlYnVnKCd4cmFuZ2UnLCBjb21wKTtcbiAgY29tcCA9IHJlcGxhY2VTdGFycyhjb21wLCBsb29zZSk7XG4gIGRlYnVnKCdzdGFycycsIGNvbXApO1xuICByZXR1cm4gY29tcDtcbn1cblxuZnVuY3Rpb24gaXNYKGlkKSB7XG4gIHJldHVybiAhaWQgfHwgaWQudG9Mb3dlckNhc2UoKSA9PT0gJ3gnIHx8IGlkID09PSAnKic7XG59XG5cbi8vIH4sIH4+IC0tPiAqIChhbnksIGtpbmRhIHNpbGx5KVxuLy8gfjIsIH4yLngsIH4yLngueCwgfj4yLCB+PjIueCB+PjIueC54IC0tPiA+PTIuMC4wIDwzLjAuMFxuLy8gfjIuMCwgfjIuMC54LCB+PjIuMCwgfj4yLjAueCAtLT4gPj0yLjAuMCA8Mi4xLjBcbi8vIH4xLjIsIH4xLjIueCwgfj4xLjIsIH4+MS4yLnggLS0+ID49MS4yLjAgPDEuMy4wXG4vLyB+MS4yLjMsIH4+MS4yLjMgLS0+ID49MS4yLjMgPDEuMy4wXG4vLyB+MS4yLjAsIH4+MS4yLjAgLS0+ID49MS4yLjAgPDEuMy4wXG5mdW5jdGlvbiByZXBsYWNlVGlsZGVzKGNvbXAsIGxvb3NlKSB7XG4gIHJldHVybiBjb21wLnRyaW0oKS5zcGxpdCgvXFxzKy8pLm1hcChmdW5jdGlvbihjb21wKSB7XG4gICAgcmV0dXJuIHJlcGxhY2VUaWxkZShjb21wLCBsb29zZSk7XG4gIH0pLmpvaW4oJyAnKTtcbn1cblxuZnVuY3Rpb24gcmVwbGFjZVRpbGRlKGNvbXAsIGxvb3NlKSB7XG4gIHZhciByID0gbG9vc2UgPyByZVtUSUxERUxPT1NFXSA6IHJlW1RJTERFXTtcbiAgcmV0dXJuIGNvbXAucmVwbGFjZShyLCBmdW5jdGlvbihfLCBNLCBtLCBwLCBwcikge1xuICAgIGRlYnVnKCd0aWxkZScsIGNvbXAsIF8sIE0sIG0sIHAsIHByKTtcbiAgICB2YXIgcmV0O1xuXG4gICAgaWYgKGlzWChNKSlcbiAgICAgIHJldCA9ICcnO1xuICAgIGVsc2UgaWYgKGlzWChtKSlcbiAgICAgIHJldCA9ICc+PScgKyBNICsgJy4wLjAgPCcgKyAoK00gKyAxKSArICcuMC4wJztcbiAgICBlbHNlIGlmIChpc1gocCkpXG4gICAgICAvLyB+MS4yID09ID49MS4yLjAtIDwxLjMuMC1cbiAgICAgIHJldCA9ICc+PScgKyBNICsgJy4nICsgbSArICcuMCA8JyArIE0gKyAnLicgKyAoK20gKyAxKSArICcuMCc7XG4gICAgZWxzZSBpZiAocHIpIHtcbiAgICAgIGRlYnVnKCdyZXBsYWNlVGlsZGUgcHInLCBwcik7XG4gICAgICBpZiAocHIuY2hhckF0KDApICE9PSAnLScpXG4gICAgICAgIHByID0gJy0nICsgcHI7XG4gICAgICByZXQgPSAnPj0nICsgTSArICcuJyArIG0gKyAnLicgKyBwICsgcHIgK1xuICAgICAgICAgICAgJyA8JyArIE0gKyAnLicgKyAoK20gKyAxKSArICcuMCc7XG4gICAgfSBlbHNlXG4gICAgICAvLyB+MS4yLjMgPT0gPj0xLjIuMyA8MS4zLjBcbiAgICAgIHJldCA9ICc+PScgKyBNICsgJy4nICsgbSArICcuJyArIHAgK1xuICAgICAgICAgICAgJyA8JyArIE0gKyAnLicgKyAoK20gKyAxKSArICcuMCc7XG5cbiAgICBkZWJ1ZygndGlsZGUgcmV0dXJuJywgcmV0KTtcbiAgICByZXR1cm4gcmV0O1xuICB9KTtcbn1cblxuLy8gXiAtLT4gKiAoYW55LCBraW5kYSBzaWxseSlcbi8vIF4yLCBeMi54LCBeMi54LnggLS0+ID49Mi4wLjAgPDMuMC4wXG4vLyBeMi4wLCBeMi4wLnggLS0+ID49Mi4wLjAgPDMuMC4wXG4vLyBeMS4yLCBeMS4yLnggLS0+ID49MS4yLjAgPDIuMC4wXG4vLyBeMS4yLjMgLS0+ID49MS4yLjMgPDIuMC4wXG4vLyBeMS4yLjAgLS0+ID49MS4yLjAgPDIuMC4wXG5mdW5jdGlvbiByZXBsYWNlQ2FyZXRzKGNvbXAsIGxvb3NlKSB7XG4gIHJldHVybiBjb21wLnRyaW0oKS5zcGxpdCgvXFxzKy8pLm1hcChmdW5jdGlvbihjb21wKSB7XG4gICAgcmV0dXJuIHJlcGxhY2VDYXJldChjb21wLCBsb29zZSk7XG4gIH0pLmpvaW4oJyAnKTtcbn1cblxuZnVuY3Rpb24gcmVwbGFjZUNhcmV0KGNvbXAsIGxvb3NlKSB7XG4gIGRlYnVnKCdjYXJldCcsIGNvbXAsIGxvb3NlKTtcbiAgdmFyIHIgPSBsb29zZSA/IHJlW0NBUkVUTE9PU0VdIDogcmVbQ0FSRVRdO1xuICByZXR1cm4gY29tcC5yZXBsYWNlKHIsIGZ1bmN0aW9uKF8sIE0sIG0sIHAsIHByKSB7XG4gICAgZGVidWcoJ2NhcmV0JywgY29tcCwgXywgTSwgbSwgcCwgcHIpO1xuICAgIHZhciByZXQ7XG5cbiAgICBpZiAoaXNYKE0pKVxuICAgICAgcmV0ID0gJyc7XG4gICAgZWxzZSBpZiAoaXNYKG0pKVxuICAgICAgcmV0ID0gJz49JyArIE0gKyAnLjAuMCA8JyArICgrTSArIDEpICsgJy4wLjAnO1xuICAgIGVsc2UgaWYgKGlzWChwKSkge1xuICAgICAgaWYgKE0gPT09ICcwJylcbiAgICAgICAgcmV0ID0gJz49JyArIE0gKyAnLicgKyBtICsgJy4wIDwnICsgTSArICcuJyArICgrbSArIDEpICsgJy4wJztcbiAgICAgIGVsc2VcbiAgICAgICAgcmV0ID0gJz49JyArIE0gKyAnLicgKyBtICsgJy4wIDwnICsgKCtNICsgMSkgKyAnLjAuMCc7XG4gICAgfSBlbHNlIGlmIChwcikge1xuICAgICAgZGVidWcoJ3JlcGxhY2VDYXJldCBwcicsIHByKTtcbiAgICAgIGlmIChwci5jaGFyQXQoMCkgIT09ICctJylcbiAgICAgICAgcHIgPSAnLScgKyBwcjtcbiAgICAgIGlmIChNID09PSAnMCcpIHtcbiAgICAgICAgaWYgKG0gPT09ICcwJylcbiAgICAgICAgICByZXQgPSAnPj0nICsgTSArICcuJyArIG0gKyAnLicgKyBwICsgcHIgK1xuICAgICAgICAgICAgICAgICcgPCcgKyBNICsgJy4nICsgbSArICcuJyArICgrcCArIDEpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgcmV0ID0gJz49JyArIE0gKyAnLicgKyBtICsgJy4nICsgcCArIHByICtcbiAgICAgICAgICAgICAgICAnIDwnICsgTSArICcuJyArICgrbSArIDEpICsgJy4wJztcbiAgICAgIH0gZWxzZVxuICAgICAgICByZXQgPSAnPj0nICsgTSArICcuJyArIG0gKyAnLicgKyBwICsgcHIgK1xuICAgICAgICAgICAgICAnIDwnICsgKCtNICsgMSkgKyAnLjAuMCc7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRlYnVnKCdubyBwcicpO1xuICAgICAgaWYgKE0gPT09ICcwJykge1xuICAgICAgICBpZiAobSA9PT0gJzAnKVxuICAgICAgICAgIHJldCA9ICc+PScgKyBNICsgJy4nICsgbSArICcuJyArIHAgK1xuICAgICAgICAgICAgICAgICcgPCcgKyBNICsgJy4nICsgbSArICcuJyArICgrcCArIDEpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgcmV0ID0gJz49JyArIE0gKyAnLicgKyBtICsgJy4nICsgcCArXG4gICAgICAgICAgICAgICAgJyA8JyArIE0gKyAnLicgKyAoK20gKyAxKSArICcuMCc7XG4gICAgICB9IGVsc2VcbiAgICAgICAgcmV0ID0gJz49JyArIE0gKyAnLicgKyBtICsgJy4nICsgcCArXG4gICAgICAgICAgICAgICcgPCcgKyAoK00gKyAxKSArICcuMC4wJztcbiAgICB9XG5cbiAgICBkZWJ1ZygnY2FyZXQgcmV0dXJuJywgcmV0KTtcbiAgICByZXR1cm4gcmV0O1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVwbGFjZVhSYW5nZXMoY29tcCwgbG9vc2UpIHtcbiAgZGVidWcoJ3JlcGxhY2VYUmFuZ2VzJywgY29tcCwgbG9vc2UpO1xuICByZXR1cm4gY29tcC5zcGxpdCgvXFxzKy8pLm1hcChmdW5jdGlvbihjb21wKSB7XG4gICAgcmV0dXJuIHJlcGxhY2VYUmFuZ2UoY29tcCwgbG9vc2UpO1xuICB9KS5qb2luKCcgJyk7XG59XG5cbmZ1bmN0aW9uIHJlcGxhY2VYUmFuZ2UoY29tcCwgbG9vc2UpIHtcbiAgY29tcCA9IGNvbXAudHJpbSgpO1xuICB2YXIgciA9IGxvb3NlID8gcmVbWFJBTkdFTE9PU0VdIDogcmVbWFJBTkdFXTtcbiAgcmV0dXJuIGNvbXAucmVwbGFjZShyLCBmdW5jdGlvbihyZXQsIGd0bHQsIE0sIG0sIHAsIHByKSB7XG4gICAgZGVidWcoJ3hSYW5nZScsIGNvbXAsIHJldCwgZ3RsdCwgTSwgbSwgcCwgcHIpO1xuICAgIHZhciB4TSA9IGlzWChNKTtcbiAgICB2YXIgeG0gPSB4TSB8fCBpc1gobSk7XG4gICAgdmFyIHhwID0geG0gfHwgaXNYKHApO1xuICAgIHZhciBhbnlYID0geHA7XG5cbiAgICBpZiAoZ3RsdCA9PT0gJz0nICYmIGFueVgpXG4gICAgICBndGx0ID0gJyc7XG5cbiAgICBpZiAoeE0pIHtcbiAgICAgIGlmIChndGx0ID09PSAnPicgfHwgZ3RsdCA9PT0gJzwnKSB7XG4gICAgICAgIC8vIG5vdGhpbmcgaXMgYWxsb3dlZFxuICAgICAgICByZXQgPSAnPDAuMC4wJztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIG5vdGhpbmcgaXMgZm9yYmlkZGVuXG4gICAgICAgIHJldCA9ICcqJztcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGd0bHQgJiYgYW55WCkge1xuICAgICAgLy8gcmVwbGFjZSBYIHdpdGggMFxuICAgICAgaWYgKHhtKVxuICAgICAgICBtID0gMDtcbiAgICAgIGlmICh4cClcbiAgICAgICAgcCA9IDA7XG5cbiAgICAgIGlmIChndGx0ID09PSAnPicpIHtcbiAgICAgICAgLy8gPjEgPT4gPj0yLjAuMFxuICAgICAgICAvLyA+MS4yID0+ID49MS4zLjBcbiAgICAgICAgLy8gPjEuMi4zID0+ID49IDEuMi40XG4gICAgICAgIGd0bHQgPSAnPj0nO1xuICAgICAgICBpZiAoeG0pIHtcbiAgICAgICAgICBNID0gK00gKyAxO1xuICAgICAgICAgIG0gPSAwO1xuICAgICAgICAgIHAgPSAwO1xuICAgICAgICB9IGVsc2UgaWYgKHhwKSB7XG4gICAgICAgICAgbSA9ICttICsgMTtcbiAgICAgICAgICBwID0gMDtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChndGx0ID09PSAnPD0nKSB7XG4gICAgICAgIC8vIDw9MC43LnggaXMgYWN0dWFsbHkgPDAuOC4wLCBzaW5jZSBhbnkgMC43Lnggc2hvdWxkXG4gICAgICAgIC8vIHBhc3MuICBTaW1pbGFybHksIDw9Ny54IGlzIGFjdHVhbGx5IDw4LjAuMCwgZXRjLlxuICAgICAgICBndGx0ID0gJzwnXG4gICAgICAgIGlmICh4bSlcbiAgICAgICAgICBNID0gK00gKyAxXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBtID0gK20gKyAxXG4gICAgICB9XG5cbiAgICAgIHJldCA9IGd0bHQgKyBNICsgJy4nICsgbSArICcuJyArIHA7XG4gICAgfSBlbHNlIGlmICh4bSkge1xuICAgICAgcmV0ID0gJz49JyArIE0gKyAnLjAuMCA8JyArICgrTSArIDEpICsgJy4wLjAnO1xuICAgIH0gZWxzZSBpZiAoeHApIHtcbiAgICAgIHJldCA9ICc+PScgKyBNICsgJy4nICsgbSArICcuMCA8JyArIE0gKyAnLicgKyAoK20gKyAxKSArICcuMCc7XG4gICAgfVxuXG4gICAgZGVidWcoJ3hSYW5nZSByZXR1cm4nLCByZXQpO1xuXG4gICAgcmV0dXJuIHJldDtcbiAgfSk7XG59XG5cbi8vIEJlY2F1c2UgKiBpcyBBTkQtZWQgd2l0aCBldmVyeXRoaW5nIGVsc2UgaW4gdGhlIGNvbXBhcmF0b3IsXG4vLyBhbmQgJycgbWVhbnMgXCJhbnkgdmVyc2lvblwiLCBqdXN0IHJlbW92ZSB0aGUgKnMgZW50aXJlbHkuXG5mdW5jdGlvbiByZXBsYWNlU3RhcnMoY29tcCwgbG9vc2UpIHtcbiAgZGVidWcoJ3JlcGxhY2VTdGFycycsIGNvbXAsIGxvb3NlKTtcbiAgLy8gTG9vc2VuZXNzIGlzIGlnbm9yZWQgaGVyZS4gIHN0YXIgaXMgYWx3YXlzIGFzIGxvb3NlIGFzIGl0IGdldHMhXG4gIHJldHVybiBjb21wLnRyaW0oKS5yZXBsYWNlKHJlW1NUQVJdLCAnJyk7XG59XG5cbi8vIFRoaXMgZnVuY3Rpb24gaXMgcGFzc2VkIHRvIHN0cmluZy5yZXBsYWNlKHJlW0hZUEhFTlJBTkdFXSlcbi8vIE0sIG0sIHBhdGNoLCBwcmVyZWxlYXNlLCBidWlsZFxuLy8gMS4yIC0gMy40LjUgPT4gPj0xLjIuMCA8PTMuNC41XG4vLyAxLjIuMyAtIDMuNCA9PiA+PTEuMi4wIDwzLjUuMCBBbnkgMy40Lnggd2lsbCBkb1xuLy8gMS4yIC0gMy40ID0+ID49MS4yLjAgPDMuNS4wXG5mdW5jdGlvbiBoeXBoZW5SZXBsYWNlKCQwLFxuICAgICAgICAgICAgICAgICAgICAgICBmcm9tLCBmTSwgZm0sIGZwLCBmcHIsIGZiLFxuICAgICAgICAgICAgICAgICAgICAgICB0bywgdE0sIHRtLCB0cCwgdHByLCB0Yikge1xuXG4gIGlmIChpc1goZk0pKVxuICAgIGZyb20gPSAnJztcbiAgZWxzZSBpZiAoaXNYKGZtKSlcbiAgICBmcm9tID0gJz49JyArIGZNICsgJy4wLjAnO1xuICBlbHNlIGlmIChpc1goZnApKVxuICAgIGZyb20gPSAnPj0nICsgZk0gKyAnLicgKyBmbSArICcuMCc7XG4gIGVsc2VcbiAgICBmcm9tID0gJz49JyArIGZyb207XG5cbiAgaWYgKGlzWCh0TSkpXG4gICAgdG8gPSAnJztcbiAgZWxzZSBpZiAoaXNYKHRtKSlcbiAgICB0byA9ICc8JyArICgrdE0gKyAxKSArICcuMC4wJztcbiAgZWxzZSBpZiAoaXNYKHRwKSlcbiAgICB0byA9ICc8JyArIHRNICsgJy4nICsgKCt0bSArIDEpICsgJy4wJztcbiAgZWxzZSBpZiAodHByKVxuICAgIHRvID0gJzw9JyArIHRNICsgJy4nICsgdG0gKyAnLicgKyB0cCArICctJyArIHRwcjtcbiAgZWxzZVxuICAgIHRvID0gJzw9JyArIHRvO1xuXG4gIHJldHVybiAoZnJvbSArICcgJyArIHRvKS50cmltKCk7XG59XG5cblxuLy8gaWYgQU5ZIG9mIHRoZSBzZXRzIG1hdGNoIEFMTCBvZiBpdHMgY29tcGFyYXRvcnMsIHRoZW4gcGFzc1xuUmFuZ2UucHJvdG90eXBlLnRlc3QgPSBmdW5jdGlvbih2ZXJzaW9uKSB7XG4gIGlmICghdmVyc2lvbilcbiAgICByZXR1cm4gZmFsc2U7XG5cbiAgaWYgKHR5cGVvZiB2ZXJzaW9uID09PSAnc3RyaW5nJylcbiAgICB2ZXJzaW9uID0gbmV3IFNlbVZlcih2ZXJzaW9uLCB0aGlzLmxvb3NlKTtcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuc2V0Lmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKHRlc3RTZXQodGhpcy5zZXRbaV0sIHZlcnNpb24pKVxuICAgICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufTtcblxuZnVuY3Rpb24gdGVzdFNldChzZXQsIHZlcnNpb24pIHtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBzZXQubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoIXNldFtpXS50ZXN0KHZlcnNpb24pKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgaWYgKHZlcnNpb24ucHJlcmVsZWFzZS5sZW5ndGgpIHtcbiAgICAvLyBGaW5kIHRoZSBzZXQgb2YgdmVyc2lvbnMgdGhhdCBhcmUgYWxsb3dlZCB0byBoYXZlIHByZXJlbGVhc2VzXG4gICAgLy8gRm9yIGV4YW1wbGUsIF4xLjIuMy1wci4xIGRlc3VnYXJzIHRvID49MS4yLjMtcHIuMSA8Mi4wLjBcbiAgICAvLyBUaGF0IHNob3VsZCBhbGxvdyBgMS4yLjMtcHIuMmAgdG8gcGFzcy5cbiAgICAvLyBIb3dldmVyLCBgMS4yLjQtYWxwaGEubm90cmVhZHlgIHNob3VsZCBOT1QgYmUgYWxsb3dlZCxcbiAgICAvLyBldmVuIHRob3VnaCBpdCdzIHdpdGhpbiB0aGUgcmFuZ2Ugc2V0IGJ5IHRoZSBjb21wYXJhdG9ycy5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNldC5sZW5ndGg7IGkrKykge1xuICAgICAgZGVidWcoc2V0W2ldLnNlbXZlcik7XG4gICAgICBpZiAoc2V0W2ldLnNlbXZlciA9PT0gQU5ZKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcblxuICAgICAgaWYgKHNldFtpXS5zZW12ZXIucHJlcmVsZWFzZS5sZW5ndGggPiAwKSB7XG4gICAgICAgIHZhciBhbGxvd2VkID0gc2V0W2ldLnNlbXZlcjtcbiAgICAgICAgaWYgKGFsbG93ZWQubWFqb3IgPT09IHZlcnNpb24ubWFqb3IgJiZcbiAgICAgICAgICAgIGFsbG93ZWQubWlub3IgPT09IHZlcnNpb24ubWlub3IgJiZcbiAgICAgICAgICAgIGFsbG93ZWQucGF0Y2ggPT09IHZlcnNpb24ucGF0Y2gpXG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gVmVyc2lvbiBoYXMgYSAtcHJlLCBidXQgaXQncyBub3Qgb25lIG9mIHRoZSBvbmVzIHdlIGxpa2UuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59XG5cbmV4cG9ydHMuc2F0aXNmaWVzID0gc2F0aXNmaWVzO1xuZnVuY3Rpb24gc2F0aXNmaWVzKHZlcnNpb24sIHJhbmdlLCBsb29zZSkge1xuICB0cnkge1xuICAgIHJhbmdlID0gbmV3IFJhbmdlKHJhbmdlLCBsb29zZSk7XG4gIH0gY2F0Y2ggKGVyKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiByYW5nZS50ZXN0KHZlcnNpb24pO1xufVxuXG5leHBvcnRzLm1heFNhdGlzZnlpbmcgPSBtYXhTYXRpc2Z5aW5nO1xuZnVuY3Rpb24gbWF4U2F0aXNmeWluZyh2ZXJzaW9ucywgcmFuZ2UsIGxvb3NlKSB7XG4gIHJldHVybiB2ZXJzaW9ucy5maWx0ZXIoZnVuY3Rpb24odmVyc2lvbikge1xuICAgIHJldHVybiBzYXRpc2ZpZXModmVyc2lvbiwgcmFuZ2UsIGxvb3NlKTtcbiAgfSkuc29ydChmdW5jdGlvbihhLCBiKSB7XG4gICAgcmV0dXJuIHJjb21wYXJlKGEsIGIsIGxvb3NlKTtcbiAgfSlbMF0gfHwgbnVsbDtcbn1cblxuZXhwb3J0cy52YWxpZFJhbmdlID0gdmFsaWRSYW5nZTtcbmZ1bmN0aW9uIHZhbGlkUmFuZ2UocmFuZ2UsIGxvb3NlKSB7XG4gIHRyeSB7XG4gICAgLy8gUmV0dXJuICcqJyBpbnN0ZWFkIG9mICcnIHNvIHRoYXQgdHJ1dGhpbmVzcyB3b3Jrcy5cbiAgICAvLyBUaGlzIHdpbGwgdGhyb3cgaWYgaXQncyBpbnZhbGlkIGFueXdheVxuICAgIHJldHVybiBuZXcgUmFuZ2UocmFuZ2UsIGxvb3NlKS5yYW5nZSB8fCAnKic7XG4gIH0gY2F0Y2ggKGVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLy8gRGV0ZXJtaW5lIGlmIHZlcnNpb24gaXMgbGVzcyB0aGFuIGFsbCB0aGUgdmVyc2lvbnMgcG9zc2libGUgaW4gdGhlIHJhbmdlXG5leHBvcnRzLmx0ciA9IGx0cjtcbmZ1bmN0aW9uIGx0cih2ZXJzaW9uLCByYW5nZSwgbG9vc2UpIHtcbiAgcmV0dXJuIG91dHNpZGUodmVyc2lvbiwgcmFuZ2UsICc8JywgbG9vc2UpO1xufVxuXG4vLyBEZXRlcm1pbmUgaWYgdmVyc2lvbiBpcyBncmVhdGVyIHRoYW4gYWxsIHRoZSB2ZXJzaW9ucyBwb3NzaWJsZSBpbiB0aGUgcmFuZ2UuXG5leHBvcnRzLmd0ciA9IGd0cjtcbmZ1bmN0aW9uIGd0cih2ZXJzaW9uLCByYW5nZSwgbG9vc2UpIHtcbiAgcmV0dXJuIG91dHNpZGUodmVyc2lvbiwgcmFuZ2UsICc+JywgbG9vc2UpO1xufVxuXG5leHBvcnRzLm91dHNpZGUgPSBvdXRzaWRlO1xuZnVuY3Rpb24gb3V0c2lkZSh2ZXJzaW9uLCByYW5nZSwgaGlsbywgbG9vc2UpIHtcbiAgdmVyc2lvbiA9IG5ldyBTZW1WZXIodmVyc2lvbiwgbG9vc2UpO1xuICByYW5nZSA9IG5ldyBSYW5nZShyYW5nZSwgbG9vc2UpO1xuXG4gIHZhciBndGZuLCBsdGVmbiwgbHRmbiwgY29tcCwgZWNvbXA7XG4gIHN3aXRjaCAoaGlsbykge1xuICAgIGNhc2UgJz4nOlxuICAgICAgZ3RmbiA9IGd0O1xuICAgICAgbHRlZm4gPSBsdGU7XG4gICAgICBsdGZuID0gbHQ7XG4gICAgICBjb21wID0gJz4nO1xuICAgICAgZWNvbXAgPSAnPj0nO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnPCc6XG4gICAgICBndGZuID0gbHQ7XG4gICAgICBsdGVmbiA9IGd0ZTtcbiAgICAgIGx0Zm4gPSBndDtcbiAgICAgIGNvbXAgPSAnPCc7XG4gICAgICBlY29tcCA9ICc8PSc7XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTXVzdCBwcm92aWRlIGEgaGlsbyB2YWwgb2YgXCI8XCIgb3IgXCI+XCInKTtcbiAgfVxuXG4gIC8vIElmIGl0IHNhdGlzaWZlcyB0aGUgcmFuZ2UgaXQgaXMgbm90IG91dHNpZGVcbiAgaWYgKHNhdGlzZmllcyh2ZXJzaW9uLCByYW5nZSwgbG9vc2UpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLy8gRnJvbSBub3cgb24sIHZhcmlhYmxlIHRlcm1zIGFyZSBhcyBpZiB3ZSdyZSBpbiBcImd0clwiIG1vZGUuXG4gIC8vIGJ1dCBub3RlIHRoYXQgZXZlcnl0aGluZyBpcyBmbGlwcGVkIGZvciB0aGUgXCJsdHJcIiBmdW5jdGlvbi5cblxuICBmb3IgKHZhciBpID0gMDsgaSA8IHJhbmdlLnNldC5sZW5ndGg7ICsraSkge1xuICAgIHZhciBjb21wYXJhdG9ycyA9IHJhbmdlLnNldFtpXTtcblxuICAgIHZhciBoaWdoID0gbnVsbDtcbiAgICB2YXIgbG93ID0gbnVsbDtcblxuICAgIGNvbXBhcmF0b3JzLmZvckVhY2goZnVuY3Rpb24oY29tcGFyYXRvcikge1xuICAgICAgaGlnaCA9IGhpZ2ggfHwgY29tcGFyYXRvcjtcbiAgICAgIGxvdyA9IGxvdyB8fCBjb21wYXJhdG9yO1xuICAgICAgaWYgKGd0Zm4oY29tcGFyYXRvci5zZW12ZXIsIGhpZ2guc2VtdmVyLCBsb29zZSkpIHtcbiAgICAgICAgaGlnaCA9IGNvbXBhcmF0b3I7XG4gICAgICB9IGVsc2UgaWYgKGx0Zm4oY29tcGFyYXRvci5zZW12ZXIsIGxvdy5zZW12ZXIsIGxvb3NlKSkge1xuICAgICAgICBsb3cgPSBjb21wYXJhdG9yO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gSWYgdGhlIGVkZ2UgdmVyc2lvbiBjb21wYXJhdG9yIGhhcyBhIG9wZXJhdG9yIHRoZW4gb3VyIHZlcnNpb25cbiAgICAvLyBpc24ndCBvdXRzaWRlIGl0XG4gICAgaWYgKGhpZ2gub3BlcmF0b3IgPT09IGNvbXAgfHwgaGlnaC5vcGVyYXRvciA9PT0gZWNvbXApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvLyBJZiB0aGUgbG93ZXN0IHZlcnNpb24gY29tcGFyYXRvciBoYXMgYW4gb3BlcmF0b3IgYW5kIG91ciB2ZXJzaW9uXG4gICAgLy8gaXMgbGVzcyB0aGFuIGl0IHRoZW4gaXQgaXNuJ3QgaGlnaGVyIHRoYW4gdGhlIHJhbmdlXG4gICAgaWYgKCghbG93Lm9wZXJhdG9yIHx8IGxvdy5vcGVyYXRvciA9PT0gY29tcCkgJiZcbiAgICAgICAgbHRlZm4odmVyc2lvbiwgbG93LnNlbXZlcikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2UgaWYgKGxvdy5vcGVyYXRvciA9PT0gZWNvbXAgJiYgbHRmbih2ZXJzaW9uLCBsb3cuc2VtdmVyKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gVXNlIHRoZSBkZWZpbmUoKSBmdW5jdGlvbiBpZiB3ZSdyZSBpbiBBTUQgbGFuZFxuaWYgKHR5cGVvZiBkZWZpbmUgPT09ICdmdW5jdGlvbicgJiYgZGVmaW5lLmFtZClcbiAgZGVmaW5lKGV4cG9ydHMpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuICAsIFN0cmVhbSA9IHJlcXVpcmUoJ3N0cmVhbScpLlN0cmVhbVxuICAsIFNwbGl0ID0gcmVxdWlyZSgnc3BsaXQnKVxuICAsIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbiAgLCBkZWZhdWx0UG9ydCA9IDU0MzJcbiAgLCBpc1dpbiA9IChwcm9jZXNzLnBsYXRmb3JtID09PSAnd2luMzInKVxuICAsIHdhcm5TdHJlYW0gPSBwcm9jZXNzLnN0ZGVyclxuO1xuXG5cbnZhciBTX0lSV1hHID0gNTYgICAgIC8vICAgIDAwMDcwKDgpXG4gICwgU19JUldYTyA9IDcgICAgICAvLyAgICAwMDAwNyg4KVxuICAsIFNfSUZNVCAgPSA2MTQ0MCAgLy8gMDAxNzAwMDAoOClcbiAgLCBTX0lGUkVHID0gMzI3NjggIC8vICAwMTAwMDAwKDgpXG47XG5mdW5jdGlvbiBpc1JlZ0ZpbGUobW9kZSkge1xuICAgIHJldHVybiAoKG1vZGUgJiBTX0lGTVQpID09IFNfSUZSRUcpO1xufVxuXG52YXIgZmllbGROYW1lcyA9IFsgJ2hvc3QnLCAncG9ydCcsICdkYXRhYmFzZScsICd1c2VyJywgJ3Bhc3N3b3JkJyBdO1xudmFyIG5yT2ZGaWVsZHMgPSBmaWVsZE5hbWVzLmxlbmd0aDtcbnZhciBwYXNzS2V5ID0gZmllbGROYW1lc1sgbnJPZkZpZWxkcyAtMSBdO1xuXG5cbmZ1bmN0aW9uIHdhcm4oKSB7XG4gICAgdmFyIGlzV3JpdGFibGUgPSAoXG4gICAgICAgIHdhcm5TdHJlYW0gaW5zdGFuY2VvZiBTdHJlYW0gJiZcbiAgICAgICAgICB0cnVlID09PSB3YXJuU3RyZWFtLndyaXRhYmxlXG4gICAgKTtcblxuICAgIGlmIChpc1dyaXRhYmxlKSB7XG4gICAgICAgIHZhciBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKS5jb25jYXQoXCJcXG5cIik7XG4gICAgICAgIHdhcm5TdHJlYW0ud3JpdGUoIHV0aWwuZm9ybWF0LmFwcGx5KHV0aWwsIGFyZ3MpICk7XG4gICAgfVxufVxuXG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShtb2R1bGUuZXhwb3J0cywgJ2lzV2luJywge1xuICAgIGdldCA6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gaXNXaW47XG4gICAgfSAsXG4gICAgc2V0IDogZnVuY3Rpb24odmFsKSB7XG4gICAgICAgIGlzV2luID0gdmFsO1xuICAgIH1cbn0pO1xuXG5cbm1vZHVsZS5leHBvcnRzLndhcm5UbyA9IGZ1bmN0aW9uKHN0cmVhbSkge1xuICAgIHZhciBvbGQgPSB3YXJuU3RyZWFtO1xuICAgIHdhcm5TdHJlYW0gPSBzdHJlYW07XG4gICAgcmV0dXJuIG9sZDtcbn07XG5cbm1vZHVsZS5leHBvcnRzLmdldEZpbGVOYW1lID0gZnVuY3Rpb24oZW52KXtcbiAgICBlbnYgPSBlbnYgfHwgcHJvY2Vzcy5lbnY7XG4gICAgdmFyIGZpbGUgPSBlbnYuUEdQQVNTRklMRSB8fCAoXG4gICAgICAgIGlzV2luID9cbiAgICAgICAgICBwYXRoLmpvaW4oIGVudi5BUFBEQVRBICwgJ3Bvc3RncmVzcWwnLCAncGdwYXNzLmNvbmYnICkgOlxuICAgICAgICAgIHBhdGguam9pbiggZW52LkhPTUUsICcucGdwYXNzJyApXG4gICAgKTtcbiAgICByZXR1cm4gZmlsZTtcbn07XG5cbm1vZHVsZS5leHBvcnRzLnVzZVBnUGFzcyA9IGZ1bmN0aW9uKHN0YXRzLCBmbmFtZSkge1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocHJvY2Vzcy5lbnYsICdQR1BBU1NXT1JEJykpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGlmIChpc1dpbikge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICBmbmFtZSA9IGZuYW1lIHx8ICc8dW5rbj4nO1xuXG4gICAgaWYgKCEgaXNSZWdGaWxlKHN0YXRzLm1vZGUpKSB7XG4gICAgICAgIHdhcm4oJ1dBUk5JTkc6IHBhc3N3b3JkIGZpbGUgXCIlc1wiIGlzIG5vdCBhIHBsYWluIGZpbGUnLCBmbmFtZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHMubW9kZSAmIChTX0lSV1hHIHwgU19JUldYTykpIHtcbiAgICAgICAgLyogSWYgcGFzc3dvcmQgZmlsZSBpcyBpbnNlY3VyZSwgYWxlcnQgdGhlIHVzZXIgYW5kIGlnbm9yZSBpdC4gKi9cbiAgICAgICAgd2FybignV0FSTklORzogcGFzc3dvcmQgZmlsZSBcIiVzXCIgaGFzIGdyb3VwIG9yIHdvcmxkIGFjY2VzczsgcGVybWlzc2lvbnMgc2hvdWxkIGJlIHU9cncgKDA2MDApIG9yIGxlc3MnLCBmbmFtZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5cblxudmFyIG1hdGNoZXIgPSBtb2R1bGUuZXhwb3J0cy5tYXRjaCA9IGZ1bmN0aW9uKGNvbm5JbmZvLCBlbnRyeSkge1xuICAgIHJldHVybiBmaWVsZE5hbWVzLnNsaWNlKDAsIC0xKS5yZWR1Y2UoZnVuY3Rpb24ocHJldiwgZmllbGQsIGlkeCl7XG4gICAgICAgIGlmIChpZHggPT0gMSkge1xuICAgICAgICAgICAgLy8gdGhlIHBvcnRcbiAgICAgICAgICAgIGlmICggTnVtYmVyKCBjb25uSW5mb1tmaWVsZF0gfHwgZGVmYXVsdFBvcnQgKSA9PT0gTnVtYmVyKCBlbnRyeVtmaWVsZF0gKSApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcHJldiAmJiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwcmV2ICYmIChcbiAgICAgICAgICAgIGVudHJ5W2ZpZWxkXSA9PT0gJyonIHx8XG4gICAgICAgICAgICAgIGVudHJ5W2ZpZWxkXSA9PT0gY29ubkluZm9bZmllbGRdXG4gICAgICAgICk7XG4gICAgfSwgdHJ1ZSk7XG59O1xuXG5cbm1vZHVsZS5leHBvcnRzLmdldFBhc3N3b3JkID0gZnVuY3Rpb24oY29ubkluZm8sIHN0cmVhbSwgY2IpIHtcbiAgICB2YXIgcGFzcztcbiAgICB2YXIgbGluZVN0cmVhbSA9IHN0cmVhbS5waXBlKG5ldyBTcGxpdCgpKTtcblxuICAgIGZ1bmN0aW9uIG9uTGluZShsaW5lKSB7XG4gICAgICAgIHZhciBlbnRyeSA9IHBhcnNlTGluZShsaW5lKTtcbiAgICAgICAgaWYgKGVudHJ5ICYmIGlzVmFsaWRFbnRyeShlbnRyeSkgJiYgbWF0Y2hlcihjb25uSW5mbywgZW50cnkpKSB7XG4gICAgICAgICAgICBwYXNzID0gZW50cnlbcGFzc0tleV07XG4gICAgICAgICAgICBsaW5lU3RyZWFtLmVuZCgpOyAvLyAtPiBjYWxscyBvbkVuZCgpLCBidXQgcGFzcyBpcyBzZXQgbm93XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB2YXIgb25FbmQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgc3RyZWFtLmRlc3Ryb3koKTtcbiAgICAgICAgY2IocGFzcyk7XG4gICAgfTtcblxuICAgIHZhciBvbkVyciA9IGZ1bmN0aW9uKGVycikge1xuICAgICAgICBzdHJlYW0uZGVzdHJveSgpO1xuICAgICAgICB3YXJuKCdXQVJOSU5HOiBlcnJvciBvbiByZWFkaW5nIGZpbGU6ICVzJywgZXJyKTtcbiAgICAgICAgY2IodW5kZWZpbmVkKTtcbiAgICB9O1xuXG4gICAgc3RyZWFtLm9uKCdlcnJvcicsIG9uRXJyKTtcbiAgICBsaW5lU3RyZWFtXG4gICAgICAgIC5vbignZGF0YScsIG9uTGluZSlcbiAgICAgICAgLm9uKCdlbmQnLCBvbkVuZClcbiAgICAgICAgLm9uKCdlcnJvcicsIG9uRXJyKVxuICAgIDtcblxufTtcblxuXG52YXIgcGFyc2VMaW5lID0gbW9kdWxlLmV4cG9ydHMucGFyc2VMaW5lID0gZnVuY3Rpb24obGluZSkge1xuICAgIGlmIChsaW5lLmxlbmd0aCA8IDExIHx8IGxpbmUubWF0Y2goL15cXHMrIy8pKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHZhciBjdXJDaGFyID0gJyc7XG4gICAgdmFyIHByZXZDaGFyID0gJyc7XG4gICAgdmFyIGZpZWxkSWR4ID0gMDtcbiAgICB2YXIgc3RhcnRJZHggPSAwO1xuICAgIHZhciBlbmRJZHggPSAwO1xuICAgIHZhciBvYmogPSB7fTtcbiAgICB2YXIgaXNMYXN0RmllbGQgPSBmYWxzZTtcbiAgICB2YXIgYWRkVG9PYmogPSBmdW5jdGlvbihpZHgsIGkwLCBpMSkge1xuICAgICAgICB2YXIgZmllbGQgPSBsaW5lLnN1YnN0cmluZyhpMCwgaTEpO1xuXG4gICAgICAgIGlmICghIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKHByb2Nlc3MuZW52LCAnUEdQQVNTX05PX0RFRVNDQVBFJykpIHtcbiAgICAgICAgICAgIGZpZWxkID0gZmllbGQucmVwbGFjZSgvXFxcXChbOlxcXFxdKS9nLCAnJDEnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIG9ialsgZmllbGROYW1lc1tpZHhdIF0gPSBmaWVsZDtcbiAgICB9O1xuXG4gICAgZm9yICh2YXIgaSA9IDAgOyBpIDwgbGluZS5sZW5ndGgtMSA7IGkgKz0gMSkge1xuICAgICAgICBjdXJDaGFyID0gbGluZS5jaGFyQXQoaSsxKTtcbiAgICAgICAgcHJldkNoYXIgPSBsaW5lLmNoYXJBdChpKTtcblxuICAgICAgICBpc0xhc3RGaWVsZCA9IChmaWVsZElkeCA9PSBuck9mRmllbGRzLTEpO1xuXG4gICAgICAgIGlmIChpc0xhc3RGaWVsZCkge1xuICAgICAgICAgICAgYWRkVG9PYmooZmllbGRJZHgsIHN0YXJ0SWR4KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGkgPj0gMCAmJiBjdXJDaGFyID09ICc6JyAmJiBwcmV2Q2hhciAhPT0gJ1xcXFwnKSB7XG4gICAgICAgICAgICBhZGRUb09iaihmaWVsZElkeCwgc3RhcnRJZHgsIGkrMSk7XG5cbiAgICAgICAgICAgIHN0YXJ0SWR4ID0gaSsyO1xuICAgICAgICAgICAgZmllbGRJZHggKz0gMTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG9iaiA9ICggT2JqZWN0LmtleXMob2JqKS5sZW5ndGggPT09IG5yT2ZGaWVsZHMgKSA/IG9iaiA6IG51bGw7XG5cbiAgICByZXR1cm4gb2JqO1xufTtcblxuXG52YXIgaXNWYWxpZEVudHJ5ID0gbW9kdWxlLmV4cG9ydHMuaXNWYWxpZEVudHJ5ID0gZnVuY3Rpb24oZW50cnkpe1xuICAgIHZhciBydWxlcyA9IHtcbiAgICAgICAgLy8gaG9zdFxuICAgICAgICAwIDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICByZXR1cm4geC5sZW5ndGggPiAwO1xuICAgICAgICB9ICxcbiAgICAgICAgLy8gcG9ydFxuICAgICAgICAxIDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICBpZiAoeCA9PT0gJyonKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB4ID0gTnVtYmVyKHgpO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICBpc0Zpbml0ZSh4KSAmJlxuICAgICAgICAgICAgICAgICAgeCA+IDAgJiZcbiAgICAgICAgICAgICAgICAgIHggPCA5MDA3MTk5MjU0NzQwOTkyICYmXG4gICAgICAgICAgICAgICAgICBNYXRoLmZsb29yKHgpID09PSB4XG4gICAgICAgICAgICApO1xuICAgICAgICB9ICxcbiAgICAgICAgLy8gZGF0YWJhc2VcbiAgICAgICAgMiA6IGZ1bmN0aW9uKHgpe1xuICAgICAgICAgICAgcmV0dXJuIHgubGVuZ3RoID4gMDtcbiAgICAgICAgfSAsXG4gICAgICAgIC8vIHVzZXJuYW1lXG4gICAgICAgIDMgOiBmdW5jdGlvbih4KXtcbiAgICAgICAgICAgIHJldHVybiB4Lmxlbmd0aCA+IDA7XG4gICAgICAgIH0gLFxuICAgICAgICAvLyBwYXNzd29yZFxuICAgICAgICA0IDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICByZXR1cm4geC5sZW5ndGggPiAwO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGZvciAodmFyIGlkeCA9IDAgOyBpZHggPCBmaWVsZE5hbWVzLmxlbmd0aCA7IGlkeCArPSAxKSB7XG4gICAgICAgIHZhciBydWxlID0gcnVsZXNbaWR4XTtcbiAgICAgICAgdmFyIHZhbHVlID0gZW50cnlbIGZpZWxkTmFtZXNbaWR4XSBdIHx8ICcnO1xuXG4gICAgICAgIHZhciByZXMgPSBydWxlKHZhbHVlKTtcbiAgICAgICAgaWYgKCFyZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0cnVlO1xufTtcblxuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuICAsIGZzID0gcmVxdWlyZSgnZnMnKVxuICAsIGhlbHBlciA9IHJlcXVpcmUoJy4vaGVscGVyLmpzJylcbjtcblxuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKGNvbm5JbmZvLCBjYikge1xuICAgIHZhciBmaWxlID0gaGVscGVyLmdldEZpbGVOYW1lKCk7XG4gICAgXG4gICAgZnMuc3RhdChmaWxlLCBmdW5jdGlvbihlcnIsIHN0YXQpe1xuICAgICAgICBpZiAoZXJyIHx8ICFoZWxwZXIudXNlUGdQYXNzKHN0YXQsIGZpbGUpKSB7XG4gICAgICAgICAgICByZXR1cm4gY2IodW5kZWZpbmVkKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBzdCA9IGZzLmNyZWF0ZVJlYWRTdHJlYW0oZmlsZSk7XG5cbiAgICAgICAgaGVscGVyLmdldFBhc3N3b3JkKGNvbm5JbmZvLCBzdCwgY2IpO1xuICAgIH0pO1xufTtcblxubW9kdWxlLmV4cG9ydHMud2FyblRvID0gaGVscGVyLndhcm5UbztcbiIsIid1c2Ugc3RyaWN0J1xuXG5leHBvcnRzLnBhcnNlID0gZnVuY3Rpb24gKHNvdXJjZSwgdHJhbnNmb3JtKSB7XG4gIHJldHVybiBuZXcgQXJyYXlQYXJzZXIoc291cmNlLCB0cmFuc2Zvcm0pLnBhcnNlKClcbn1cblxuZnVuY3Rpb24gQXJyYXlQYXJzZXIgKHNvdXJjZSwgdHJhbnNmb3JtKSB7XG4gIHRoaXMuc291cmNlID0gc291cmNlXG4gIHRoaXMudHJhbnNmb3JtID0gdHJhbnNmb3JtIHx8IGlkZW50aXR5XG4gIHRoaXMucG9zaXRpb24gPSAwXG4gIHRoaXMuZW50cmllcyA9IFtdXG4gIHRoaXMucmVjb3JkZWQgPSBbXVxuICB0aGlzLmRpbWVuc2lvbiA9IDBcbn1cblxuQXJyYXlQYXJzZXIucHJvdG90eXBlLmlzRW9mID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5wb3NpdGlvbiA+PSB0aGlzLnNvdXJjZS5sZW5ndGhcbn1cblxuQXJyYXlQYXJzZXIucHJvdG90eXBlLm5leHRDaGFyYWN0ZXIgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBjaGFyYWN0ZXIgPSB0aGlzLnNvdXJjZVt0aGlzLnBvc2l0aW9uKytdXG4gIGlmIChjaGFyYWN0ZXIgPT09ICdcXFxcJykge1xuICAgIHJldHVybiB7XG4gICAgICB2YWx1ZTogdGhpcy5zb3VyY2VbdGhpcy5wb3NpdGlvbisrXSxcbiAgICAgIGVzY2FwZWQ6IHRydWVcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB2YWx1ZTogY2hhcmFjdGVyLFxuICAgIGVzY2FwZWQ6IGZhbHNlXG4gIH1cbn1cblxuQXJyYXlQYXJzZXIucHJvdG90eXBlLnJlY29yZCA9IGZ1bmN0aW9uIChjaGFyYWN0ZXIpIHtcbiAgdGhpcy5yZWNvcmRlZC5wdXNoKGNoYXJhY3Rlcilcbn1cblxuQXJyYXlQYXJzZXIucHJvdG90eXBlLm5ld0VudHJ5ID0gZnVuY3Rpb24gKGluY2x1ZGVFbXB0eSkge1xuICB2YXIgZW50cnlcbiAgaWYgKHRoaXMucmVjb3JkZWQubGVuZ3RoID4gMCB8fCBpbmNsdWRlRW1wdHkpIHtcbiAgICBlbnRyeSA9IHRoaXMucmVjb3JkZWQuam9pbignJylcbiAgICBpZiAoZW50cnkgPT09ICdOVUxMJyAmJiAhaW5jbHVkZUVtcHR5KSB7XG4gICAgICBlbnRyeSA9IG51bGxcbiAgICB9XG4gICAgaWYgKGVudHJ5ICE9PSBudWxsKSBlbnRyeSA9IHRoaXMudHJhbnNmb3JtKGVudHJ5KVxuICAgIHRoaXMuZW50cmllcy5wdXNoKGVudHJ5KVxuICAgIHRoaXMucmVjb3JkZWQgPSBbXVxuICB9XG59XG5cbkFycmF5UGFyc2VyLnByb3RvdHlwZS5wYXJzZSA9IGZ1bmN0aW9uIChuZXN0ZWQpIHtcbiAgdmFyIGNoYXJhY3RlciwgcGFyc2VyLCBxdW90ZVxuICB3aGlsZSAoIXRoaXMuaXNFb2YoKSkge1xuICAgIGNoYXJhY3RlciA9IHRoaXMubmV4dENoYXJhY3RlcigpXG4gICAgaWYgKGNoYXJhY3Rlci52YWx1ZSA9PT0gJ3snICYmICFxdW90ZSkge1xuICAgICAgdGhpcy5kaW1lbnNpb24rK1xuICAgICAgaWYgKHRoaXMuZGltZW5zaW9uID4gMSkge1xuICAgICAgICBwYXJzZXIgPSBuZXcgQXJyYXlQYXJzZXIodGhpcy5zb3VyY2Uuc3Vic3RyKHRoaXMucG9zaXRpb24gLSAxKSwgdGhpcy50cmFuc2Zvcm0pXG4gICAgICAgIHRoaXMuZW50cmllcy5wdXNoKHBhcnNlci5wYXJzZSh0cnVlKSlcbiAgICAgICAgdGhpcy5wb3NpdGlvbiArPSBwYXJzZXIucG9zaXRpb24gLSAyXG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjaGFyYWN0ZXIudmFsdWUgPT09ICd9JyAmJiAhcXVvdGUpIHtcbiAgICAgIHRoaXMuZGltZW5zaW9uLS1cbiAgICAgIGlmICghdGhpcy5kaW1lbnNpb24pIHtcbiAgICAgICAgdGhpcy5uZXdFbnRyeSgpXG4gICAgICAgIGlmIChuZXN0ZWQpIHJldHVybiB0aGlzLmVudHJpZXNcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNoYXJhY3Rlci52YWx1ZSA9PT0gJ1wiJyAmJiAhY2hhcmFjdGVyLmVzY2FwZWQpIHtcbiAgICAgIGlmIChxdW90ZSkgdGhpcy5uZXdFbnRyeSh0cnVlKVxuICAgICAgcXVvdGUgPSAhcXVvdGVcbiAgICB9IGVsc2UgaWYgKGNoYXJhY3Rlci52YWx1ZSA9PT0gJywnICYmICFxdW90ZSkge1xuICAgICAgdGhpcy5uZXdFbnRyeSgpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMucmVjb3JkKGNoYXJhY3Rlci52YWx1ZSlcbiAgICB9XG4gIH1cbiAgaWYgKHRoaXMuZGltZW5zaW9uICE9PSAwKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdhcnJheSBkaW1lbnNpb24gbm90IGJhbGFuY2VkJylcbiAgfVxuICByZXR1cm4gdGhpcy5lbnRyaWVzXG59XG5cbmZ1bmN0aW9uIGlkZW50aXR5ICh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWVcbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIHBhcnNlQnl0ZWEgKGlucHV0KSB7XG4gIGlmICgvXlxcXFx4Ly50ZXN0KGlucHV0KSkge1xuICAgIC8vIG5ldyAnaGV4JyBzdHlsZSByZXNwb25zZSAocGcgPjkuMClcbiAgICByZXR1cm4gbmV3IEJ1ZmZlcihpbnB1dC5zdWJzdHIoMiksICdoZXgnKVxuICB9XG4gIHZhciBvdXRwdXQgPSAnJ1xuICB2YXIgaSA9IDBcbiAgd2hpbGUgKGkgPCBpbnB1dC5sZW5ndGgpIHtcbiAgICBpZiAoaW5wdXRbaV0gIT09ICdcXFxcJykge1xuICAgICAgb3V0cHV0ICs9IGlucHV0W2ldXG4gICAgICArK2lcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKC9bMC03XXszfS8udGVzdChpbnB1dC5zdWJzdHIoaSArIDEsIDMpKSkge1xuICAgICAgICBvdXRwdXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShwYXJzZUludChpbnB1dC5zdWJzdHIoaSArIDEsIDMpLCA4KSlcbiAgICAgICAgaSArPSA0XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgYmFja3NsYXNoZXMgPSAxXG4gICAgICAgIHdoaWxlIChpICsgYmFja3NsYXNoZXMgPCBpbnB1dC5sZW5ndGggJiYgaW5wdXRbaSArIGJhY2tzbGFzaGVzXSA9PT0gJ1xcXFwnKSB7XG4gICAgICAgICAgYmFja3NsYXNoZXMrK1xuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIGsgPSAwOyBrIDwgTWF0aC5mbG9vcihiYWNrc2xhc2hlcyAvIDIpOyArK2spIHtcbiAgICAgICAgICBvdXRwdXQgKz0gJ1xcXFwnXG4gICAgICAgIH1cbiAgICAgICAgaSArPSBNYXRoLmZsb29yKGJhY2tzbGFzaGVzIC8gMikgKiAyXG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBuZXcgQnVmZmVyKG91dHB1dCwgJ2JpbmFyeScpXG59XG4iLCIndXNlIHN0cmljdCdcblxudmFyIERBVEVfVElNRSA9IC8oXFxkezEsfSktKFxcZHsyfSktKFxcZHsyfSkgKFxcZHsyfSk6KFxcZHsyfSk6KFxcZHsyfSkoXFwuXFxkezEsfSk/L1xudmFyIERBVEUgPSAvXihcXGR7MSx9KS0oXFxkezJ9KS0oXFxkezJ9KSQvXG52YXIgVElNRV9aT05FID0gLyhbWistXSkoXFxkezJ9KT86PyhcXGR7Mn0pPzo/KFxcZHsyfSk/L1xudmFyIEJDID0gL0JDJC9cbnZhciBJTkZJTklUWSA9IC9eLT9pbmZpbml0eSQvXG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gcGFyc2VEYXRlIChpc29EYXRlKSB7XG4gIGlmIChJTkZJTklUWS50ZXN0KGlzb0RhdGUpKSB7XG4gICAgLy8gQ2FwaXRhbGl6ZSB0byBJbmZpbml0eSBiZWZvcmUgcGFzc2luZyB0byBOdW1iZXJcbiAgICByZXR1cm4gTnVtYmVyKGlzb0RhdGUucmVwbGFjZSgnaScsICdJJykpXG4gIH1cbiAgdmFyIG1hdGNoZXMgPSBEQVRFX1RJTUUuZXhlYyhpc29EYXRlKVxuXG4gIGlmICghbWF0Y2hlcykge1xuICAgIC8vIEZvcmNlIFlZWVktTU0tREQgZGF0ZXMgdG8gYmUgcGFyc2VkIGFzIGxvY2FsIHRpbWVcbiAgICByZXR1cm4gREFURS50ZXN0KGlzb0RhdGUpID9cbiAgICAgIGdldERhdGUoaXNvRGF0ZSkgOlxuICAgICAgbnVsbFxuICB9XG5cbiAgdmFyIGlzQkMgPSBCQy50ZXN0KGlzb0RhdGUpXG4gIHZhciB5ZWFyID0gcGFyc2VJbnQobWF0Y2hlc1sxXSwgMTApXG4gIHZhciBpc0ZpcnN0Q2VudHVyeSA9IHllYXIgPiAwICYmIHllYXIgPCAxMDBcbiAgeWVhciA9IChpc0JDID8gJy0nIDogJycpICsgeWVhclxuXG4gIHZhciBtb250aCA9IHBhcnNlSW50KG1hdGNoZXNbMl0sIDEwKSAtIDFcbiAgdmFyIGRheSA9IG1hdGNoZXNbM11cbiAgdmFyIGhvdXIgPSBwYXJzZUludChtYXRjaGVzWzRdLCAxMClcbiAgdmFyIG1pbnV0ZSA9IHBhcnNlSW50KG1hdGNoZXNbNV0sIDEwKVxuICB2YXIgc2Vjb25kID0gcGFyc2VJbnQobWF0Y2hlc1s2XSwgMTApXG5cbiAgdmFyIG1zID0gbWF0Y2hlc1s3XVxuICBtcyA9IG1zID8gMTAwMCAqIHBhcnNlRmxvYXQobXMpIDogMFxuXG4gIHZhciBkYXRlXG4gIHZhciBvZmZzZXQgPSB0aW1lWm9uZU9mZnNldChpc29EYXRlKVxuICBpZiAob2Zmc2V0ICE9IG51bGwpIHtcbiAgICB2YXIgdXRjID0gRGF0ZS5VVEMoeWVhciwgbW9udGgsIGRheSwgaG91ciwgbWludXRlLCBzZWNvbmQsIG1zKVxuICAgIGRhdGUgPSBuZXcgRGF0ZSh1dGMgLSBvZmZzZXQpXG4gIH0gZWxzZSB7XG4gICAgZGF0ZSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCBkYXksIGhvdXIsIG1pbnV0ZSwgc2Vjb25kLCBtcylcbiAgfVxuXG4gIGlmIChpc0ZpcnN0Q2VudHVyeSkge1xuICAgIGRhdGUuc2V0VVRDRnVsbFllYXIoeWVhcilcbiAgfVxuXG4gIHJldHVybiBkYXRlXG59XG5cbmZ1bmN0aW9uIGdldERhdGUgKGlzb0RhdGUpIHtcbiAgdmFyIG1hdGNoZXMgPSBEQVRFLmV4ZWMoaXNvRGF0ZSlcbiAgdmFyIHllYXIgPSBwYXJzZUludChtYXRjaGVzWzFdLCAxMClcbiAgdmFyIG1vbnRoID0gcGFyc2VJbnQobWF0Y2hlc1syXSwgMTApIC0gMVxuICB2YXIgZGF5ID0gbWF0Y2hlc1szXVxuICAvLyBZWVlZLU1NLUREIHdpbGwgYmUgcGFyc2VkIGFzIGxvY2FsIHRpbWVcbiAgdmFyIGRhdGUgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgZGF5KVxuICBkYXRlLnNldEZ1bGxZZWFyKHllYXIpXG4gIHJldHVybiBkYXRlXG59XG5cbi8vIG1hdGNoIHRpbWV6b25lczpcbi8vIFogKFVUQylcbi8vIC0wNVxuLy8gKzA2OjMwXG5mdW5jdGlvbiB0aW1lWm9uZU9mZnNldCAoaXNvRGF0ZSkge1xuICB2YXIgem9uZSA9IFRJTUVfWk9ORS5leGVjKGlzb0RhdGUuc3BsaXQoJyAnKVsxXSlcbiAgaWYgKCF6b25lKSByZXR1cm5cbiAgdmFyIHR5cGUgPSB6b25lWzFdXG5cbiAgaWYgKHR5cGUgPT09ICdaJykge1xuICAgIHJldHVybiAwXG4gIH1cbiAgdmFyIHNpZ24gPSB0eXBlID09PSAnLScgPyAtMSA6IDFcbiAgdmFyIG9mZnNldCA9IHBhcnNlSW50KHpvbmVbMl0sIDEwKSAqIDM2MDAgK1xuICAgIHBhcnNlSW50KHpvbmVbM10gfHwgMCwgMTApICogNjAgK1xuICAgIHBhcnNlSW50KHpvbmVbNF0gfHwgMCwgMTApXG5cbiAgcmV0dXJuIG9mZnNldCAqIHNpZ24gKiAxMDAwXG59XG4iLCIndXNlIHN0cmljdCdcblxudmFyIGV4dGVuZCA9IHJlcXVpcmUoJ3h0ZW5kL211dGFibGUnKVxuXG5tb2R1bGUuZXhwb3J0cyA9IFBvc3RncmVzSW50ZXJ2YWxcblxuZnVuY3Rpb24gUG9zdGdyZXNJbnRlcnZhbCAocmF3KSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBQb3N0Z3Jlc0ludGVydmFsKSkge1xuICAgIHJldHVybiBuZXcgUG9zdGdyZXNJbnRlcnZhbChyYXcpXG4gIH1cbiAgZXh0ZW5kKHRoaXMsIHBhcnNlKHJhdykpXG59XG52YXIgcHJvcGVydGllcyA9IFsnc2Vjb25kcycsICdtaW51dGVzJywgJ2hvdXJzJywgJ2RheXMnLCAnbW9udGhzJywgJ3llYXJzJ11cblBvc3RncmVzSW50ZXJ2YWwucHJvdG90eXBlLnRvUG9zdGdyZXMgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBmaWx0ZXJlZCA9IHByb3BlcnRpZXMuZmlsdGVyKHRoaXMuaGFzT3duUHJvcGVydHksIHRoaXMpXG5cbiAgLy8gSW4gYWRkaXRpb24gdG8gYHByb3BlcnRpZXNgLCB3ZSBuZWVkIHRvIGFjY291bnQgZm9yIGZyYWN0aW9ucyBvZiBzZWNvbmRzLlxuICBpZiAodGhpcy5taWxsaXNlY29uZHMgJiYgZmlsdGVyZWQuaW5kZXhPZignc2Vjb25kcycpIDwgMCkge1xuICAgIGZpbHRlcmVkLnB1c2goJ3NlY29uZHMnKVxuICB9XG5cbiAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgcmV0dXJuICcwJ1xuICByZXR1cm4gZmlsdGVyZWRcbiAgICAubWFwKGZ1bmN0aW9uIChwcm9wZXJ0eSkge1xuICAgICAgdmFyIHZhbHVlID0gdGhpc1twcm9wZXJ0eV0gfHwgMFxuXG4gICAgICAvLyBBY2NvdW50IGZvciBmcmFjdGlvbmFsIHBhcnQgb2Ygc2Vjb25kcyxcbiAgICAgIC8vIHJlbW92ZSB0cmFpbGluZyB6ZXJvZXMuXG4gICAgICBpZiAocHJvcGVydHkgPT09ICdzZWNvbmRzJyAmJiB0aGlzLm1pbGxpc2Vjb25kcykge1xuICAgICAgICB2YWx1ZSA9ICh2YWx1ZSArIHRoaXMubWlsbGlzZWNvbmRzIC8gMTAwMCkudG9GaXhlZCg2KS5yZXBsYWNlKC9cXC4/MCskLywgJycpXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB2YWx1ZSArICcgJyArIHByb3BlcnR5XG4gICAgfSwgdGhpcylcbiAgICAuam9pbignICcpXG59XG5cbnZhciBwcm9wZXJ0aWVzSVNPRXF1aXZhbGVudCA9IHtcbiAgeWVhcnM6ICdZJyxcbiAgbW9udGhzOiAnTScsXG4gIGRheXM6ICdEJyxcbiAgaG91cnM6ICdIJyxcbiAgbWludXRlczogJ00nLFxuICBzZWNvbmRzOiAnUydcbn1cbnZhciBkYXRlUHJvcGVydGllcyA9IFsneWVhcnMnLCAnbW9udGhzJywgJ2RheXMnXVxudmFyIHRpbWVQcm9wZXJ0aWVzID0gWydob3VycycsICdtaW51dGVzJywgJ3NlY29uZHMnXVxuLy8gYWNjb3JkaW5nIHRvIElTTyA4NjAxXG5Qb3N0Z3Jlc0ludGVydmFsLnByb3RvdHlwZS50b0lTTyA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIGRhdGVQYXJ0ID0gZGF0ZVByb3BlcnRpZXNcbiAgICAubWFwKGJ1aWxkUHJvcGVydHksIHRoaXMpXG4gICAgLmpvaW4oJycpXG5cbiAgdmFyIHRpbWVQYXJ0ID0gdGltZVByb3BlcnRpZXNcbiAgICAubWFwKGJ1aWxkUHJvcGVydHksIHRoaXMpXG4gICAgLmpvaW4oJycpXG5cbiAgcmV0dXJuICdQJyArIGRhdGVQYXJ0ICsgJ1QnICsgdGltZVBhcnRcblxuICBmdW5jdGlvbiBidWlsZFByb3BlcnR5IChwcm9wZXJ0eSkge1xuICAgIHZhciB2YWx1ZSA9IHRoaXNbcHJvcGVydHldIHx8IDBcblxuICAgIC8vIEFjY291bnQgZm9yIGZyYWN0aW9uYWwgcGFydCBvZiBzZWNvbmRzLFxuICAgIC8vIHJlbW92ZSB0cmFpbGluZyB6ZXJvZXMuXG4gICAgaWYgKHByb3BlcnR5ID09PSAnc2Vjb25kcycgJiYgdGhpcy5taWxsaXNlY29uZHMpIHtcbiAgICAgIHZhbHVlID0gKHZhbHVlICsgdGhpcy5taWxsaXNlY29uZHMgLyAxMDAwKS50b0ZpeGVkKDYpLnJlcGxhY2UoLzArJC8sICcnKVxuICAgIH1cblxuICAgIHJldHVybiB2YWx1ZSArIHByb3BlcnRpZXNJU09FcXVpdmFsZW50W3Byb3BlcnR5XVxuICB9XG5cbn1cblxudmFyIE5VTUJFUiA9ICcoWystXT9cXFxcZCspJ1xudmFyIFlFQVIgPSBOVU1CRVIgKyAnXFxcXHMreWVhcnM/J1xudmFyIE1PTlRIID0gTlVNQkVSICsgJ1xcXFxzK21vbnM/J1xudmFyIERBWSA9IE5VTUJFUiArICdcXFxccytkYXlzPydcbnZhciBUSU1FID0gJyhbKy1dKT8oW1xcXFxkXSopOihcXFxcZFxcXFxkKTooXFxcXGRcXFxcZClcXC4/KFxcXFxkezEsNn0pPydcbnZhciBJTlRFUlZBTCA9IG5ldyBSZWdFeHAoW1lFQVIsIE1PTlRILCBEQVksIFRJTUVdLm1hcChmdW5jdGlvbiAocmVnZXhTdHJpbmcpIHtcbiAgcmV0dXJuICcoJyArIHJlZ2V4U3RyaW5nICsgJyk/J1xufSlcbi5qb2luKCdcXFxccyonKSlcblxuLy8gUG9zaXRpb25zIG9mIHZhbHVlcyBpbiByZWdleCBtYXRjaFxudmFyIHBvc2l0aW9ucyA9IHtcbiAgeWVhcnM6IDIsXG4gIG1vbnRoczogNCxcbiAgZGF5czogNixcbiAgaG91cnM6IDksXG4gIG1pbnV0ZXM6IDEwLFxuICBzZWNvbmRzOiAxMSxcbiAgbWlsbGlzZWNvbmRzOiAxMlxufVxuLy8gV2UgY2FuIHVzZSBuZWdhdGl2ZSB0aW1lXG52YXIgbmVnYXRpdmVzID0gWydob3VycycsICdtaW51dGVzJywgJ3NlY29uZHMnLCAnbWlsbGlzZWNvbmRzJ11cblxuZnVuY3Rpb24gcGFyc2VNaWxsaXNlY29uZHMgKGZyYWN0aW9uKSB7XG4gIC8vIGFkZCBvbWl0dGVkIHplcm9lc1xuICB2YXIgbWljcm9zZWNvbmRzID0gZnJhY3Rpb24gKyAnMDAwMDAwJy5zbGljZShmcmFjdGlvbi5sZW5ndGgpXG4gIHJldHVybiBwYXJzZUludChtaWNyb3NlY29uZHMsIDEwKSAvIDEwMDBcbn1cblxuZnVuY3Rpb24gcGFyc2UgKGludGVydmFsKSB7XG4gIGlmICghaW50ZXJ2YWwpIHJldHVybiB7fVxuICB2YXIgbWF0Y2hlcyA9IElOVEVSVkFMLmV4ZWMoaW50ZXJ2YWwpXG4gIHZhciBpc05lZ2F0aXZlID0gbWF0Y2hlc1s4XSA9PT0gJy0nXG4gIHJldHVybiBPYmplY3Qua2V5cyhwb3NpdGlvbnMpXG4gICAgLnJlZHVjZShmdW5jdGlvbiAocGFyc2VkLCBwcm9wZXJ0eSkge1xuICAgICAgdmFyIHBvc2l0aW9uID0gcG9zaXRpb25zW3Byb3BlcnR5XVxuICAgICAgdmFyIHZhbHVlID0gbWF0Y2hlc1twb3NpdGlvbl1cbiAgICAgIC8vIG5vIGVtcHR5IHN0cmluZ1xuICAgICAgaWYgKCF2YWx1ZSkgcmV0dXJuIHBhcnNlZFxuICAgICAgLy8gbWlsbGlzZWNvbmRzIGFyZSBhY3R1YWxseSBtaWNyb3NlY29uZHMgKHVwIHRvIDYgZGlnaXRzKVxuICAgICAgLy8gd2l0aCBvbWl0dGVkIHRyYWlsaW5nIHplcm9lcy5cbiAgICAgIHZhbHVlID0gcHJvcGVydHkgPT09ICdtaWxsaXNlY29uZHMnXG4gICAgICAgID8gcGFyc2VNaWxsaXNlY29uZHModmFsdWUpXG4gICAgICAgIDogcGFyc2VJbnQodmFsdWUsIDEwKVxuICAgICAgLy8gbm8gemVyb3NcbiAgICAgIGlmICghdmFsdWUpIHJldHVybiBwYXJzZWRcbiAgICAgIGlmIChpc05lZ2F0aXZlICYmIH5uZWdhdGl2ZXMuaW5kZXhPZihwcm9wZXJ0eSkpIHtcbiAgICAgICAgdmFsdWUgKj0gLTFcbiAgICAgIH1cbiAgICAgIHBhcnNlZFtwcm9wZXJ0eV0gPSB2YWx1ZVxuICAgICAgcmV0dXJuIHBhcnNlZFxuICAgIH0sIHt9KVxufVxuIiwiLy9maWx0ZXIgd2lsbCByZWVtaXQgdGhlIGRhdGEgaWYgY2IoZXJyLHBhc3MpIHBhc3MgaXMgdHJ1dGh5XG5cbi8vIHJlZHVjZSBpcyBtb3JlIHRyaWNreVxuLy8gbWF5YmUgd2Ugd2FudCB0byBncm91cCB0aGUgcmVkdWN0aW9ucyBvciBlbWl0IHByb2dyZXNzIHVwZGF0ZXMgb2NjYXNpb25hbGx5XG4vLyB0aGUgbW9zdCBiYXNpYyByZWR1Y2UganVzdCBlbWl0cyBvbmUgJ2RhdGEnIGV2ZW50IGFmdGVyIGl0IGhhcyByZWNpZXZlZCAnZW5kJ1xuXG5cbnZhciB0aHJvdWdoID0gcmVxdWlyZSgndGhyb3VnaCcpXG52YXIgRGVjb2RlciA9IHJlcXVpcmUoJ3N0cmluZ19kZWNvZGVyJykuU3RyaW5nRGVjb2RlclxuXG5tb2R1bGUuZXhwb3J0cyA9IHNwbGl0XG5cbi8vVE9ETyBwYXNzIGluIGEgZnVuY3Rpb24gdG8gbWFwIGFjcm9zcyB0aGUgbGluZXMuXG5cbmZ1bmN0aW9uIHNwbGl0IChtYXRjaGVyLCBtYXBwZXIsIG9wdGlvbnMpIHtcbiAgdmFyIGRlY29kZXIgPSBuZXcgRGVjb2RlcigpXG4gIHZhciBzb0ZhciA9ICcnXG4gIHZhciBtYXhMZW5ndGggPSBvcHRpb25zICYmIG9wdGlvbnMubWF4TGVuZ3RoO1xuICB2YXIgdHJhaWxpbmcgPSBvcHRpb25zICYmIG9wdGlvbnMudHJhaWxpbmcgPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlXG4gIGlmKCdmdW5jdGlvbicgPT09IHR5cGVvZiBtYXRjaGVyKVxuICAgIG1hcHBlciA9IG1hdGNoZXIsIG1hdGNoZXIgPSBudWxsXG4gIGlmICghbWF0Y2hlcilcbiAgICBtYXRjaGVyID0gL1xccj9cXG4vXG5cbiAgZnVuY3Rpb24gZW1pdChzdHJlYW0sIHBpZWNlKSB7XG4gICAgaWYobWFwcGVyKSB7XG4gICAgICB0cnkge1xuICAgICAgICBwaWVjZSA9IG1hcHBlcihwaWVjZSlcbiAgICAgIH1cbiAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmV0dXJuIHN0cmVhbS5lbWl0KCdlcnJvcicsIGVycilcbiAgICAgIH1cbiAgICAgIGlmKCd1bmRlZmluZWQnICE9PSB0eXBlb2YgcGllY2UpXG4gICAgICAgIHN0cmVhbS5xdWV1ZShwaWVjZSlcbiAgICB9XG4gICAgZWxzZVxuICAgICAgc3RyZWFtLnF1ZXVlKHBpZWNlKVxuICB9XG5cbiAgZnVuY3Rpb24gbmV4dCAoc3RyZWFtLCBidWZmZXIpIHtcbiAgICB2YXIgcGllY2VzID0gKChzb0ZhciAhPSBudWxsID8gc29GYXIgOiAnJykgKyBidWZmZXIpLnNwbGl0KG1hdGNoZXIpXG4gICAgc29GYXIgPSBwaWVjZXMucG9wKClcblxuICAgIGlmIChtYXhMZW5ndGggJiYgc29GYXIubGVuZ3RoID4gbWF4TGVuZ3RoKVxuICAgICAgcmV0dXJuIHN0cmVhbS5lbWl0KCdlcnJvcicsIG5ldyBFcnJvcignbWF4aW11bSBidWZmZXIgcmVhY2hlZCcpKVxuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwaWVjZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBwaWVjZSA9IHBpZWNlc1tpXVxuICAgICAgZW1pdChzdHJlYW0sIHBpZWNlKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0aHJvdWdoKGZ1bmN0aW9uIChiKSB7XG4gICAgbmV4dCh0aGlzLCBkZWNvZGVyLndyaXRlKGIpKVxuICB9LFxuICBmdW5jdGlvbiAoKSB7XG4gICAgaWYoZGVjb2Rlci5lbmQpXG4gICAgICBuZXh0KHRoaXMsIGRlY29kZXIuZW5kKCkpXG4gICAgaWYodHJhaWxpbmcgJiYgc29GYXIgIT0gbnVsbClcbiAgICAgIGVtaXQodGhpcywgc29GYXIpXG4gICAgdGhpcy5xdWV1ZShudWxsKVxuICB9KVxufVxuIiwidmFyIFN0cmVhbSA9IHJlcXVpcmUoJ3N0cmVhbScpXG5cbi8vIHRocm91Z2hcbi8vXG4vLyBhIHN0cmVhbSB0aGF0IGRvZXMgbm90aGluZyBidXQgcmUtZW1pdCB0aGUgaW5wdXQuXG4vLyB1c2VmdWwgZm9yIGFnZ3JlZ2F0aW5nIGEgc2VyaWVzIG9mIGNoYW5naW5nIGJ1dCBub3QgZW5kaW5nIHN0cmVhbXMgaW50byBvbmUgc3RyZWFtKVxuXG5leHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSB0aHJvdWdoXG50aHJvdWdoLnRocm91Z2ggPSB0aHJvdWdoXG5cbi8vY3JlYXRlIGEgcmVhZGFibGUgd3JpdGFibGUgc3RyZWFtLlxuXG5mdW5jdGlvbiB0aHJvdWdoICh3cml0ZSwgZW5kLCBvcHRzKSB7XG4gIHdyaXRlID0gd3JpdGUgfHwgZnVuY3Rpb24gKGRhdGEpIHsgdGhpcy5xdWV1ZShkYXRhKSB9XG4gIGVuZCA9IGVuZCB8fCBmdW5jdGlvbiAoKSB7IHRoaXMucXVldWUobnVsbCkgfVxuXG4gIHZhciBlbmRlZCA9IGZhbHNlLCBkZXN0cm95ZWQgPSBmYWxzZSwgYnVmZmVyID0gW10sIF9lbmRlZCA9IGZhbHNlXG4gIHZhciBzdHJlYW0gPSBuZXcgU3RyZWFtKClcbiAgc3RyZWFtLnJlYWRhYmxlID0gc3RyZWFtLndyaXRhYmxlID0gdHJ1ZVxuICBzdHJlYW0ucGF1c2VkID0gZmFsc2VcblxuLy8gIHN0cmVhbS5hdXRvUGF1c2UgICA9ICEob3B0cyAmJiBvcHRzLmF1dG9QYXVzZSAgID09PSBmYWxzZSlcbiAgc3RyZWFtLmF1dG9EZXN0cm95ID0gIShvcHRzICYmIG9wdHMuYXV0b0Rlc3Ryb3kgPT09IGZhbHNlKVxuXG4gIHN0cmVhbS53cml0ZSA9IGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgd3JpdGUuY2FsbCh0aGlzLCBkYXRhKVxuICAgIHJldHVybiAhc3RyZWFtLnBhdXNlZFxuICB9XG5cbiAgZnVuY3Rpb24gZHJhaW4oKSB7XG4gICAgd2hpbGUoYnVmZmVyLmxlbmd0aCAmJiAhc3RyZWFtLnBhdXNlZCkge1xuICAgICAgdmFyIGRhdGEgPSBidWZmZXIuc2hpZnQoKVxuICAgICAgaWYobnVsbCA9PT0gZGF0YSlcbiAgICAgICAgcmV0dXJuIHN0cmVhbS5lbWl0KCdlbmQnKVxuICAgICAgZWxzZVxuICAgICAgICBzdHJlYW0uZW1pdCgnZGF0YScsIGRhdGEpXG4gICAgfVxuICB9XG5cbiAgc3RyZWFtLnF1ZXVlID0gc3RyZWFtLnB1c2ggPSBmdW5jdGlvbiAoZGF0YSkge1xuLy8gICAgY29uc29sZS5lcnJvcihlbmRlZClcbiAgICBpZihfZW5kZWQpIHJldHVybiBzdHJlYW1cbiAgICBpZihkYXRhID09PSBudWxsKSBfZW5kZWQgPSB0cnVlXG4gICAgYnVmZmVyLnB1c2goZGF0YSlcbiAgICBkcmFpbigpXG4gICAgcmV0dXJuIHN0cmVhbVxuICB9XG5cbiAgLy90aGlzIHdpbGwgYmUgcmVnaXN0ZXJlZCBhcyB0aGUgZmlyc3QgJ2VuZCcgbGlzdGVuZXJcbiAgLy9tdXN0IGNhbGwgZGVzdHJveSBuZXh0IHRpY2ssIHRvIG1ha2Ugc3VyZSB3ZSdyZSBhZnRlciBhbnlcbiAgLy9zdHJlYW0gcGlwZWQgZnJvbSBoZXJlLlxuICAvL3RoaXMgaXMgb25seSBhIHByb2JsZW0gaWYgZW5kIGlzIG5vdCBlbWl0dGVkIHN5bmNocm9ub3VzbHkuXG4gIC8vYSBuaWNlciB3YXkgdG8gZG8gdGhpcyBpcyB0byBtYWtlIHN1cmUgdGhpcyBpcyB0aGUgbGFzdCBsaXN0ZW5lciBmb3IgJ2VuZCdcblxuICBzdHJlYW0ub24oJ2VuZCcsIGZ1bmN0aW9uICgpIHtcbiAgICBzdHJlYW0ucmVhZGFibGUgPSBmYWxzZVxuICAgIGlmKCFzdHJlYW0ud3JpdGFibGUgJiYgc3RyZWFtLmF1dG9EZXN0cm95KVxuICAgICAgcHJvY2Vzcy5uZXh0VGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgIHN0cmVhbS5kZXN0cm95KClcbiAgICAgIH0pXG4gIH0pXG5cbiAgZnVuY3Rpb24gX2VuZCAoKSB7XG4gICAgc3RyZWFtLndyaXRhYmxlID0gZmFsc2VcbiAgICBlbmQuY2FsbChzdHJlYW0pXG4gICAgaWYoIXN0cmVhbS5yZWFkYWJsZSAmJiBzdHJlYW0uYXV0b0Rlc3Ryb3kpXG4gICAgICBzdHJlYW0uZGVzdHJveSgpXG4gIH1cblxuICBzdHJlYW0uZW5kID0gZnVuY3Rpb24gKGRhdGEpIHtcbiAgICBpZihlbmRlZCkgcmV0dXJuXG4gICAgZW5kZWQgPSB0cnVlXG4gICAgaWYoYXJndW1lbnRzLmxlbmd0aCkgc3RyZWFtLndyaXRlKGRhdGEpXG4gICAgX2VuZCgpIC8vIHdpbGwgZW1pdCBvciBxdWV1ZVxuICAgIHJldHVybiBzdHJlYW1cbiAgfVxuXG4gIHN0cmVhbS5kZXN0cm95ID0gZnVuY3Rpb24gKCkge1xuICAgIGlmKGRlc3Ryb3llZCkgcmV0dXJuXG4gICAgZGVzdHJveWVkID0gdHJ1ZVxuICAgIGVuZGVkID0gdHJ1ZVxuICAgIGJ1ZmZlci5sZW5ndGggPSAwXG4gICAgc3RyZWFtLndyaXRhYmxlID0gc3RyZWFtLnJlYWRhYmxlID0gZmFsc2VcbiAgICBzdHJlYW0uZW1pdCgnY2xvc2UnKVxuICAgIHJldHVybiBzdHJlYW1cbiAgfVxuXG4gIHN0cmVhbS5wYXVzZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZihzdHJlYW0ucGF1c2VkKSByZXR1cm5cbiAgICBzdHJlYW0ucGF1c2VkID0gdHJ1ZVxuICAgIHJldHVybiBzdHJlYW1cbiAgfVxuXG4gIHN0cmVhbS5yZXN1bWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYoc3RyZWFtLnBhdXNlZCkge1xuICAgICAgc3RyZWFtLnBhdXNlZCA9IGZhbHNlXG4gICAgICBzdHJlYW0uZW1pdCgncmVzdW1lJylcbiAgICB9XG4gICAgZHJhaW4oKVxuICAgIC8vbWF5IGhhdmUgYmVjb21lIHBhdXNlZCBhZ2FpbixcbiAgICAvL2FzIGRyYWluIGVtaXRzICdkYXRhJy5cbiAgICBpZighc3RyZWFtLnBhdXNlZClcbiAgICAgIHN0cmVhbS5lbWl0KCdkcmFpbicpXG4gICAgcmV0dXJuIHN0cmVhbVxuICB9XG4gIHJldHVybiBzdHJlYW1cbn1cblxuIiwiLy8gUmV0dXJucyBhIHdyYXBwZXIgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgd3JhcHBlZCBjYWxsYmFja1xuLy8gVGhlIHdyYXBwZXIgZnVuY3Rpb24gc2hvdWxkIGRvIHNvbWUgc3R1ZmYsIGFuZCByZXR1cm4gYVxuLy8gcHJlc3VtYWJseSBkaWZmZXJlbnQgY2FsbGJhY2sgZnVuY3Rpb24uXG4vLyBUaGlzIG1ha2VzIHN1cmUgdGhhdCBvd24gcHJvcGVydGllcyBhcmUgcmV0YWluZWQsIHNvIHRoYXRcbi8vIGRlY29yYXRpb25zIGFuZCBzdWNoIGFyZSBub3QgbG9zdCBhbG9uZyB0aGUgd2F5LlxubW9kdWxlLmV4cG9ydHMgPSB3cmFwcHlcbmZ1bmN0aW9uIHdyYXBweSAoZm4sIGNiKSB7XG4gIGlmIChmbiAmJiBjYikgcmV0dXJuIHdyYXBweShmbikoY2IpXG5cbiAgaWYgKHR5cGVvZiBmbiAhPT0gJ2Z1bmN0aW9uJylcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCduZWVkIHdyYXBwZXIgZnVuY3Rpb24nKVxuXG4gIE9iamVjdC5rZXlzKGZuKS5mb3JFYWNoKGZ1bmN0aW9uIChrKSB7XG4gICAgd3JhcHBlcltrXSA9IGZuW2tdXG4gIH0pXG5cbiAgcmV0dXJuIHdyYXBwZXJcblxuICBmdW5jdGlvbiB3cmFwcGVyKCkge1xuICAgIHZhciBhcmdzID0gbmV3IEFycmF5KGFyZ3VtZW50cy5sZW5ndGgpXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcmdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBhcmdzW2ldID0gYXJndW1lbnRzW2ldXG4gICAgfVxuICAgIHZhciByZXQgPSBmbi5hcHBseSh0aGlzLCBhcmdzKVxuICAgIHZhciBjYiA9IGFyZ3NbYXJncy5sZW5ndGgtMV1cbiAgICBpZiAodHlwZW9mIHJldCA9PT0gJ2Z1bmN0aW9uJyAmJiByZXQgIT09IGNiKSB7XG4gICAgICBPYmplY3Qua2V5cyhjYikuZm9yRWFjaChmdW5jdGlvbiAoaykge1xuICAgICAgICByZXRba10gPSBjYltrXVxuICAgICAgfSlcbiAgICB9XG4gICAgcmV0dXJuIHJldFxuICB9XG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGV4dGVuZFxuXG52YXIgaGFzT3duUHJvcGVydHkgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuXG5mdW5jdGlvbiBleHRlbmQodGFyZ2V0KSB7XG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXVxuXG4gICAgICAgIGZvciAodmFyIGtleSBpbiBzb3VyY2UpIHtcbiAgICAgICAgICAgIGlmIChoYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0YXJnZXRcbn1cbiIsImltcG9ydCBBV1MgPSByZXF1aXJlKCdhd3Mtc2RrJyk7XHJcbmltcG9ydCB7IEhhbmRsZXIsIENvbnRleHQsIENhbGxiYWNrIH0gZnJvbSAnYXdzLWxhbWJkYSc7XHJcbmltcG9ydCBwZyA9IHJlcXVpcmUoJ3BnJyk7XHJcbmltcG9ydCBmcyA9IHJlcXVpcmUoJ2ZzJyk7XHJcbmltcG9ydCBnbG9iID0gcmVxdWlyZSgnZ2xvYicpO1xyXG5cclxuY29uc3QgaW5pdGlhbGl6ZURhdGFiYXNlOiBIYW5kbGVyID0gYXN5bmMgKGV2ZW50OiBhbnksIGNvbnRleHQ6IENvbnRleHQsIGNhbGxiYWNrOiBDYWxsYmFjaykgPT4ge1xyXG4gICAgdHJ5IHtcclxuXHJcbiAgICAgICAgLy8gZ2V0IGEgREIgY2xpZW50IHRvIHJ1biBvdXIgcXVlcmllcyB3aXRoXHJcbiAgICAgICAgdmFyIGRiQ2xpZW50ID0gbmV3IHBnLkNsaWVudCgpO1xyXG5cclxuICAgICAgICAvL29wZW4gdGhlIGNvbm5lY3Rpb25cclxuICAgICAgICBhd2FpdCBkYkNsaWVudC5jb25uZWN0KCk7XHJcblxyXG4gICAgICAgIC8vZ3JhYiB0aGUgZW52IHZhcnMgd2UnbGwgbmVlZCBmb3IgdGhlIHVzZXJuYW1lcyBhbmQgcGFzc3dvcmRzIHRvIGNyZWF0ZVxyXG4gICAgICAgIGxldCBsYW1iZGFfdXNlcm5hbWUgPSBwcm9jZXNzLmVudi5MQU1CREFQR1VTRVI7XHJcbiAgICAgICAgbGV0IGxhbWJkYV9wYXNzd29yZCA9IHByb2Nlc3MuZW52LkxBTUJEQVBHUEFTU1dPUkQ7XHJcbiAgICAgICAgbGV0IHJlYWRvbmx5X3VzZXJuYW1lID0gcHJvY2Vzcy5lbnYuUkVBRE9OTFlQR1VTRVI7XHJcbiAgICAgICAgbGV0IHJlYWRvbmx5X3Bhc3N3b3JkID0gcHJvY2Vzcy5lbnYuUkVBRE9OTFlQQVNTV09SRDtcclxuICAgICAgICBsZXQgY3VycmVudF92ZXJzaW9uID0gcHJvY2Vzcy5lbnYuQ1VSUkVOVFZFUlNJT047XHJcblxyXG4gICAgICAgIC8vIGhvdyBJIGRlYnVnIC8gd29yayBvbiB0aGlzOiBcclxuXHJcbiAgICAgICAgLy8gVGVycmFmb3JtOiBcclxuICAgICAgICAvLyAgIEkgdW5jb21tZW50ZWQgdGhlIGxhbWJkYSBpbnZvY2F0aW9uIGluIHRlcnJhZm9ybSB0byBwcmV2ZW50IHJ1bm5pbmcgdGhpcyBjb2RlXHJcbiAgICAgICAgLy8gICBJIGhhZCB0byB0ZXJyYWZvcm0gYXBwbHkgZXZlcnl0aGluZywgYXMgdGhlcmUgYXJlIHRoaW5ncyBuZWNlc3NhcnkgZm9yIGNsb3Vkd2F0Y2ggbG9ncyBhbmQgc3R1ZmYgdGhhdCBhcmUgbm90IG9idmlvdXMgaWYgeW91IGp1c3QgLXRhcmdldCB0aGlzIGZ1bmN0aW9uXHJcblxyXG4gICAgICAgIC8vIGNvbW1hbmQgbGluZXMgdG8gYnVpbGQgYW5kIHVwbG9hZCBuZXcgemlwOiBcclxuICAgICAgICAvLyAgIG5wbSBydW4gYnVpbGQgICAgXCJydW4gdGhlIHNjcmlwdCBjYWxsZWQgYnVpbGRcIiAuLiBjcmVhdGVzIGEgbmV3IC56aXAgZmlsZVxyXG4gICAgICAgIC8vICAgYXdzIGxhbWJkYSB1cGRhdGUtZnVuY3Rpb24tY29kZSAtLWZ1bmN0aW9uLW5hbWUgZGV2ZWxvcG1lbnQtdGYtd2F6ZS1kYi1pbml0aWFsaXplIC0tcmVnaW9uIHVzLXdlc3QtMiAtLXppcC1maWxlIGZpbGViOi8vLi4vd2F6ZS1kYi1pbml0aWFsaXplLnppcFxyXG5cclxuICAgICAgICAvLyB1c2UgY29kZSBsaWtlOiBcclxuICAgICAgICAvLyAgIGNvbnNvbGUubG9nKFwic2NoZW1hcmVzdWx0OiBcIitKU09OLnN0cmluZ2lmeShzY2hlbWFSZXN1bHQpKTtcclxuXHJcbiAgICAgICAgLy8gbmV3IGNvZGU6IFxyXG5cclxuICAgICAgICAvLyAxLiBJZiBzY2hlbWEgZG9lc24ndCBleGlzdCwgcnVuIHRoZSBzY2hlbWEgc2NyaXB0LiBcclxuICAgICAgICAvLyAgICBQcm9ibGVtOiBWZXJzaW9uIDIgZGlkbid0IGNyZWF0ZSByZWFkb25seSBwYXNzd29yZCBcclxuICAgICAgICAvLyAgICBDaGFuZ2UgdG86IEFsd2F5cyBydW4gc2NoZW1hIGNyZWF0ZSBzY3JpcHQsIGFuZCB1c2UgXCJpZiBub3QgZXhpc3RcIiBhbmQgdXBkYXRlIHRoZSBwYXNzd29yZC4gICAgXHJcbiAgICAgICAgLy8gICAgRXZlcnl0aGluZyBlbHNlIHdpbGwgYmUgdXBkYXRlZCB0b28sIHNvIGJldHRlciB1cGRhdGUgZGF0YWJhc2UgdG8gbWF0Y2guIFxyXG5cclxuICAgICAgICAvLyAyLiBydW4gdGhlIGNyZWF0ZSBzY3JpcHRcclxuICAgICAgICAvLyAgICBQcm9ibGVtOiBOZXcgVmVyc2lvbiAzIGhhcyBhbGwgdGhlIHRoaW5ncyBhbHJlYWR5IGluIGl0XHJcbiAgICAgICAgLy8gICAgaWYgd2UgaGF2ZSBpbmZyYXN0cnVjdHVyZSBzZXQgdXAgYW5kIHJ1biB0aGlzIHRlcnJhZm9ybSwgaXRzIGdvaW5nIHRvIGludm9rZSB0aGlzIGxhbWJkYVxyXG4gICAgICAgIC8vICAgIFRoZXJlZm9yZSBhIGxvdCBvZiB0aGluZ3MgYWxyZWFkeSBleGlzdCwgYW5kIGFyZSBnb2luZyB0byBmYWlsXHJcbiAgICAgICAgLy8gICAgU29sdXRpb246ICBtYWtlIHRoZSBtYWluIGNyZWF0ZSBzY3JpcHQgXCJpZiBub3QgZXhpc3RzXCIgYXMgd2VsbFxyXG5cclxuICAgICAgICAvLyAzLiBSdW4gYWRkaXRpb25hbCB1cGRhdGUgc2NyaXB0c1xyXG4gICAgICAgIC8vICAgIC4uLiBcclxuICAgICAgICAvLyAgIFxyXG5cclxuICAgICAgICAvLyBTbyBwcmV0dHkgbXVjaCwgd2hhdCB0aGlzIGlzIGxvb2tpbmcgbGlrZTogXHJcbiAgICAgICAgLy8gYSkgYWx3YXlzIGNyZWF0ZSBpZiBub3QgZXhpc3RzXHJcbiAgICAgICAgLy8gYikgZm9yY2UgdXBkYXRlIG9mIHBhc3N3b3JkcyBldmVyeSB0aW1lIChyZXdyaXRlIGNyZWF0ZSBzY2hlbWEgc2NyaXB0KVxyXG4gICAgICAgIC8vIGMpIHJlcHJlc2VudCB2ZXJzaW9uIDIgYXMgaXRzIG93biBzY3JpcHQuIFxyXG4gICAgICAgIC8vIGQpIGFsd2F5cyBhcHBseSBhbGwgc2NyaXB0cyBpbiBhIHBhcnRpY3VsYXIgb3JkZXJcclxuXHJcbiAgICAgICAgLyogICAgICAvL2NoZWNrIGlmIHRoZSBzY2hlbWEgYWxyZWFkeSBleGlzdHMsIGFuZCBpZiBzbywgY2hlY2sgdGhlIHZlcnNpb24gaW5zdGFsbGVkIGFnYWluc3Qgd2hhdCB3ZSdyZSB0cnlpbmcgdG8gaW5zdGFsbFxyXG4gICAgICAgICAgICAgIC8vaWYgdmVyc2lvbnMgYXJlIHNhbWUsIGp1c3QgbG9nIGluZm8gbWVzc2FnZSBhbmQgZXhpdCwgb3RoZXJ3aXNlIGxvZyB3YXJuaW5nIGFuZCBleGl0XHJcbiAgICAgICAgICAgICAgbGV0IHNjaGVtYVJlc3VsdCA9IGF3YWl0IGRiQ2xpZW50LnF1ZXJ5KFwiU0VMRUNUIDEgRlJPTSBpbmZvcm1hdGlvbl9zY2hlbWEuc2NoZW1hdGEgV0hFUkUgc2NoZW1hX25hbWUgPSAnd2F6ZSc7XCIpO1xyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic2NoZW1hcmVzdWx0OiBcIitKU09OLnN0cmluZ2lmeShzY2hlbWFSZXN1bHQpKTtcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICBpZiAoc2NoZW1hUmVzdWx0LnJvd0NvdW50ID4gMCl7XHJcbiAgICAgICAgICAgICAgICAgIC8vdGhlIHNjaGVtYSBleGlzdHMsIHNlZSBpZiB3ZSBoYXZlIGEgdmVyc2lvbiB0YWJsZSAodGhhdCBnZXRzIGl0cyBvd24gc3BlY2lhbCBlcnJvcilcclxuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJTQ0hFTUEgZXhpc3RzLCB2ZXJpZnlpbmcgdmVyc2lvbnNcIik7XHJcbiAgICAgIFxyXG4gICAgICAgICAgICAgICAgICBsZXQgdmVyc2lvblRhYmxlRXhpc3RzUmVzdWx0ID0gYXdhaXQgZGJDbGllbnQucXVlcnkoXCJTRUxFQ1QgMSBGUk9NIGluZm9ybWF0aW9uX3NjaGVtYS50YWJsZXMgV0hFUkUgdGFibGVfc2NoZW1hID0gJ3dhemUnIEFORCB0YWJsZV9uYW1lID0gJ2FwcGxpY2F0aW9uX3ZlcnNpb24nO1wiKVxyXG4gICAgICAgICAgICAgICAgICBpZih2ZXJzaW9uVGFibGVFeGlzdHNSZXN1bHQucm93Q291bnQgPT09IDApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy90aGVyZSBJUyBOTyB2ZXJzaW9uIHRhYmxlLCB3aGljaCBpcyBhIHByb2JsZW1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1ZlcnNpb24gdGFibGUgbm90IGZvdW5kJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyByZXNwb25zZTogZm9ybWF0VGVycmFmb3JtV2FybmluZygnVmVyc2lvbiB0YWJsZSBub3QgZm91bmQsIHBsZWFzZSB2ZXJpZnkgU1FMIHNjaGVtYSBpcyB1cCB0byBkYXRlLicpIH07XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIC8vdmVyc2lvbiB0YWJsZSBmb3VuZCwgc28gd2UgbmVlZCB0byBtYWtlIHN1cmUgaXQgaXMgdGhlIHNhbWUgdmVyc2lvbiBhcyB3aGF0IHdlIHdvdWxkIGJlIHRyeWluZyB0byBpbnN0YWxsXHJcbiAgICAgICAgICAgICAgICAgIGxldCB2ZXJzaW9uQ2hlY2tSZXN1bHQgPSBhd2FpdCBkYkNsaWVudC5xdWVyeShcIlNFTEVDVCB2ZXJzaW9uX251bWJlciBmcm9tIHdhemUuYXBwbGljYXRpb25fdmVyc2lvbiBPUkRFUiBCWSBpbnN0YWxsX2RhdGUgREVTQyBMSU1JVCAxXCIpO1xyXG4gICAgICAgICAgICAgICAgICAvL2lmIHdlIGRpZG4ndCBnZXQgYSByZXN1bHQsIG9yIGdldCBhIHJlc3VsdCB0aGF0IGlzbid0IGFuIGV4YWN0IG1hdGNoLCB3YXJuIGFib3V0IGl0XHJcbiAgICAgICAgICAgICAgICAgIGlmKHZlcnNpb25DaGVja1Jlc3VsdC5yb3dDb3VudCA9PT0gMCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdObyB2ZXJzaW9uIHJlY29yZHMgZm91bmQnKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHJlc3BvbnNlOiBmb3JtYXRUZXJyYWZvcm1XYXJuaW5nKCdObyB2ZXJzaW9uIHJlY29yZHMgZm91bmQsIHBsZWFzZSB2ZXJpZnkgU1FMIHNjaGVtYSBpcyB1cCB0byBkYXRlLicpIH07XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgZWxzZSBpZih2ZXJzaW9uQ2hlY2tSZXN1bHQucm93c1swXS52ZXJzaW9uX251bWJlciAhPT0gY3VycmVudF92ZXJzaW9uKXtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1ZlcnNpb24gbWlzbWF0Y2gnKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHJlc3BvbnNlOiBmb3JtYXRUZXJyYWZvcm1XYXJuaW5nKCdWZXJzaW9uIG1pc21hdGNoLCBwbGVhc2UgdmVyaWZ5IFNRTCBzY2hlbWEgaXMgdXAgdG8gZGF0ZS4nKSB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgICAvL3ZlcnNpb25zIG1hdGNoIHVwLCBzbyBqdXN0IHJldHVybiBhIG5vdGljZSB0aGF0IG5vdGhpbmcgbmVlZGVkIHRvIGJlIGRvbmVcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdWZXJzaW9ucyBtYXRjaCwgbm8gREIgY2hhbmdlcyBuZWVkZWQnKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHJlc3BvbnNlOiBcIkRhdGFiYXNlIGlzIHVwLXRvLWRhdGVcIiB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAqL1xyXG5cclxuICAgICAgICB2YXIgZmlsZU5hbWVzID0gZ2xvYi5zeW5jKFwiKi5zcWxcIiwge30pOyAgLy8gc29ydCBkZWZhdWx0cyB0byB0cnVlOyBcclxuXHJcbiAgICAgICAgZm9yIChsZXQgZmlsZU5hbWUgb2YgZmlsZU5hbWVzKSB7XHJcbiAgICAgICAgICAgIGlmICghZmlsZU5hbWUubWF0Y2goL15cXGQvKSkgeyBcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU2tpcHBpbmcgXCIrZmlsZU5hbWUrXCIgYmVjYXVzZSBpdCBkb2Vzbid0IHN0YXJ0IHdpdGggYSBkaWdpdFwiKTtcclxuICAgICAgICAgICAgICAgIGNvbnRpbnVlOyBcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IGZpbGVDb250ZW50ID0gZnMucmVhZEZpbGVTeW5jKGZpbGVOYW1lLCAndXRmLTgnKTtcclxuICAgICAgICAgICAgLy8ganVzdCBpbiBjYXNlIGl0IHdhcyBzYXZlZCBhcyBVVEY4IEJPTSAuLiBcclxuICAgICAgICAgICAgZmlsZUNvbnRlbnQgPSBmaWxlQ29udGVudC5yZXBsYWNlKC9eXFx1RkVGRi8sICcnKTtcclxuXHJcbiAgICAgICAgICAgIC8vbm93IHdlIG5lZWQgdG8gcmVwbGFjZSB0aGUgcGxhY2Vob2xkZXJzXHJcbiAgICAgICAgICAgIC8vd2UnbGwgYWxzbyBkbyBhIHF1aWNrIGNoZWNrIHRoYXQgdGhleSBhY3R1YWxseSBleGlzdCwgYW5kIHRocm93IGFuIGVycm9yIGlmIG5vdCwganVzdCBpbiBjYXNlIHNvbWVvbmUgYnJva2UgdGhlIHNjcmlwdFxyXG4gICAgICAgICAgICBjb25zdCBsYW1iZGFVc2VyUGxhY2Vob2xkZXIgPSAnTEFNQkRBX1JPTEVfTkFNRV9QTEFDRUhPTERFUic7XHJcbiAgICAgICAgICAgIGNvbnN0IGxhbWJkYVBhc3NQbGFjZWhvbGRlciA9ICdMQU1CREFfUk9MRV9QQVNTV09SRF9QTEFDRUhPTERFUic7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlYWRvbmx5VXNlclBsYWNlaG9sZGVyID0gJ1JFQURPTkxZX1JPTEVfTkFNRV9QTEFDRUhPTERFUic7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlYWRvbmx5UGFzc1BsYWNlaG9sZGVyID0gJ1JFQURPTkxZX1JPTEVfUEFTU1dPUkRfUExBQ0VIT0xERVInO1xyXG5cclxuICAgICAgICAgICAgLy9ydW4gYWxsIHRoZSByZXBsYWNlbWVudHNcclxuICAgICAgICAgICAgbGV0IHJlcGxhY2VkRmlsZUNvbnRlbnQgPSBmaWxlQ29udGVudC5yZXBsYWNlKG5ldyBSZWdFeHAobGFtYmRhVXNlclBsYWNlaG9sZGVyLCAnZycpLCBsYW1iZGFfdXNlcm5hbWUpXHJcbiAgICAgICAgICAgICAgICAucmVwbGFjZShuZXcgUmVnRXhwKGxhbWJkYVBhc3NQbGFjZWhvbGRlciwgJ2cnKSwgbGFtYmRhX3Bhc3N3b3JkKVxyXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UobmV3IFJlZ0V4cChyZWFkb25seVVzZXJQbGFjZWhvbGRlciwgJ2cnKSwgcmVhZG9ubHlfdXNlcm5hbWUpXHJcbiAgICAgICAgICAgICAgICAucmVwbGFjZShuZXcgUmVnRXhwKHJlYWRvbmx5UGFzc1BsYWNlaG9sZGVyLCAnZycpLCByZWFkb25seV9wYXNzd29yZCk7XHJcblxyXG4gICAgICAgICAgICBsZXQgd2FzUmVwbGFjZWQgPSBcIlwiO1xyXG4gICAgICAgICAgICBpZiAoZmlsZUNvbnRlbnQgIT0gcmVwbGFjZWRGaWxlQ29udGVudCkgeyBcclxuICAgICAgICAgICAgICAgIHdhc1JlcGxhY2VkID0gXCIgKHdpdGggcmVwbGFjZW1lbnRzKVwiO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvL2V4ZWN1dGUgdGhlIHNxbCFcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJFeGVjdXRpbmcgXCIgKyBmaWxlTmFtZSArIHdhc1JlcGxhY2VkKTtcclxuICAgICAgICAgICAgbGV0IHJlc3VsdHMgPSBhd2FpdCBkYkNsaWVudC5xdWVyeShyZXBsYWNlZEZpbGVDb250ZW50KTtcclxuICAgICAgICAgICAgZm9yKGxldCBpbmRleCBpbiByZXN1bHRzIGFzIGFueSkgeyBcclxuICAgICAgICAgICAgICAgIGxldCByZXN1bHQgPSAocmVzdWx0cyBhcyBhbnkpW2luZGV4XTtcclxuICAgICAgICAgICAgICAgIC8vIGhvcGVmdWxseSB0aGlzIGlzIGVub3VnaCB0byBmaWd1cmUgb3V0IHdoaWNoIHN0YXRlbWVudCBpcyBhIHByb2JsZW0gaW4gdGhlIGZ1dHVyZVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5kZXggKyBcIi4gXCIrcmVzdWx0LmNvbW1hbmQgK1wiIFwiKyhyZXN1bHQucm93Q291bnQgPT09IG51bGwgPyBcIlwiIDogcmVzdWx0LnJvd0NvdW50KSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy9yZXR1cm4gc3VjY2Vzc1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdEYXRhYmFzZSBpbnRpYWxpemF0aW9uIHN1Y2NlZWRlZCcpO1xyXG4gICAgICAgIHJldHVybiB7IHJlc3BvbnNlOiBcIkRhdGFiYXNlIGludGlhbGl6YXRpb24gc3VjY2VlZGVkXCIgfVxyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICBjYWxsYmFjayhlcnIpO1xyXG4gICAgICAgIHJldHVybiBlcnI7XHJcbiAgICB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICAvLyBDTE9TRSBUSEFUIENMSUVOVCFcclxuICAgICAgICBhd2FpdCBkYkNsaWVudC5lbmQoKTtcclxuICAgIH1cclxufTtcclxuXHJcbmV4cG9ydCB7IGluaXRpYWxpemVEYXRhYmFzZSB9XHJcblxyXG4vL2J1aWxkIGEgdGVycmFmb3JtLW91dHB1dC1mcmllbmRseSB3YXJuaW5nIG1lc3NhZ2VcclxuZnVuY3Rpb24gZm9ybWF0VGVycmFmb3JtV2FybmluZyh3YXJuaW5nTWVzc2FnZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIHJldHVybiBgXHJcbiAgICBcclxuICAgIFdBUk5JTkchICoqKioqKioqKioqKioqKioqKioqKiBXQVJOSU5HISAqKioqKioqKioqKioqKioqKioqKiogV0FSTklORyFcclxuICAgICR7d2FybmluZ01lc3NhZ2V9XHJcbiAgICBXQVJOSU5HISAqKioqKioqKioqKioqKioqKioqKiogV0FSTklORyEgKioqKioqKioqKioqKioqKioqKioqIFdBUk5JTkchXHJcblxyXG4gICAgYDtcclxufVxyXG5cclxuLy8gZm9yIHJ1bm5pbmcgbG9jYWxseVxyXG5jb25zb2xlLmxvZyhcInRlc3QgOTo1M2FtXCIpO1xyXG5pbml0aWFsaXplRGF0YWJhc2UobnVsbCwgbnVsbCwgKHIpID0+IGNvbnNvbGUubG9nKFwiY2FsbGJhY2s6IFwiICsgSlNPTi5zdHJpbmdpZnkocikpKTtcclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXNzZXJ0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNyeXB0b1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJkbnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZXZlbnRzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImZzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5ldFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJwYXRoXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInBnLW5hdGl2ZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzdHJlYW1cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3RyaW5nX2RlY29kZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidGxzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInVybFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJ1dGlsXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=